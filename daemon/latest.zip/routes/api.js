const { requestApi } = require('../lib/apiBridge')

module.exports = [
  {
    method: 'post',
    path: '/api/jsos',
    handler: async (req, res) => {
      const { type, payload } = req.body
      if (!type) {
        return res.status(400).json({ ok: false, error: 'Missing type' })
      }

      try {
        const result = await requestApi(type, payload)
        res.json({ ok: true, id: req.body.id, result })
      } catch (error) {
        res.status(500).json({ ok: false, error: error.message })
      }
    },
  },
]
