#!/usr/bin/env node

const express = require('express')
const debug = require('./lib/debug')
const { registerRoutes } = require('./lib/router')
const { initApiBridge } = require('./lib/apiBridge')
const routes = require('./routes')
const { execSync } = require('child_process')

// Ensure bin files are executable (snapshot may not preserve permissions)
try {
  execSync('chmod +x ./bin/* && chmod +x ./node_modules/.bin/*')
} catch {}

// Configuration
const PORT = process.env.DAEMON_PORT || 1993

// Create Express app
const app = express()

// Middleware
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// CORS
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200)
  }
  next()
})

// Request logging
app.use((req, res, next) => {
  debug.debug(`${req.method} ${req.path}`)
  next()
})

// Register routes
registerRoutes(app, routes)

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' })
})

// Error handler
app.use((err, req, res, next) => {
  debug.error('Server error:', err)
  res.status(500).json({ error: 'Internal server error' })
})

// Start server
const server = app.listen(PORT, () => {
  debug.always(`JSOS daemon listening on port ${PORT}`)

  // Initialize API bridge (stdin listener for main window responses)
  initApiBridge()

  const { sendLifecycleEvent } = require('./lib/rpc')
  sendLifecycleEvent('daemon.started', { port: PORT })
})

// Graceful shutdown
function shutdown(signal) {
  debug.always(`Received ${signal}, shutting down...`)
  const { sendLifecycleEvent } = require('./lib/rpc')
  sendLifecycleEvent('daemon.stopped', { reason: signal })

  server.close(() => {
    process.exit(0)
  })

  // Force exit after 3 seconds
  setTimeout(() => {
    process.exit(1)
  }, 3000)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))

process.on('uncaughtException', (err) => {
  debug.error('Uncaught Exception:', err)
  const { sendLifecycleEvent } = require('./lib/rpc')
  sendLifecycleEvent('daemon.error', { error: err.message, stack: err.stack })
  process.exit(1)
})

// Heartbeat
setInterval(() => {
  const { sendLifecycleEvent } = require('./lib/rpc')
  sendLifecycleEvent('daemon.heartbeat', { timestamp: Date.now() })
}, 30000)
