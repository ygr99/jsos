/**
 * 随机盒子 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 抓取代理。
 * 抓取必须放服务端：浏览器直连目标站会被 CORS 拦死。
 *
 * 站点配置硬编码在 lib/sites.js，不支持运行时增删改——这是自用随机入口，
 * 不是配置工具。界面上可改的是每个站点的启用开关与置顶（存在 data/state.json）。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { SITES } from './lib/sites.js';
import { getSource, listKinds } from './lib/registry.js';
import {
  loadState, setEnabled, setPinned, clearCache,
} from './lib/store.js';
import { CrawlError, fetchPageItems, setProxyConfig, getProxyConfig } from './lib/crawl.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

const ok = (res, data) => res.json({ ok: true, ...data });
const fail = (res, msg, code = 400) => res.status(code).json({ ok: false, error: msg });

function handle(res, err, fallback = '操作失败') {
  if (err instanceof CrawlError) return fail(res, err.message);
  console.error('[random-box]', err);
  return fail(res, err?.message || fallback, 500);
}

/** 内置站点 + 运行时的开关/置顶状态合并后输出 */
async function sitesWithState() {
  const state = await loadState();
  return SITES.map((s) => ({
    ...s,
    // 状态文件里没记录过的站点，用 sites.js 里的默认值
    enabled: state[s.id]?.enabled ?? s.enabled !== false,
    pinned: !!state[s.id]?.pinned,
    pinnedAt: state[s.id]?.pinnedAt || 0,
  }));
}

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  ok(res, { service: 'random-box', time: new Date().toISOString() });
});

/**
 * 前端启动时上报 JSOS 的 CORS 代理配置（getProxyConfig）。
 * WebContainer 内 Node 直连外站会被 CORS 拦掉，抓取层在直连失败时
 * 自动改走这个代理（GET {proxy}/{url} + x-cors-proxy-key）。
 * 本机直跑时前端拿不到 JSOS API，不会上报，直连即可。
 */
app.post('/api/relay', (req, res) => {
  const { url, key } = req.body || {};
  if (!url || !/^https?:\/\//.test(String(url))) return fail(res, '代理配置无效');
  setProxyConfig({ url, key });
  ok(res, { proxy: { url: String(url).replace(/\/+$/, ''), hasKey: !!key } });
});

/** 网络自检：直连与代理两条路径都测（WebContainer 环境排障用） */
app.post('/api/diag', async (req, res) => {
  const target = String(req.body?.url || 'https://www.chinawriter.com.cn/404057/419383/index1.html');
  const started = Date.now();
  try {
    const r = await fetchPageItems({ mode: 'html', listUrl: target, itemSelector: 'a', startPage: 1 }, 1);
    ok(res, {
      url: target,
      reachable: r.meta?.ok ?? false,
      status: r.meta?.status ?? 0,
      bytes: r.meta?.bytes ?? 0,
      charset: r.meta?.charset || '',
      viaProxy: !!r.meta?.viaProxy,
      proxyConfigured: !!getProxyConfig(),
      ms: Date.now() - started,
      reason: r.meta?.reason || '',
    });
  } catch (err) {
    ok(res, { url: target, reachable: false, ms: Date.now() - started, reason: err?.message || '未知错误' });
  }
});

/* ------------------------------ 站点 ------------------------------ */

app.get('/api/sites', async (req, res) => {
  try { ok(res, { sites: await sitesWithState(), kinds: listKinds() }); }
  catch (err) { handle(res, err, '读取站点失败'); }
});

app.post('/api/sites/:id/toggle', async (req, res) => {
  try {
    const site = SITES.find((s) => s.id === req.params.id);
    if (!site) return fail(res, '站点不存在', 404);
    const current = (await sitesWithState()).find((s) => s.id === req.params.id);
    await setEnabled(site.id, !current.enabled);
    ok(res, { sites: await sitesWithState() });
  } catch (err) { handle(res, err, '切换状态失败'); }
});

app.post('/api/sites/:id/pin', async (req, res) => {
  try {
    const site = SITES.find((s) => s.id === req.params.id);
    if (!site) return fail(res, '站点不存在', 404);
    const current = (await sitesWithState()).find((s) => s.id === req.params.id);
    await setPinned(site.id, !current.pinned);
    ok(res, { sites: await sitesWithState() });
  } catch (err) { handle(res, err, '置顶失败'); }
});

/* ------------------------------ 随机翻阅 ------------------------------ */

/**
 * 抽一条。
 * body: { siteId?, refreshMax? }
 *   不传 siteId → 从已启用站点里随机挑一个
 *   refreshMax  → 忽略页码缓存重新探测
 */
app.post('/api/pick', async (req, res) => {
  const started = Date.now();
  try {
    const sites = await sitesWithState();
    let pool = sites.filter((s) => s.enabled);
    if (!pool.length) return fail(res, '所有站点都关着，先打开一个');

    // 指定站点：只试它，失败即报错（含原因）
    if (req.body?.siteId) {
      const site = sites.find((s) => s.id === req.body.siteId);
      if (!site) return fail(res, '站点不存在', 404);
      const logs = [];
      const result = await runPick(site, { logs, refreshMax: !!req.body?.refreshMax });
      return ok(res, { item: buildItem(site, result, logs, started) });
    }

    // 随机全部：抽到坏源（如 B 站风控、站点下线）自动换下一个启用源，最多试完全部
    const logs = [];
    while (pool.length) {
      const site = pool[Math.floor(Math.random() * pool.length)];
      try {
        const result = await runPick(site, { logs, refreshMax: !!req.body?.refreshMax });
        return ok(res, { item: buildItem(site, result, logs, started) });
      } catch (err) {
        logs.push({ page: '-', ok: false, note: `「${site.name}」失败自动跳过：${err?.message || '未知错误'}` });
        pool = pool.filter((s) => s.id !== site.id);
      }
    }
    return fail(res, logs.length ? logs[logs.length - 1].note : '所有启用源都不可用');
  } catch (err) { handle(res, err, '抽取失败'); }
});

function runPick(site, { logs, refreshMax }) {
  const source = getSource(site);
  return getSource(site) && source.pick(site, {
    log: (e) => logs.push(e),
    refreshMax: !!refreshMax,
  });
}

function buildItem(site, result, logs, started) {
  const source = getSource(site);
  return {
    siteId: site.id,
    siteName: site.name,
    kind: source.label,
    title: result.title,
    url: result.url,
    openMode: result.openMode || 'link',
    text: result.text,
    detail: result.detail || {},
    fromCache: !!result.fromCache,
    viaProxy: !!result.viaProxy,
    logs,
    ms: Date.now() - started,
  };
}

/* ------------------------------ 缓存 ------------------------------ */

app.post('/api/cache/clear', async (req, res) => {
  try { await clearCache(); ok(res, {}); }
  catch (err) { handle(res, err, '清理缓存失败'); }
});

/* ------------------------------ 静态回退 ------------------------------ */

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`random-box running on ${port}`));
