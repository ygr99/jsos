/* 流体实验室 FluidLab — WebGL2 实时流体模拟
 * 求解流程（Jos Stam "Stable Fluids" GPU 版）：
 *   curl(涡量) → vorticity confinement(涡量约束) → divergence(散度)
 *   → pressure Jacobi 迭代(压力投影) → gradient subtract(投影回速度场)
 *   → 半拉格朗日平流 velocity / dye
 */
'use strict';

const canvas = document.getElementById('fluid');
const glErrorEl = document.getElementById('glError');
const resLabel = document.getElementById('resLabel');
const fpsEl = document.getElementById('fps');

const config = {
  SIM_RES: 192,
  DYE_RES: 768,
  DENSITY_DISSIPATION: 1.0,    // 染料消散
  VELOCITY_DISSIPATION: 0.25,  // 速度消散
  PRESSURE: 0.8,               // 压力场每帧留存率
  PRESSURE_ITERATIONS: 22,     // Jacobi 迭代次数
  CURL: 28,                    // 涡量约束强度
  SPLAT_RADIUS: 0.24,          // 笔刷半径
  SPLAT_FORCE: 6000,           // 喷射力度
  SHADING: true,               // 染料立体光照
  PAUSED: false,
  VIEW: 0,                     // 0 染料 / 1 速度场 / 2 涡量
  AUTO_DEMO: true,             // 空闲自动演示
};

let gl = null;
let dye, velocity, divergence, curlTex, pressure;
let copyProgram, clearProgram, splatProgram, advectionProgram,
    divergenceProgram, curlProgram, vorticityProgram, pressureProgram, gradientProgram, displayProgram;

try {
  gl = canvas.getContext('webgl2', {
    alpha: false, depth: false, stencil: false, antialias: false,
    preserveDrawingBuffer: false, powerPreference: 'high-performance',
  });
  if (!gl) throw new Error('WebGL2 不可用');
  if (!gl.getExtension('EXT_color_buffer_float') && !gl.getExtension('EXT_color_buffer_half_float')) {
    throw new Error('缺少浮点渲染目标扩展（EXT_color_buffer_float）');
  }
} catch (err) {
  glErrorEl.classList.remove('hidden');
  glErrorEl.querySelector('p').textContent = '初始化失败：' + err.message + '。流体模拟需要支持 WebGL2 的浏览器。';
  throw err;
}

canvas.addEventListener('contextmenu', e => e.preventDefault());

/* ---------------- 着色器工具 ---------------- */

function compileShader(type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error('着色器编译失败: ' + gl.getShaderInfoLog(shader));
  }
  return shader;
}

function createProgram(vs, fsSource) {
  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, compileShader(gl.FRAGMENT_SHADER, fsSource));
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error('程序链接失败: ' + gl.getProgramInfoLog(program));
  }
  const uniforms = {};
  const count = gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < count; i++) {
    const name = gl.getActiveUniform(program, i).name;
    uniforms[name] = gl.getUniformLocation(program, name);
  }
  return { bind: () => gl.useProgram(program), uniforms };
}

// 公共顶点着色器：输出 uv 及四邻坐标
const baseVertex = compileShader(gl.VERTEX_SHADER, `#version 300 es
precision highp float;
layout(location=0) in vec2 aPosition;
out vec2 vUv; out vec2 vL; out vec2 vR; out vec2 vT; out vec2 vB;
uniform vec2 texelSize;
void main () {
  vUv = aPosition * 0.5 + 0.5;
  vL = vUv - vec2(texelSize.x, 0.0);
  vR = vUv + vec2(texelSize.x, 0.0);
  vT = vUv + vec2(0.0, texelSize.y);
  vB = vUv - vec2(0.0, texelSize.y);
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`);

const FRAG_HEAD = `#version 300 es
precision highp float;
precision highp sampler2D;
in vec2 vUv; in vec2 vL; in vec2 vR; in vec2 vT; in vec2 vB;
out vec4 FragColor;
`;

copyProgram      = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uTexture;
void main () { FragColor = texture(uTexture, vUv); }`);

clearProgram     = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uTexture;
uniform float value;
void main () { FragColor = value * texture(uTexture, vUv); }`);

splatProgram     = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uTarget;
uniform float aspectRatio;
uniform vec3 color;
uniform vec2 point;
uniform float radius;
void main () {
  vec2 p = vUv - point;
  p.x *= aspectRatio;
  vec3 splat = exp(-dot(p, p) / radius) * color;
  vec3 base = texture(uTarget, vUv).xyz;
  FragColor = vec4(base + splat, 1.0);
}`);

advectionProgram = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uVelocity;
uniform sampler2D uSource;
uniform vec2 texelSize;
uniform float dt;
uniform float dissipation;
void main () {
  vec2 coord = vUv - dt * texture(uVelocity, vUv).xy * texelSize;
  vec4 result = texture(uSource, coord);
  float decay = 1.0 + dissipation * dt;
  FragColor = result / decay;
}`);

divergenceProgram = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uVelocity;
void main () {
  float L = texture(uVelocity, vL).x;
  float R = texture(uVelocity, vR).x;
  float T = texture(uVelocity, vT).y;
  float B = texture(uVelocity, vB).y;
  vec2 C = texture(uVelocity, vUv).xy;
  if (vL.x < 0.0) { L = -C.x; }
  if (vR.x > 1.0) { R = -C.x; }
  if (vT.y > 1.0) { T = -C.y; }
  if (vB.y < 0.0) { B = -C.y; }
  float div = 0.5 * (R - L + T - B);
  FragColor = vec4(div, 0.0, 0.0, 1.0);
}`);

curlProgram      = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uVelocity;
void main () {
  float L = texture(uVelocity, vL).y;
  float R = texture(uVelocity, vR).y;
  float T = texture(uVelocity, vT).x;
  float B = texture(uVelocity, vB).x;
  float vorticity = R - L - T + B;
  FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);
}`);

vorticityProgram = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uVelocity;
uniform sampler2D uCurl;
uniform float curl;
uniform float dt;
void main () {
  float L = texture(uCurl, vL).x;
  float R = texture(uCurl, vR).x;
  float T = texture(uCurl, vT).x;
  float B = texture(uCurl, vB).x;
  float C = texture(uCurl, vUv).x;
  vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));
  force /= length(force) + 0.0001;
  force *= curl * C;
  force.y *= -1.0;
  vec2 velocity = texture(uVelocity, vUv).xy;
  velocity += force * dt;
  velocity = min(max(velocity, -1000.0), 1000.0);
  FragColor = vec4(velocity, 0.0, 1.0);
}`);

pressureProgram  = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uPressure;
uniform sampler2D uDivergence;
void main () {
  float L = texture(uPressure, vL).x;
  float R = texture(uPressure, vR).x;
  float T = texture(uPressure, vT).x;
  float B = texture(uPressure, vB).x;
  float divergence = texture(uDivergence, vUv).x;
  float pressure = (L + R + B + T - divergence) * 0.25;
  FragColor = vec4(pressure, 0.0, 0.0, 1.0);
}`);

gradientProgram  = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uPressure;
uniform sampler2D uVelocity;
void main () {
  float L = texture(uPressure, vL).x;
  float R = texture(uPressure, vR).x;
  float T = texture(uPressure, vT).x;
  float B = texture(uPressure, vB).x;
  vec2 velocity = texture(uVelocity, vUv).xy;
  velocity -= vec2(R - L, T - B);
  FragColor = vec4(velocity, 0.0, 1.0);
}`);

displayProgram   = createProgram(baseVertex, FRAG_HEAD + `
uniform sampler2D uTexture;
uniform vec2 texelSize;
uniform int uMode;
uniform float uShading;
vec3 hsv2rgb (vec3 c) {
  vec3 p = abs(fract(c.xxx + vec3(0.0, 2.0/3.0, 1.0/3.0)) * 6.0 - 3.0);
  return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
void main () {
  if (uMode == 1) {                       // 速度场：色相=方向 亮度=大小
    vec2 v = texture(uTexture, vUv).xy;
    float mag = clamp(length(v) / 800.0, 0.0, 1.0);
    float ang = atan(v.y, v.x) / 6.28318530718 + 0.5;
    FragColor = vec4(hsv2rgb(vec3(ang, 0.85, pow(mag, 0.7))), 1.0);
    return;
  }
  if (uMode == 2) {                       // 涡量：红=逆时针 蓝=顺时针
    float c = texture(uTexture, vUv).x;
    FragColor = vec4(clamp(c / 25.0, 0.0, 1.0), 0.0, clamp(-c / 25.0, 0.0, 1.0), 1.0);
    return;
  }
  vec3 c = texture(uTexture, vUv).rgb;    // 染料（可选伪 3D 光照）
  if (uShading > 0.5) {
    float lc = length(texture(uTexture, vL).rgb);
    float rc = length(texture(uTexture, vR).rgb);
    float tc = length(texture(uTexture, vT).rgb);
    float bc = length(texture(uTexture, vB).rgb);
    float dx = rc - lc;
    float dy = tc - bc;
    vec3 n = normalize(vec3(dx, dy, length(texelSize)));
    float diffuse = clamp(dot(n, vec3(0.0, 0.0, 1.0)) + 0.7, 0.7, 1.0);
    c *= diffuse;
  }
  FragColor = vec4(c, 1.0);
}`);

/* ---------------- 全屏绘制 ---------------- */

const blit = (() => {
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(0);
  return (target) => {
    if (target == null) {
      gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    } else {
      gl.viewport(0, 0, target.width, target.height);
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
    }
    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
  };
})();

/* ---------------- 帧缓冲 ---------------- */

const TEX_TYPE = gl.HALF_FLOAT;
const TEX = { internalFormat: gl.RGBA16F, format: gl.RGBA };

function createFBO (w, h) {
  gl.activeTexture(gl.TEXTURE0);
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D, 0, TEX.internalFormat, w, h, 0, TEX.format, TEX_TYPE, null);
  const fbo = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
  gl.viewport(0, 0, w, h);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
  return {
    texture, fbo, width: w, height: h,
    texelSizeX: 1 / w, texelSizeY: 1 / h,
    attach (id) {
      gl.activeTexture(gl.TEXTURE0 + id);
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      return id;
    },
    dispose () {
      gl.deleteTexture(texture);
      gl.deleteFramebuffer(fbo);
    },
  };
}

function createDoubleFBO (w, h) {
  return {
    read: createFBO(w, h),
    write: createFBO(w, h),
    width: w, height: h,
    texelSizeX: 1 / w, texelSizeY: 1 / h,
    swap () { const t = this.read; this.read = this.write; this.write = t; },
    dispose () { this.read.dispose(); this.write.dispose(); },
  };
}

function resizeDoubleFBO (target, w, h) {
  if (target.width === w && target.height === h) return target;
  const next = createDoubleFBO(w, h);
  copyProgram.bind();
  gl.uniform1i(copyProgram.uniforms.uTexture, target.read.attach(0));
  blit(next.read);
  target.dispose();
  return next;
}

function getResolution (resolution) {
  let aspect = gl.drawingBufferWidth / gl.drawingBufferHeight;
  if (aspect < 1) aspect = 1 / aspect;
  const min = Math.round(resolution);
  const max = Math.round(resolution * aspect);
  return gl.drawingBufferWidth > gl.drawingBufferHeight
    ? { width: max, height: min }
    : { width: min, height: max };
}

function initFramebuffers () {
  const simRes = getResolution(config.SIM_RES);
  const dyeRes = getResolution(config.DYE_RES);
  dye = dye ? resizeDoubleFBO(dye, dyeRes.width, dyeRes.height) : createDoubleFBO(dyeRes.width, dyeRes.height);
  velocity = velocity ? resizeDoubleFBO(velocity, simRes.width, simRes.height) : createDoubleFBO(simRes.width, simRes.height);
  if (divergence) divergence.dispose();
  if (curlTex) curlTex.dispose();
  if (pressure) pressure.dispose();
  divergence = createFBO(simRes.width, simRes.height);
  curlTex = createFBO(simRes.width, simRes.height);
  pressure = createDoubleFBO(simRes.width, simRes.height);
  updateResLabel(simRes, dyeRes);
}

function updateResLabel (simRes, dyeRes) {
  resLabel.textContent = `模拟 ${simRes.width}×${simRes.height} · 染料 ${dyeRes.width}×${dyeRes.height}`;
}

/* ---------------- 模拟一步 ---------------- */

function step (dt) {
  gl.disable(gl.BLEND);

  curlProgram.bind();
  gl.uniform2f(curlProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1i(curlProgram.uniforms.uVelocity, velocity.read.attach(0));
  blit(curlTex);

  vorticityProgram.bind();
  gl.uniform2f(vorticityProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1i(vorticityProgram.uniforms.uVelocity, velocity.read.attach(0));
  gl.uniform1i(vorticityProgram.uniforms.uCurl, curlTex.attach(1));
  gl.uniform1f(vorticityProgram.uniforms.curl, config.CURL);
  gl.uniform1f(vorticityProgram.uniforms.dt, dt);
  blit(velocity.write);
  velocity.swap();

  divergenceProgram.bind();
  gl.uniform2f(divergenceProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1i(divergenceProgram.uniforms.uVelocity, velocity.read.attach(0));
  blit(divergence);

  clearProgram.bind();
  gl.uniform1i(clearProgram.uniforms.uTexture, pressure.read.attach(0));
  gl.uniform1f(clearProgram.uniforms.value, config.PRESSURE);
  blit(pressure.write);
  pressure.swap();

  pressureProgram.bind();
  gl.uniform2f(pressureProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1i(pressureProgram.uniforms.uDivergence, divergence.attach(0));
  for (let i = 0; i < config.PRESSURE_ITERATIONS; i++) {
    gl.uniform1i(pressureProgram.uniforms.uPressure, pressure.read.attach(1));
    blit(pressure.write);
    pressure.swap();
  }

  gradientProgram.bind();
  gl.uniform2f(gradientProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1i(gradientProgram.uniforms.uPressure, pressure.read.attach(0));
  gl.uniform1i(gradientProgram.uniforms.uVelocity, velocity.read.attach(1));
  blit(velocity.write);
  velocity.swap();

  advectionProgram.bind();
  gl.uniform2f(advectionProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
  gl.uniform1f(advectionProgram.uniforms.dt, dt);
  gl.uniform1i(advectionProgram.uniforms.uVelocity, velocity.read.attach(0));
  gl.uniform1i(advectionProgram.uniforms.uSource, velocity.read.attach(0));
  gl.uniform1f(advectionProgram.uniforms.dissipation, config.VELOCITY_DISSIPATION);
  blit(velocity.write);
  velocity.swap();

  gl.uniform1i(advectionProgram.uniforms.uVelocity, velocity.read.attach(0));
  gl.uniform1i(advectionProgram.uniforms.uSource, dye.read.attach(1));
  gl.uniform1f(advectionProgram.uniforms.dissipation, config.DENSITY_DISSIPATION);
  blit(dye.write);
  dye.swap();
}

function render () {
  displayProgram.bind();
  gl.uniform2f(displayProgram.uniforms.texelSize, 1 / gl.drawingBufferWidth, 1 / gl.drawingBufferHeight);
  gl.uniform1i(displayProgram.uniforms.uMode, config.VIEW);
  gl.uniform1f(displayProgram.uniforms.uShading, config.SHADING ? 1 : 0);
  const src = config.VIEW === 0 ? dye.read : config.VIEW === 1 ? velocity.read : curlTex;
  gl.uniform1i(displayProgram.uniforms.uTexture, src.attach(0));
  blit(null);
}

/* ---------------- 注入（splat） ---------------- */

function correctRadius (radius) {
  const aspect = canvas.width / canvas.height;
  if (aspect > 1) radius *= aspect;
  return radius;
}
function correctDeltaX (delta) {
  const aspect = canvas.width / canvas.height;
  if (aspect < 1) delta *= aspect;
  return delta;
}
function correctDeltaY (delta) {
  const aspect = canvas.width / canvas.height;
  if (aspect > 1) delta /= aspect;
  return delta;
}

function splat (x, y, dx, dy, color) {
  splatProgram.bind();
  gl.uniform1i(splatProgram.uniforms.uTarget, velocity.read.attach(0));
  gl.uniform1f(splatProgram.uniforms.aspectRatio, canvas.width / canvas.height);
  gl.uniform2f(splatProgram.uniforms.point, x, y);
  gl.uniform3f(splatProgram.uniforms.color, dx, dy, 0);
  gl.uniform1f(splatProgram.uniforms.radius, correctRadius(config.SPLAT_RADIUS / 100));
  blit(velocity.write);
  velocity.swap();

  gl.uniform1i(splatProgram.uniforms.uTarget, dye.read.attach(0));
  gl.uniform3f(splatProgram.uniforms.color, color.r, color.g, color.b);
  blit(dye.write);
  dye.swap();
}

/* ---------------- 颜色 ---------------- */

let hue = Math.random();
function genColor () {
  hue = (hue + 0.17 + Math.random() * 0.1) % 1;
  return hsv2rgb(hue, 1.0, 1.0, 0.18);
}
function hsv (h, s, v, k = 0.18) { return hsv2rgb(h, s, v, k); }
function hsv2rgb (h, s, v, k) {
  const i = Math.floor(h * 6);
  const f = h * 6 - i;
  const p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
  let r, g, b;
  switch (i % 6) {
    case 0: r = v; g = t; b = p; break;
    case 1: r = q; g = v; b = p; break;
    case 2: r = p; g = v; b = t; break;
    case 3: r = p; g = q; b = v; break;
    case 4: r = t; g = p; b = v; break;
    default: r = v; g = p; b = q;
  }
  return { r: r * k, g: g * k, b: b * k };
}
function mult (c, k) { return { r: c.r * k, g: c.g * k, b: c.b * k }; }

/* ---------------- 指针输入 ---------------- */

const pointers = new Map();
let lastInteract = performance.now();

function pointerUV (e) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left) / rect.width,
    y: 1 - (e.clientY - rect.top) / rect.height,
  };
}

canvas.addEventListener('pointerdown', e => {
  canvas.setPointerCapture(e.pointerId);
  const { x, y } = pointerUV(e);
  const color = genColor();
  pointers.set(e.pointerId, { x, y, dx: 0, dy: 0, moved: false, color });
  splat(x, y, 0, 0, mult(color, 8));
  lastInteract = performance.now();
});

canvas.addEventListener('pointermove', e => {
  lastInteract = performance.now();
  const p = pointers.get(e.pointerId);
  if (!p) return;
  const { x, y } = pointerUV(e);
  p.dx = correctDeltaX(x - p.x) * config.SPLAT_FORCE;
  p.dy = correctDeltaY(y - p.y) * config.SPLAT_FORCE;
  p.x = x; p.y = y;
  p.moved = Math.abs(p.dx) > 0 || Math.abs(p.dy) > 0;
});

function releasePointer (e) { pointers.delete(e.pointerId); }
canvas.addEventListener('pointerup', releasePointer);
canvas.addEventListener('pointercancel', releasePointer);

function applyInputs () {
  for (const p of pointers.values()) {
    if (p.moved) {
      p.moved = false;
      splat(p.x, p.y, p.dx, p.dy, p.color);
    }
  }
}

/* ---------------- 预设场景 & 自动演示 ---------------- */

let presetTimer = null;
function stopPresetTimer () {
  if (presetTimer) { clearInterval(presetTimer); presetTimer = null; }
}

function presetVortex () {
  stopPresetTimer();
  const N = 16;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    splat(
      0.5 + Math.cos(a) * 0.17, 0.5 + Math.sin(a) * 0.17,
      -Math.sin(a) * 850, Math.cos(a) * 850,
      mult(hsv(i / N, 1, 1), 8)
    );
  }
}

function presetFirework () {
  stopPresetTimer();
  for (let i = 0; i < 28; i++) {
    const a = Math.random() * Math.PI * 2;
    const s = 300 + Math.random() * 750;
    splat(0.5, 0.55, Math.cos(a) * s, Math.sin(a) * s, mult(genColor(), 7));
  }
}

function presetFountain () {
  stopPresetTimer();
  let t = 0;
  presetTimer = setInterval(() => {
    t++;
    for (let i = 0; i < 3; i++) {
      splat(
        0.5 + (i - 1) * 0.12 + (Math.random() - 0.5) * 0.02, 0.07,
        (Math.random() - 0.5) * 260, 820 + Math.random() * 380,
        mult(genColor(), 5)
      );
    }
    if (t > 34) stopPresetTimer();
  }, 70);
}

function randomBurst (n = 10) {
  stopPresetTimer();
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2;
    const s = Math.random() * 600;
    splat(
      0.15 + Math.random() * 0.7, 0.15 + Math.random() * 0.7,
      Math.cos(a) * s, Math.sin(a) * s,
      mult(genColor(), 5)
    );
  }
}

function clearCanvas () {
  stopPresetTimer();
  dye.dispose(); velocity.dispose(); pressure.dispose();
  dye = velocity = pressure = null;
  initFramebuffers();
}

let orbitAngle = Math.random() * Math.PI * 2;
let lastAuto = 0;
function autoDemo (now) {
  if (!config.AUTO_DEMO || config.PAUSED) return;
  if (now - lastInteract < 6000 || now - lastAuto < 620) return;
  lastAuto = now;
  orbitAngle += 0.85 + Math.random() * 0.6;
  const r = 0.22 + Math.sin(now * 0.0003) * 0.08;
  const cx = 0.5 + Math.cos(orbitAngle) * r * 1.35;
  const cy = 0.5 + Math.sin(orbitAngle) * r;
  const s = 480 + Math.random() * 420;
  splat(cx, cy, -Math.sin(orbitAngle) * s, Math.cos(orbitAngle) * s, mult(genColor(), 6));
  if (Math.random() < 0.12) randomBurst(6);
}

/* ---------------- UI ---------------- */

const panel = document.getElementById('panel');
document.getElementById('panelToggle').addEventListener('click', () => panel.classList.toggle('hidden'));

function addSlider (section, key, label, min, max, step, fmt) {
  const row = document.createElement('div');
  row.className = 'ctl';
  const lab = document.createElement('label');
  lab.textContent = label;
  const val = document.createElement('span');
  val.className = 'val';
  const input = document.createElement('input');
  input.type = 'range';
  input.min = min; input.max = max; input.step = step;
  input.value = config[key];
  const show = () => { val.textContent = fmt ? fmt(config[key]) : config[key]; };
  input.addEventListener('input', () => {
    config[key] = parseFloat(input.value);
    show();
    if (key === 'PRESSURE_ITERATIONS') { /* 下一帧生效 */ }
  });
  show();
  row.append(lab, input, val);
  section.appendChild(row);
}

const sceneSec = document.getElementById('sceneButtons');
[['漩涡', presetVortex], ['烟花', presetFirework], ['喷泉', presetFountain], ['随机喷发', () => randomBurst(12)], ['清空画布', clearCanvas]]
  .forEach(([text, fn]) => {
    const b = document.createElement('button');
    b.textContent = text;
    b.addEventListener('click', () => { lastInteract = performance.now(); fn(); });
    sceneSec.appendChild(b);
  });

addSlider(document.getElementById('paramSliders'), 'DENSITY_DISSIPATION', '染料消散', 0, 3, 0.05, v => v.toFixed(2));
addSlider(document.getElementById('paramSliders'), 'VELOCITY_DISSIPATION', '速度消散', 0, 2, 0.05, v => v.toFixed(2));
addSlider(document.getElementById('paramSliders'), 'CURL', '涡量约束', 0, 50, 1, v => v.toFixed(0));
addSlider(document.getElementById('paramSliders'), 'PRESSURE_ITERATIONS', '压力迭代', 8, 40, 1, v => v.toFixed(0));
addSlider(document.getElementById('paramSliders'), 'SPLAT_FORCE', '喷射力度', 1000, 12000, 100, v => v.toFixed(0));
addSlider(document.getElementById('paramSliders'), 'SPLAT_RADIUS', '笔刷半径', 0.05, 0.6, 0.01, v => v.toFixed(2));

const QUALITIES = { '流畅': [128, 512], '均衡': [192, 768], '高清': [256, 1024] };
const qualitySel = document.getElementById('quality');
Object.keys(QUALITIES).forEach(k => {
  const opt = document.createElement('option');
  opt.value = k; opt.textContent = k;
  if (QUALITIES[k][0] === config.SIM_RES) opt.selected = true;
  qualitySel.appendChild(opt);
});
qualitySel.addEventListener('change', () => {
  const [s, d] = QUALITIES[qualitySel.value];
  config.SIM_RES = s; config.DYE_RES = d;
  initFramebuffers();
});

const viewBtns = Array.from(document.querySelectorAll('#viewSeg button'));
viewBtns.forEach((b, i) => b.addEventListener('click', () => setView(i)));
function setView (i) {
  config.VIEW = i;
  viewBtns.forEach((b, j) => b.classList.toggle('active', j === i));
}
setView(0);

function bindCheck (id, key, onChange) {
  const el = document.getElementById(id);
  el.checked = config[key];
  el.addEventListener('change', () => { config[key] = el.checked; if (onChange) onChange(); });
  return el;
}
const pauseCheck = bindCheck('optPause', 'PAUSED');
bindCheck('optShading', 'SHADING');
bindCheck('optAuto', 'AUTO_DEMO');

window.addEventListener('keydown', e => {
  if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return;
  switch (e.code) {
    case 'Space':
      e.preventDefault();
      config.PAUSED = !config.PAUSED;
      pauseCheck.checked = config.PAUSED;
      break;
    case 'KeyC': clearCanvas(); break;
    case 'KeyR': lastInteract = performance.now(); randomBurst(12); break;
    case 'KeyV': setView((config.VIEW + 1) % 3); break;
    case 'KeyH': panel.classList.toggle('hidden'); break;
  }
});

/* ---------------- 主循环 ---------------- */

function resizeCanvas () {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = Math.max(1, Math.floor(canvas.clientWidth * dpr));
  const h = Math.max(1, Math.floor(canvas.clientHeight * dpr));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w; canvas.height = h;
    return true;
  }
  return false;
}

resizeCanvas();
initFramebuffers();
presetVortex();

let lastTime = performance.now();
let fpsEMA = 60, lastFpsUpdate = 0;

function frame (now) {
  const dt = Math.min((now - lastTime) / 1000, 1 / 30) || 1 / 60;
  lastTime = now;

  fpsEMA += (1 / dt - fpsEMA) * 0.06;
  if (now - lastFpsUpdate > 500) {
    lastFpsUpdate = now;
    fpsEl.textContent = `${Math.round(fpsEMA)} FPS`;
  }

  if (resizeCanvas()) initFramebuffers();
  autoDemo(now);
  applyInputs();
  if (!config.PAUSED) step(dt);
  render();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
