import { useState, useEffect } from 'react'
import { HashRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom'
import { Info, Cpu, Database, Palette, PanelLeftClose, PanelLeft } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useLocale, LocaleProvider } from '@/i18n'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tooltip, TooltipTrigger, TooltipPopup } from '@/components/ui/tooltip'
import AboutPage from '@/pages/About'
import ApiDemoPage from '@/pages/ApiDemo'
import DataStoragePage from '@/pages/DataStorage'
import UIShowcasePage from '@/pages/UIShowcase'
import WidgetGuide from '@/pages/WidgetGuide'

const navItems = [
  { id: 'about', icon: Info },
  { id: 'api-demo', icon: Cpu },
  { id: 'data-storage', icon: Database },
  { id: 'ui-showcase', icon: Palette },
]

function AppContent() {
  const { t } = useLocale()
  const [collapsed, setCollapsed] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640)
    check()
    addEventListener('resize', check)
    return () => removeEventListener('resize', check)
  }, [])

  useEffect(() => {
    function apply(effective) {
      document.documentElement.classList.toggle('dark', effective === 'dark')
    }

    window.JSOS?.getTheme().then(mode => {
      if (mode === 'system') {
        const mq = window.matchMedia('(prefers-color-scheme: dark)')
        apply(mq.matches ? 'dark' : 'light')
      } else {
        apply(mode)
      }
    })

    const unsub = window.JSOS?.onThemeChange(apply)
    return () => unsub?.()
  }, [])

  const activeNav = location.pathname.replace(/^\//, '') || 'about'

  const isWidget = location.pathname.startsWith('/widget')

  if (isWidget) {
    return (
      <div className="h-full flex">
        <Routes>
          <Route path="/widget/guide" element={<WidgetGuide />} />
          <Route path="*" element={<WidgetGuide />} />
        </Routes>
      </div>
    )
  }

  return (
    <div className={cn('h-full flex', isMobile ? 'pl-14' : '')}>
      {isMobile && !collapsed && (
        <div className="fixed inset-0 z-40 bg-black/32 backdrop-blur-sm" onClick={() => setCollapsed(true)} />
      )}
      <aside className={cn(
        'border-r border-border flex flex-col transition-all duration-200',
        collapsed ? 'w-14' : 'w-56',
        isMobile
          ? 'fixed left-0 top-0 z-50 h-full bg-background'
          : 'shrink-0 bg-muted/30'
      )}>
        <div className={cn(
          'border-b border-border flex items-center',
          collapsed ? 'justify-center p-2' : 'justify-between p-2 pl-4'
        )}>
          {!collapsed && (
            <h1 className="font-semibold text-base truncate">{t('app.name')}</h1>
          )}
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => setCollapsed(!collapsed)}
            aria-label={collapsed ? t('nav.expand') : t('nav.collapse')}
          >
            {collapsed ? <PanelLeft className="size-4" /> : <PanelLeftClose className="size-4" />}
          </Button>
        </div>
        <nav className="flex-1 p-2 space-y-1">
          {navItems.map((item) => (
            <Tooltip key={item.id}>
              <TooltipTrigger
                render={
                  <button
                    type="button"
                    onClick={() => {
                      navigate(`/${item.id}`)
                      if (isMobile) setCollapsed(true)
                    }}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer',
                      collapsed ? 'justify-center px-2' : '',
                      activeNav === item.id
                        ? 'bg-primary/10 text-primary font-medium'
                        : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                    )}
                  />
                }
              >
                <item.icon className="size-4.5 shrink-0" />
                {!collapsed && (
                  <span className="flex-1 text-left">{t(`nav.${item.id}`)}</span>
                )}
              </TooltipTrigger>
              {collapsed && (
                <TooltipPopup side="right">{t(`nav.${item.id}`)}</TooltipPopup>
              )}
            </Tooltip>
          ))}
        </nav>
      </aside>
      <main className="flex-1 min-w-0">
        <ScrollArea>
          <Routes>
            <Route path="/about" element={<AboutPage />} />
            <Route path="/api-demo" element={<ApiDemoPage />} />
            <Route path="/data-storage" element={<DataStoragePage />} />
            <Route path="/ui-showcase" element={<UIShowcasePage />} />
            <Route path="*" element={<Navigate to="/about" replace />} />
          </Routes>
        </ScrollArea>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <LocaleProvider>
      <HashRouter>
        <AppContent />
      </HashRouter>
    </LocaleProvider>
  )
}
