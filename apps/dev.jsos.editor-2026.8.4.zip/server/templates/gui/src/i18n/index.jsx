import { useState, useEffect, useCallback, createContext, useContext } from 'react'
import { zhCN } from './zh-CN'
import { en } from './en'

const messages = { 'zh-CN': zhCN, en }

function detectBrowserLocale() {
  if (typeof window === 'undefined') return 'zh-CN'
  const lang = navigator.language
  return lang.startsWith('zh') ? 'zh-CN' : 'en'
}

const LocaleContext = createContext(null)

export function LocaleProvider({ children }) {
  const [locale, setLocaleState] = useState(detectBrowserLocale)

  useEffect(() => {
    if (window.JSOS?.getLocale) {
      window.JSOS.getLocale().then(lang => {
        if (lang && messages[lang]) setLocaleState(lang)
      })
    }
    const unsub = window.JSOS?.onLocaleChange?.(lang => {
      if (lang && messages[lang]) setLocaleState(lang)
    })
    return () => unsub?.()
  }, [])

  const setLocale = useCallback((lang) => {
    if (!messages[lang]) return
    setLocaleState(lang)
    if (window.JSOS?.setLocale) {
      window.JSOS.setLocale(lang)
    }
  }, [])

  const translate = useCallback((key) => {
    return messages[locale]?.[key] || messages['en']?.[key] || key
  }, [locale])

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t: translate }}>
      {children}
    </LocaleContext.Provider>
  )
}

export function useLocale() {
  const ctx = useContext(LocaleContext)
  if (!ctx) {
    const locale = detectBrowserLocale()
    return {
      locale,
      setLocale: () => {},
      t: (key) => messages[locale]?.[key] || messages['en']?.[key] || key,
    }
  }
  return ctx
}
