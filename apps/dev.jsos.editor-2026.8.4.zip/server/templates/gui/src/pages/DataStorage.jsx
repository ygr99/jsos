import { useState, useEffect, useCallback } from 'react'
import { useLocale } from '@/i18n'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogPopup, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Pencil, Trash2, FileText, FolderOpen } from 'lucide-react'

const API_URL = '/api/notes'

export default function DataStoragePage() {
  const { t } = useLocale()
  const [notes, setNotes] = useState([])
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingNote, setEditingNote] = useState(null)
  const [formTitle, setFormTitle] = useState('')
  const [formContent, setFormContent] = useState('')
  const [saving, setSaving] = useState(false)
  const [selectedIds, setSelectedIds] = useState(new Set())

  const fetchNotes = useCallback(async () => {
    try {
      const res = await fetch(API_URL)
      if (res.ok) setNotes(await res.json())
    } catch (e) {
      window.JSOS?.toast?.({ title: t('data.error'), description: e.message, type: 'error' })
    } finally {
      setLoading(false)
    }
  }, [t])

  useEffect(() => { fetchNotes() }, [fetchNotes])

  const handleAdd = useCallback(() => {
    setEditingNote(null)
    setFormTitle('')
    setFormContent('')
    setFormOpen(true)
  }, [])

  const handleEdit = useCallback((note) => {
    setEditingNote(note)
    setFormTitle(note.title)
    setFormContent(note.content)
    setFormOpen(true)
  }, [])

  const handleSave = useCallback(async () => {
    if (!formTitle.trim()) return
    setSaving(true)
    try {
      if (editingNote) {
        const res = await fetch(`${API_URL}/${editingNote.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: formTitle.trim(), content: formContent.trim() }),
        })
        if (res.ok) {
          const updated = await res.json()
          setNotes(prev => prev.map(n => n.id === updated.id ? updated : n))
          window.JSOS?.toast?.({ title: t('data.saved'), type: 'success' })
        }
      } else {
        const res = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: formTitle.trim(), content: formContent.trim() }),
        })
        if (res.ok) {
          const created = await res.json()
          setNotes(prev => [...prev, created])
          window.JSOS?.toast?.({ title: t('data.saved'), type: 'success' })
        }
      }
      setFormOpen(false)
    } catch (e) {
      window.JSOS?.toast?.({ title: t('data.error'), description: e.message, type: 'error' })
    } finally {
      setSaving(false)
    }
  }, [formTitle, formContent, editingNote, t])

  const handleDelete = useCallback(async (id) => {
    try {
      const res = await fetch(`${API_URL}/${id}`, { method: 'DELETE' })
      if (res.ok) {
        setNotes(prev => prev.filter(n => n.id !== id))
        setSelectedIds(prev => { const next = new Set(prev); next.delete(id); return next })
        window.JSOS?.toast?.({ title: t('data.deleted'), type: 'success' })
      }
    } catch (e) {
      window.JSOS?.toast?.({ title: t('data.error'), description: e.message, type: 'error' })
    }
  }, [t])

  const handleDeleteSelected = useCallback(async () => {
    if (selectedIds.size === 0) return
    try {
      const res = await fetch(API_URL, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedIds) }),
      })
      if (res.ok) {
        setNotes(prev => prev.filter(n => !selectedIds.has(n.id)))
        setSelectedIds(new Set())
        window.JSOS?.toast?.({ title: t('data.deleted'), type: 'success' })
      }
    } catch (e) {
      window.JSOS?.toast?.({ title: t('data.error'), description: e.message, type: 'error' })
    }
  }, [selectedIds, t])

  const toggleSelect = useCallback((id) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  const handleOpenDataDir = useCallback(async () => {
    try {
      const info = await window.JSOS?.getAppInfo?.('dev.jsos.example-gui')
      if (info?.dataDir) {
        await window.JSOS?.openApp?.('dev.jsos.filemanager', { route: info.dataDir })
      }
    } catch (e) {
      window.JSOS?.toast?.({ title: t('data.error'), description: e.message, type: 'error' })
    }
  }, [t])

  if (loading) {
    return (
      <div className="p-6 max-w-2xl">
        <div className="w-full h-40 rounded-xl bg-muted/30 animate-pulse" />
      </div>
    )
  }

  return (
    <div className="p-6 max-w-2xl">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-xl font-semibold">{t('data.title')}</h2>
          <p className="text-sm text-muted-foreground">{t('data.description')}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleOpenDataDir}>
            <FolderOpen className="size-4 mr-1" />
            {t('data.openDir')}
          </Button>
          {selectedIds.size > 0 && (
            <Button variant="destructive" size="sm" onClick={handleDeleteSelected}>
              <Trash2 className="size-4 mr-1" />
              {t('data.deleteSelected')} ({selectedIds.size})
            </Button>
          )}
          <Button onClick={handleAdd} size="sm">
            <Plus className="size-4" />
            {t('data.add')}
          </Button>
        </div>
      </div>

      {notes.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <FileText className="size-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t('data.empty')}</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={handleAdd}>
            <Plus className="size-4" />
            {t('data.add')}
          </Button>
        </div>
      ) : (
        <div className="space-y-2 mt-4">
          {notes.map(note => (
            <div
              key={note.id}
              className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                selectedIds.has(note.id) ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
              }`}
            >
              <input
                type="checkbox"
                checked={selectedIds.has(note.id)}
                onChange={() => toggleSelect(note.id)}
                className="mt-1 size-4 accent-primary"
              />
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{note.title}</p>
                {note.content && (
                  <p className="text-sm text-muted-foreground truncate mt-0.5">{note.content}</p>
                )}
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(note.updatedAt || note.createdAt).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button variant="ghost" size="icon-sm" onClick={() => handleEdit(note)}>
                  <Pencil className="size-4" />
                </Button>
                <Button variant="ghost" size="icon-sm" onClick={() => handleDelete(note.id)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogPopup showCloseButton={false}>
          <DialogHeader>
            <DialogTitle>{editingNote ? t('data.editNote') : t('data.addNew')}</DialogTitle>
            <DialogDescription>
              {editingNote ? t('data.editNote') : t('data.addNew')}
            </DialogDescription>
          </DialogHeader>
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">{t('data.titleLabel')}</label>
              <Input
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                placeholder={t('data.titlePlaceholder')}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">{t('data.contentLabel')}</label>
              <Textarea
                value={formContent}
                onChange={(e) => setFormContent(e.target.value)}
                placeholder={t('data.contentPlaceholder')}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="ghost" size="sm" />}>
              {t('data.cancel')}
            </DialogClose>
            <Button size="sm" onClick={handleSave} disabled={saving || !formTitle.trim()}>
              {saving ? '...' : t('data.save')}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>
    </div>
  )
}
