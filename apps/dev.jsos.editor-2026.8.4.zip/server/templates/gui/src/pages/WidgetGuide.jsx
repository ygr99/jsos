import { FileCode, Puzzle, MousePointerClick } from 'lucide-react'

function Card({ icon: Icon, title, children, accent }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card/80 backdrop-blur-sm overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className={`h-1.5 ${accent}`} />
      <div className="p-4 space-y-3">
        <div className="flex items-center gap-2">
          <div className="size-8 rounded-lg bg-muted flex items-center justify-center">
            <Icon className="size-4.5 text-foreground" />
          </div>
          <h3 className="font-semibold text-sm">{title}</h3>
        </div>
        <div className="space-y-2 text-xs text-muted-foreground leading-relaxed">
          {children}
        </div>
      </div>
    </div>
  )
}

function CodeInline({ children }) {
  return (
    <code className="px-1 py-0.5 rounded bg-muted/70 text-foreground text-[11px] font-mono">
      {children}
    </code>
  )
}

export default function WidgetGuide() {
  return (
    <div className="size-full p-4 overflow-auto">
      <div className="max-w-lg mx-auto space-y-3">

        <div className="text-center mb-4">
          <div className="size-12 mx-auto mb-2 rounded-xl bg-primary/10 flex items-center justify-center">
            <Puzzle className="size-6 text-primary" />
          </div>
          <h2 className="text-base font-semibold">Desktop Widget Guide</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Everything you need to know about JSOS widgets
          </p>
        </div>

        <Card icon={FileCode} title="1. Declare in package.json" accent="bg-blue-500">
          <p>
            Add a <CodeInline>widgets</CodeInline> array to your app's
            <CodeInline>package.json#jsos</CodeInline>:
          </p>
          <pre className="bg-muted/70 p-2 rounded text-[11px] font-mono leading-relaxed overflow-x-auto">
{`"widgets": [{
  "id": "my-widget",
  "name": { "en": "My Widget" },
  "url": "/#/widget/my-widget",
  "cols": 3,
  "rows": 2,
  "background": "frosted"
}]`}
          </pre>
          <p>
            Each widget needs a unique <CodeInline>id</CodeInline>,
            a <CodeInline>url</CodeInline> that renders its content,
            and <CodeInline>cols</CodeInline>/<CodeInline>rows</CodeInline>
            for grid sizing.
          </p>
        </Card>

        <Card icon={MousePointerClick} title="2. Routes & Rendering" accent="bg-emerald-500">
          <p>
            The widget URL loads in an iframe. Use hash routing
            to render the correct component:
          </p>
          <pre className="bg-muted/70 p-2 rounded text-[11px] font-mono leading-relaxed overflow-x-auto">
{`// App.jsx — detect widget route
const isWidget = location.pathname
  .startsWith('/widget')

if (isWidget) {
  return <MyWidgetComponent />
}

// Normal app layout with sidebar...
return <div class="h-full flex">...</div>`}
          </pre>
          <p>
            The widget runs in the same process as your app,
            so it can share state, fetch data from your server,
            and call <CodeInline>window.JSOS.*</CodeInline> APIs.
          </p>
        </Card>

        <Card icon={Puzzle} title="3. Adding to Desktop" accent="bg-purple-500">
          <p>
            Users add widgets via:
          </p>
          <ul className="list-disc pl-4 space-y-1">
            <li>
              <strong>Right-click</strong> on the desktop
              → <em>Add Widget</em>
            </li>
            <li>
              <strong>App Manager</strong> → widget tab
            </li>
            <li>
              <strong>Programmatically</strong> via JSOS API:
            </li>
          </ul>
          <pre className="bg-muted/70 p-2 rounded text-[11px] font-mono leading-relaxed overflow-x-auto">
{`// From any app
await window.JSOS.addWidget(
  'dev.jsos.example-gui',
  'widget-guide',
  { x: 300, y: 200 }
)`}
          </pre>
          <p>
            Widgets auto-align to the desktop grid (104px cells).
            Each instance gets a unique ID — you can add the same
            widget multiple times.
          </p>
        </Card>

        <Card icon={Puzzle} title="4. Background Styles" accent="bg-amber-500">
          <p>
            Widgets support 3 background modes via the
            <CodeInline>background</CodeInline> field:
          </p>
          <pre className="bg-muted/70 p-2 rounded text-[11px] font-mono leading-relaxed overflow-x-auto">
{`// Frosted glass (default)
"background": "frosted"

// Or with custom opacity/blur:
"background": {
  "type": "frosted",
  "opacity": 80,
  "blur": 12
}

// Solid background:
"background": "solid"

// Transparent:
"background": "transparent"`}
          </pre>
        </Card>

        <div className="text-center pt-4 pb-2">
          <p className="text-xs text-muted-foreground">
            This widget itself is built with the same patterns!
          </p>
        </div>

      </div>
    </div>
  )
}
