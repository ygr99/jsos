import { useState } from 'react'
import { useLocale } from '@/i18n'
import { Button } from '@/components/ui/button'
import { Select, SelectTrigger, SelectValue, SelectPopup, SelectItem } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Input } from '@/components/ui/input'
import { Dialog, DialogPopup, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog'
import { Tooltip, TooltipTrigger, TooltipPopup } from '@/components/ui/tooltip'
import { ExternalLink, BookOpen } from 'lucide-react'

const selectOptions = [
  { value: '1', label: 'Option 1' },
  { value: '2', label: 'Option 2' },
  { value: '3', label: 'Option 3' },
]

function Section({ title, desc, children }) {
  return (
    <section className="rounded-lg border border-border p-4 space-y-3">
      <div>
        <h3 className="text-sm font-medium">{title}</h3>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        {children}
      </div>
    </section>
  )
}

export default function UIShowcasePage() {
  const { t } = useLocale()
  const [switchOn, setSwitchOn] = useState(false)
  const [sliderValue, setSliderValue] = useState(50)
  const [inputValue, setInputValue] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [selectValue, setSelectValue] = useState(null)

  return (
    <div className="p-6 max-w-2xl space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-1">{t('ui.title')}</h2>
        <p className="text-sm text-muted-foreground">{t('ui.description')}</p>
      </div>

      <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-3">
        <div className="flex items-start gap-3">
          <BookOpen className="size-5 text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium">{t('ui.coss.title')}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {t('ui.coss.desc')}
            </p>
            <div className="flex flex-wrap gap-3 mt-2">
              <a
                href="https://coss.com/ui/docs"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
              >
                {t('ui.coss.link')} <ExternalLink className="size-3" />
              </a>
              <a
                href="https://base-ui.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
              >
                {t('ui.coss.baseui')} <ExternalLink className="size-3" />
              </a>
              <a
                href="https://tailwindcss.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
              >
                {t('ui.coss.tailwind')} <ExternalLink className="size-3" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <Section title={t('ui.button')} desc={t('ui.button.desc')}>
        <Button size="sm">{t('ui.button')}</Button>
        <Button variant="outline" size="sm">Outline</Button>
        <Button variant="ghost" size="sm">Ghost</Button>
        <Button variant="destructive" size="sm">Destructive</Button>
        <Button size="sm" loading>Loading</Button>
      </Section>

      <Section title={t('ui.select')} desc={t('ui.select.desc')}>
        <Select
          items={selectOptions}
          value={selectValue}
          onValueChange={(item) => setSelectValue(item)}
        >
          <SelectTrigger className="w-48">
            <SelectValue placeholder={t('ui.options.option1')} />
          </SelectTrigger>
          <SelectPopup>
            {selectOptions.map((item) => (
              <SelectItem key={item.value} value={item}>
                {item.label}
              </SelectItem>
            ))}
          </SelectPopup>
        </Select>
      </Section>

      <Section title={t('ui.switch')} desc={t('ui.switch.desc')}>
        <div className="flex items-center gap-3">
          <Switch checked={switchOn} onCheckedChange={setSwitchOn} />
          <span className="text-sm">{switchOn ? t('ui.switch.on') : t('ui.switch.off')}</span>
        </div>
      </Section>

      <Section title={t('ui.slider')} desc={t('ui.slider.desc')}>
        <div className="w-full max-w-xs space-y-2">
          <Slider
            value={[sliderValue]}
            onValueChange={(val) => setSliderValue(Array.isArray(val) ? val[0] : val)}
            min={0}
            max={100}
          />
          <p className="text-xs text-muted-foreground">{t('ui.slider')}: {sliderValue}</p>
        </div>
      </Section>

      <Section title={t('ui.input')} desc={t('ui.input.desc')}>
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={t('ui.input.placeholder')}
          className="max-w-xs"
        />
      </Section>

      <Section title={t('ui.tooltip')} desc={t('ui.tooltip.desc')}>
        <Tooltip>
          <TooltipTrigger
            render={
              <Button variant="outline" size="sm">{t('ui.tooltip.hover')}</Button>
            }
          />
          <TooltipPopup>{t('ui.tooltip.content')}</TooltipPopup>
        </Tooltip>
      </Section>

      <Section title={t('ui.dialog')} desc={t('ui.dialog.desc')}>
        <Button variant="outline" size="sm" onClick={() => setDialogOpen(true)}>
          {t('ui.dialog.open')}
        </Button>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogPopup showCloseButton={false}>
            <DialogHeader>
              <DialogTitle>{t('ui.dialog.title')}</DialogTitle>
              <DialogDescription>{t('ui.dialog.content')}</DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <DialogClose render={<Button variant="ghost" size="sm" />}>
                {t('common.close')}
              </DialogClose>
              <Button size="sm" onClick={() => setDialogOpen(false)}>
                {t('ui.dialog.confirm')}
              </Button>
            </DialogFooter>
          </DialogPopup>
        </Dialog>
      </Section>

      <div className="pt-4 text-center text-xs text-muted-foreground">
        {t('ui.coss.catalog')}{' '}
        <a
          href="https://coss.com/ui/docs"
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          coss.com/ui/docs
        </a>
      </div>
    </div>
  )
}
