import { useState, useEffect } from 'react'
import { useLocale } from '@/i18n'
import { Button } from '@/components/ui/button'
import { version } from '../../package.json'

const SOURCE_CODE_URL = 'https://codeberg.org/jsos-dev/dev.jsos.example-gui'

export default function AboutPage() {
  const { t } = useLocale()
  const [systemInfo, setSystemInfo] = useState(null)

  useEffect(() => {
    window.JSOS?.getSystemInfo?.().then(info => {
      setSystemInfo(info)
    }).catch(() => {})
  }, [])

  return (
    <div className="p-6 max-w-lg">
      <div className="flex flex-col items-center text-center mb-8">
        <div className="w-20 h-20 mb-4 rounded-2xl bg-primary/10 flex items-center justify-center">
          <span className="text-3xl font-bold text-primary">EG</span>
        </div>
        <h1 className="text-2xl font-bold mb-1">{t('app.name')}</h1>
        <p className="text-muted-foreground text-sm leading-relaxed">
          {t('about.description')}
        </p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-sm text-muted-foreground">{t('about.version')}</span>
          <span className="text-sm font-mono">v{version}</span>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-sm text-muted-foreground">{t('about.sourceCode')}</span>
          <a
            href={SOURCE_CODE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-primary hover:underline truncate max-w-[260px]"
          >
            {SOURCE_CODE_URL}
          </a>
        </div>
      </div>

      <div className="mt-8 space-y-3">
        <p className="text-sm font-medium">{t('about.getSystemInfo')}</p>
        <pre className="text-xs bg-muted/50 p-3 rounded-lg overflow-auto max-h-40">
          {systemInfo ? JSON.stringify(systemInfo, null, 2) : t('about.loading')}
        </pre>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.JSOS?.openApp?.('dev.jsos.docs')}
        >
          {t('about.jsosApiDocs')}
        </Button>
      </div>
    </div>
  )
}
