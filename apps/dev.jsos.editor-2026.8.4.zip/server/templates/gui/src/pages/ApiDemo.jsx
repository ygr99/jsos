import { useCallback } from 'react'
import { useLocale } from '@/i18n'
import { Button } from '@/components/ui/button'
import { Select, SelectTrigger, SelectValue, SelectPopup, SelectItem } from '@/components/ui/select'
import { Code } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useState } from 'react'

const themeOptions = [
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
  { value: 'system', label: 'System' },
]

const langOptions = [
  { value: 'zh-CN', label: '简体中文' },
  { value: 'en', label: 'English' },
]

const dockOptions = [
  { value: 'bottom', labelKey: 'api.dock.bottom' },
  { value: 'top', labelKey: 'api.dock.top' },
  { value: 'left', labelKey: 'api.dock.left' },
  { value: 'right', labelKey: 'api.dock.right' },
]

function CodeBlock({ code, showLabel, hideLabel }) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => setVisible(!visible)}
        className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground cursor-pointer"
      >
        {visible ? <HideIcon /> : <ShowIcon />}
        {visible ? hideLabel : showLabel}
      </button>
      {visible && (
        <pre className="mt-1 text-xs bg-muted/50 p-2 rounded overflow-auto max-h-32 border border-border font-mono leading-relaxed">{code}</pre>
      )}
    </div>
  )
}

function HideIcon() {
  return (
    <svg className="size-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
      <line x1="1" y1="1" x2="23" y2="23" />
    </svg>
  )
}

function ShowIcon() {
  return (
    <svg className="size-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function ApiSection({ title, desc, children, code, showLabel, hideLabel }) {
  return (
    <section className="rounded-lg border border-border p-4 space-y-3">
      <div>
        <div className="flex items-center gap-2">
          <Code className="size-4 text-primary" />
          <h3 className="text-sm font-medium">{title}</h3>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {children}
      </div>
      {code && <CodeBlock code={code} showLabel={showLabel} hideLabel={hideLabel} />}
    </section>
  )
}

export default function ApiDemoPage() {
  const { t } = useLocale()

  const handleToast = useCallback((type) => {
    window.JSOS?.toast?.({ title: t(`api.toast.${type}`), description: `${t('api.toast')}: ${t(`api.toast.${type}`)}`, type })
  }, [t])

  return (
    <div className="p-6 max-w-3xl space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-1">{t('api.title')}</h2>
        <p className="text-sm text-muted-foreground">{t('api.description')}</p>
      </div>

      <ApiSection
        title={t('api.toast')}
        desc={t('api.toast.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`// ${t('api.toast')}
await window.JSOS.toast({
  title: '${t('api.toast.success')}',
  description: '...',
  type: 'success'
})
// types: 'default' | 'success' | 'error' | 'info' | 'warning'
// timeout: 0 = never auto-close (default 3000ms)`}
      >
        <Button size="sm" onClick={() => handleToast('success')}>{t('api.toast.success')}</Button>
        <Button variant="destructive" size="sm" onClick={() => handleToast('error')}>{t('api.toast.error')}</Button>
        <Button variant="outline" size="sm" onClick={() => handleToast('info')}>{t('api.toast.info')}</Button>
        <Button variant="outline" size="sm" onClick={() => handleToast('warning')}>{t('api.toast.warning')}</Button>
        <Button variant="ghost" size="sm" onClick={() => handleToast('default')}>{t('api.toast.default')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.theme')}
        desc={t('api.theme.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const mode = await window.JSOS.getTheme()
// 'light' | 'dark' | 'system'

const effective = await window.JSOS.getThemeMode()
// 'light' | 'dark'

await window.JSOS.setTheme('dark')

const unsub = window.JSOS.onThemeChange(effective => {
  document.documentElement.classList.toggle('dark', effective === 'dark')
})`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const mode = await window.JSOS?.getTheme()
          window.JSOS?.toast?.({ title: `${t('api.theme')}: ${mode}`, type: 'info' })
        }}>{t('api.theme.get')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const effective = await window.JSOS?.getThemeMode()
          window.JSOS?.toast?.({ title: `Effective: ${effective}`, type: 'info' })
        }}>{t('api.theme.getMode')}</Button>
        <Select items={themeOptions} onValueChange={async (item) => {
          if (!item) return
          await window.JSOS?.setTheme(item.value)
          window.JSOS?.toast?.({ title: `${t('api.theme')}: ${item.value}`, type: 'success' })
        }}>
          <SelectTrigger className="w-36">
            <SelectValue placeholder={t('api.theme.set')} />
          </SelectTrigger>
          <SelectPopup>
            {themeOptions.map(item => (
              <SelectItem key={item.value} value={item}>{item.label}</SelectItem>
            ))}
          </SelectPopup>
        </Select>
      </ApiSection>

      <ApiSection
        title={t('api.locale')}
        desc={t('api.locale.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const locale = await window.JSOS.getLocale()
// 'zh-CN' | 'en'

await window.JSOS.setLocale('en')

const unsub = window.JSOS.onLocaleChange(newLocale => {
  console.log('Language:', newLocale)
})`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const locale = await window.JSOS?.getLocale()
          window.JSOS?.toast?.({ title: `${t('api.locale')}: ${locale}`, type: 'info' })
        }}>{t('api.locale.get')}</Button>
        <Select items={langOptions} onValueChange={async (item) => {
          if (!item) return
          await window.JSOS?.setLocale(item.value)
          window.JSOS?.toast?.({ title: `${t('api.locale')}: ${item.value}`, type: 'success' })
        }}>
          <SelectTrigger className="w-36">
            <SelectValue placeholder={t('api.locale.set')} />
          </SelectTrigger>
          <SelectPopup>
            {langOptions.map(item => (
              <SelectItem key={item.value} value={item}>{item.label}</SelectItem>
            ))}
          </SelectPopup>
        </Select>
      </ApiSection>

      <ApiSection
        title={t('api.appManagement')}
        desc={t('api.appManagement.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const apps = await window.JSOS.getApps()

const info = await window.JSOS.getAppInfo('dev.jsos.settings')

const result = await window.JSOS.openApp('dev.jsos.settings', {
  route: '/wallpaper',
  params: { workspaceId: 'home' }
})

const { running } = await window.JSOS.isAppRunning('terminal-app')

await window.JSOS.closeAppWindow()`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const apps = await window.JSOS?.getApps()
          const running = apps?.filter(a => a.isRunning).length || 0
          window.JSOS?.toast?.({ title: `Apps: ${apps?.length || 0}, ${running} running`, type: 'info' })
        }}>{t('api.appManagement.getApps')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const info = await window.JSOS?.getAppInfo?.('dev.jsos.example-gui')
          window.JSOS?.toast?.({ title: `v${info?.version}`, type: 'info' })
        }}>{t('api.appManagement.getAppInfo')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const { running } = await window.JSOS?.isAppRunning?.('dev.jsos.example-gui') || {}
          window.JSOS?.toast?.({ title: `Running: ${running}`, type: 'info' })
        }}>{t('api.appManagement.isRunning')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const result = await window.JSOS?.openApp?.('dev.jsos.settings', { route: '/theme' })
          if (result?.success) window.JSOS?.toast?.({ title: 'Settings opened', type: 'success' })
        }}>{t('api.appManagement.openApp')}</Button>
        <Button variant="ghost" size="sm" onClick={() => window.JSOS?.closeAppWindow()}>{t('api.appManagement.closeWindow')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.workspace')}
        desc={t('api.workspace.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const workspaces = await window.JSOS.getWorkspaces()

const ws = await window.JSOS.getCurrentWorkspace()

await window.JSOS.switchWorkspace('ws-123456')

const r = await window.JSOS.createWorkspace('My Workspace')

await window.JSOS.renameWorkspace('ws-123456', 'New Name')`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const ws = await window.JSOS?.getWorkspaces()
          window.JSOS?.toast?.({ title: `Workspaces: ${ws?.length || 0}`, type: 'info' })
        }}>{t('api.workspace.list')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const ws = await window.JSOS?.getCurrentWorkspace()
          window.JSOS?.toast?.({ title: `${ws?.name}`, type: 'info' })
        }}>{t('api.workspace.current')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.dock')}
        desc={t('api.dock.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const { position } = await window.JSOS.getDockSettings()

await window.JSOS.setDockSettings({ position: 'left' })
// 'bottom' | 'top' | 'left' | 'right'`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const settings = await window.JSOS?.getDockSettings()
          window.JSOS?.toast?.({ title: `${t('api.dock')}: ${settings?.position}`, type: 'info' })
        }}>{t('api.dock.get')}</Button>
        <Select
          items={dockOptions}
          onValueChange={async (item) => {
            if (!item) return
            await window.JSOS?.setDockSettings({ position: item.value })
            window.JSOS?.toast?.({ title: `${t('api.dock')}: ${item.value}`, type: 'success' })
          }}
        >
          <SelectTrigger className="w-36">
            <SelectValue placeholder={t('api.dock.set')} />
          </SelectTrigger>
          <SelectPopup>
            {dockOptions.map(item => (
              <SelectItem key={item.value} value={item}>{t(item.labelKey)}</SelectItem>
            ))}
          </SelectPopup>
        </Select>
      </ApiSection>

      <ApiSection
        title={t('api.terminal')}
        desc={t('api.terminal.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const { opacity, blur } = await window.JSOS.getTerminalBgSettings()

await window.JSOS.setTerminalBgSettings({ opacity: 80, blur: 15 })
// opacity: 0-100, blur: 0-30`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const settings = await window.JSOS?.getTerminalBgSettings()
          window.JSOS?.toast?.({ title: `opacity=${settings?.opacity}, blur=${settings?.blur}`, type: 'info' })
        }}>{t('api.terminal.get')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.wallpaper')}
        desc={t('api.wallpaper.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const wp = await window.JSOS.getWallpaper()

await window.JSOS.setWallpaper({
  type: 'image',
  data: 'base64...',
  mimeType: 'image/jpeg',
  overlay: 'rgba(0,0,0,0.3)',
  overlayOpacity: 30,
  blur: 5
})

await window.JSOS.resetWallpaper()`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const wp = await window.JSOS?.getWallpaper()
          window.JSOS?.toast?.({ title: `${t('api.wallpaper')}: ${wp?.type}`, type: 'info' })
        }}>{t('api.wallpaper.get')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.proxy')}
        desc={t('api.proxy.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const config = await window.JSOS.getProxyConfig()

await window.JSOS.setProxyConfig({
  url: 'https://cors-proxy.example.com',
  key: 'your-api-key'
})

const result = await window.JSOS.proxyFetch(
  'https://api.example.com/data',
  { method: 'GET' }
)`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const config = await window.JSOS?.getProxyConfig?.()
          window.JSOS?.toast?.({ title: config ? `Proxy: ${config.url}` : 'No proxy', type: 'info' })
        }}>{t('api.proxy.get')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.systemInfo')}
        desc={t('api.systemInfo.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const { version } = await window.JSOS.getSystemInfo()

const storage = await window.JSOS.getStorageInfo()
// { quota, usage, usageDetails, persistent }`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          const info = await window.JSOS?.getSystemInfo?.()
          window.JSOS?.toast?.({ title: `JSOS v${info?.version}`, type: 'info' })
        }}>{t('api.systemInfo.get')}</Button>
        <Button variant="outline" size="sm" onClick={async () => {
          const storage = await window.JSOS?.getStorageInfo?.()
          if (storage) {
            const usageMB = (storage.usage / 1024 / 1024).toFixed(1)
            const quotaMB = (storage.quota / 1024 / 1024).toFixed(1)
            window.JSOS?.toast?.({ title: `Storage: ${usageMB}MB / ${quotaMB}MB`, type: 'info' })
          }
        }}>{t('api.systemInfo.storage')}</Button>
      </ApiSection>

      <ApiSection
        title={t('api.backup')}
        desc={t('api.backup.desc')}
        showLabel={t('api.showCode')}
        hideLabel={t('api.hideCode')}
        code={`const data = await window.JSOS.exportAllData()

const result = await window.JSOS.importAllData(backupData)
// WARNING: clears all existing data!

await window.JSOS.clearAllData()
await window.JSOS.restart()`}
      >
        <Button variant="outline" size="sm" onClick={async () => {
          try {
            const data = await window.JSOS?.exportAllData?.()
            window.JSOS?.toast?.({ title: `Exported ${Object.keys(data?.databases || {}).length} databases`, type: 'success' })
          } catch { window.JSOS?.toast?.({ title: 'Export failed', type: 'error' }) }
        }}>{t('api.backup.export')}</Button>
      </ApiSection>

      <div className="pt-4 text-center text-xs text-muted-foreground">
        {t('api.summary')}
      </div>
    </div>
  )
}
