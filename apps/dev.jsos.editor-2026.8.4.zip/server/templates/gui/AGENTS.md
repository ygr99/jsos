# AGENTS.md — `dev.jsos.example-gui`

## Quick start

```bash
npm install        # no postinstall needed
npm run dev        # Vite dev server (no backend)
npm run build:jsos-app   # produces dev.jsos.example-gui-<version>.zip
npm start          # node server.js — serves dist/ + /api/notes REST API
```

## Architecture

- **React 19** SPA via Vite 6, hash router (`react-router-dom`), Tailwind 4, **coss-ui** components (`@base-ui/react`)
- **No tests, no linter, no typecheck** — zero test/lint/typecheck infra
- Entry: `index.html` → `src/main.jsx` → `src/App.jsx`
- UI components live in `src/components/ui/` — use CVA variants, `@base-ui/react` primitives (`useRender`, `mergeProps`), `@/lib/utils` for `cn()` (clsx + twMerge)
- i18n: custom `LocaleProvider` in `src/i18n/` — keys in JS files, not JSON. Fallback always `en`. Call `t(key)` from `useLocale()`
- Path alias `@` → `./src` (in `vite.config.js`)

## JSOS-specific rules

- All `window.JSOS.*` calls **must** be guarded with optional chaining — they are undefined outside JSOS or during dev
- App runs inside JSOS desktop, not standalone. Use hash routing (`/#/path`).
- Theme: `.dark` class on `<html>` toggled via `JSOS.getTheme()` / `JSOS.onThemeChange()`
- Widget routes (`/widget/*`) render **without sidebar** — detect in `App.jsx` via `location.pathname.startsWith('/widget')`
- Widgets declared in `package.json#jsos.widgets` — `cols`/`rows` for grid sizing (104px cells), `background` supports `"frosted"` (default), `"solid"`, `"transparent"`
- Production server (`server.js`): serves `dist/`, exposes `/api/notes` CRUD endpoints, persists to `DATA_DIR/notes.json` (defaults to `./data/`)

## Build artifact oddity

`build:jsos-app` temporarily **mutates** `package.json` (strips `devDependencies`) then restores it from a backup. Never interrupt this script.

## Data layer

- REST API: `GET/POST /api/notes`, `GET/PUT/DELETE /api/notes/:id`, `DELETE /api/notes` (bulk, body: `{ids: [...]}`)
- Persistence: JSON file at `DATA_DIR/notes.json` (server-side only). No client-side storage.
