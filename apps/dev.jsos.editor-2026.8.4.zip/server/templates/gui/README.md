# GUI Example

A comprehensive JSOS GUI application demonstrating development patterns, API integration, and UI component usage.

## Features

- Sidebar navigation with multiple pages
- JSOS API demo (Toast, Theme, Locale, App Management, Workspace, Dock, Terminal, Wallpaper, Proxy, System Info, Backup)
- Data Storage CRUD with server-side JSON persistence
- UI component showcase (coss-ui)
- Desktop widget (Widget Guide)
- i18n (English / Chinese) with live locale switching
- Dark / light theme support

## Getting Started

```bash
npm install
npm run dev
```

Open the app via JSOS desktop or navigate to the assigned port.

## Build

```bash
npm run build:jsos-app
```

Produces `dev.jsos.example-gui-<version>.zip` at the project root.

## License

MIT
