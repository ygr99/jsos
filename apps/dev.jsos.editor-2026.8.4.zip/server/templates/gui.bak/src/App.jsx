export default function App() {
  return (
    <div className="h-full flex items-center justify-center text-foreground">
      <h1>Hello JSOS!</h1>
    </div>
  )
}
