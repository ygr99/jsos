import { join, relative, sep } from 'path';
import fs from 'fs';

export function safePath(base, userPath) {
  const resolved = join(base, userPath);
  if (!resolved.startsWith(base + sep) && resolved !== base) return null;
  if (resolved.includes('\0')) return null;
  return resolved;
}

export function listDir(dirPath, baseDir) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  const items = [];
  for (const entry of entries) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = join(dirPath, entry.name);
    const relPath = relative(baseDir, fullPath);
    if (entry.isDirectory()) {
      items.push({ name: entry.name, path: relPath, type: 'directory', children: [] });
    } else {
      const stat = fs.statSync(fullPath);
      items.push({ name: entry.name, path: relPath, type: 'file', size: stat.size });
    }
  }
  items.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return items;
}

function sortTreeChildren(children) {
  children.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  for (const child of children) {
    if (child.children) sortTreeChildren(child.children);
  }
}

export function buildFileTree(baseDir) {
  const tree = { name: '.', path: '', type: 'directory', children: [] };
  function walk(dir, node) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const fullPath = join(dir, entry.name);
      const relPath = relative(baseDir, fullPath);
      if (entry.isDirectory()) {
        const child = { name: entry.name, path: relPath, type: 'directory', children: [] };
        node.children.push(child);
        walk(fullPath, child);
      } else {
        const stat = fs.statSync(fullPath);
        node.children.push({ name: entry.name, path: relPath, type: 'file', size: stat.size });
      }
    }
  }
  walk(baseDir, tree);
  sortTreeChildren(tree.children);
  return tree;
}
