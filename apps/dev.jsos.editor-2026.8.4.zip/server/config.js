import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

export const ROOT = join(__dirname, '..', 'dist');
export const DATA_DIR = process.env.DATA_DIR || join(__dirname, '..', 'data');
export const PROJECTS_DIR = join(DATA_DIR, 'projects');
