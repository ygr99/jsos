import { join, dirname } from 'path';
import fs from 'fs';
import { safePath, buildFileTree } from '../utils.js';
import { PROJECTS_DIR } from '../config.js';

export default function (app) {
  app.get('/api/files', (req, res) => {
    try {
      const project = req.query.project || '';
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath || !fs.existsSync(projectPath)) {
        return res.json({ tree: { name: '.', path: '', type: 'directory', children: [] } });
      }
      const tree = buildFileTree(projectPath);
      res.json({ tree });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/files/read', (req, res) => {
    try {
      const project = req.query.project || '';
      const file = req.query.file || '';
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project' });
      const filePath = safePath(projectPath, file);
      if (!filePath) return res.status(400).json({ error: 'Invalid file path' });
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
        return res.status(404).json({ error: 'File not found' });
      }
      const content = fs.readFileSync(filePath, 'utf8');
      const ext = file.split('.').pop();
      res.json({ content, ext });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/files/write', (req, res) => {
    try {
      const { project, file, content } = req.body;
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project' });
      const filePath = safePath(projectPath, file);
      if (!filePath) return res.status(400).json({ error: 'Invalid file path' });
      fs.mkdirSync(dirname(filePath), { recursive: true });
      fs.writeFileSync(filePath, content, 'utf8');
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/files/rename', (req, res) => {
    try {
      const { project, file, newName } = req.body;
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project' });
      const filePath = safePath(projectPath, file);
      if (!filePath) return res.status(400).json({ error: 'Invalid file path' });
      const newPath = safePath(dirname(filePath), newName);
      if (!newPath) return res.status(400).json({ error: 'Invalid new name' });
      fs.renameSync(filePath, newPath);
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/files/delete', (req, res) => {
    try {
      const { project, file } = req.body;
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project' });
      const filePath = safePath(projectPath, file);
      if (!filePath) return res.status(400).json({ error: 'Invalid file path' });
      if (fs.statSync(filePath).isDirectory()) {
        fs.rmSync(filePath, { recursive: true });
      } else {
        fs.unlinkSync(filePath);
      }
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/files/mkdir', (req, res) => {
    try {
      const { project, path: dirPath } = req.body;
      const projectPath = safePath(PROJECTS_DIR, project);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project' });
      const targetPath = safePath(projectPath, dirPath);
      if (!targetPath) return res.status(400).json({ error: 'Invalid path' });
      fs.mkdirSync(targetPath, { recursive: true });
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
}
