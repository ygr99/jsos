import { join, dirname } from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { safePath } from '../utils.js';
import { PROJECTS_DIR, DATA_DIR } from '../config.js';
import { createTemplate } from '../template.js';

export default function (app) {
  app.get('/api/projects', (req, res) => {
    try {
      if (!fs.existsSync(PROJECTS_DIR)) {
        fs.mkdirSync(PROJECTS_DIR, { recursive: true });
        return res.json({ projects: [] });
      }
      const projects = fs.readdirSync(PROJECTS_DIR, { withFileTypes: true })
        .filter(d => d.isDirectory() && !d.name.startsWith('.'))
        .map(d => {
          const pkgPath = join(PROJECTS_DIR, d.name, 'package.json');
          let manifest = null;
          if (fs.existsSync(pkgPath)) {
            try {
              manifest = JSON.parse(fs.readFileSync(pkgPath, 'utf8')).jsos || null;
            } catch {}
          }
          return { id: d.name, name: d.name, manifest };
        });
      res.json({ projects });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/projects', (req, res) => {
    try {
      const { name, type } = req.body;
      if (!name || !type) return res.status(400).json({ error: 'name and type required' });
      const projectPath = safePath(PROJECTS_DIR, name);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project name' });
      if (fs.existsSync(projectPath)) return res.status(409).json({ error: 'Project already exists' });
      fs.mkdirSync(projectPath, { recursive: true });
      const template = createTemplate(type);
      for (const [filePath, content] of Object.entries(template)) {
        const fullPath = join(projectPath, filePath);
        fs.mkdirSync(dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, content, 'utf8');
      }
      res.json({ success: true, project: name });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/projects/delete', (req, res) => {
    try {
      const { name } = req.body;
      if (!name) return res.status(400).json({ error: 'name required' });
      const projectPath = safePath(PROJECTS_DIR, name);
      if (!projectPath) return res.status(400).json({ error: 'Invalid project name' });
      if (!fs.existsSync(projectPath)) return res.status(404).json({ error: 'Project not found' });
      fs.rmSync(projectPath, { recursive: true });
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/projects/zip', (req, res) => {
    try {
      const { project: projectName } = req.body;
      if (!projectName) return res.status(400).json({ error: 'project required' });
      const projectPath = safePath(PROJECTS_DIR, projectName);
      if (!projectPath || !fs.existsSync(projectPath)) {
        return res.status(404).json({ error: 'Project not found' });
      }
      const zipPath = join(DATA_DIR, `${projectName}.zip`);
      execSync(`cd "${projectPath}" && zip -r "${zipPath}" . -x "node_modules/*" ".git/*"`, { stdio: 'pipe' });
      const data = fs.readFileSync(zipPath);
      fs.unlinkSync(zipPath);
      res.json({ data: Array.from(data), fileName: `${projectName}.zip` });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
}
