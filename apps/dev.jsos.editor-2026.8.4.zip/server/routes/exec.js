import { execSync } from 'child_process';
import { safePath } from '../utils.js';
import { PROJECTS_DIR, DATA_DIR } from '../config.js';

export default function (app) {
  app.post('/api/exec', (req, res) => {
    try {
      const { command, project } = req.body;
      if (!command) return res.status(400).json({ error: 'command required' });
      const cwd = project ? safePath(PROJECTS_DIR, project) : DATA_DIR;
      if (!cwd) return res.status(400).json({ error: 'Invalid project' });
      const output = execSync(command, { cwd, encoding: 'utf8', timeout: 30000, maxBuffer: 1024 * 1024 });
      res.json({ output, exitCode: 0 });
    } catch (e) {
      const output = e.stdout || '';
      const stderr = e.stderr || '';
      res.json({ output: output + stderr, exitCode: e.status || 1 });
    }
  });

  app.get('/api/proxy', async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ error: 'url required' });
      const response = await fetch(url);
      const text = await response.text();
      res.json({ data: text, ok: response.ok, status: response.status });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
}
