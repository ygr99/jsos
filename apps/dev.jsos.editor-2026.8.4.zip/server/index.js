import express from 'express';
import { join } from 'path';
import { createServer } from 'http';
import { ROOT, DATA_DIR } from './config.js';
import setupFilesRoutes from './routes/files.js';
import setupProjectsRoutes from './routes/projects.js';
import setupExecRoutes from './routes/exec.js';
import { setupFileWatcher } from './fileWatcher.js';

const app = express();
app.use(express.json({ limit: '50mb' }));

// 暴露配置给客户端（dataDir 用于终端 cwd）
app.get('/api/config', (req, res) => {
  res.json({ dataDir: DATA_DIR });
});

setupFilesRoutes(app);
setupProjectsRoutes(app);
setupExecRoutes(app);
setupFileWatcher(app);

app.use(express.static(ROOT));
app.get('*', (req, res) => {
  res.sendFile(join(ROOT, 'index.html'));
});

const server = createServer(app);

server.listen(process.env.PORT || 3000, () => {
  console.log(process.env.PORT || 3000);
});
