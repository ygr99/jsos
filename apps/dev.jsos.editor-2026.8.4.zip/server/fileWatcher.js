import fs from 'fs';
import { join, relative } from 'path';
import { safePath } from './utils.js';
import { PROJECTS_DIR } from './config.js';

const watchers = new Map();
const clients = new Map();

function debounce(fn, delay) {
  let timer = null;
  return (...args) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function startWatching(project) {
  if (watchers.has(project)) {
    watchers.get(project).refCount++;
    return watchers.get(project).watcher;
  }

  const projectPath = safePath(PROJECTS_DIR, project);
  if (!projectPath || !fs.existsSync(projectPath)) return null;

  const pendingEvents = new Map();

  const flushEvents = () => {
    for (const [event, paths] of pendingEvents) {
      const uniquePaths = [...new Set(paths)];
      const data = JSON.stringify({ type: 'file-change', event, paths: uniquePaths, project });
      for (const [res, client] of clients) {
        if (!client.closed && client.project === project) {
          res.write(`data: ${data}\n\n`);
        }
      }
    }
    pendingEvents.clear();
  };

  const debouncedFlush = debounce(flushEvents, 300);

  const addEvent = (event, filePath) => {
    const relPath = relative(projectPath, filePath);
    if (relPath.includes('node_modules') || relPath.startsWith('.')) return;

    if (!pendingEvents.has(event)) pendingEvents.set(event, []);
    pendingEvents.get(event).push(relPath);
    debouncedFlush();
  };

  let watcher;
  try {
    watcher = fs.watch(projectPath, { recursive: true }, (eventType, filename) => {
      if (!filename) return;
      const fullPath = join(projectPath, filename);

      try {
        if (fs.existsSync(fullPath)) {
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) return;
          addEvent('change', fullPath);
        } else {
          addEvent('delete', fullPath);
        }
      } catch {
        addEvent('delete', fullPath);
      }
    });
  } catch (e) {
    console.error(`Failed to watch project ${project}:`, e.message);
    return null;
  }

  watchers.set(project, { watcher, refCount: 1 });
  return watcher;
}

function stopWatching(project) {
  const entry = watchers.get(project);
  if (!entry) return;

  entry.refCount--;
  if (entry.refCount <= 0) {
    entry.watcher.close();
    watchers.delete(project);
  }
}

export function setupFileWatcher(app) {
  app.get('/api/file-watch', (req, res) => {
    const project = req.query.project || '';

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });

    res.write(':ok\n\n');

    const client = { project, closed: false };
    clients.set(res, client);

    if (project) {
      startWatching(project);
    }

    const heartbeat = setInterval(() => {
      if (!client.closed) {
        res.write(':ping\n\n');
      }
    }, 30000);

    req.on('close', () => {
      client.closed = true;
      clients.delete(res);
      clearInterval(heartbeat);
      if (client.project) {
        stopWatching(client.project);
      }
    });
  });
}
