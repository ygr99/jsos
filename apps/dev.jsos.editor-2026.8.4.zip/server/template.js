import { readdirSync, readFileSync, statSync } from 'fs';
import { join, relative, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = join(__dirname, 'templates');

const defaults = {
  gui: { id: 'com.example.myapp', name: 'My App' },
  cli: { id: 'com.example.myapp', name: 'my-cli-tool' },
};

function readDirRecursive(dir, baseDir, vars) {
  const files = {};
  for (const entry of readdirSync(dir)) {
    const fullPath = join(dir, entry);
    const relPath = relative(baseDir, fullPath);
    if (statSync(fullPath).isDirectory()) {
      Object.assign(files, readDirRecursive(fullPath, baseDir, vars));
    } else {
      let content = readFileSync(fullPath, 'utf-8');
      for (const [key, val] of Object.entries(vars)) {
        content = content.replaceAll(`{{${key}}}`, val);
      }
      files[relPath] = content;
    }
  }
  return files;
}

export function createTemplate(type) {
  const templateDir = join(TEMPLATES_DIR, type);
  if (!statSync(templateDir).isDirectory()) {
    throw new Error(`Unknown template type: ${type}`);
  }
  const vars = defaults[type] || {};
  return readDirRecursive(templateDir, templateDir, vars);
}
