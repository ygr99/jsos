import express from 'express';
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>日期时间</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:#1e1e2e;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none}
#clock{text-align:center;font-size:3.5rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.3)}
@media(max-width:480px){#clock{font-size:2rem}}
</style>
</head>
<body>
<div id="clock"></div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  document.getElementById('clock').textContent=y+'年'+mo+'月'+da+'日 '+wd+wn+'周 '+h+':'+mi;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

app.get('/widget/clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:transparent;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none;overflow:hidden}
#clock{text-align:center}
.date{font-size:1rem;font-weight:500;opacity:.85;letter-spacing:1px}
.time{font-size:2.8rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.4);line-height:1.2}
.seconds{font-size:1.2rem;font-weight:400;opacity:.6;margin-left:4px}
</style>
</head>
<body>
<div id="clock">
  <div class="date" id="date"></div>
  <div class="time"><span id="time"></span><span class="seconds" id="seconds"></span></div>
</div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  const s=String(n.getSeconds()).padStart(2,'0');
  document.getElementById('date').textContent=y+'\u5E74'+mo+'\u6708'+da+'\u65E5 '+wd+wn+'\u5468';
  document.getElementById('time').textContent=h+':'+mi;
  document.getElementById('seconds').textContent=s;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

// 模拟时钟小组件（3×3 格 = 304px 见方）
// 写实路线：普通家用挂钟 —— 白塑料外壳 + 米白纸面 + 黑色粗体数字 + 黑漆时针分针 + 红秒针，
// 加弧面玻璃高光/边缘内阴影、指针在纸面上的投影、整机悬浮投影。**背景全透明**，桌面上只浮着一只钟。
// 写实参照：jsos-apps/toolbox/public/tools/airConditioner（白塑机身 + 真实投影 + 实物质感的大方向）。
// 尺寸表（viewBox 200，圆心 100）：外壳 r88 / 玻璃压圈 r83 / 纸面 r82 / 刻度 68~78 / 数字环 r57 /
// 时针 0.52Rd、分针 0.72Rd、秒针 0.78Rd（Rd=82）。刻度与数字由脚本生成，避免手写 60 行。
app.get('/widget/analog-clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>模拟时钟</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{background:transparent;overflow:hidden;-webkit-user-select:none;user-select:none;display:flex;align-items:center;justify-content:center}
svg{display:block;width:100%;height:100%;filter:drop-shadow(0 2px 3px rgba(16,20,26,.30)) drop-shadow(0 7px 13px rgba(16,20,26,.18))}
</style>
</head>
<body>
<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
<defs>
<linearGradient id="ck-case" x1="0.12" y1="0" x2="0.72" y2="1">
<stop offset="0" stop-color="#ffffff"/>
<stop offset="0.4" stop-color="#f5f7f9"/>
<stop offset="0.76" stop-color="#e4e8ec"/>
<stop offset="1" stop-color="#cbd1d8"/>
</linearGradient>
<radialGradient id="ck-dial" cx="0.42" cy="0.33" r="0.92">
<stop offset="0" stop-color="#fffefc"/>
<stop offset="0.58" stop-color="#f8f6f1"/>
<stop offset="0.86" stop-color="#eeebe4"/>
<stop offset="1" stop-color="#dfdcd2"/>
</radialGradient>
<radialGradient id="ck-vin" cx="0.5" cy="0.5" r="0.5">
<stop offset="0.66" stop-color="#0b0d10" stop-opacity="0"/>
<stop offset="1" stop-color="#0b0d10" stop-opacity="0.20"/>
</radialGradient>
<linearGradient id="ck-gloss" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#ffffff" stop-opacity="0.60"/>
<stop offset="0.45" stop-color="#ffffff" stop-opacity="0.16"/>
<stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
</linearGradient>
<linearGradient id="ck-hand" x1="0" y1="0" x2="1" y2="0">
<stop offset="0" stop-color="#3c424a"/>
<stop offset="0.26" stop-color="#0f1215"/>
<stop offset="0.56" stop-color="#2e343c"/>
<stop offset="1" stop-color="#090b0e"/>
</linearGradient>
<radialGradient id="ck-cap" cx="0.34" cy="0.27" r="0.88">
<stop offset="0" stop-color="#aab1ba"/>
<stop offset="0.5" stop-color="#535a64"/>
<stop offset="1" stop-color="#1d2127"/>
</radialGradient>
<clipPath id="ck-dial-clip"><circle cx="100" cy="100" r="82"/></clipPath>
</defs>

<circle id="ck-body" cx="100" cy="100" r="88" fill="url(#ck-case)"/>
<circle cx="100" cy="100" r="88" fill="none" stroke="#b3b9c1" stroke-width="0.7"/>
<circle cx="100" cy="100" r="83" fill="none" stroke="#a6adb6" stroke-width="1.6"/>
<circle cx="100" cy="100" r="82" fill="url(#ck-dial)"/>

<g id="ck-ticks"></g>
<g id="ck-nums" text-anchor="middle" font-family="'Segoe UI','Microsoft YaHei',system-ui,sans-serif" font-weight="600" font-size="20" fill="#1c2024"></g>
<text x="100" y="64" text-anchor="middle" font-family="'Segoe UI',system-ui,sans-serif" font-size="4.2" letter-spacing="1.4" fill="#a9b0b8">JSOS</text>

<circle cx="100" cy="100" r="82" fill="url(#ck-vin)"/>
<g clip-path="url(#ck-dial-clip)">
<ellipse cx="56" cy="42" rx="78" ry="52" fill="url(#ck-gloss)" transform="rotate(-26 56 42)"/>
<ellipse cx="152" cy="152" rx="54" ry="27" fill="url(#ck-gloss)" opacity="0.3" transform="rotate(-26 152 152)"/>
</g>

<g id="ck-needles" style="filter:drop-shadow(0.6px 0.9px 0.45px rgba(0,0,0,.34))">
<path id="ck-hour" d="M96.6,104.5 A3.4,3.4 0 0 1 103.4,104.5 L101.7,55 A1.7,1.7 0 0 0 98.3,55 Z" fill="url(#ck-hand)"/>
<path id="ck-minute" d="M97.2,111.5 A2.8,2.8 0 0 1 102.8,111.5 L101.3,26 A1.3,1.3 0 0 0 98.7,26 Z" fill="url(#ck-hand)"/>
<circle cx="100" cy="100" r="5" fill="url(#ck-cap)"/>
<circle cx="98.2" cy="98.2" r="1.4" fill="#ffffff" opacity="0.5"/>
</g>

<g id="ck-second">
<line x1="100" y1="22" x2="100" y2="113" stroke="#cf2b21" stroke-width="1.1"/>
<circle cx="100" cy="106" r="2.6" fill="#cf2b21"/>
<circle cx="100" cy="100" r="2.7" fill="#cf2b21"/>
</g>
</svg>
<script>
(function(){
  var C=100,NS='http://www.w3.org/2000/svg';
  var ticks=document.getElementById('ck-ticks');
  for(var i=0;i<60;i++){
    var hour=i%5===0, a=i*6*Math.PI/180, r1=hour?68:73, r2=78;
    var l=document.createElementNS(NS,'line');
    l.setAttribute('x1',(C+r1*Math.sin(a)).toFixed(2));
    l.setAttribute('y1',(C-r1*Math.cos(a)).toFixed(2));
    l.setAttribute('x2',(C+r2*Math.sin(a)).toFixed(2));
    l.setAttribute('y2',(C-r2*Math.cos(a)).toFixed(2));
    l.setAttribute('stroke',hour?'#1c2024':'#454b53');
    l.setAttribute('stroke-width',hour?3.2:1.1);
    l.setAttribute('stroke-linecap',hour?'butt':'round');
    ticks.appendChild(l);
  }
  var nums=document.getElementById('ck-nums');
  for(var h=1;h<=12;h++){
    var b=h*30*Math.PI/180;
    var t=document.createElementNS(NS,'text');
    t.setAttribute('x',(C+57*Math.sin(b)).toFixed(2));
    t.setAttribute('y',(C-57*Math.cos(b)).toFixed(2));
    t.setAttribute('dy','0.35em');
    t.textContent=String(h);
    nums.appendChild(t);
  }
  var hourHand=document.getElementById('ck-hour');
  var minuteHand=document.getElementById('ck-minute');
  var secondHand=document.getElementById('ck-second');
  var timer=null;
  function rotate(el,deg){el.setAttribute('transform','rotate('+deg.toFixed(2)+' '+C+' '+C+')');}
  function tick(){
    var n=new Date();
    var s=n.getSeconds()+n.getMilliseconds()/1000;
    var mi=n.getMinutes();
    var h=n.getHours()%12;
    rotate(secondHand,s*6);
    rotate(minuteHand,(mi+s/60)*6);
    rotate(hourHand,(h+mi/60)*30);
    timer=setTimeout(tick,1000-(Date.now()%1000)+5);
  }
  // 标签页被切走时定时器会被节流，回来时立刻对时（保持单条定时链）
  document.addEventListener('visibilitychange',function(){
    if(!document.hidden){clearTimeout(timer);tick();}
  });
  tick();
})();
</script>
</body>
</html>`);
});

app.listen(port, () => console.log(`running on ${port}`));
