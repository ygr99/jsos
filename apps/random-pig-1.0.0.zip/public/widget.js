/**
 * 小猪 · 小组件逻辑（today 2×2 / story 2×3）
 * ---------------------------------------------------------------
 * 今日猪（?w=today）：当天固定，服务端按本地日期定一只，点一下换「随机一只」（不破坏今日运势）。
 * 故事（?w=story）：每次刷新随机换一句。
 *
 * 掉线自愈（AGENTS.md §5.3）：失败后起心跳、恢复即停、连续 3 次失败才向平台上报
 * __jsos_widget_recover。心跳打的是 /api/ping（亚毫秒、不出网），
 * ⚠️ 间隔从可注入的 sessionStorage 读，不要覆写 setTimeout（会连带影响 CSS 动画）。
 * ⚠️ 不用 JSOS.openApp兜底（必定弹窗口），也不用整页 location.reload。
 */
(() => {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const params = new URLSearchParams(location.search);
  const variant = params.get('w') === 'story' ? 'story' : 'today';
  document.body.dataset.w = variant;

  const els = {
    img: $('#wImg'),
    ph: $('#wPh'),
    name: $('#wName'),
    desc: $('#wDesc'),
    story: $('#wStory'),
    loading: $('#wLoading'),
  };

  // story 变体把图与名并排，正文移到整行下方（正文字宽优先，挤在图右侧会糊）
  if (variant === 'story') {
    const card = $('.w-card');
    const head = document.createElement('div');
    head.className = 'w-head';
    head.appendChild($('.w-art'));
    head.appendChild($('.w-text'));
    card.insertBefore(head, els.story); // ⚠️ 必须 insertBefore：append 会排到 .w-story 之后，
  }                                     //    结果正文出现在图上方（顺序反了）

  const HEARTBEAT_MS = Number(sessionStorage.getItem('__test_heartbeat_ms')) || 20000;
  const FAIL_THRESHOLD = 3;
  let fails = 0;
  let timer = null;
  let busy = false;

  async function getJSON(url) {
    const res = await fetch(url, { cache: 'no-store' });
    const text = await res.text();
    if (!res.ok) throw new Error(text.slice(0, 60) || `HTTP ${res.status}`);
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error(text.includes('.localservice@no-server') ? 'backend down' : 'bad json');
    }
    if (!data || data.ok !== true) throw new Error(data?.error || 'failed');
    return data;
  }

  function render(pig, note) {
    els.name.textContent = pig.name || '小猪';
    els.desc.textContent = pig.description || '';
    els.desc.hidden = !pig.description;
    if (els.story) els.story.textContent = pig.analysis || '';

    els.img.hidden = false;
    els.ph.hidden = true;
    els.img.alt = pig.name || '小猪';
    els.img.onerror = () => {
      els.img.hidden = true;
      els.ph.hidden = false;
      els.ph.textContent = (pig.name || '猪').slice(0, 1);
    };
    els.img.src = `/api/pig/img/${encodeURIComponent(pig.id)}`;
    if (note) els.desc.textContent = note;
  }

  async function load() {
    if (busy) return;
    busy = true;
    try {
      const data = variant === 'today'
        ? await getJSON('/api/pig/today')
        : await getJSON('/api/pig/random');
      render(data.pig, variant === 'today' ? data.date : '');
      els.loading.hidden = true;
      stopHeartbeat();
    } catch {
      fail();
    } finally {
      busy = false;
    }
  }

  /* --------------------- 掉线自愈 --------------------- */

  function fail() {
    if (els.loading && !els.name.textContent.trim()) els.loading.hidden = false;
    fails += 1;
    if (fails >= FAIL_THRESHOLD && !timer) startHeartbeat();
  }

  function startHeartbeat() {
    timer = setInterval(async () => {
      try {
        const res = await fetch('/api/ping', { cache: 'no-store' });
        await res.text();
        stopHeartbeat();
        load();
      } catch {
        if (fails >= FAIL_THRESHOLD) {
          parent.postMessage({ type: '__jsos_widget_recover', appId: 'random-pig' }, '*');
        }
      }
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat() {
    if (timer) clearInterval(timer);
    timer = null;
    fails = 0;
  }

  els.img.addEventListener('click', (e) => {
    e.stopPropagation();
    load(); // 点击换一只
  });
  els.name.addEventListener('click', (e) => {
    e.stopPropagation();
    load();
  });

  load();
})();