#!/bin/jsh
# Pi Agent 启动脚本：进入数据目录，缺装补装，启动 pi
# 供应商与模型在 pi 内部配置（/model），API key 按 pi 提示配置
cd $DATA_DIR
pi --version >/dev/null 2>&1 || npm install -g @earendil-works/pi-coding-agent@latest
pi
