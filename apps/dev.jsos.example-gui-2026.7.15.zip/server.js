import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const NOTES_PATH = path.join(DATA_DIR, 'notes.json');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function readNotes() {
  try {
    if (!fs.existsSync(NOTES_PATH)) {
      fs.writeFileSync(NOTES_PATH, '[]', 'utf8');
      return [];
    }
    return JSON.parse(fs.readFileSync(NOTES_PATH, 'utf8'));
  } catch {
    return [];
  }
}

function writeNotes(notes) {
  fs.writeFileSync(NOTES_PATH, JSON.stringify(notes, null, 2), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  if (pathname === '/api/notes') {
    try {
      const notes = readNotes();
      if (req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(notes));
      }
      if (req.method === 'POST') {
        const body = JSON.parse(await readBody(req));
        const note = {
          id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
          title: body.title || 'Untitled',
          content: body.content || '',
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        notes.push(note);
        writeNotes(notes);
        res.writeHead(201, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(note));
      }
      if (req.method === 'DELETE') {
        const ids = JSON.parse(await readBody(req)).ids || [];
        const filtered = notes.filter(n => !ids.includes(n.id));
        writeNotes(filtered);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ deleted: notes.length - filtered.length }));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (pathname.startsWith('/api/notes/')) {
    try {
      const noteId = pathname.split('/').pop();
      const notes = readNotes();
      if (req.method === 'PUT') {
        const body = JSON.parse(await readBody(req));
        const idx = notes.findIndex(n => n.id === noteId);
        if (idx === -1) {
          res.writeHead(404);
          return res.end('Not Found');
        }
        notes[idx] = { ...notes[idx], ...body, id: noteId, updatedAt: Date.now() };
        writeNotes(notes);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(notes[idx]));
      }
      if (req.method === 'DELETE') {
        const filtered = notes.filter(n => n.id !== noteId);
        writeNotes(filtered);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ deleted: notes.length - filtered.length }));
      }
      if (req.method === 'GET') {
        const note = notes.find(n => n.id === noteId);
        if (!note) {
          res.writeHead(404);
          return res.end('Not Found');
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(note));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  let decoded = decodeURIComponent(pathname);
  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }
  let target = path.resolve(path.join(ROOT, decoded));
  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }
  fs.readFile(target, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

server.listen(process.env.PORT, () => console.log(process.env.PORT));
