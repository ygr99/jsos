/**
 * 音乐 (music) — JSOS 应用服务端
 * ---------------------------------------------------------------
 * 移植自 99-起始页 server/routes/music.js + soda.js，axios 改为原生 fetch
 * （经 lib/http.js 出站封装：JSOS 容器内全走系统 CORS 代理，本机直连）。
 *
 * 能力：
 *   - 五源搜索/播放：网易云 / QQ音乐 / 汽水音乐 / 哔哩哔哩 / 抖音
 *   - 歌词（LRC）、音频/图片防盗链代理（流式 + Range）
 *   - AI 歌词解读（SSE 流式，Key 仅存服务端）
 *   - 随机一首歌（歌词网 + 歌曲海联动）
 */

import express from 'express';
import crypto from 'node:crypto';
import { Readable } from 'node:stream';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { outbound, outboundJson, ok, fail, UA, IN_CONTAINER } from './lib/http.js';
import { parseNeteasePlay } from './lib/netease.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '2mb' }));

/* ================================================================
 * 上游数据清洗：部分第三方解析接口返回的字符串被反引号包裹
 * （如 `https://p3.music.126.net/...jpg`），直接用会导致封面 404、
 * 音频无法播放。对所有第三方来源的响应统一剥离首尾反引号。
 * ================================================================ */
function cleanBacktickStrings(value) {
  if (typeof value === 'string') {
    let s = value.trim();
    if (s.startsWith('`') && s.endsWith('`') && s.length >= 2) s = s.slice(1, -1).trim();
    return s;
  }
  if (Array.isArray(value)) return value.map(cleanBacktickStrings);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = cleanBacktickStrings(v);
    return out;
  }
  return value;
}

/* ================================================================
 * AI 配置（服务端持有，不暴露给前端）
 * ================================================================ */
const AI_CONFIG = {
  baseUrl: 'https://api.siliconflow.cn/v1',
  apiKey: 'sk-jmrorpycvurahpoxjqmvetjoszkoyfgtruetitjnotwjdjcj',
  model: 'deepseek-ai/DeepSeek-V4-Flash',
  temperature: 0.7,
};

const MOBILE_UA =
  'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1';

/* ================================================================
 * 音频代理：处理跨域与 Referer/Range 防盗链
 * 示例：/api/proxy/audio?url=ENCODED_M4S_URL&referer=https%3A%2F%2Fwww.bilibili.com%2F
 * ================================================================ */
app.get('/api/proxy/audio', async (req, res) => {
  const audioUrl = req.query.url;
  const referer = req.query.referer || 'https://www.bilibili.com/';

  if (!audioUrl) return res.status(400).json(fail(400, '缺少url参数'));

  try {
    const headers = {
      Referer: referer,
      'User-Agent': UA,
      Accept: '*/*',
      // 音频流禁压缩，保证 Range 语义正确
      'Accept-Encoding': 'identity;q=1, *;q=0',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache',
    };
    if (req.headers.range) headers.Range = req.headers.range;

    let upstream = await outbound(audioUrl, {
      headers,
      timeout: 30000,
      // 容器内 Referer 会被浏览器 fetch 丢弃 → 经代理保留参数注入（防盗链目标必需）
      proxyQuery: { 'x-upstream-referer': referer },
    });

    // B 站音频走 9001 播放代理（/i/bilibili/audio?u=）中转；该跳失败时回退直连 CDN 直链。
    // 注意 u 参数被双重编码（拼 9001 URL 时一次、拼代理路径时一次），需解两次
    const relayMatch = audioUrl.match(/\/i\/bilibili\/audio\?u=([^&]+)/);
    if (relayMatch && upstream.status >= 400) {
      console.error('音频代理: 9001 中转返回', upstream.status, '，尝试直连 CDN');
      try {
        let direct = decodeURIComponent(relayMatch[1]);
        try { direct = decodeURIComponent(direct); } catch { /* 一次解码即可 */ }
        const directResp = await outbound(direct, {
          headers,
          timeout: 30000,
          proxyQuery: { 'x-upstream-referer': referer },
        });
        if (directResp.status < 400) upstream = directResp;
      } catch (ignore) { /* 保持中转的原响应 */ }
    }
    if (upstream.status >= 400) {
      console.error('音频代理: 上游异常', upstream.status, audioUrl.slice(0, 150));
    }

    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'audio/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Range');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length');
    for (const key of ['content-length', 'content-range', 'etag', 'last-modified']) {
      const v = upstream.headers.get(key);
      if (v) res.setHeader(key, v);
    }
    res.status(upstream.status);

    if (!upstream.body) {
      res.end();
      return;
    }
    // 流式转发（客户端断开时中止上游，避免白白下载）
    const stream = Readable.fromWeb(upstream.body);
    req.on('close', () => stream.destroy());
    stream.on('error', (err) => {
      console.error('音频流错误:', err.message);
      if (!res.headersSent) res.status(500).json(fail(500, '音频流传输失败'));
      else res.end();
    });
    stream.pipe(res);
  } catch (e) {
    console.error('音频代理请求失败:', e.message);
    res.status(500).json(fail(500, '音频代理请求失败'));
  }
});

/* ================================================================
 * 图片代理：解决 B 站/汽水图片 403 与跨域
 * 示例：/api/proxy/image?url=ENCODED_IMAGE_URL
 * ================================================================ */
app.get('/api/proxy/image', async (req, res) => {
  const imageUrl = req.query.url;
  if (!imageUrl) return res.status(400).json(fail(400, '缺少url参数'));

  const referer =
    imageUrl.includes('hdslb.com') || imageUrl.includes('bili')
      ? 'https://www.bilibili.com/'
      : 'https://www.douyin.com/';

  try {
    const upstream = await outbound(imageUrl, {
      headers: {
        Referer: referer,
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      },
      timeout: 15000,
    });
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(upstream.status).send(buf);
  } catch (e) {
    console.error('图片代理请求失败:', e.message);
    res.status(500).json(fail(500, '图片代理请求失败'));
  }
});

/* ================================================================
 * 网易云音乐 - 搜索
 * 主路径 POST cloudsearch；容器内代理若不支持 POST 则回退 GET 老接口
 * （result.songs 的 artists/album 字段前端本就兼容）
 * ================================================================ */
app.get('/api/netease/search', async (req, res) => {
  try {
    const q = req.query.q;
    const limit = req.query.limit || '10';
    const offset = req.query.offset || '0';

    if (!q || q.trim() === '') return res.status(400).json(fail(400, '请提供搜索关键词 q'));

    const neteaseHeaders = {
      Referer: 'https://music.163.com/',
      Origin: 'https://music.163.com',
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    // 1. POST cloudsearch（原逻辑）
    let r = await outboundJson('https://music.163.com/api/cloudsearch/pc', {
      method: 'POST',
      headers: neteaseHeaders,
      body: new URLSearchParams({ s: q, type: '1', limit: String(limit), offset: String(offset) }),
      timeout: 15000,
    });

    // 2. 回退：GET 老接口（代理不支持 POST body 时兜底）
    if (!r.ok || !r.json?.result?.songs) {
      const fb = await outboundJson(
        `https://music.163.com/api/search/get?s=${encodeURIComponent(q)}&type=1&limit=${limit}&offset=${offset}`,
        { headers: { Referer: 'https://music.163.com/' }, timeout: 15000 }
      );
      if (fb.json?.result?.songs) r = fb;
    }

    if (!r.json) return res.status(500).json(fail(500, '网易云搜索失败'));

    // 新旧接口字段统一为 cloudsearch 结构（ar/al），前端两种都认
    if (Array.isArray(r.json.result?.songs)) {
      r.json.result.songs = r.json.result.songs.map((s) => ({
        ...s,
        ar: s.ar || s.artists,
        al: s.al || s.album,
        dt: s.dt || (s.duration || 0),
      }));
    }
    res.json(ok(r.json));
  } catch (e) {
    console.error('网易云搜索异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 网易云音乐 - 歌曲详情
 * ================================================================ */
app.get('/api/netease/song', async (req, res) => {
  try {
    const id = req.query.id;
    if (!id) return res.status(400).json(fail(400, '请提供歌曲 id'));

    const r = await outboundJson('https://interface3.music.163.com/api/v3/song/detail', {
      method: 'POST',
      headers: {
        Referer: 'https://music.163.com/',
        Origin: 'https://music.163.com',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({ c: JSON.stringify([{ id, v: 0 }]) }),
      timeout: 15000,
    });

    if (!r.json) return res.status(500).json(fail(500, '服务器内部错误'));
    res.json(ok(r.json));
  } catch (e) {
    console.error('网易云歌曲详情异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 网易云音乐 - 播放直链
 * 解析链移植自 musicdl（lib/netease.js）：l1(svip)→l2→l3→l4→官方 eapi
 * level: standard / higher / exhigh / lossless / hires
 * ================================================================ */
app.get('/api/netease/play', async (req, res) => {
  try {
    const id = req.query.id;
    const level = req.query.level || 'exhigh';
    if (!id) return res.status(400).json(fail(400, '请提供歌曲 id'));

    const result = cleanBacktickStrings(await parseNeteasePlay(id, level));

    if (!result || !result.audioUrl) {
      return res.status(404).json({ code: 404, data: null, message: '未获取到可播放链接，请尝试其他平台', retry: false });
    }
    console.log(`网易云解析成功: ${result.source} (${result.quality || level})`);
    res.json(ok(result));
  } catch (e) {
    console.error('网易云播放直链异常:', e.message);
    res.status(503).json({ code: 503, data: null, message: '网易云音乐解析服务暂时不可用，请尝试其他平台', retry: false });
  }
});

/* ================================================================
 * 网易云音乐 - 歌词
 * ================================================================ */
app.get('/api/netease/lyric', async (req, res) => {
  try {
    const id = req.query.id;
    if (!id) return res.status(400).json(fail(400, '请提供歌曲 id'));

    const lyricParsers = [
      async () => {
        const r = await outboundJson(`https://music.xuanluoge.top/api.php?miss=lyric&id=${id}`, { timeout: 10000 });
        if (r.json?.data?.lrc) return { lyric: r.json.data.lrc, source: 'xuanluoge' };
        return null;
      },
      async () => {
        const r = await outboundJson('https://interface3.music.163.com/api/song/lyric', {
          method: 'POST',
          timeout: 10000,
          headers: {
            Referer: 'https://music.163.com/',
            Origin: 'https://music.163.com',
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({ id, cp: 'false', tv: '0', lv: '0', rv: '0', kv: '0', yv: '0', ytv: '0', yrv: '0' }),
        });
        if (r.json?.lrc?.lyric) return { lyric: r.json.lrc.lyric, source: 'official' };
        return null;
      },
    ];

    let result = null;
    for (const parser of lyricParsers) {
      try {
        result = await parser();
        if (result && result.lyric) break;
      } catch (err) {
        console.log('歌词接口失败:', err.message);
        continue;
      }
    }

    if (!result || !result.lyric) return res.status(404).json(fail(404, '未获取到歌词'));
    res.json(ok(result));
  } catch (e) {
    console.error('网易云歌词异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * QQ 音乐 - 搜索
 * 主路径 POST body JSON（musicdl 方式，稳定）；GET data= 老方式作回退
 * ================================================================ */
app.get('/api/qq/search', async (req, res) => {
  try {
    const q = req.query.q;
    const page = parseInt(req.query.page || req.query.p || '1');
    const limit = parseInt(req.query.limit || req.query.n || '20');

    if (!q || q.trim() === '') return res.status(400).json(fail(400, '请提供搜索关键词 q'));

    const qqHeaders = { Referer: 'https://y.qq.com/', Origin: 'https://y.qq.com', 'User-Agent': UA };

    // 1. POST body JSON
    const payload = {
      comm: { ct: '19', cv: '1859', uin: '0', format: 'json' },
      req: {
        method: 'DoSearchForQQMusicMobile',
        module: 'music.search.SearchCgiService',
        param: { search_type: 0, query: q, page_num: page, num_per_page: limit, highlight: 1, grp: 1 },
      },
    };
    let r = await outboundJson('https://u.y.qq.com/cgi-bin/musicu.fcg', {
      method: 'POST',
      headers: { ...qqHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      timeout: 15000,
    });

    // u.y.qq.com 对高频请求偶发 200 空 body，间隔重试一次
    if (!r.json?.req?.data?.body) {
      await new Promise((resolve) => setTimeout(resolve, 800));
      r = await outboundJson('https://u.y.qq.com/cgi-bin/musicu.fcg', {
        method: 'POST',
        headers: { ...qqHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        timeout: 15000,
      });
    }

    // 2. 回退：GET data= 老方式
    if (!r.json?.req?.data?.body?.item_song && !r.json?.req?.data?.body) {
      const searchData = {
        comm: { ct: '19', cv: '1859', uin: '0', format: 'json' },
        req: {
          method: 'DoSearchForQQMusicMobile',
          module: 'music.search.SearchCgiService',
          param: { search_type: 0, query: q, page_num: page, num_per_page: limit },
        },
      };
      const fallback = await outboundJson(`https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&data=${encodeURIComponent(JSON.stringify(searchData))}`, {
        headers: qqHeaders, timeout: 15000,
      });
      if (fallback.json?.req?.data?.body) r = fallback;
    }

    const result = r.json;
    const body = result?.req?.data?.body || {};

    const stripHtml = (html) => (html ? String(html).replace(/<[^>]+>/g, '') : '');

    const formattedSongs = (body.item_song || []).map((song) => ({
      songmid: song.mid || song.songmid,
      songname: stripHtml(song.title || song.songname),
      singers: (song.singer || []).map((s) => stripHtml(s.name)).join(', '),
      album: stripHtml(song.album?.title || song.albumname),
      albummid: song.album?.mid || song.albummid,
      interval: song.interval,
      cover: song.album?.mid || song.albummid
        ? `https://y.gtimg.cn/music/photo_new/T002R300x300M000${song.album?.mid || song.albummid}.jpg`
        : null,
    }));

    res.json(ok({ songs: formattedSongs, total: body.meta?.sum || formattedSongs.length, page, limit }));
  } catch (e) {
    console.error('QQ搜索异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * QQ 音乐 - 歌词（vkeys 优先，官方 fcg 兜底，Base64 解码）
 * ================================================================ */
app.get('/api/qq/lyric', async (req, res) => {
  const songmid = req.query.songmid;
  const musicid = req.query.musicid;

  if (!songmid && !musicid) return res.status(400).json(fail(400, '请提供 songmid 或 musicid'));

  try {
    const b64 = (v) => {
      try { return Buffer.from(v, 'base64').toString('utf-8'); } catch { return v; }
    };

    // 1. vkeys
    if (songmid) {
      try {
        const r = await outboundJson(`https://api.vkeys.cn/v2/music/tencent/lyric?mid=${songmid}`, { timeout: 10000 });
        if (r.json?.data?.lrc) return res.json(ok({ lyric: r.json.data.lrc, source: 'vkeys' }));
      } catch { /* 落到官方接口 */ }
    }

    // 2. 官方 fcg
    if (songmid) {
      const params = new URLSearchParams({
        songmid, g_tk: '5381', loginUin: '0', hostUin: '0', format: 'json', inCharset: 'utf8', outCharset: 'utf-8', platform: 'yqq',
      });
      const r = await outboundJson(`https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?${params}`, {
        headers: { Referer: 'https://y.qq.com/', Origin: 'https://y.qq.com', 'User-Agent': UA },
        timeout: 10000,
      });
      const data = r.json || {};
      const result = { source: 'official' };
      if (data.lyric) result.lyric = b64(data.lyric);
      if (data.trans) result.trans = b64(data.trans);
      if (data.roman) result.roman = b64(data.roman);
      if (result.lyric || result.trans) return res.json(ok(result));
      return res.status(404).json(fail(404, '未获取到歌词'));
    }

    // 3. musicid 旧接口（CDATA 抽取）
    const url = `https://c.y.qq.com/qqmusic/fcgi-bin/lyric_download.fcg?version=15&lrctype=4&musicid=${encodeURIComponent(musicid)}`;
    const r = await outboundJson(url, { headers: { Referer: 'https://y.qq.com/', Origin: 'https://y.qq.com' }, timeout: 10000 });
    const text = r.text || '';
    const regex = /CDATA\[(.+?)]]/g;
    const matches = [];
    let match;
    while ((match = regex.exec(text)) !== null) matches.push(match[1]);

    const result = { source: 'official' };
    if (matches[0]) result.lyric = matches[0];
    if (matches[1]) result.trans = matches[1];
    return res.json(ok(result));
  } catch (e) {
    console.error('QQ歌词异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * QQ 音乐 - 播放直链（官方 GetVkey 优先 + 4 个第三方回退）
 * quality: lq / hq / sq / flac / hires
 * ================================================================ */
app.get('/api/qq/play', async (req, res) => {
  const songmid = req.query.songmid;
  const albummid = req.query.albummid || req.query.albumMid;
  const quality = req.query.quality || 'hq';

  if (!songmid) return res.status(400).json(fail(400, '请提供 songmid'));

  try {
    const qualityMap = {
      flac: { filenamePrefix: 'F000', ext: '.flac', name: 'FLAC' },
      sq: { filenamePrefix: 'F000', ext: '.flac', name: 'SQ无损' },
      hires: { filenamePrefix: 'RS01', ext: '.flac', name: 'Hi-Res' },
      hq: { filenamePrefix: 'M800', ext: '.mp3', name: 'HQ高品质' },
      mq: { filenamePrefix: 'M500', ext: '.mp3', name: 'MQ标准品质' },
      lq: { filenamePrefix: 'C400', ext: '.m4a', name: 'LQ流畅品质' },
    };
    const targetQuality = qualityMap[quality] || qualityMap['hq'];
    const randomGuid = () => String(10000000 + Math.floor(Math.random() * 90000000));

    // 1. 官方 GetVkey（sip 用 isure.stream 域名，与 musicdl 一致）
    const getOfficialUrl = async () => {
      const requestData = {
        comm: { uin: '0', format: 'json', ct: '19', cv: '0' },
        'music.vkey.GetVkey': {
          method: 'UrlGetVkey',
          module: 'music.vkey.GetVkey',
          param: {
            filename: [`${targetQuality.filenamePrefix}${songmid}${songmid}${targetQuality.ext}`],
            guid: randomGuid(),
            songmid: [songmid],
            songtype: [0],
          },
        },
      };
      const r = await outboundJson('https://u.y.qq.com/cgi-bin/musicu.fcg', {
        method: 'POST',
        timeout: 10000,
        headers: { Referer: 'https://y.qq.com/', Origin: 'https://y.qq.com', 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData),
      });
      const vkeyData = r.json?.['music.vkey.GetVkey']?.data;
      if (vkeyData?.midurlinfo?.[0]?.purl) {
        const purl = vkeyData.midurlinfo[0].purl;
        const sip = vkeyData.sip?.find?.((s) => s && s.startsWith('http')) || 'https://isure.stream.qqmusic.qq.com/';
        return { audioUrl: sip + purl, quality: targetQuality.name, ext: targetQuality.ext, source: 'official' };
      }
      return null;
    };

    // 2. 第三方回退
    const thirdPartyParsers = [
      async () => {
        // vkeys 新接口（musicdl）：品质用数字，从用户档位向下尝试
        const vkqMap = { hires: [11, 10, 9, 8], sq: [10, 9, 8], flac: [10, 9, 8], hq: [9, 8], lq: [4, 1] };
        const qualityList = vkqMap[quality] || vkqMap.hq;
        for (const qn of qualityList) {
          const r = await outboundJson(`https://api.vkeys.cn/music/tencent/song/link?mid=${songmid}&quality=${qn}`, { timeout: 10000 });
          const d = r.json;
          if (d?.data?.url && String(d.data.url).startsWith('http')) {
            return { audioUrl: d.data.url, name: d.data.song, artist: d.data.singer, album: d.data.album, cover: d.data.cover, duration: d.data.interval, quality: d.data.quality, source: 'vkeys' };
          }
        }
        return null;
      },
      async () => {
        // vkeys v2 旧接口兜底
        const r = await outboundJson(`https://api.vkeys.cn/v2/music/tencent/geturl?mid=${songmid}&quality=${quality}`, { timeout: 10000 });
        const d = r.json;
        if (d?.data?.url) {
          return { audioUrl: d.data.url, name: d.data.song, artist: d.data.singer, album: d.data.album, cover: d.data.cover, duration: d.data.interval, quality: d.data.quality, source: 'vkeys-v2' };
        }
        return null;
      },
      async () => {
        // xcvts 带 apiKey（musicdl 内嵌 key，base64 第 14 位起解码）
        const keys = ['charlespikachuNzg5OTMzNDRiOWJmMTEwNTY1NTU5OTAwOWNkYmEzZDI=', 'charlespikachuY2U3NzhlYjBkMTg1OGVkZmI0YjIwNzFhMTE1ZjFlZGY=', 'charlespikachuNzRhNjdhZjM3ZjUyODg4MjYxNmRkMzU1OTdlYTc0MGQ='];
        const apiKey = Buffer.from(keys[Math.floor(Math.random() * keys.length)].slice(14), 'base64').toString('utf-8');
        const qualityNameMap = { lq: '普通', hq: 'HQ高品质', sq: 'SQ无损', flac: 'SQ无损', hires: '臻品2.0' };
        const q = qualityNameMap[quality] || 'HQ高品质';
        const r = await outboundJson(`https://api.xcvts.cn/api/music/qq?apiKey=${encodeURIComponent(apiKey)}&mid=${songmid}&type=${encodeURIComponent(q)}`, { timeout: 10000 });
        const d = r.json;
        if (d?.data?.music) {
          return { audioUrl: d.data.music, name: d.data.title, artist: d.data.singer, album: d.data.album_name, cover: d.data.cover, lyric: d.data.lyric, source: 'xcvts' };
        }
        return null;
      },
      async () => {
        const r = await outboundJson(`https://tang.api.s01s.cn/music_open_api.php?mid=${songmid}`, { timeout: 10000 });
        const d = r.json;
        const urlFields = ['song_play_url_sq', 'song_play_url_pq', 'song_play_url_hq', 'song_play_url', 'song_play_url_standard', 'song_play_url_fq'];
        for (const field of urlFields) {
          if (d?.[field]) {
            return { audioUrl: d[field], name: d.song_name, artist: d.singer_name, album: d.album_name, cover: d.album_pic, lyric: d.song_lyric, source: 'tang' };
          }
        }
        return null;
      },
      async () => {
        const keys = [
          'c2stNTI3OWY0MGQ3ODQxZDVmZDFlODEyZWRkMzRhODg4OTQ=',
          'c2stNTVkNjE0MDY2NTk1NGU4ZjY2NTFmODNhMmQ2ZWYyNmU=',
        ];
        const key = Buffer.from(keys[Math.floor(Math.random() * keys.length)], 'base64').toString('utf-8');
        const br = quality === 'hires' ? 'hires' : quality === 'sq' || quality === 'flac' ? 'flac' : '320k';
        const r = await outboundJson(`https://apii.xianyuw.cn/api/v1/qq-music-search?id=${songmid}&key=${key}&no_url=0&br=${br}`, { timeout: 10000 });
        const d = r.json;
        if (d?.data?.url) {
          return { audioUrl: d.data.url, name: d.data.title, artist: String(d.data.author || '').replace(/\//g, ', '), album: d.data.album, cover: d.data.cover, source: 'xianyuw' };
        }
        return null;
      },
    ];

    let result = await getOfficialUrl().catch((err) => {
      console.log('官方 API 获取失败:', err.message);
      return null;
    });

    if (!result || !result.audioUrl) {
      for (const parser of thirdPartyParsers) {
        try {
          result = await parser();
          if (result && result.audioUrl) break;
        } catch (err) {
          console.log('第三方解析接口失败:', err.message);
          continue;
        }
      }
    }

    if (!result || !result.audioUrl) return res.status(404).json(fail(404, '未获取到可播放链接'));

    if (albummid) {
      result.cover = result.cover || `https://y.gtimg.cn/music/photo_new/T002R300x300M000${albummid}.jpg`;
    }
    result.headers = { Referer: 'https://y.qq.com/', 'User-Agent': UA };
    res.json(ok(cleanBacktickStrings(result)));
  } catch (e) {
    console.error('QQ播放直链异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * B站 - 从 HTML 解析 __INITIAL_STATE__ / __playinfo__
 * ================================================================ */
function parseInitialStateFromHtml(html) {
  try {
    const patterns = [
      /<script>window\.__INITIAL_STATE__=(.*?);\(function\(\)\)/s,
      /<script>window\.__INITIAL_STATE__=(.*?)<\/script>/s,
      /<script[^>]*>window\.__INITIAL_STATE__=(.+?)<\/script>/s,
      /window\.__INITIAL_STATE__\s*=\s*({.+?});?\s*(?:<\/script>|\(function)/s,
    ];
    for (const pattern of patterns) {
      const match = html.match(pattern);
      if (match && match[1]) {
        try {
          const data = JSON.parse(match[1]);
          if (data && (data.videoData || data.aid || data.bvid)) return data;
        } catch { continue; }
      }
    }
  } catch { /* ignore */ }
  return null;
}

function parsePlayInfoFromHtml(html) {
  try {
    const patterns = [
      /<script>window\.__playinfo__=(.*?)<\/script>/s,
      /<script[^>]*>window\.__playinfo__=(.+?)<\/script>/s,
      /window\.__playinfo__\s*=\s*({.+?});?\s*<\/script>/s,
    ];
    for (const pattern of patterns) {
      const match = html.match(pattern);
      if (match && match[1]) {
        try {
          const data = JSON.parse(match[1]);
          if (data && data.data) return data;
        } catch { continue; }
      }
    }
  } catch { /* ignore */ }
  return null;
}

function bilibiliPageHeaders() {
  const buvid3 = `XY${Math.random().toString(36).substring(2, 10).toUpperCase()}${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
  return {
    Referer: 'https://www.bilibili.com/',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    Cookie: `buvid3=${buvid3}; b_nut=100; CURRENT_FNVAL=4048`,
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Upgrade-Insecure-Requests': '1',
  };
}

/* B站 - 视频分P信息（上游转发 + 本地解析） */
app.get('/api/bilibili/pages', async (req, res) => {
  try {
    const bvid = req.query.bvid;
    if (!bvid) return res.status(400).json(fail(400, '请提供视频BV号'));

    const upstreamData = await upstreamPass('/api/bilibili/pages', `bvid=${encodeURIComponent(bvid)}`);
    if (upstreamData?.pages) {
      return res.json(ok(upstreamData));
    }

    const r = await outboundJson(`https://www.bilibili.com/video/${bvid}`, {
      headers: bilibiliPageHeaders(),
      timeout: 20000,
    });
    const initial = r.text ? parseInitialStateFromHtml(r.text) : null;

    if (!initial?.videoData) return res.status(404).json(fail(404, '无法获取视频信息'));

    const videoData = initial.videoData;
    const formattedPages = (videoData.pages || []).map((page) => ({
      page: page.page,
      part: page.part,
      duration: page.duration,
      url: `https://www.bilibili.com/video/${bvid}?p=${page.page}`,
    }));

    res.json(ok({
      title: videoData.title,
      bvid,
      pic: videoData.pic,
      pages: formattedPages,
      owner: videoData.owner || {},
      isMultiPart: formattedPages.length > 1,
      totalPages: formattedPages.length,
    }));
  } catch (e) {
    console.error('获取B站视频分P信息失败:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* B站 - 音频解析（上游转发优先 → 官方 API → 网页解析兜底）
 * ⚠️ B站 API 风控实测：完整 Chrome UA + 缺 sec-ch-ua/cookie 的组合会被 412，
 * 短 UA 在本机代理出口/Cloudflare Worker 出口也会被累计风控 412——
 * 唯阿里云服务器（8.129.83.45）出口正常。
 * 上游列表默认：9001 直连（本机/服务器直连；容器内经系统代理直达，代理已支持
 * 裸 IP 目标 + query key 无 preflight 形态）。可用环境变量 MUSIC_UPSTREAM 追加。
 * 上游全失败时回退本地解析链。 */
const BILI_API_UA = 'Mozilla/5.0 Chrome/126';
const MUSIC_UPSTREAMS = [
  ...(process.env.MUSIC_UPSTREAM ? [process.env.MUSIC_UPSTREAM.replace(/\/+$/, '')] : []),
  'http://8.129.83.45:9001',
];

/** 随机 buvid3（B 站风控 cookie 变体） */
function genBuvid() {
  return `XY${Math.random().toString(36).substring(2, 10).toUpperCase()}${Math.random().toString(36).substring(2, 10).toUpperCase()}_INFOWEBL`;
}

/** B 站 CDN 域名（含 html5 durl 的可能形态） */
const BILI_CDN_RE = /(^|\.)(bilivideo|bilivimedia)\.com$/i;

/** B 站 CDN 直链 → 9001 播放代理（/i/bilibili/audio，国内出口中转）。
 * 直链有防盗链且部分 CDN 会拒绝与解析出口不一致的请求（实测容器内经代理抓 CDN 403，
 * 而解析链路容器→代理→9001 稳定可用）→ 音频统一走 9001 中转，与解析同出口。 */
function biliCdnRelayUrl(cdnUrl, base) {
  return (base || MUSIC_UPSTREAMS[0]) + '/i/bilibili/audio?u=' + encodeURIComponent(cdnUrl);
}

/** B 站 API 间歇风控（412/概率性拒绝）→ 多指纹变体 + 间隔重试，提高单点成功率 */
async function biliApiJson(url, { referer = 'https://www.bilibili.com/' } = {}) {
  const variants = [
    { 'User-Agent': BILI_API_UA, Referer: referer },
    { 'User-Agent': BILI_API_UA, Referer: referer, Cookie: `buvid3=${genBuvid()}; b_nut=100; CURRENT_FNVAL=4048` },
    { 'User-Agent': UA, Referer: referer, Cookie: `buvid3=${genBuvid()}` },
  ];
  let last = null;
  for (let i = 0; i < variants.length; i++) {
    if (i > 0) await new Promise((r) => setTimeout(r, 400));
    const r = await outboundJson(url, { headers: variants[i], timeout: 10000 });
    if (r.json?.code === 0) return r;
    last = r;
    console.log(`[bilibili] 第${i + 1}/3 次尝试: status=${r.status} code=${r.json?.code ?? '-'}`);
  }
  return last;
}

/** 依次尝试上游转发，成功（code 200 且有 data）即返回。
 * 上游（9001 起始页新版）可能返回相对 audioUrl（/i/bilibili/audio?... 指向其自身
 * 播放代理路由）→ 补全为该上游的绝对地址，music 的 /api/proxy/audio 才能代理播放。
 * 上游自身对 B 站的解析受间歇风控影响（412→500），每个上游失败后间隔重试一次。 */
async function upstreamPass(route, query) {
  for (const base of MUSIC_UPSTREAMS) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        if (attempt > 0) await new Promise((r) => setTimeout(r, 700));
        // 9001 不校验 key，不发自定义头（容器内避免 preflight）
        const r = await outboundJson(`${base}${route}?${query}`, {
          headers: { 'User-Agent': UA },
          timeout: 25000,
        });
        if (r.json?.code === 200 && r.json?.data) {
          const data = cleanBacktickStrings(r.json.data);
          if (typeof data.audioUrl === 'string' && data.audioUrl.startsWith('/')) {
            data.audioUrl = base + data.audioUrl;
            if (data.originalAudioUrl && data.originalAudioUrl.startsWith('/')) {
              data.originalAudioUrl = base + data.originalAudioUrl;
            }
          }
          return data;
        }
        console.log(`上游(${base}${route}) 返回异常: code=${r.json?.code} msg=${r.json?.message || JSON.stringify(r.json?.data)?.slice(0, 40)}`);
      } catch (e) {
        console.log(`上游(${base}${route}) 不可达:`, e?.name === 'TimeoutError' ? 'timeout' : (e?.message || e));
      }
    }
  }
  return null;
}

app.get('/api/bilibili/audio', async (req, res) => {
  try {
    const videoUrl = req.query.url;
    if (!videoUrl || !videoUrl.includes('bilibili.com/video')) {
      return res.status(400).json(fail(400, '请提供有效的哔哩哔哩视频URL'));
    }

    let bvid = null;
    let pageNum = 1;
    const bvMatch = videoUrl.match(/\/video\/(BV\w+)/i);
    const avMatch = videoUrl.match(/\/video\/av(\d+)/i);
    const pMatch = videoUrl.match(/[?&]p=(\d+)/i);
    if (bvMatch) bvid = bvMatch[1];
    else if (avMatch) bvid = 'av' + avMatch[1];
    if (pMatch) pageNum = parseInt(pMatch[1]);
    if (!bvid) return res.status(400).json(fail(400, '无法从URL中提取视频ID'));

    // 0. 上游转发优先（自建代理/Vercel 门面 → 9001，阿里云出口未被 B 站风控）
    const upstreamData = await upstreamPass('/api/bilibili/audio', `url=${encodeURIComponent(videoUrl)}`);
    if (upstreamData?.audioUrl) {
      return res.json(ok(upstreamData));
    }

    // 1. 官方 API（多指纹重试）
    try {
      const apiResp = await biliApiJson(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`);
      if (apiResp.json?.code === 0) {
        const data = apiResp.json.data;
        const cid = pageNum > 1 && data.pages && data.pages[pageNum - 1] ? data.pages[pageNum - 1].cid : data.cid;

        const playResp = await biliApiJson(
          `https://api.bilibili.com/x/player/playurl?bvid=${bvid}&cid=${cid}&qn=80&fnver=0&fnval=16&fourk=1`
        );

        if (playResp.json?.code === 0) {
          const playData = playResp.json.data;
          let audioUrl = null;
          if (playData.dash?.audio?.length > 0) {
            const audio = playData.dash.audio.sort((a, b) => b.bandwidth - a.bandwidth)[0];
            audioUrl = audio.baseUrl || audio.url;
          } else if (playData.url) {
            audioUrl = playData.url;
          }

          if (audioUrl) {
            const pages = (data.pages || []).map((p) => ({
              page: p.page, part: p.part, duration: p.duration,
              url: `https://www.bilibili.com/video/${bvid}?p=${p.page}`,
            }));
            const currentPage = pages.find((p) => p.page === pageNum) || pages[0];
            let title = data.title;
            if (currentPage?.part && pages.length > 1) {
              title = currentPage.part;
              if (/^(第\s*\d+\s*[集期话]|\d+)$/.test(title)) title = `${title} - ${data.title}`;
            }

            return res.json(ok({
              title, audioUrl: biliCdnRelayUrl(audioUrl), originalAudioUrl: audioUrl,
              cover: data.pic, currentPage, pages,
              isMultiPart: pages.length > 1, totalPages: pages.length,
              currentPageNumber: pageNum, videoId: bvid,
              owner: { name: data.owner?.name || 'UP主', mid: data.owner?.mid, face: data.owner?.face },
              headers: { Referer: 'https://www.bilibili.com/', 'User-Agent': UA },
            }));
          }
        }
      }
    } catch (apiError) {
      console.log('B站官方API解析失败，尝试备用方案:', apiError.message);
    }

    // 1b. html5 playurl 兜底（platform=html5 + try_look 免登录形态，返回可直接播放的 mp4）
    try {
      const viewResp = await biliApiJson(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`);
      if (viewResp.json?.code === 0) {
        const vdata = viewResp.json.data;
        const cid = pageNum > 1 && vdata.pages && vdata.pages[pageNum - 1] ? vdata.pages[pageNum - 1].cid : vdata.cid;

        const playResp = await biliApiJson(
          `https://api.bilibili.com/x/player/playurl?bvid=${bvid}&cid=${cid}&qn=64&platform=html5&high_quality=1&try_look=1`
        );
        const playData = playResp.json?.data;
        const html5Url = playData?.durl?.[0]?.url || playData?.url;
        if (html5Url && String(html5Url).startsWith('http')) {
          const pages = (vdata.pages || []).map((p) => ({
            page: p.page, part: p.part, duration: p.duration,
            url: `https://www.bilibili.com/video/${bvid}?p=${p.page}`,
          }));
          const currentPage = pages.find((p) => p.page === pageNum) || pages[0];
          let title = vdata.title;
          if (currentPage?.part && pages.length > 1) {
            title = `${currentPage.part} - ${vdata.title}`;
          }
          console.log('[bilibili] html5 playurl 兜底成功');
          return res.json(ok({
            title, audioUrl: html5Url, cover: vdata.pic, currentPage, pages,
            isMultiPart: pages.length > 1, totalPages: pages.length,
            currentPageNumber: pageNum, videoId: bvid,
            owner: { name: vdata.owner?.name || 'UP主', mid: vdata.owner?.mid, face: vdata.owner?.face },
            headers: { Referer: 'https://www.bilibili.com/', 'User-Agent': UA },
            source: 'bilibili-html5',
          }));
        }
      }
    } catch (html5Error) {
      console.log('B站 html5 兜底失败:', html5Error.message);
    }

    // 2. 网页解析兜底
    const pageUrl = `https://www.bilibili.com/video/${bvid}${pageNum > 1 ? '?p=' + pageNum : ''}`;
    const r = await outboundJson(pageUrl, { headers: bilibiliPageHeaders(), timeout: 20000 });
    const html = r.text || '';

    const playInfo = parsePlayInfoFromHtml(html);
    let audioUrl = null;
    let deadline = null;

    if (playInfo?.data?.dash?.audio?.length > 0) {
      const dash = playInfo.data.dash;
      let bestIdx = 0;
      let bestBandwidth = -1;
      dash.audio.forEach((a, i) => {
        if (a.bandwidth > bestBandwidth) { bestBandwidth = a.bandwidth; bestIdx = i; }
      });
      audioUrl = dash.audio[bestIdx].baseUrl;
      try {
        const q = new URL(audioUrl).search;
        if (q) deadline = new URLSearchParams(q).get('deadline');
      } catch { /* ignore */ }
    }

    const initial = parseInitialStateFromHtml(html);
    let title = null;
    let cover = null;
    const pages = [];
    let currentPage = null;
    let owner = null;

    if (initial?.videoData) {
      const videoData = initial.videoData;
      title = videoData.title;
      cover = videoData.pic;
      if (videoData.owner) {
        owner = { name: videoData.owner.name, mid: videoData.owner.mid, face: videoData.owner.face };
      }
      if (cover) {
        cover = cover.replace(/\\u002F/g, '/').replace(/\u002F/g, '/');
        if (!cover.startsWith('http')) cover = cover.startsWith('//') ? 'https:' + cover : 'https://' + cover;
      }
      if (videoData.pages) {
        videoData.pages.forEach((pg) => {
          const item = {
            page: pg.page, part: pg.part, duration: pg.duration,
            url: `https://www.bilibili.com/video/${bvid}?p=${pg.page}`,
          };
          pages.push(item);
          if (pg.page === pageNum) currentPage = item;
        });
        if (currentPage?.part) {
          const albumTitle = title;
          const partTitle = currentPage.part;
          if (partTitle) {
            title = partTitle;
            if (/^(第\s*\d+\s*[集期话]|\d+)$/.test(partTitle)) title = partTitle + ' - ' + albumTitle;
          }
        }
      }
    }

    if (!audioUrl) return res.status(404).json(fail(404, '无法从视频中提取音频链接'));

    res.json(ok({
      title, audioUrl: biliCdnRelayUrl(audioUrl), originalAudioUrl: audioUrl,
      cover, currentPage, pages,
      isMultiPart: pages.length > 1, totalPages: pages.length,
      currentPageNumber: pageNum, videoId: bvid, deadline, owner,
      headers: { Referer: 'https://www.bilibili.com/', 'User-Agent': UA },
    }));
  } catch (e) {
    console.error('B站视频音频解析失败:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 抖音视频解析音频
 * ================================================================ */
app.all('/api/douyin/parse', async (req, res) => {
  try {
    const url = req.query.url || req.body?.url;
    if (!url || url.trim() === '') return res.status(400).json(fail(400, '请提供抖音链接url'));

    // 0. 上游转发优先（9001 同款逻辑；aifooler 失败时兜底）
    const upstreamData = await upstreamPass('/api/douyin/parse', `url=${encodeURIComponent(url)}`);
    if (upstreamData?.audioUrl) return res.json(ok(upstreamData));

    const r = await outboundJson('https://www.aifooler.com/api/parse-video-url', {
      method: 'POST',
      timeout: 30000,
      headers: { 'Content-Type': 'application/json', Origin: 'https://www.aifooler.com', Referer: 'https://www.aifooler.com/video-audio' },
      body: JSON.stringify({ url }),
    });

    const json = r.json;
    if (!json?.success) return res.status(500).json(fail(500, json?.message || '解析失败'));

    const data = json.data;
    if (!data) return res.status(404).json(fail(404, '未获取到解析结果'));
    if (!data.videoUrl) return res.status(404).json(fail(404, '未获取到可播放链接'));

    res.json(ok({
      title: data.title,
      audioUrl: data.videoUrl,
      cover: data.coverUrl,
      headers: { Referer: 'https://www.douyin.com/', 'User-Agent': UA },
    }));
  } catch (e) {
    console.error('抖音视频解析失败:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * AI 歌词解读（SSE 流式转发）
 * ================================================================ */
app.post('/api/ai/analyze-lyrics', async (req, res) => {
  const { lyrics, songName, artist } = req.body || {};

  if (!lyrics || lyrics.trim() === '') return res.status(400).json(fail(400, '请提供歌词内容'));

  try {
    const prompt = `我将提供一段的歌词文本：

**请按照以下四个维度进行整体赏析：**
**一、 核心意境**
* **一句话定义：** 如果要给这首歌词定义一个关键词，会是什么？
* **整体画面：** 通读全词，这首歌构建了一个怎样的故事？

**二、 叙事脉络与情绪递进**
* **叙事弧：** 请分析歌词的情绪是如何流动的？
* **歌词结构：** 是否存在前后呼应的设计？

**三、 哲学内涵**
* 歌词实则隐喻了什么人生哲学或社会现象？
* 这首歌词通过什么方式引起了读者的共鸣？

**四、最富情感的段落**
* 请找出歌词中最能体现情感的那一段，它是如何引发读者共鸣的？

**五、 总结性评价**

* **歌曲信息：** ${songName ? `歌名：${songName}` : ''}${artist ? ` / 艺术家：${artist}` : ''}
* **歌词文本：**
${lyrics}
`;

    const upstream = await outbound(`${AI_CONFIG.baseUrl}/chat/completions`, {
      method: 'POST',
      timeout: 120000,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${AI_CONFIG.apiKey}`,
      },
      body: JSON.stringify({
        model: AI_CONFIG.model,
        messages: [
          { role: 'system', content: '你是一位敏锐的文学编辑和歌词审美专家。请基于用户提供的歌词文本进行深入赏析，提供有洞察力的解读。' },
          { role: 'user', content: prompt },
        ],
        stream: true,
        temperature: AI_CONFIG.temperature,
        max_tokens: 4096,
      }),
    });

    if (!upstream.ok || !upstream.body) {
      return res.status(500).json(fail(500, 'AI 分析服务暂时不可用'));
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const stream = Readable.fromWeb(upstream.body);
    req.on('close', () => stream.destroy());
    stream.on('error', (err) => {
      console.error('AI 流式响应错误:', err.message);
      res.end();
    });
    stream.pipe(res);
  } catch (e) {
    console.error('AI 歌词解读失败:', e.message);
    res.status(500).json(fail(500, 'AI 分析服务暂时不可用'));
  }
});

/* ================================================================
 * 随机一首歌（歌词网随机 → 歌曲海搜索第一个结果）
 * ================================================================ */
app.get('/api/random-song', async (req, res) => {
  try {
    const minId = 3;
    const maxId = 97264;
    const maxAttempts = 10;
    let attempt = 0;

    const HTML_HEADERS = {
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9',
    };

    // 歌曲海需要 session cookie 才能搜索：先访问首页拿一次，失败不阻断
    let cookieHeader = '';
    try {
      const home = await outbound('https://www.gequhai.com/', { headers: HTML_HEADERS, timeout: 10000 });
      const cookies = typeof home.headers.getSetCookie === 'function'
        ? home.headers.getSetCookie()
        : (home.headers.get('set-cookie') ? [home.headers.get('set-cookie')] : []);
      cookieHeader = cookies.map((c) => c.split(';')[0]).join('; ');
    } catch { /* 没拿到 cookie 也继续，部分情况仍可搜 */ }

    while (attempt < maxAttempts) {
      const randomId = Math.floor(Math.random() * (maxId - minId + 1)) + minId;
      const lyricsUrl = `https://lyrics.net.cn/lyrics/${randomId}`;

      try {
        const page = await outboundJson(lyricsUrl, { headers: { ...HTML_HEADERS, Referer: 'https://lyrics.net.cn/' }, timeout: 10000 });
        const html = page.text || '';
        let name = null;
        let artist = null;

        const h1Match = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
        if (h1Match) {
          const songMatch = h1Match[1].trim().match(/^(.+?)歌词-(.+?)\s*\|/);
          if (songMatch) { name = songMatch[1].trim(); artist = songMatch[2].trim(); }
        }
        if (!name || !artist) {
          const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
          if (titleMatch) {
            const titleSongMatch = titleMatch[1].trim().match(/^(.+?)歌词-(.+?)\s*\|/);
            if (titleSongMatch) { name = titleSongMatch[1].trim(); artist = titleSongMatch[2].trim(); }
          }
        }

        if (name && artist) {
          const cleanName = name.replace(/[-–—]/g, ' ').replace(/\s+/g, ' ').trim();
          const cleanArtist = artist.replace(/[-–—]/g, ' ').replace(/\s+/g, ' ').trim();

          const doSearch = async (kw) => {
            const r = await outboundJson(`https://www.gequhai.com/s/${encodeURIComponent(kw)}`, {
              headers: { ...HTML_HEADERS, Referer: 'https://www.gequhai.com/', Cookie: cookieHeader },
              timeout: 10000,
            });
            const sh = r.text || '';
            return sh.match(/<a\s+(?:[^>]*\s+)?href="(\/play\/\d+)"(?:\s+[^>]*)?>/i) ||
                   sh.match(/<a\s+(?:[^>]*\s+)?class="[^"]*text-info[^"]*"(?:\s+[^>]*)?\s+href="(\/play\/\d+)"/i);
          };

          let firstResultMatch = null;
          try {
            firstResultMatch = await doSearch(`${cleanName} ${cleanArtist}`);
          } catch (searchErr) {
            console.log('歌曲海搜索失败:', searchErr.message);
          }

          if (!firstResultMatch) {
            console.log(`歌曲 ${name} - ${artist} 组合搜索未找到，尝试只搜索歌名...`);
            try {
              firstResultMatch = await doSearch(cleanName);
            } catch (err) {
              console.log(`降级搜索失败: ${err.message}`);
            }
          }

          if (firstResultMatch) {
            return res.json(ok({
              id: randomId,
              name,
              artist,
              url: lyricsUrl,
              searchUrl: `https://www.gequhai.com/s/${encodeURIComponent(`${cleanName} ${cleanArtist}`)}`,
              playUrl: `https://www.gequhai.com${firstResultMatch[1]}`,
            }));
          }

          console.log(`歌曲 ${name} - ${artist} 在歌曲海未找到，继续尝试...`);
        }

        attempt++;
      } catch (err) {
        console.log(`尝试 ${randomId} 失败:`, err.message);
        attempt++;
      }
    }

    return res.status(404).json(fail(404, '未能获取到有效的随机歌曲'));
  } catch (e) {
    console.error('随机歌曲获取失败:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 汽水音乐 - 搜索（musicdl 3.5.1 参数版）
 * ================================================================ */
app.get('/api/soda/search', async (req, res) => {
  try {
    const q = req.query.q;
    const cursor = req.query.cursor || '0';
    if (!q || q.trim() === '') return res.status(400).json(fail(400, '请提供搜索关键词 q'));

    const DEVICE_ID = '3753066532709850';
    const params = {
      aid: '386088', app_name: 'luna_pc', region: 'cn', geo_region: 'cn', os_region: 'cn', sim_region: '',
      device_id: DEVICE_ID, cdid: '', iid: '3753066532713946',
      version_name: '3.5.1', version_code: '30050100', channel: 'official', build_mode: 'master',
      network_carrier: '', ac: 'wifi', tz_name: 'Asia/Shanghai', resolution: '',
      device_platform: 'windows', device_type: 'Windows', os_version: 'Windows 10 Education', fp: DEVICE_ID,
      q, cursor,
      search_id: crypto.randomUUID(),
      search_method: 'input', debug_params: '', from_search_id: '', search_scene: '',
    };
    const url = `https://api.qishui.com/luna/pc/search/track?${new URLSearchParams(params)}`;

    const r = await outboundJson(url, {
      headers: {
        'User-Agent': 'LunaPC/3.5.1(408871041)',
        'Content-Type': 'application/json; charset=utf-8',
      },
      timeout: 15000,
    });

    // api.qishui.com 对多数数据中心 IP 风控（200 空 body）→ 上游 9001 转发兜底
    if (!r.json?.data) {
      const up = await upstreamPass('/api/soda/search', `q=${encodeURIComponent(q)}&cursor=${encodeURIComponent(cursor)}`);
      if (up) return res.json(ok(up));
    }

    if (!r.json) return res.status(500).json(fail(500, '服务器内部错误'));
    res.json(ok(r.json));
  } catch (e) {
    console.error('汽水音乐搜索异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 汽水音乐 - 播放直链（分享页免解密 + qiuyu520 第三方回退）
 * ================================================================ */
app.get('/api/soda/play', async (req, res) => {
  try {
    const id = req.query.id;
    if (!id) return res.status(400).json(fail(400, '请提供歌曲 id'));

    // 0. 上游转发优先（9001 同款逻辑）
    const upstreamData = await upstreamPass('/api/soda/play', `id=${encodeURIComponent(id)}`);
    if (upstreamData?.audioUrl) return res.json(ok(upstreamData));

    // 1. 分享页解析（原逻辑）
    const shareUrl = `https://music.douyin.com/qishui/share/track?track_id=${id}`;
    const r = await outboundJson(shareUrl, {
      headers: { 'User-Agent': MOBILE_UA, Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', Referer: 'https://www.douyin.com/', Origin: 'https://www.douyin.com' },
      timeout: 15000,
    });

    const match = (r.text || '').match(/_ROUTER_DATA\s*=\s*({[\s\S]*?});/);
    if (match) {
      const routerData = JSON.parse(match[1].trim());
      const audioOption = routerData.loaderData?.track_page?.audioWithLyricsOption || {};
      let audioUrl = audioOption.url || '';

      if (audioUrl) {
        audioUrl = audioUrl.replace(/\\u002F/g, '/').replace(/%7C/g, '|').replace(/%3D/g, '=');

        const trackInfo = routerData.loaderData?.track_page?.trackInfo || {};
        const albumInfo = trackInfo.albumInfo || {};
        const artists = trackInfo.artists || [];

        let coverUrl = null;
        if (albumInfo.cover?.url) coverUrl = `/api/proxy/image?url=${encodeURIComponent(albumInfo.cover.url)}`;

        const proxyAudioUrl = `/api/proxy/audio?url=${encodeURIComponent(audioUrl)}&referer=${encodeURIComponent('https://www.douyin.com/')}`;

        return res.json(ok({
          audioUrl: proxyAudioUrl,
          originalAudioUrl: audioUrl,
          name: trackInfo.title,
          artist: artists.map((a) => a.name).join(', '),
          album: albumInfo.title,
          cover: coverUrl,
          duration: audioOption.duration ? Math.round(audioOption.duration / 1000) : undefined,
          source: 'soda',
        }));
      }
    }

    // 2. qiuyu520 第三方回退（musicdl：POST /qishuiParse/api/track/v2）
    const qr = await outboundJson('http://qiuyu520.fun/qishuiParse/api/track/v2', {
      method: 'POST',
      timeout: 12000,
      headers: {
        Accept: 'application/json, text/plain, */*',
        'User-Agent': UA,
        Referer: 'http://qiuyu520.fun/qishui/',
        Origin: 'http://qiuyu520.fun',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ track_id: String(id) }),
    });
    const qd = qr.json?.data;
    if (qd?.url && String(qd.url).startsWith('http')) {
      const proxyAudioUrl = String(qd.url).startsWith('https:')
        ? `/api/proxy/audio?url=${encodeURIComponent(qd.url)}&referer=${encodeURIComponent('https://www.douyin.com/')}`
        : qd.url;
      return res.json(ok({
        audioUrl: proxyAudioUrl,
        originalAudioUrl: qd.url,
        name: qd.title,
        artist: qd.artist,
        album: qd.album,
        cover: qd.cover,
        source: 'soda-qiuyu',
      }));
    }

    return res.status(404).json(fail(404, '未获取到播放链接'));
  } catch (e) {
    console.error('汽水音乐播放直链异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 汽水音乐 - 歌词（分享页 → LRC 转换）
 * ================================================================ */
app.get('/api/soda/lyric', async (req, res) => {
  try {
    const id = req.query.id;
    if (!id) return res.status(400).json(fail(400, '请提供歌曲 id'));

    const shareUrl = `https://music.douyin.com/qishui/share/track?track_id=${id}`;
    const r = await outboundJson(shareUrl, {
      headers: { 'User-Agent': MOBILE_UA, Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' },
      timeout: 15000,
    });

    const match = (r.text || '').match(/_ROUTER_DATA\s*=\s*({[\s\S]*?});/);
    if (!match) return res.status(404).json(fail(404, '未获取到歌词数据'));

    const routerData = JSON.parse(match[1].trim());
    const sentences = routerData.loaderData?.track_page?.audioWithLyricsOption?.lyrics?.sentences || [];
    if (sentences.length === 0) return res.status(404).json(fail(404, '未获取到歌词'));

    const lrcLines = sentences.map((sentence) => {
      const startMs = sentence.startMs || 0;
      const minutes = Math.floor(startMs / 60000);
      const seconds = Math.floor((startMs % 60000) / 1000);
      const ms = startMs % 1000;
      const timeStr = `[${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(ms).padStart(3, '0')}]`;
      const text = (sentence.words || []).map((w) => w.text || '').join('');
      return `${timeStr}${text}`;
    });

    res.json(ok({ lyric: lrcLines.join('\n'), source: 'soda' }));
  } catch (e) {
    console.error('汽水音乐歌词异常:', e.message);
    res.status(500).json(fail(500, '服务器内部错误'));
  }
});

/* ================================================================
 * 静态托管与启动
 * ================================================================ */
app.use(express.static(path.join(__dirname, 'public')));

app.listen(port, () => {
  console.log(`music running on ${port} (${IN_CONTAINER ? 'JSOS 容器内，出站走系统代理' : '本机直连'})`);
});
