/* ==========================================================================
   白噪音 whitenoise — 混音器前端
   ---------------------------------------------------------------------------
   • 声音目录来自 /api/sounds（60 声音 / 250 变体）
   • 每路声音 = 独立 <audio>（loop），音量 = 总音量 × 分路音量
   • CDN 直链播放优先（<audio> 不受 CORS 限制，零代理开销）；
     失败自动降级到同源 /api/audio 代理（CDN 无 ACAO 头时的兜底）
   • 混音状态经 /api/state 持久化（§7.9 模式 A）
   ========================================================================== */

const $ = (id) => document.getElementById(id);

const CDN = 'https://cdn.gameziyuan.shop/audio';
const QUALITY = { low: '_64', medium: '_128', high: '_320' };

/** 分类顺序 + 中文名 + 图标（与参考设计一致） */
const CATS = [
  { id: 'all', label: '全部' },
  { id: 'background', label: '自然' },
  { id: 'place', label: '场所' },
  { id: 'asmr', label: 'ASMR' },
  { id: 'ambient', label: '环境' },
  { id: 'noise', label: '噪音' },
  { id: 'other', label: '其他' },
  { id: 'lofi', label: 'Lofi' },
];

/** 每个声音的主题色（低饱和，用于图标块） */
const TONES = {
  background: '#3b82f6', place: '#f59e0b', asmr: '#8b5cf6',
  ambient: '#0f9488', noise: '#6b7280', other: '#ec4899', lofi: '#6366f1',
};

/** 声音 → 简约线性图标 path（按 id 归类，未命中的用通用声波） */
const ICONS = {
  waves: 'M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5s2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1M2 12c.6.5 1.2 1 2.5 1S7 12 9.5 12s2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1M2 18c.6.5 1.2 1 2.5 1s2.5-2 5-2 2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1',
  birds: 'M16 7h.01M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20',
  fire: 'M12 3c1.5 3 4 4.5 4 8a4 4 0 0 1-8 0c0-1.5.5-2.5 1.2-3.2.3 1.2 1 1.7 1.8 1.7 1.2 0 1.5-1 1.5-2 0-1.6-.5-3-.5-4.5Z',
  rain: 'M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2M16 14v6M8 14v6M12 16v6',
  stream: 'M3 6h18M3 12h18M3 18h18',
  wind: 'M12.8 19.6A2 2 0 1 0 14 16H2M17.5 8a2.5 2.5 0 1 1 2 4H2M9.8 4.4A2 2 0 1 1 11 8H2',
  forest: 'M12 22v-6M12 16l4-3.5-4 .5 4-3.5-4 .5L12 8 8 9.5l4-.5-4 3.5 4-.5L12 16Z',
  road: 'M4 20 8 4M20 20 16 4M12 6v3M12 13v3',
  frog: 'M6 14a6 6 0 0 1 12 0v2H6zM9 11h.01M15 11h.01',
  night: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z',
  thunder: 'M6 16.3A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 .5 9m-5 0-3 5h4l-3 5',
  waterfall: 'M8 3h8l-1 18H9zM4 8c1 1 2 1 3 0M17 13c1 1 2 1 3 0',
  snow: 'M12 3v18M4 8l16 8M20 8 4 16',
  bells: 'M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10.3 21a2 2 0 0 0 3.4 0',
  cafe: 'M4 8h13v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5zM17 9h2a3 3 0 0 1 0 6h-2',
  chants: 'M10 9h4M12 7v5M14 21v-3a2 2 0 0 0-4 0v3M6 21V7l6-4 6 4v14',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM12 7v5l3 2',
  keyboard: 'M3 6h18v12H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10',
  cat: 'M12 5c-1.8-2-5-2.8-6.4-2.2-1.4.6.4 7 .4 7A7 7 0 0 0 12 21a7 7 0 0 0 6-11.2s1.8-6.4.4-7C17 2.2 13.8 3 12 5Z',
  vacuum: 'M10 12h4M10 8h4M14 21v-3a2 2 0 0 0-4 0v3M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16',
  space: 'M12 3a9 9 0 1 0 9 9M12 12l6-6M15 6h-3v-3',
  train: 'M4 6h16v10H4zM7 20l2-4M17 20l-2-4M8 13h.01M16 13h.01',
  plane: 'M17.8 19.8 16 14l-3 3v4l-2 2-2-2v-4l-3-3-1.8 5.8L2 18l3-6V7l-2-3 4-1 5 5h4a3 3 0 0 1 0 6h-2l-1.2 5.8z',
  basketball: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM2 12h20M12 2v20M5 5a14 14 0 0 1 0 14M19 5a14 14 0 0 0 0 14',
  supermarket: 'M6 2 4 6v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6l-2-4zM4 6h16M9 10a3 3 0 0 0 6 0',
  city: 'M6 21V9l6-4 6 4v12M10 21v-5h4v5M2 21h20',
  barber: 'M6 3 18 15M6 21 18 9M9 6a3 3 0 1 0 0 0M9 18a3 3 0 1 0 0 0',
  bubbles: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM17 20a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
  chips: 'M4 8h16v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM9 8v-2a3 3 0 0 1 6 0v2',
  printer: 'M6 9V3h12v6M6 18H4v-6h16v6h-2M8 14h8v7H8z',
  engine: 'M6 9h3V6h6v3h3l2 3v5h-2v2H6v-2H4v-5zM9 3v3',
  boat: 'M4 18 12 4l8 14M6 18v2M18 18v2M3 22h18',
  whale: 'M3 12c2 4 5 6 9 6s7-2 9-5c-1-1-3-1-4 0-1-4-5-6-9-5-3 .7-5 2-5 4Z M6 8 4 5M9 7 8 4',
  breath: 'M12 3v18M8 8l4-5 4 5M8 16l4 5 4-5',
  magma: 'M12 22 4 12h4l2-3 3 2 3-4 1 5h4z',
  walk: 'M13 4a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM11 21l1-5-3-3 1-5 4 2 3 1M9 13l-2 4',
  white_noise: 'M2 8h4l3-5 3 18 3-13 2 5h5',
  pink_noise: 'M2 12c3 0 3-6 6-6s3 12 6 12 3-9 6-9',
  brown_noise: 'M4 4v16M8 8v8M12 6v12M16 10v4M20 8v8',
  lofi: 'M9 18V5l10-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM19 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
  save: 'M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2ZM17 21v-8H7v8M7 3v5h8',
  default: 'M12 6v12M9 9v6M15 9v6M6 11v2M18 11v2',
};
const iconPath = (id) => ICONS[id] || ICONS.default;

/* ------------------------------ 状态 ------------------------------ */

const state = {
  sounds: [],
  active: {},          // id -> { variant, volume }  （音量 0-100）
  master: 80,
  cat: 'all',
  q: '',
  playing: false,
  presets: [],         // 内置推荐预设（/api/presets）
  mine: [],            // 我的预设（持久化在 state.presets）
  seg: 'rec',          // rec = 推荐 / mine = 我的
};

const audio = new Map();  // id -> HTMLAudioElement

/** 每路声音的取流状态（仅内存，不持久化）：
 *  loading = 正在取流（CDN 直链 / 同源代理），还没真正出声
 *  ready   = 已经能播（或正在播）
 *  failed  = 直链与代理都失败
 *  —— 只有 ready 才显示跳动条与「正在播放」，避免"还没出声就显示播放中" */
const psMap = new Map();
const psOf = (id) => psMap.get(id) || 'ready';

function setPs(id, v) {
  if (psMap.get(id) === v) return;
  psMap.set(id, v);
  patchCard(id);
  renderChips();
}

/* ------------------------------ 工具 ------------------------------ */

const enc = (p) => p.split('/').map(encodeURIComponent).join('/');

function buildUrl(snd, variantId, quality = 'low') {
  const v = snd.variants.find((x) => x.id === variantId) || snd.variants[0];
  const suffix = snd.category === 'lofi' || snd.noQuality ? '' : QUALITY[quality] || QUALITY.low;
  return `${CDN}/${enc(snd.catEn)}/${enc(snd.folder)}/${encodeURIComponent(v.id + suffix + '.m4a')}`;
}
/** 同源代理兜底地址（CDN 无 ACAO 头时的退路） */
function proxyUrl(snd, variantId, quality = 'low') {
  return `/api/audio?sound=${encodeURIComponent(snd.id)}&variant=${encodeURIComponent(variantId)}&quality=${quality}`;
}
const byId = (id) => state.sounds.find((s) => s.id === id);

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, 1800);
}

/** 把 range 的已填充比例写进 CSS 变量（webkit 轨道渐变用） */
function paintRange(el) {
  const min = +el.min || 0, max = +el.max || 100;
  el.style.setProperty('--fill', ((el.value - min) / (max - min) * 100).toFixed(1) + '%');
}

/* ------------------------------ 音频引擎 ------------------------------ */

function ensureAudio(id) {
  if (audio.has(id)) return audio.get(id);
  const snd = byId(id);
  if (!snd) return null;
  const a = new Audio();
  a.loop = true;
  a.preload = 'auto';

  // 取流进度 → 状态：只有真正能播了才切到「正在播放」
  a.addEventListener('loadstart', () => setPs(id, 'loading'));
  a.addEventListener('canplay', () => setPs(id, 'ready'));
  a.addEventListener('playing', () => setPs(id, 'ready'));
  a.addEventListener('timeupdate', () => setPs(id, 'ready'));   // 兜底：确实出声了

  // 直链优先；直链失败降级同源代理；代理也失败 → 播放失败
  a.addEventListener('error', () => {
    if (a._dead) return;                 // stopSound 清空 src 引发的空错误，忽略
    const st = state.active[id];
    if (!st) return;
    if (a.dataset.fallback !== '1') {
      a.dataset.fallback = '1';
      setPs(id, 'loading');
      a.src = proxyUrl(snd, st.variant);
      if (state.playing) a.play().catch(() => {});
      return;
    }
    setPs(id, 'failed');
  });

  audio.set(id, a);
  return a;
}

function applyVolume(id) {
  const a = audio.get(id);
  const st = state.active[id];
  if (!a || !st) return;
  const v = (st.volume / 100) * (state.master / 100);
  a.volume = Math.max(0, Math.min(1, v));
}

/** 该音频此刻该用的地址（直链 / 代理兜底） */
function srcFor(a, snd, variantId) {
  return a.dataset.fallback === '1' ? proxyUrl(snd, variantId) : buildUrl(snd, variantId);
}

function startSound(id, autoplay = true) {
  const snd = byId(id);
  const st = state.active[id];
  if (!snd || !st) return;
  const a = ensureAudio(id);
  a._dead = false;
  // 必须比绝对地址：a.src 读出来是绝对 URL，相对路径永远不相等 → 会反复重载
  const want = new URL(srcFor(a, snd, st.variant), location.href).href;
  if (a.src !== want) {          // 换源才算重新取流（暂停后恢复不重载）
    a.src = want;
    setPs(id, 'loading');
  }
  applyVolume(id);
  if (autoplay && state.playing) a.play().catch(() => {});
}

/** 播放失败后手动重试：重置回直链优先，重新取一遍流 */
function retrySound(id) {
  const snd = byId(id);
  const a = audio.get(id);
  if (!snd || !a || !(id in state.active)) return;
  delete a.dataset.fallback;
  a.src = buildUrl(snd, state.active[id].variant);
  a.load();                      // 同地址也强制重新取流
  setPs(id, 'loading');
  if (state.playing) a.play().catch(() => {});
}

function stopSound(id, keepSrc = false) {
  const a = audio.get(id);
  if (!a) return;
  a._dead = true;
  a.pause();
  psMap.delete(id);
  if (!keepSrc) { a.src = ''; audio.delete(id); }
}

function toggleSound(id) {
  const on = id in state.active;
  if (on) {
    delete state.active[id];
    stopSound(id);
  } else {
    const snd = byId(id);
    state.active[id] = { variant: snd.variants[0].id, volume: 60 };
    setPs(id, 'loading');        // 先亮加载态，等取流成功再显示播放中
    startSound(id);
    if (!state.playing) setPlaying(true);
  }
  persist();
  render();
}

function setPlaying(p) {
  state.playing = p;
  document.body.classList.toggle('playing', p);
  for (const id of Object.keys(state.active)) {
    if (p) startSound(id); else audio.get(id)?.pause();
  }
  // 总开关不持久化"播放中"（下次打开自动尊重用户上一次的动作，但不静默出声）
  persist();
  renderChips();
}

/* ------------------------------ 声景预设 ------------------------------ */

/** 预设的当前状态：'active'（正在用）/ 'partial'（部分命中）/ '' */
function presetMatch(p) {
  const ids = Object.keys(state.active);
  const items = p.sounds.filter((it) => byId(it.id));
  if (!items.length) return '';
  const hit = items.filter((it) => {
    const st = state.active[it.id];
    if (!st) return false;
    return !p.strictVariant || st.variant === it.variant;
  }).length;
  if (hit === items.length && ids.length === items.length) return 'active';
  if (hit > 0) return 'partial';
  return '';
}

/** 当前混音中属于预设条目的数量（用于「2/3」这类角标） */
function presetHit(p) {
  return p.sounds.filter((it) => byId(it.id) && state.active[it.id]).length;
}

function presetSub(p) {
  if (state.seg === 'mine') {
    const hit = presetHit(p);
    return hit ? `${hit} 个声音 · 已应用` : `${p.sounds.length} 个声音`;
  }
  return (p.tags || []).join(' · ');
}

function renderPresetSeg() {
  const seg = $('preset-seg');
  const n = state.mine.length;
  seg.querySelectorAll('.seg-btn').forEach((b) => {
    const on = b.dataset.seg === state.seg;
    b.classList.toggle('active', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
    b.textContent = b.dataset.seg === 'mine' ? (n ? `我的 ${n}` : '我的') : '推荐';
    b.onclick = () => { state.seg = b.dataset.seg; persistPresetSeg(); renderPresets(); };
  });
}

function renderPresets() {
  renderPresetSeg();
  const list = state.seg === 'mine' ? state.mine : state.presets;
  const grid = $('preset-grid');
  const empty = $('preset-empty');
  const noArch = !list.length;
  grid.innerHTML = noArch ? '' : list.map((p) => {
    const tone = p.tone || '#0f9488';
    const m = presetMatch(p);
    const acts = state.seg === 'mine'
      ? `<button class="icon-btn" data-pact="rename" data-pid="${p.id}" title="重命名">
           <svg viewBox="0 0 24 24" class="i"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
         </button>
         <button class="icon-btn" data-pact="del" data-pid="${p.id}" title="删除">
           <svg viewBox="0 0 24 24" class="i"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>
         </button>`
      : '';
    return `
    <div class="preset${m === 'active' ? ' active' : ''}" data-pid="${p.id}" data-mine="${state.seg === 'mine' ? 1 : 0}">
      <div class="preset-icon" style="--tone:${tone}">
        <svg viewBox="0 0 24 24"><path d="${iconPath(p.icon)}"/></svg>
      </div>
      <div class="preset-text">
        <div class="preset-name">${p.name}</div>
        <div class="preset-tags">${presetSub(p)}</div>
      </div>
      <div class="preset-acts">
        ${acts}
        <button class="mini-btn" data-pact="preview" data-pid="${p.id}" title="将预设装入播放列表（不自动播放）">
          <svg viewBox="0 0 24 24" class="i"><path d="M11 4.7a.7.7 0 0 0-1.2-.5L6.4 7.6A1.4 1.4 0 0 1 5.4 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.4a1.4 1.4 0 0 1 1 .4l3.4 3.4a.7.7 0 0 0 1.2-.5z"/></svg>
        </button>
        <button class="mini-btn play" data-pact="play" data-pid="${p.id}" title="立即播放">
          <svg viewBox="0 0 24 24" class="i"><path d="M7 4.5a1.5 1.5 0 0 1 2.28-1.28l10.5 6.5a1.5 1.5 0 0 1 0 2.56l-10.5 6.5A1.5 1.5 0 0 1 7 17.5z" fill="currentColor" stroke="none"/></svg>
        </button>
      </div>
    </div>`;
  }).join('');

  empty.hidden = !noArch;
  if (noArch && state.seg === 'mine') {
    empty.querySelector('b').textContent = '暂无保存的混音';
    empty.querySelector('span').textContent = '在底部播放栏点击保存按钮';
  }

  grid.querySelectorAll('[data-pact]').forEach((b) => {
    b.onclick = (e) => {
      e.stopPropagation();
      const p = [...state.presets, ...state.mine].find((x) => x.id === b.dataset.pid);
      if (!p) return;
      const act = b.dataset.pact;
      if (act === 'play') applyPreset(p, true);
      else if (act === 'preview') applyPreset(p, false);
      else if (act === 'rename') renameMine(p);
      else if (act === 'del') deleteMine(p);
    };
  });
  grid.querySelectorAll('.preset').forEach((el) => {
    el.onclick = (e) => {
      if (e.target.closest('button')) return;
      const p = [...state.presets, ...state.mine].find((x) => x.id === el.dataset.pid);
      if (p) applyPreset(p, true);
    };
  });
}

/** 套用预设：替换当前混音。autoplay=false 时只装入、等待用户点播放 */
function applyPreset(p, autoplay = true) {
  const items = p.sounds.filter((it) => byId(it.id));
  if (!items.length) return toast('预设里的声音已下架');

  for (const id of Object.keys(state.active)) stopSound(id);
  state.active = {};
  for (const it of items) {
    const snd = byId(it.id);
    const variant = snd.variants.some((v) => v.id === it.variant) ? it.variant : snd.variants[0].id;
    state.active[it.id] = { variant, volume: Math.max(0, Math.min(100, +it.volume || 60)) };
    startSound(it.id, false);
  }
  if (typeof p.master === 'number') setMaster(Math.max(0, Math.min(100, p.master)));
  if (autoplay) setPlaying(true);
  else { document.body.classList.remove('playing'); state.playing = false; }

  persist();
  render();
  toast(autoplay ? `已套用「${p.name}」` : `已将「${p.name}」装入播放列表`);
}

/* -------------------------- 我的预设（增删改） -------------------------- */

let smPreset = null;   // 正在重命名的预设（null = 新建）

function savePreview() {
  $('sm-preview').innerHTML = Object.entries(state.active).map(([id, st]) => {
    const s = byId(id);
    const v = s.variants.find((x) => x.id === st.variant);
    const label = v && v.id !== s.variants[0].id ? `${s.name}·${v.name}` : s.name;
    return `<span class="sv">${label} ${st.volume}</span>`;
  }).join('') || '<span class="sv">当前没有选中的声音</span>';
}

function openSave() {
  if (!Object.keys(state.active).length) return toast('先点选几个声音再保存吧');
  smPreset = null;
  $('sm-title').textContent = '保存为声景预设';
  $('sm-name').value = '';
  savePreview();
  $('save-modal').hidden = false;
  setTimeout(() => $('sm-name').focus(), 30);
}

function commitSave() {
  const name = $('sm-name').value.trim();
  if (!name) return toast('给这个预设起个名字吧');
  const renaming = smPreset;
  if (renaming) {
    renaming.name = name;
    closeSave();
    persist();
    renderPresets();
    return toast(`已重命名为「${name}」`);
  }
  const sounds = Object.entries(state.active).map(([id, st]) => ({
    id, variant: st.variant, volume: st.volume,
  }));
  state.mine.push({
    id: 'my-' + Date.now().toString(36),
    name,
    tone: '#0f9488',
    icon: 'save',
    mine: true,
    master: state.master,
    sounds,
  });
  closeSave();
  state.seg = 'mine';
  persist();
  renderPresets();
  toast(`已保存「${name}」`);
}

function renameMine(p) {
  smPreset = p;
  $('sm-title').textContent = '重命名预设';
  $('sm-name').value = p.name;
  savePreview();
  $('save-modal').hidden = false;
  setTimeout(() => { $('sm-name').focus(); $('sm-name').select(); }, 30);
}

/** 「我的」页签 / 预设列表有变化时同步存档（节流，避免连点刷盘） */
function persistPresetSeg() {
  clearTimeout(persistPresetSeg._t);
  persistPresetSeg._t = setTimeout(async () => {
    try {
      await fetch('/api/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ presetSeg: state.seg }),
      });
    } catch { /* 静默 */ }
  }, 400);
}

function deleteMine(p) {
  if (!window.confirm(`删除预设「${p.name}」？`)) return;
  state.mine = state.mine.filter((x) => x.id !== p.id);
  persist();
  renderPresets();
  toast('已删除');
}

function closeSave() { $('save-modal').hidden = true; smPreset = null; }

/* ------------------------------ 渲染 ------------------------------ */

function matchSound(s, q) {
  if (!q) return true;
  const k = q.toLowerCase();
  return s.name.toLowerCase().includes(k)
    || s.id.toLowerCase().includes(k)
    || s.variants.some((v) => v.name.toLowerCase().includes(k));
}

function currentList() {
  const q = state.q.trim();
  return state.sounds.filter((s) => {
    if (state.cat === 'playing') { if (!(s.id in state.active)) return false; }
    else if (state.cat !== 'all' && s.category !== state.cat) return false;
    return matchSound(s, q);
  });
}

function renderTabs() {
  const tabs = $('tabs');
  const playingCount = Object.keys(state.active).length;
  const list = CATS.filter((c) => c.id !== 'playing');
  if (playingCount) list.splice(1, 0, { id: 'playing', label: '播放中' });
  tabs.innerHTML = list.map((c) => {
    const n = c.id === 'all' ? state.sounds.length
      : c.id === 'playing' ? playingCount
      : state.sounds.filter((s) => s.category === c.id).length;
    return `<button class="tab${state.cat === c.id ? ' active' : ''}" data-cat="${c.id}">${c.label}</button>`;
  }).join('');
  tabs.querySelectorAll('.tab').forEach((b) => {
    b.onclick = () => { state.cat = b.dataset.cat; render(); };
  });
}

/** 未加入混音时的副标题（音效数量 / 唯一音效名） */
function idleSub(s) {
  return s.variants.length > 1 ? `${s.variants.length} 种音效` : (s.variants[0]?.name || '');
}

/** 卡片副标题：取流中 / 失败时让位给状态文案 */
function subText(s, st, ps) {
  if (ps === 'loading') return '加载中…';
  if (ps === 'failed') return '播放失败 · 点按重试';
  return st.variant !== s.variants[0].id
    ? (s.variants.find((v) => v.id === st.variant)?.name || s.name)
    : idleSub(s);
}

/** 卡片右侧状态区：转圈（取流中）/ 跳动条（已可播）/ 重试按钮（失败） */
function stateSlot(id, ps) {
  if (!(id in state.active) || !ps) return '';
  if (ps === 'loading') return '<span class="spin" role="status" title="加载中" aria-label="加载中"></span>';
  if (ps === 'failed') {
    return `<button class="mini-btn retry" data-act="retry" title="播放失败，点此重试" aria-label="重试">
      <svg viewBox="0 0 24 24" class="i"><path d="M20.4 12a8.4 8.4 0 1 1-2.5-6"/><path d="M20.4 4.2v5h-5"/></svg>
    </button>`;
  }
  return `<div class="bars" title="${state.playing ? '播放中' : '已暂停'}"><i></i><i></i><i></i><i></i></div>`;
}

/** 状态区里的重试按钮（每次写入 innerHTML 后都要重新绑） */
function bindRetry(box, id) {
  box.querySelector('[data-act="retry"]')?.addEventListener('click', (e) => {
    e.stopPropagation();
    retrySound(id);
  });
}

/** 只更新单张卡片的状态区与副标题（不重绘整个网格，避免打断音量条拖动） */
function patchCard(id) {
  const card = [...document.querySelectorAll('.card')].find((c) => c.dataset.id === id);
  if (!card) return;
  const on = id in state.active;
  const ps = on ? psOf(id) : '';
  card.classList.toggle('loading', ps === 'loading');
  card.classList.toggle('failed', ps === 'failed');
  const slot = card.querySelector('.card-state');
  if (slot) {
    slot.innerHTML = stateSlot(id, ps);
    bindRetry(slot, id);
  }
  const snd = byId(id);
  const sub = card.querySelector('.card-sub');
  if (sub && on && snd) sub.textContent = subText(snd, state.active[id], ps);
}

function renderGrid() {
  const list = currentList();
  const grid = $('grid');
  const isEmpty = list.length === 0;
  $('empty').hidden = !isEmpty;
  if (isEmpty) {
    $('empty').querySelector('b').textContent = state.q ? `没有找到「${state.q}」` : '这个分类还没有声音';
    $('empty').querySelector('span').textContent = state.q ? '试试换个关键词，或清空搜索' : '切换其他分类看看';
  }

  grid.innerHTML = list.map((s) => {
    const on = s.id in state.active;
    const st = state.active[s.id];
    const ps = on ? psOf(s.id) : '';
    const tone = TONES[s.category] || '#0f9488';
    const sub = on ? subText(s, st, ps) : idleSub(s);
    return `
    <div class="card${on ? ' active' : ''}${ps && ps !== 'ready' ? ' ' + ps : ''}" data-id="${s.id}">
      <div class="card-main">
        <div class="card-icon" style="--tone:${tone}">
          <svg viewBox="0 0 24 24"><path d="${iconPath(s.id)}"/></svg>
        </div>
        <div class="card-text">
          <div class="card-name" title="${s.name}">${s.name}</div>
          <div class="card-sub">${sub}</div>
        </div>
        <div class="card-acts">
          ${s.variants.length > 1 ? `
          <button class="mini-btn" data-act="variant" title="切换音效">
            <svg viewBox="0 0 24 24" class="i"><path d="M16 5H3M11 12H3M11 19H3M21 16V5M18 16a3 3 0 1 0 6 0 3 3 0 0 0-6 0" transform="scale(.85) translate(2 2)"/></svg>
          </button>` : ''}
          <span class="card-state" data-state="${s.id}">${stateSlot(s.id, ps)}</span>
          <button class="mini-btn play${on ? '' : ''}" data-act="play" title="${on ? '停止' : '播放'}">
            ${on
              ? `<svg viewBox="0 0 24 24" class="i"><path d="M18 6 6 18M6 6l12 12"/></svg>`
              : `<svg viewBox="0 0 24 24" class="i"><path d="M7 4.5a1.5 1.5 0 0 1 2.28-1.28l10.5 6.5a1.5 1.5 0 0 1 0 2.56l-10.5 6.5A1.5 1.5 0 0 1 7 17.5z" fill="currentColor" stroke="none"/></svg>`}
          </button>
        </div>
      </div>
      ${on ? `
      <div class="card-vol">
        <svg viewBox="0 0 24 24" class="i vol-ico"><path d="M11 4.7a.7.7 0 0 0-1.2-.5L6.4 7.6A1.4 1.4 0 0 1 5.4 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.4a1.4 1.4 0 0 1 1 .4l3.4 3.4a.7.7 0 0 0 1.2-.5z"/></svg>
        <input type="range" min="0" max="100" value="${st.volume}" data-vol="${s.id}" aria-label="${s.name} 音量">
        <span class="vol-num">${st.volume}</span>
      </div>` : ''}
    </div>`;
  }).join('');

  grid.querySelectorAll('input[data-vol]').forEach((el) => {
    paintRange(el);
    el.oninput = () => {
      const id = el.dataset.vol;
      const v = +el.value;
      state.active[id].volume = v;
      el.parentElement.querySelector('.vol-num').textContent = v;
      paintRange(el);
      applyVolume(id);
      persistDebounced();
    };
    el.onchange = () => renderChips();
  });

  grid.querySelectorAll('.card').forEach((card) => {
    const id = card.dataset.id;
    card.querySelector('[data-act="play"]')?.addEventListener('click', (e) => {
      e.stopPropagation(); toggleSound(id);
    });
    card.querySelector('[data-act="variant"]')?.addEventListener('click', (e) => {
      e.stopPropagation(); openVariants(id);
    });
    bindRetry(card, id);
    card.addEventListener('click', (e) => {
      if (e.target.closest('input,button')) return;
      toggleSound(id);
    });
  });

  renderChips();
}

/** 底部标题：加载中 / 播放失败 / 正在播放 / 已暂停（按各路真实状态汇总） */
function nowTitle() {
  const ids = Object.keys(state.active);
  if (!ids.length) return { text: '正在播放', cls: '' };
  const ps = ids.map(psOf);
  const failed = ps.filter((s) => s === 'failed').length;
  const loading = ps.filter((s) => s === 'loading').length;
  if (failed === ids.length) return { text: '播放失败', cls: 'failed' };
  if (state.playing && loading === ids.length) return { text: '加载中…', cls: 'loading' };
  const base = state.playing ? '正在播放' : '已暂停';
  return failed
    ? { text: `${base} · ${failed} 个播放失败`, cls: 'failed' }
    : { text: base, cls: '' };
}

function renderChips() {
  const ids = Object.keys(state.active);
  const box = $('chips');
  const title = $('now-title');
  const t = nowTitle();
  title.textContent = t.text;
  title.className = 'now-title' + (t.cls ? ' ' + t.cls : '');
  if (!ids.length) {
    box.innerHTML = '<span class="chip-count">点击声音卡片添加 / 移除</span>';
    return;
  }
  box.innerHTML = ids.map((id) => {
    const s = byId(id);
    const st = state.active[id];
    const ps = psOf(id);
    const cls = ['chip'];
    let tip = '点击移除';
    if (ps === 'failed') { cls.push('err'); tip = '播放失败，点击移除'; }
    else if (ps === 'loading') { cls.push('loading'); tip = '加载中…，点击移除'; }
    else if (st.volume === 0 || state.master === 0) cls.push('muted');
    return `<span class="${cls.join(' ')}" data-chip="${id}" title="${tip}"><span class="dot"></span>${s.name}</span>`;
  }).join('') + `<span class="chip-count">${ids.length} 个混音中</span>`;
  box.querySelectorAll('[data-chip]').forEach((c) => {
    c.onclick = () => toggleSound(c.dataset.chip);
  });
}

function render() {
  renderPresets();
  renderTabs();
  renderGrid();
  const anyOn = Object.keys(state.active).length > 0;
  $('play-btn').style.opacity = anyOn ? '1' : '.55';
}

/* ------------------------------ 变体弹窗 ------------------------------ */

let vmSound = null;
function openVariants(id) {
  const s = byId(id);
  if (!s) return;
  vmSound = id;
  $('vm-title').textContent = s.name + ' · 选择音效';
  const cur = state.active[id]?.variant || s.variants[0].id;
  $('vm-body').innerHTML = s.variants.map((v) => `
    <button class="vitem${v.id === cur ? ' sel' : ''}" data-v="${encodeURIComponent(v.id)}">
      <span>${v.name}</span>${v.id === cur ? '<span class="tick">当前</span>' : ''}
    </button>`).join('');
  $('vm-body').querySelectorAll('.vitem').forEach((b) => {
    b.onclick = () => {
      const vid = decodeURIComponent(b.dataset.v);
      if (!(id in state.active)) {
        state.active[id] = { variant: vid, volume: 60 };
        startSound(id);
        if (!state.playing) setPlaying(true);
      } else {
        state.active[id].variant = vid;
        startSound(id);
      }
      closeVariants();
      persist();
      render();
    };
  });
  $('variant-modal').hidden = false;
}
function closeVariants() { $('variant-modal').hidden = true; vmSound = null; }

/* ------------------------------ 持久化 ------------------------------ */

let saveTimer = null;
function persistDebounced() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 400);
}
async function persist() {
  try {
    await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        active: state.active,
        master: state.master,
        cat: state.cat,
        presets: state.mine,
      }),
    });
  } catch { /* 静默：偏好存不下来不影响使用 */ }
}
async function load() {
  try {
    const r = await fetch('/api/state');
    const s = await r.json();
    if (s && typeof s === 'object') {
      if (s.active && typeof s.active === 'object') {
        for (const [id, v] of Object.entries(s.active)) {
          if (byId(id)) state.active[id] = { variant: v.variant, volume: +v.volume || 60 };
        }
      }
      if (typeof s.master === 'number') state.master = s.master;
      if (typeof s.cat === 'string' && CATS.some((c) => c.id === s.cat)) state.cat = s.cat;
      if (Array.isArray(s.presets)) {
        state.mine = s.presets.filter((p) => p && p.id && p.name && Array.isArray(p.sounds));
      }
      if (s.presetSeg === 'rec' || s.presetSeg === 'mine') state.seg = s.presetSeg;
    }
  } catch { /* 首次启动没有存档 */ }
}

/* ------------------------------ 导入导出 ------------------------------ */

function doExport() {
  const data = { app: 'whitenoise', version: 1, active: state.active, master: state.master };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'whitenoise-mix.json';
  a.click();
  URL.revokeObjectURL(a.href);
  toast('已导出混音方案');
}

function doImport(file) {
  const fr = new FileReader();
  fr.onload = () => {
    try {
      const d = JSON.parse(fr.result);
      const src = d.active && typeof d.active === 'object' ? d.active : d;
      const next = {};
      for (const [id, v] of Object.entries(src)) {
        if (byId(id) && v && typeof v === 'object') next[id] = { variant: v.variant, volume: +v.volume || 60 };
      }
      const n = Object.keys(next).length;
      if (!n) return toast('没有可导入的声音');
      for (const id of Object.keys(state.active)) stopSound(id);
      state.active = next;
      if (typeof d.master === 'number') state.master = d.master;
      $('vol-slider').value = state.master;
      $('vol-val').textContent = state.master;
      paintRange($('vol-slider'));
      setPlaying(true);
      persist();
      render();
      toast(`已导入 ${n} 个声音`);
    } catch { toast('文件格式不正确'); }
  };
  fr.readAsText(file);
}

/* ------------------------------ 总控 ------------------------------ */

function setMaster(v) {
  state.master = v;
  $('vol-slider').value = v;
  $('vol-val').textContent = v;
  paintRange($('vol-slider'));
  document.body.classList.toggle('muted', v === 0);
  for (const id of Object.keys(state.active)) applyVolume(id);
  renderChips();
  persistDebounced();
}

function clearAll() {
  for (const id of Object.keys(state.active)) stopSound(id);
  state.active = {};
  setPlaying(false);
  document.body.classList.remove('playing');
  persist();
  render();
}

/* ------------------------------ 启动 ------------------------------ */

async function init() {
  const [rSounds, rPresets] = await Promise.all([
    fetch('/api/sounds'),
    fetch('/api/presets').catch(() => null),
  ]);
  state.sounds = await rSounds.json();
  if (rPresets && rPresets.ok) {
    try { state.presets = await rPresets.json(); } catch { state.presets = []; }
  }

  await load();

  // 恢复上次的混音（不自动出声音，等用户点播放 —— 浏览器自动播放策略友好）
  for (const id of Object.keys(state.active)) startSound(id, false);
  document.body.classList.remove('playing');

  setMaster(state.master);
  render();

  $('play-btn').onclick = () => {
    if (!Object.keys(state.active).length) return toast('先点选一个声音吧');
    setPlaying(!state.playing);
    renderChips();
  };
  $('vol-slider').oninput = (e) => setMaster(+e.target.value);
  $('search-input').oninput = (e) => { state.q = e.target.value; renderGrid(); renderTabs(); };
  $('vol-btn').onclick = () => setMaster(state.master === 0 ? 80 : 0);
  $('btn-clear').onclick = clearAll;
  $('btn-export').onclick = doExport;
  $('btn-import').onclick = () => $('import-file').click();
  $('import-file').onchange = (e) => { if (e.target.files[0]) doImport(e.target.files[0]); e.target.value = ''; };
  $('vm-close').onclick = closeVariants;
  $('variant-modal').onclick = (e) => { if (e.target.id === 'variant-modal') closeVariants(); };
  $('btn-save').onclick = openSave;
  $('sm-close').onclick = closeSave;
  $('sm-cancel').onclick = closeSave;
  $('sm-ok').onclick = commitSave;
  $('sm-name').onkeydown = (e) => { if (e.key === 'Enter') commitSave(); };
  $('save-modal').onclick = (e) => { if (e.target.id === 'save-modal') closeSave(); };
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeVariants(); closeSave(); }
    if (e.key === ' ' && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) {
      e.preventDefault();
      $('play-btn').click();
    }
  });
}

init();
