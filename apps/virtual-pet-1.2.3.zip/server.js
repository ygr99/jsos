import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { mkdirSync, writeFileSync, existsSync, readFileSync, renameSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// [存储规范] 数据存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/<appId>，
// 卸载勾选「同时删除应用数据」时由平台整目录清除）；本机直跑回退 ./data
// 精灵图上传也随 DATA_DIR —— 顺带修复了升级重装（app 目录被替换）丢精灵图的问题
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const uploadDir = join(DATA_DIR, 'uploads');
const STATE_FILE = join(DATA_DIR, 'state.json');
if (!existsSync(uploadDir)) mkdirSync(uploadDir, { recursive: true });

app.use(express.json({ limit: '20mb' }));
app.use(express.static(join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// 宠物状态：主界面与小组件经此共享（原子写）
app.get('/api/state', (req, res) => {
  try {
    if (!existsSync(STATE_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  const d = req.body;
  if (!d || !Array.isArray(d.pets)) return res.status(400).json({ error: 'invalid state' });
  try {
    // widgetSelections（小组件实例 → 宠物 id）按 key 浅合并进已存文档：
    // 各端写回都带整份 state，merge 防止旧内存快照覆盖掉其他实例刚写入的选择
    const prev = existsSync(STATE_FILE) ? JSON.parse(readFileSync(STATE_FILE, 'utf8')) : {};
    const doc = { pets: d.pets, currentPetId: d.currentPetId };
    if (d.widgetSelections || prev.widgetSelections) {
      doc.widgetSelections = Object.assign({}, prev.widgetSelections, d.widgetSelections);
    }
    const tmp = STATE_FILE + '.tmp';
    writeFileSync(tmp, JSON.stringify(doc));
    renameSync(tmp, STATE_FILE);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 精灵图上传：前端把文件转 base64 JSON 提交（免 multipart 依赖）
app.post('/api/upload', (req, res) => {
  try {
    const { name, data } = req.body || {};
    const m = typeof data === 'string' ? data.match(/^data:image\/(png|webp|jpeg|jpg|gif);base64,(.+)$/) : null;
    if (!m) return res.status(400).json({ error: '仅支持 image base64 data URL' });
    const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
    const file = `pet_${Date.now()}.${ext}`;
    writeFileSync(join(uploadDir, file), Buffer.from(m[2], 'base64'));
    res.json({ url: `/uploads/${file}` });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`virtual-pet running on ${port}`));
