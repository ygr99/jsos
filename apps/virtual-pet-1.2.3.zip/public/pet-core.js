// 虚拟宠物共享核心：数据读写 / 状态衰减 / 精灵动画器
// 主界面 (app.js) 与桌面小组件 (widget.js) 共用
// [存储规范] 数据经 /api/state 存服务端 DATA_DIR（容器内 = workspace/data/<appId>，
// 平台卸载勾选「同时删除应用数据」时整目录清除）；跨页面用 BroadcastChannel 同步

export const DEFAULT_SHEET = '/spritesheet.webp';
const SYNC_CHANNEL = 'virtual-pet-sync';

export const SPRITE = { frameWidth: 192, frameHeight: 208, cols: 8, rows: 9 };

export const ANIMATIONS = {
  idle:     { name: '站立', frames: [0,1,2,3,4,5],       row: 0 },
  runRight: { name: '右行', frames: [0,1,2,3,4,5,6,7],   row: 1 },
  runLeft:  { name: '左行', frames: [0,1,2,3,4,5,6,7],   row: 2 },
  waving:   { name: '招手', frames: [0,1,2,3],           row: 3 },
  jumping:  { name: '跳跃', frames: [0,1,2,3,4],         row: 4 },
  failed:   { name: '难过', frames: [0,1,2,3,4,5,6,7],   row: 5 },
  waiting:  { name: '等待', frames: [0,1,2,3,4,5],       row: 6 },
  running:  { name: '奔跑', frames: [0,1,2,3,4,5],       row: 7 },
  review:   { name: '观察', frames: [0,1,2,3,4,5],       row: 8 },
};
export const ANIM_KEYS = Object.keys(ANIMATIONS);

export function newPet(name = '哆啦', spritesheetUrl = '') {
  return {
    id: 'pet_' + Date.now(),
    name,
    spritesheetUrl,
    hunger: 50, happiness: 50, energy: 50,
    lastInteraction: Date.now(),
    level: 1, experience: 0,
    currentAnimation: 'idle',
  };
}

export function defaultData() {
  return {
    pets: [Object.assign(newPet('哆啦'), { id: 'default' })],
    currentPetId: 'default',
  };
}

export async function loadData() {
  try {
    const res = await fetch('/api/state', { cache: 'no-store' });
    const d = await res.json();
    if (!d || !Array.isArray(d.pets) || !d.pets.length) return defaultData();
    return d;
  } catch (e) {
    console.error('加载宠物数据失败:', e);
    return defaultData();
  }
}

export async function saveData(data) {
  try {
    await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pets: data.pets,
        currentPetId: data.currentPetId,
        widgetSelections: data.widgetSelections || {},
      }),
    });
  } catch (e) {
    console.error('保存宠物数据失败:', e);
    return;
  }
  notifyChange();
}

/** 跨页面即时通知（同一容器内同源） */
export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage('state-updated');
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = () => cb();
  } catch {}
}

const clamp = (v, lo = 0, hi = 100) => Math.min(hi, Math.max(lo, v));

// 按距上次交互的小时数衰减（幂等：基于 lastInteraction 计算，多端同时算结果一致）
export function applyDecay(pet, now = Date.now()) {
  const hours = Math.max(0, (now - (pet.lastInteraction || now)) / 3600000);
  if (hours <= 0) return;
  pet.hunger = clamp(pet.hunger - hours * 5);
  pet.happiness = clamp(pet.happiness - hours * 3);
  pet.energy = clamp(pet.energy - hours * 2);
  if (pet.hunger < 20) {
    pet.energy = clamp(pet.energy - hours * 1);
    pet.happiness = clamp(pet.happiness - hours * 2);
  }
  if (pet.happiness < 20 && pet.energy < 80) pet.energy = clamp(pet.energy - hours * 0.5);
  if (pet.energy > 80 && pet.happiness < 100) pet.happiness = clamp(pet.happiness + hours * 0.5);
  pet.lastInteraction = now;
}

export function expNeeded(pet) { return pet.level * 50; }

// 返回升级后的新等级（未升级返回 null）
export function gainExperience(pet, exp) {
  pet.experience += exp;
  if (pet.experience >= expNeeded(pet)) {
    pet.experience -= expNeeded(pet);
    pet.level += 1;
    return pet.level;
  }
  return null;
}

// 精灵图动画器：CSS background-position 逐帧播放
export class SpriteAnimator {
  constructor(el, opts = {}) {
    this.el = el;
    this.sheetUrl = opts.sheetUrl || DEFAULT_SHEET;
    // 构造时立即设置背景图：此前背景靠 CSS 写死的默认精灵图、只有 setSheet 才改，
    // 初始宠物带自定义精灵图时会"帧坐标按新图算、背景却是默认图"
    this.setSheet(this.sheetUrl);
    this.frameRate = opts.frameRate || 150;
    // 显示宽度（帧按比例缩放）
    this.displayWidth = opts.displayWidth || SPRITE.frameWidth;
    this.scale = this.displayWidth / SPRITE.frameWidth;
    this.onAnimChange = opts.onAnimChange || null;
    this.currentAnimation = 'idle';
    this.currentFrame = 0;
    this.timer = null;
  }
  setSheet(url) {
    this.sheetUrl = url || DEFAULT_SHEET;
    this.el.style.backgroundImage = `url('${this.sheetUrl}')`;
  }
  play(name) {
    if (!ANIMATIONS[name]) return;
    this.stop();
    this.currentAnimation = name;
    this.currentFrame = 0;
    this.updateFrame();
    this.start();
    if (this.onAnimChange) this.onAnimChange(name);
  }
  updateFrame() {
    const a = ANIMATIONS[this.currentAnimation];
    const fi = a.frames[this.currentFrame];
    this.el.style.backgroundSize =
      (SPRITE.cols * SPRITE.frameWidth * this.scale) + 'px ' +
      (SPRITE.rows * SPRITE.frameHeight * this.scale) + 'px';
    this.el.style.backgroundPosition =
      (-(fi * SPRITE.frameWidth * this.scale)) + 'px ' +
      (-(a.row * SPRITE.frameHeight * this.scale)) + 'px';
  }
  start() {
    this.timer = setInterval(() => {
      const a = ANIMATIONS[this.currentAnimation];
      this.currentFrame = (this.currentFrame + 1) % a.frames.length;
      this.updateFrame();
    }, this.frameRate);
  }
  stop() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }
}

export function sheetUrlOf(pet) { return pet.spritesheetUrl || DEFAULT_SHEET; }
