let clips = [];
let tags = [];
let currentId = null;
let selectedIds = new Set();
let searchQuery = '';
let filterTag = 'all';

const $ = id => document.getElementById(id);

function init() {
  loadClips();
  bindEvents();
  initTheme();
}

async function loadClips() {
  const res = await fetch('/api/clips');
  clips = await res.json();
  updateTags();
  renderList();
  renderTags();
}

function updateTags() {
  const allTags = new Set();
  clips.forEach(c => {
    if (c.tags) c.tags.forEach(t => allTags.add(t));
  });
  tags = Array.from(allTags).sort();
}

function renderTags() {
  const container = $('custom-tags');
  container.innerHTML = tags.map(t => `
    <div class="tag-item" data-tag="${t}">${t}</div>
  `).join('');
  container.querySelectorAll('.tag-item').forEach(el => {
    el.addEventListener('click', () => setTagFilter(el.dataset.tag));
  });
}

function setTagFilter(tag) {
  filterTag = tag;
  document.querySelector('.tag-list').querySelectorAll('.tag-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tag === tag);
  });
  renderList();
  updateActions();
}

function renderList() {
  const list = $('clip-list');
  let filtered = clips;
  
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(c => 
      (c.title || '').toLowerCase().includes(q) || 
      c.content.toLowerCase().includes(q) ||
      (c.tags || []).some(t => t.toLowerCase().includes(q))
    );
  }
  
  if (filterTag !== 'all') {
    if (filterTag === 'untagged') {
      filtered = filtered.filter(c => !c.tags || c.tags.length === 0);
    } else {
      filtered = filtered.filter(c => c.tags && c.tags.includes(filterTag));
    }
  }

  if (filtered.length === 0) {
    list.innerHTML = `<div id="empty-state"><p>${searchQuery ? '未找到匹配的快帖' : '暂无快帖，点击右下角 + 添加'}</p></div>`;
    return;
  }

  list.innerHTML = filtered.map(c => `
    <div class="clip-card ${c.id === currentId ? 'active' : ''} ${selectedIds.has(c.id) ? 'selected' : ''}" data-id="${c.id}" ${selectedIds.size > 0 ? 'style="cursor:default"' : ''}>
      <div class="clip-card-content">
        ${c.content.startsWith('/images/') 
          ? `<img class="clip-card-image" src="${c.content}" alt="image" />` 
          : escapeHtml(c.content).slice(0, 300)}
      </div>
      <div class="clip-card-footer">
        <div class="clip-card-tags">
          ${(c.tags || []).map(t => `<span class="clip-card-tag">${t}</span>`).join('')}
        </div>
        ${c.title ? `<span class="clip-card-remark">${escapeHtml(c.title)}</span>` : ''}
        <span class="clip-card-time">${formatDate(c.createdAt)}</span>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.clip-card').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.dataset.id;
      if (selectedIds.size > 0) {
        toggleSelect(id);
      } else {
        selectClip(id);
      }
    });
    el.addEventListener('dblclick', () => {
      const id = el.dataset.id;
      copyClip(id);
    });
    el.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const id = el.dataset.id;
      if (!selectedIds.has(id)) {
        selectedIds.clear();
        selectedIds.add(id);
      }
      renderList();
    });
  });
}

function escapeHtml(text) {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}

function formatDate(timestamp) {
  const d = new Date(timestamp);
  const now = new Date();
  const diff = now - d;
  
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
  if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前';
  
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function selectClip(id) {
  currentId = id;
  selectedIds.clear();
  renderList();
  updateActions();
}

function toggleSelect(id) {
  if (selectedIds.has(id)) {
    selectedIds.delete(id);
  } else {
    selectedIds.add(id);
  }
  renderList();
  updateActions();
}

function updateActions() {
  const hasSelection = currentId !== null || selectedIds.size > 0;
  $('btn-copy').disabled = !hasSelection;
  $('btn-edit').disabled = !hasSelection;
  $('btn-delete').disabled = !hasSelection;
  const isCustomTag = filterTag !== 'all' && filterTag !== 'untagged';
  $('btn-pin').style.display = isCustomTag ? 'flex' : 'none';
  $('btn-pin').disabled = !hasSelection;
}

async function pinClip() {
  const id = currentId || [...selectedIds][0];
  if (!id) return;
  await fetch(`/api/clips/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pinnedAt: Date.now() })
  });
  await loadClips();
  showToast('已置顶');
}

async function copyClip(id) {
  const clip = clips.find(c => c.id === id);
  if (!clip) return;
  
  if (clip.content.startsWith('/images/')) {
    try {
      const res = await fetch(clip.content);
      const blob = await res.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
    } catch {
      showToast('复制失败');
      return;
    }
  } else {
    try {
      await navigator.clipboard.writeText(clip.content);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = clip.content;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }
  
  showToast('已复制');
}

function showToast(msg) {
  const toast = document.createElement('div');
  toast.style.cssText = 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);padding:8px 16px;background:rgba(0,0,0,.8);color:#fff;border-radius:6px;font-size:13px;z-index:2000';
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

let editingClip = null;
let uploadedImageUrl = '';

function openModal(clip = null) {
  editingClip = clip;
  const modal = $('modal');
  const title = $('modal-title');
  const inputTag = $('input-tag');
  const inputContent = $('input-content');
  const inputRemark = $('input-remark');
  
  if (clip) {
    title.textContent = '编辑快帖';
    inputTag.value = (clip.tags || []).join(', ');
    inputContent.value = clip.content.startsWith('/images/') ? '' : clip.content;
    inputRemark.value = clip.title || '';
    if (clip.content.startsWith('/images/')) {
      uploadedImageUrl = clip.content;
      updateImagePreview();
    } else {
      uploadedImageUrl = '';
      updateImagePreview();
    }
  } else {
    title.textContent = '新建快帖';
    inputTag.value = (filterTag !== 'all' && filterTag !== 'untagged') ? filterTag : '';
    inputContent.value = '';
    inputRemark.value = '';
    uploadedImageUrl = '';
    updateImagePreview();
  }
  
  modal.classList.remove('hidden');
}

function closeModal() {
  $('modal').classList.add('hidden');
  editingClip = null;
}

function updateImagePreview() {
  const preview = $('image-preview');
  if (uploadedImageUrl) {
    preview.innerHTML = `<img src="${uploadedImageUrl}" />`;
    preview.classList.add('has-image');
  } else {
    preview.innerHTML = '';
    preview.classList.remove('has-image');
  }
}

async function handleImageUpload(file) {
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = async (e) => {
    const base64 = e.target.result;
    const res = await fetch('/api/images', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64 })
    });
    const data = await res.json();
    uploadedImageUrl = data.url;
    updateImagePreview();
  };
  reader.readAsDataURL(file);
}

async function saveClip() {
  const tagStr = $('input-tag').value.trim();
  const tags = tagStr ? tagStr.split(/[,，\s]+/).filter(t => t) : [];
  const content = $('input-content').value;
  const remark = $('input-remark').value.trim();
  
  let clipContent = content;
  if (uploadedImageUrl) {
    clipContent = uploadedImageUrl;
  } else if (!content.trim()) {
    showToast('请输入内容');
    return;
  }
  
  const body = {
    type: uploadedImageUrl ? 'image' : 'text',
    title: remark,
    content: clipContent,
    tags: tags
  };
  
  let res;
  if (editingClip) {
    res = await fetch(`/api/clips/${editingClip.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } else {
    res = await fetch('/api/clips', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }
  
  if (!res.ok) {
    const text = await res.text();
    showToast('保存失败');
    return;
  }
  try { await res.json(); } catch {}
  closeModal();
  uploadedImageUrl = '';
  await loadClips();
  showToast(editingClip ? '已更新' : '已添加');
}

async function deleteClip() {
  if (selectedIds.size > 0) {
    if (!confirm(`确定删除选中的 ${selectedIds.size} 个快帖？`)) return;
    for (const id of selectedIds) {
      await fetch(`/api/clips/${id}`, { method: 'DELETE' });
    }
    selectedIds.clear();
  } else if (currentId) {
    if (!confirm('确定删除这个快帖？')) return;
    await fetch(`/api/clips/${currentId}`, { method: 'DELETE' });
    currentId = null;
  }
  
  await loadClips();
  showToast('已删除');
}

function bindEvents() {
  $('btn-new').addEventListener('click', () => openModal());
  $('btn-edit').addEventListener('click', () => {
    if (selectedIds.size === 1) {
      const clip = clips.find(c => c.id === [...selectedIds][0]);
      openModal(clip);
    } else if (currentId) {
      const clip = clips.find(c => c.id === currentId);
      openModal(clip);
    }
  });
  $('btn-delete').addEventListener('click', deleteClip);
  $('btn-pin').addEventListener('click', pinClip);
  $('btn-copy').addEventListener('click', () => {
    if (selectedIds.size > 0) {
      selectedIds.forEach(id => copyClip(id));
      showToast('已复制全部选中');
    } else if (currentId) {
      copyClip(currentId);
    }
  });
  
  $('modal-mask').addEventListener('click', closeModal);
  $('modal-close').addEventListener('click', closeModal);
  $('btn-cancel').addEventListener('click', closeModal);
  $('btn-save').addEventListener('click', saveClip);
  
  $('btn-upload-image').addEventListener('click', () => $('file-input').click());
  $('file-input').addEventListener('change', (e) => {
    handleImageUpload(e.target.files[0]);
  });
  
  function openTagModal(mode, tagName) {
    $('tag-modal-title').textContent = mode === 'add' ? '新增标签' : '修改标签';
    $('tag-modal-input').value = tagName || '';
    $('tag-modal').classList.remove('hidden');
    setTimeout(() => $('tag-modal-input').focus(), 100);
  }

  function closeTagModal() {
    $('tag-modal').classList.add('hidden');
  }

  async function saveTag() {
    const name = $('tag-modal-input').value.trim();
    if (!name) { showToast('请输入标签名'); return; }
    const mode = $('tag-modal-title').textContent === '新增标签' ? 'add' : 'rename';

    if (mode === 'add') {
      if (!tags.includes(name)) {
        tags.push(name);
        tags.sort();
        renderTags();
      }
      setTagFilter(name);
    } else {
      const oldTag = filterTag;
      if (oldTag === 'all' || oldTag === 'untagged') return;
      if (name !== oldTag) {
        for (const clip of clips) {
          if (clip.tags && clip.tags.includes(oldTag)) {
            const newTags = clip.tags.map(t => t === oldTag ? name : t);
            await fetch(`/api/clips/${clip.id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ tags: newTags })
            });
          }
        }
        await loadClips();
      }
      setTagFilter(name);
    }

    closeTagModal();
  }

  $('btn-add-tag').addEventListener('click', () => openTagModal('add'));

  $('btn-edit-tag').addEventListener('click', () => {
    if (filterTag === 'all' || filterTag === 'untagged') {
      showToast('请先选择一个标签');
      return;
    }
    openTagModal('rename', filterTag);
  });

  $('btn-delete-tag').addEventListener('click', async () => {
    const tag = filterTag;
    if (tag === 'all' || tag === 'untagged') {
      showToast('请先选择一个标签');
      return;
    }
    if (!confirm(`确定删除标签「${tag}」？将从所有快帖中移除此标签。`)) return;
    for (const clip of clips) {
      if (clip.tags && clip.tags.includes(tag)) {
        const newTags = clip.tags.filter(t => t !== tag);
        await fetch(`/api/clips/${clip.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tags: newTags })
        });
      }
    }
    await loadClips();
    setTagFilter('all');
    showToast('已删除标签');
  });

  $('tag-modal-mask').addEventListener('click', closeTagModal);
  $('tag-modal-close').addEventListener('click', closeTagModal);
  $('tag-modal-cancel').addEventListener('click', closeTagModal);
  $('tag-modal-confirm').addEventListener('click', saveTag);
  $('tag-modal-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveTag();
    else if (e.key === 'Escape') closeTagModal();
  });
  document.querySelectorAll('.tag-list > .tag-item').forEach(el => {
    el.addEventListener('click', () => setTagFilter(el.dataset.tag));
  });
  
  $('search').addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderList();
  });
  
  $('search').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter' && !e.target.value) {
      e.preventDefault();
      try {
        const text = await navigator.clipboard.readText();
        $('input-content').value = text;
        openModal();
      } catch {
        showToast('无法读取剪贴板');
      }
    }
  });
  
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!document.querySelector('.modal.hidden')) {
        closeModal();
      } else if (selectedIds.size > 0) {
        selectedIds.clear();
        renderList();
      }
    }
  });
  
  document.addEventListener('paste', (e) => {
    if (document.activeElement === $('input-content') || 
        document.activeElement === $('input-tag') ||
        document.activeElement === $('input-remark') ||
        document.activeElement === $('search')) {
      return;
    }
    const items = e.clipboardData.items;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        openModal();
        handleImageUpload(file);
        break;
      } else if (item.type === 'text/plain') {
        item.getAsString(text => {
          openModal();
          $('input-content').value = text;
        });
        break;
      }
    }
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
}

async function initTheme() {
  if (window.JSOS) {
    const theme = await window.JSOS.getTheme();
    applyTheme(theme);
    window.JSOS.onThemeChange(applyTheme);
  }
}

init();
