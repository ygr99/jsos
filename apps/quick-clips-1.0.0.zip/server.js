import express from 'express';
import { readFile, writeFile, readdir, unlink, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const CLIPS_DIR = join(DATA_DIR, 'clips');
const IMAGES_DIR = join(DATA_DIR, 'images');

app.use(express.json({ limit: '10mb' }));
app.use(express.static(join(__dirname, 'public')));

async function ensureDirs() {
  try { await mkdir(CLIPS_DIR, { recursive: true }); } catch {}
  try { await mkdir(IMAGES_DIR, { recursive: true }); } catch {}
}

app.get('/api/clips', async (req, res) => {
  try {
    await ensureDirs();
    const files = await readdir(CLIPS_DIR);
    const clips = await Promise.all(
      files.filter(f => f.endsWith('.json')).map(async (f) => {
        const data = JSON.parse(await readFile(join(CLIPS_DIR, f), 'utf-8'));
        return data;
      })
    );
    clips.sort((a, b) => {
      if (a.pinnedAt && b.pinnedAt) return b.pinnedAt - a.pinnedAt;
      if (a.pinnedAt) return -1;
      if (b.pinnedAt) return 1;
      return b.createdAt - a.createdAt;
    });
    res.json(clips);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/clips/:id', async (req, res) => {
  try {
    const data = await readFile(join(CLIPS_DIR, `${req.params.id}.json`), 'utf-8');
    res.json(JSON.parse(data));
  } catch {
    res.status(404).json({ error: 'not found' });
  }
});

app.post('/api/clips', async (req, res) => {
  try {
    await ensureDirs();
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const clip = {
      id,
      type: req.body.type || 'text',
      title: req.body.title || '',
      content: req.body.content || '',
      tags: req.body.tags || [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await writeFile(join(CLIPS_DIR, `${id}.json`), JSON.stringify(clip, null, 2));
    res.json(clip);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/clips/:id', async (req, res) => {
  try {
    const filePath = join(CLIPS_DIR, `${req.params.id}.json`);
    const existing = JSON.parse(await readFile(filePath, 'utf-8'));
    const updated = { ...existing, ...req.body, id: req.params.id, updatedAt: Date.now() };
    await writeFile(filePath, JSON.stringify(updated, null, 2));
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/clips/:id', async (req, res) => {
  try {
    await unlink(join(CLIPS_DIR, `${req.params.id}.json`));
    res.json({ ok: true });
  } catch {
    res.status(404).json({ error: 'not found' });
  }
});

app.post('/api/images', async (req, res) => {
  try {
    await ensureDirs();
    const { base64 } = req.body;
    if (!base64) return res.status(400).json({ error: 'missing base64' });
    const ext = base64.startsWith('data:image/png') ? 'png' : 
                 base64.startsWith('data:image/jpeg') || base64.startsWith('data:image/jpg') ? 'jpg' : 'png';
    const filename = Date.now().toString(36) + '.' + ext;
    const data = base64.split(',')[1];
    await writeFile(join(IMAGES_DIR, filename), Buffer.from(data, 'base64'));
    res.json({ url: '/images/' + filename });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/images/:filename', async (req, res) => {
  try {
    const filePath = join(IMAGES_DIR, req.params.filename);
    const ext = req.params.filename.split('.').pop().toLowerCase();
    const mime = ext === 'png' ? 'image/png' : 'image/jpeg';
    const data = await readFile(filePath);
    res.set('Content-Type', mime);
    res.send(data);
  } catch {
    res.status(404).send('Not found');
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`running on ${port}`));
