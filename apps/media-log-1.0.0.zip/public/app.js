/* 书影音游 media-log —— 前端逻辑
 * 数据流：/api/state 拉取全量 → 本地筛选/分组渲染 → 增删改后重新拉取
 * 时间轴：年 → 月（左侧 sticky 年月栏）→ 日 → 卡片网格
 */
(function () {
  'use strict';

  // ---------------- 常量 ----------------

  const STATUS_KEYS = ['done', 'doing', 'want'];

  /** 不同分类类型的状态表述：书籍说"已读"，影视说"已看" */
  const KIND_STATUS = {
    book: { done: '已读', doing: '在读', want: '想读' },
    movie: { done: '已看', doing: '在看', want: '想看' },
    music: { done: '已听', doing: '在听', want: '想听' },
    game: { done: '已玩', doing: '在玩', want: '想玩' },
    other: { done: '已完成', doing: '进行中', want: '想做' },
  };
  const KIND_NAME = { book: '书籍', movie: '影视', music: '音乐', game: '游戏', other: '通用' };
  /** 无封面时的渐变底色（按分类类型区分） */
  const KIND_THEME = {
    book: ['#f7b955', '#e08b34'],
    movie: ['#fb7185', '#c026d3'],
    music: ['#34d399', '#0ea5e9'],
    game: ['#a78bfa', '#4f46e5'],
    other: ['#94a3b8', '#64748b'],
  };
  const WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  const COLLAPSE_KEY = 'media-log.sidebar-collapsed';

  // ---------------- 运行时状态 ----------------

  const S = {
    categories: [],
    items: [],
    catId: 'book',
    status: 'done',
    q: '',
    sort: 'date-desc',
    editingId: null,
  };

  // ---------------- DOM 简写 ----------------

  const $ = id => document.getElementById(id);
  const el = {
    shell: $('shell'), collapseBtn: $('collapse-btn'), icCollapse: $('ic-collapse'), icExpand: $('ic-expand'),
    catNav: $('cat-nav'), pageTitle: $('page-title'), pageSub: $('page-sub'),
    statusTabs: $('status-tabs'), timeline: $('timeline'),
    search: $('search-input'), sortSelect: $('sort-select'),
    btnAdd: $('btn-add'), btnManage: $('btn-manage-cat'),
    toast: $('toast'),
  };

  // ---------------- 工具 ----------------

  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function kindOf(catId) {
    const c = S.categories.find(x => x.id === catId);
    return c ? c.kind : 'other';
  }

  function statusLabel(kind, key) {
    return (KIND_STATUS[kind] || KIND_STATUS.other)[key];
  }

  function toast(msg, isError) {
    el.toast.textContent = msg;
    el.toast.classList.toggle('error', !!isError);
    el.toast.removeAttribute('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.toast.setAttribute('hidden', ''), 2400);
  }

  async function api(url, options) {
    const res = await fetch(url, Object.assign({
      headers: { 'Content-Type': 'application/json' },
    }, options || {}));
    let data = null;
    try { data = await res.json(); } catch { /* 非 JSON 响应 */ }
    if (!res.ok) throw new Error((data && data.error) || `请求失败 (${res.status})`);
    return data;
  }

  // ---------------- 数据加载 ----------------

  async function load() {
    try {
      const st = await api('/api/state');
      S.categories = Array.isArray(st.categories) ? st.categories : [];
      S.items = Array.isArray(st.items) ? st.items : [];
      if (!S.categories.some(c => c.id === S.catId)) S.catId = S.categories[0] ? S.categories[0].id : 'book';
      renderAll();
    } catch (err) {
      el.timeline.innerHTML = `<div class="state">加载失败：${esc(err.message)}</div>`;
    }
  }

  function renderAll() {
    renderCategories();
    renderStatusTabs();
    renderTimeline();
  }

  // ---------------- 侧边栏：分类 ----------------

  function renderCategories() {
    const counts = {};
    for (const it of S.items) counts[it.categoryId] = (counts[it.categoryId] || 0) + 1;

    el.catNav.innerHTML = S.categories.map(c => `
      <button class="nav-item${c.id === S.catId ? ' active' : ''}" data-cat="${esc(c.id)}" title="${esc(c.name)}（${counts[c.id] || 0} 条）">
        <span class="nav-emoji">${esc(c.emoji)}</span>
        <span class="nav-name">${esc(c.name)}</span>
        <span class="nav-count">${counts[c.id] || 0}</span>
      </button>`).join('');

    const cat = S.categories.find(c => c.id === S.catId);
    el.pageTitle.textContent = cat ? `${cat.emoji} ${cat.name}` : '书影音游';
  }

  // ---------------- 状态子标签 ----------------

  function renderStatusTabs() {
    const kind = kindOf(S.catId);
    const counts = { done: 0, doing: 0, want: 0 };
    for (const it of S.items) if (it.categoryId === S.catId) counts[it.status] = (counts[it.status] || 0) + 1;

    el.statusTabs.innerHTML = STATUS_KEYS.map(k => `
      <button class="status-tab${k === S.status ? ' active' : ''}" data-status="${k}">
        ${esc(statusLabel(kind, k))}<span class="tab-count">${counts[k] || 0}</span>
      </button>`).join('');
  }

  // ---------------- 时间轴 ----------------

  function sortedItems() {
    const q = S.q.trim().toLowerCase();
    let list = S.items.filter(it => it.categoryId === S.catId && it.status === S.status);
    if (q) list = list.filter(it =>
      it.title.toLowerCase().includes(q) || (it.comment || '').toLowerCase().includes(q));

    const cmp = {
      'date-desc': (a, b) => b.date.localeCompare(a.date) || String(b.createdAt).localeCompare(String(a.createdAt)),
      'date-asc': (a, b) => a.date.localeCompare(b.date) || String(a.createdAt).localeCompare(String(b.createdAt)),
      'rating-desc': (a, b) => (b.rating || 0) - (a.rating || 0) || b.date.localeCompare(a.date),
      'rating-asc': (a, b) => (a.rating || 0) - (b.rating || 0) || b.date.localeCompare(a.date),
    }[S.sort];
    return list.slice().sort(cmp);
  }

  /** 已排序的条目 → 按月 → 按日 分组 */
  function groupTimeline(list) {
    const months = [];
    for (const it of list) {
      const [y, m, d] = it.date.split('-');
      let month = months[months.length - 1];
      if (!month || month.year !== y || month.month !== m) {
        month = { year: y, month: m, days: [], count: 0 };
        months.push(month);
      }
      let day = month.days[month.days.length - 1];
      if (!day || day.day !== d) {
        day = { day: d, week: WEEK[new Date(`${it.date}T00:00:00`).getDay()], items: [] };
        month.days.push(day);
      }
      day.items.push(it);
      month.count++;
    }
    return months;
  }

  function posterHtml(item) {
    if (item.poster) {
      return `<img src="${esc(item.poster)}" alt="${esc(item.title)}" loading="lazy" onerror="this.parentNode.classList.add('img-failed')">`;
    }
    const [c1, c2] = KIND_THEME[kindOf(item.categoryId)] || KIND_THEME.other;
    return `<div class="poster-fallback" style="background:linear-gradient(150deg,${c1},${c2})">
      <span class="pf-emoji">${esc((S.categories.find(c => c.id === item.categoryId) || {}).emoji || '📦')}</span>
      <span class="pf-text">${esc(item.title)}</span>
    </div>`;
  }

  function cardHtml(item) {
    const rating = item.rating
      ? `<span class="rating-badge${item.rating >= 8.5 ? ' hot' : ''}">${Number(item.rating).toFixed(1)}</span>`
      : '';
    return `<article class="mcard" data-id="${esc(item.id)}">
      <div class="poster">
        ${posterHtml(item)}
        ${rating}
        <div class="poster-actions">
          <button type="button" data-act="edit">编辑</button>
          <button type="button" data-act="del" class="del">删除</button>
        </div>
      </div>
      <div class="meta">
        <div class="m-title" title="${esc(item.title)}">${esc(item.title)}</div>
        ${item.comment ? `<div class="m-sub" title="${esc(item.comment)}">${esc(item.comment)}</div>` : ''}
      </div>
    </article>`;
  }

  function renderTimeline() {
    const kind = kindOf(S.catId);
    const list = sortedItems();
    const cat = S.categories.find(c => c.id === S.catId);
    const total = S.items.filter(it => it.categoryId === S.catId).length;
    el.pageSub.textContent = `共 ${total} 条 · ${statusLabel(kind, S.status)} ${list.length} 条`;

    if (!list.length) {
      const isEmptyCat = total === 0;
      el.timeline.innerHTML = `<div class="empty">
        <div class="empty-emoji">${esc(cat ? cat.emoji : '📦')}</div>
        <p>${S.q.trim()
          ? '没有匹配的记录'
          : (isEmptyCat ? `还没有${cat ? cat.name : ''}记录，添加第一条吧` : `「${statusLabel(kind, S.status)}」下还没有记录`)}</p>
        <button class="btn primary" data-act="add-empty">+ 添加记录</button>
      </div>`;
      return;
    }

    el.timeline.innerHTML = groupTimeline(list).map(mo => `
      <div class="month-block">
        <div class="ym-rail">
          <div class="ym-month">${esc(mo.month)}</div>
          <div class="ym-year">${esc(mo.year)}</div>
          <div class="ym-count">${mo.count} 条</div>
          <div class="ym-line"></div>
        </div>
        <div class="month-body">
          ${mo.days.map(dd => `
            <div class="day-group">
              <div class="day-head">
                <span class="day-num">${esc(mo.month)}.${esc(dd.day)}</span>
                <span class="day-week">${esc(dd.week)}</span>
                <span class="day-line"></span>
                <span class="day-count">${dd.items.length} 条</span>
              </div>
              <div class="item-grid">${dd.items.map(cardHtml).join('')}</div>
            </div>`).join('')}
        </div>
      </div>`).join('');
  }

  // ---------------- 条目弹窗 ----------------

  const itemModal = $('item-modal');
  const f = {
    title: $('f-title'), category: $('f-category'), status: $('f-status'),
    date: $('f-date'), rating: $('f-rating'), ratingVal: $('f-rating-val'),
    poster: $('f-poster'), posterPreview: $('f-poster-preview'), comment: $('f-comment'),
    uploadBtn: $('f-upload'), posterFile: $('poster-file'), posterHint: $('poster-hint'),
  };
  const POSTER_HINT = '支持 PNG / JPG / WebP / GIF，≤ 8MB';
  const MAX_IMAGE = 8 * 1024 * 1024;

  function syncStatusOptions() {
    const kind = kindOf(f.category.value);
    f.status.innerHTML = STATUS_KEYS.map(k => `<option value="${k}">${esc(statusLabel(kind, k))}</option>`).join('');
  }

  function syncRatingLabel() {
    const v = parseFloat(f.rating.value);
    f.ratingVal.textContent = v > 0 ? v.toFixed(1) : '未评分';
  }

  /** 选择本地图片 → 上传服务端 → 回填地址到输入框并刷新预览 */
  async function uploadPoster(file) {
    if (!file) return;
    if (!/^image\/(png|jpeg|webp|gif)$/.test(file.type)) { toast('仅支持 PNG / JPG / WebP / GIF', true); return; }
    if (file.size > MAX_IMAGE) { toast('图片不能超过 8MB', true); return; }

    f.uploadBtn.disabled = true;
    f.posterHint.textContent = '上传中…';
    try {
      const base64 = await new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(String(fr.result));
        fr.onerror = () => reject(new Error('读取文件失败'));
        fr.readAsDataURL(file);
      });
      const { url } = await api('/api/images', { method: 'POST', body: JSON.stringify({ base64 }) });
      f.poster.value = url;
      syncPosterPreview();
      toast('封面已上传');
    } catch (err) {
      toast(err.message, true);
    } finally {
      f.uploadBtn.disabled = false;
      f.posterHint.textContent = POSTER_HINT;
    }
  }

  function syncPosterPreview() {
    const url = f.poster.value.trim();
    f.posterPreview.innerHTML = url ? `<img src="${esc(url)}" alt="预览" onerror="this.parentNode.innerHTML='<span>无效</span>'">` : '<span>预览</span>';
  }

  function openItemModal(item) {
    S.editingId = item ? item.id : null;
    $('item-modal-title').textContent = item ? '编辑记录' : '添加记录';
    $('item-delete').toggleAttribute('hidden', !item);

    f.category.innerHTML = S.categories
      .map(c => `<option value="${esc(c.id)}">${esc(c.emoji)} ${esc(c.name)}</option>`).join('');

    const it = item || {};
    f.title.value = it.title || '';
    f.category.value = it.categoryId || S.catId;
    syncStatusOptions();
    f.status.value = it.status || S.status;
    f.date.value = it.date || todayStr();
    f.rating.value = it.rating || 0;
    syncRatingLabel();
    f.poster.value = it.poster || '';
    syncPosterPreview();
    f.comment.value = it.comment || '';
    f.posterHint.textContent = POSTER_HINT;

    itemModal.removeAttribute('hidden');
    setTimeout(() => f.title.focus(), 30);
  }

  function closeItemModal() { itemModal.setAttribute('hidden', ''); }

  async function saveItem() {
    const title = f.title.value.trim();
    if (!title) { toast('标题不能为空', true); f.title.focus(); return; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(f.date.value)) { toast('请选择完整的年月日', true); return; }
    const rating = parseFloat(f.rating.value);
    const payload = {
      title,
      categoryId: f.category.value,
      status: f.status.value,
      date: f.date.value,
      rating: rating > 0 ? rating : null,
      poster: f.poster.value.trim(),
      comment: f.comment.value.trim(),
    };
    try {
      if (S.editingId) await api(`/api/items/${encodeURIComponent(S.editingId)}`, { method: 'PUT', body: JSON.stringify(payload) });
      else await api('/api/items', { method: 'POST', body: JSON.stringify(payload) });
      closeItemModal();
      await load();
      toast(S.editingId ? '已保存' : '已添加');
    } catch (err) { toast(err.message, true); }
  }

  async function deleteItem(id) {
    const it = S.items.find(i => i.id === id);
    if (!it) return;
    const ok = await confirmDlg('删除记录', `确定删除「${it.title}」吗？此操作不可撤销。`);
    if (!ok) return;
    try {
      await api(`/api/items/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await load();
      toast('已删除');
    } catch (err) { toast(err.message, true); }
  }

  // ---------------- 分类管理 ----------------

  const catModal = $('cat-modal');

  function renderCatManager() {
    const counts = {};
    for (const it of S.items) counts[it.categoryId] = (counts[it.categoryId] || 0) + 1;

    $('cat-list').innerHTML = S.categories.map(c => `
      <div class="cat-row" data-cat="${esc(c.id)}">
        <span class="cat-emoji">${esc(c.emoji)}</span>
        <div class="cat-main">
          <div class="cat-name">${esc(c.name)}</div>
          <div class="cat-info">${esc(KIND_NAME[c.kind] || KIND_NAME.other)} · ${counts[c.id] || 0} 条</div>
        </div>
        ${c.system ? '<span class="lock-tag" title="系统分类不可删除">🔒 默认</span>' : ''}
        <div class="cat-ops">
          <button type="button" class="btn tiny ghost" data-act="cat-edit">编辑</button>
          <button type="button" class="btn tiny ghost" data-act="cat-del" ${c.system ? 'disabled title="系统分类不可删除"' : ''}>删除</button>
        </div>
      </div>`).join('');
  }

  function openCatModal() { renderCatManager(); catModal.removeAttribute('hidden'); }
  function closeCatModal() { catModal.setAttribute('hidden', ''); }

  /** 把某一行切换成内联编辑态 */
  function enterCatEdit(row) {
    const id = row.dataset.cat;
    const c = S.categories.find(x => x.id === id);
    if (!c) return;
    row.innerHTML = `
      <div class="cat-edit">
        <input type="text" class="emoji-input" value="${esc(c.emoji)}" maxlength="4" title="图标">
        <input type="text" value="${esc(c.name)}" maxlength="20" title="分类名">
        <select>
          ${Object.keys(KIND_NAME).map(k => `<option value="${k}"${k === c.kind ? ' selected' : ''}>${esc(KIND_NAME[k])}</option>`).join('')}
        </select>
      </div>
      <div class="cat-ops">
        <button type="button" class="btn tiny primary" data-act="cat-save">保存</button>
        <button type="button" class="btn tiny ghost" data-act="cat-cancel">取消</button>
      </div>`;
    row.querySelector('input[type="text"]:not(.emoji-input)').focus();
  }

  async function saveCatEdit(row) {
    const id = row.dataset.cat;
    const emoji = row.querySelector('.emoji-input').value.trim() || '📦';
    const name = row.querySelector('.cat-edit input[type="text"]:not(.emoji-input)').value.trim();
    const kind = row.querySelector('.cat-edit select').value;
    if (!name) { toast('分类名不能为空', true); return; }
    try {
      await api(`/api/categories/${encodeURIComponent(id)}`, {
        method: 'PUT', body: JSON.stringify({ name, emoji, kind }),
      });
      await load();
      renderCatManager();
      toast('分类已更新');
    } catch (err) { toast(err.message, true); }
  }

  async function deleteCat(id) {
    const c = S.categories.find(x => x.id === id);
    if (!c) return;
    const used = S.items.filter(i => i.categoryId === id).length;
    if (used) { toast(`「${c.name}」下还有 ${used} 条记录，先移走再删除`, true); return; }
    const ok = await confirmDlg('删除分类', `确定删除分类「${c.name}」吗？`);
    if (!ok) return;
    try {
      await api(`/api/categories/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await load();
      renderCatManager();
      toast('分类已删除');
    } catch (err) { toast(err.message, true); }
  }

  async function addCat() {
    const name = $('nc-name').value.trim();
    if (!name) { toast('请输入分类名称', true); return; }
    try {
      await api('/api/categories', {
        method: 'POST',
        body: JSON.stringify({ name, emoji: $('nc-emoji').value.trim() || '📦', kind: $('nc-kind').value }),
      });
      $('nc-name').value = '';
      $('nc-emoji').value = '📦';
      await load();
      renderCatManager();
      toast('分类已添加');
    } catch (err) { toast(err.message, true); }
  }

  // ---------------- 确认弹窗 ----------------

  const confirmModal = $('confirm-modal');
  let confirmResolve = null;

  function confirmDlg(title, text) {
    $('confirm-title').textContent = title;
    $('confirm-text').textContent = text;
    confirmModal.removeAttribute('hidden');
    return new Promise(res => { confirmResolve = res; });
  }

  function closeConfirm(result) {
    confirmModal.setAttribute('hidden', '');
    if (confirmResolve) { const r = confirmResolve; confirmResolve = null; r(result); }
  }

  // ---------------- 侧边栏折叠 ----------------

  function setCollapsed(collapsed) {
    el.shell.classList.toggle('collapsed', collapsed);
    // SVG 元素没有 hidden IDL 属性，必须写真实 content attribute，CSS [hidden] 才生效
    el.icCollapse.toggleAttribute('hidden', collapsed);
    el.icExpand.toggleAttribute('hidden', !collapsed);
    el.collapseBtn.setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch {}
  }

  function initCollapse() {
    let saved = '0';
    try { saved = localStorage.getItem(COLLAPSE_KEY) || '0'; } catch {}
    setCollapsed(saved === '1');
  }

  // ---------------- 事件绑定 ----------------

  function bind() {
    el.collapseBtn.addEventListener('click', () => setCollapsed(!el.shell.classList.contains('collapsed')));

    el.catNav.addEventListener('click', e => {
      const btn = e.target.closest('.nav-item');
      if (!btn) return;
      S.catId = btn.dataset.cat;
      S.status = 'done';
      renderAll();
    });

    el.statusTabs.addEventListener('click', e => {
      const btn = e.target.closest('.status-tab');
      if (!btn) return;
      S.status = btn.dataset.status;
      renderStatusTabs();
      renderTimeline();
    });

    el.timeline.addEventListener('click', e => {
      const addEmpty = e.target.closest('[data-act="add-empty"]');
      if (addEmpty) { openItemModal(null); return; }
      const card = e.target.closest('.mcard');
      if (!card) return;
      const actBtn = e.target.closest('[data-act]');
      const id = card.dataset.id;
      if (!actBtn) return;
      if (actBtn.dataset.act === 'edit') {
        const item = S.items.find(i => i.id === id);
        if (item) openItemModal(item);
      } else if (actBtn.dataset.act === 'del') {
        deleteItem(id);
      }
    });

    el.search.addEventListener('input', () => { S.q = el.search.value; renderTimeline(); });
    el.sortSelect.addEventListener('change', () => { S.sort = el.sortSelect.value; renderTimeline(); });

    el.btnAdd.addEventListener('click', () => openItemModal(null));
    el.btnManage.addEventListener('click', openCatModal);

    // 条目弹窗
    $('item-modal-close').addEventListener('click', closeItemModal);
    $('item-cancel').addEventListener('click', closeItemModal);
    $('item-save').addEventListener('click', saveItem);
    $('item-delete').addEventListener('click', () => { if (S.editingId) { const id = S.editingId; closeItemModal(); deleteItem(id); } });
    f.category.addEventListener('change', syncStatusOptions);
    f.rating.addEventListener('input', syncRatingLabel);
    f.poster.addEventListener('input', syncPosterPreview);
    $('f-today').addEventListener('click', () => { f.date.value = todayStr(); });

    // 封面上传：按钮 / 点预览框 / 拖拽到预览框
    f.uploadBtn.addEventListener('click', () => f.posterFile.click());
    f.posterPreview.addEventListener('click', () => f.posterFile.click());
    f.posterFile.addEventListener('change', () => {
      const file = f.posterFile.files && f.posterFile.files[0];
      if (file) uploadPoster(file);
      f.posterFile.value = '';
    });
    ['dragenter', 'dragover'].forEach(t =>
      f.posterPreview.addEventListener(t, e => { e.preventDefault(); f.posterPreview.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach(t =>
      f.posterPreview.addEventListener(t, e => { e.preventDefault(); f.posterPreview.classList.remove('drag'); }));
    f.posterPreview.addEventListener('drop', e => {
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) uploadPoster(file);
    });
    itemModal.addEventListener('mousedown', e => { if (e.target === itemModal) closeItemModal(); });

    // 分类弹窗
    $('cat-modal-close').addEventListener('click', closeCatModal);
    $('cat-close').addEventListener('click', closeCatModal);
    catModal.addEventListener('mousedown', e => { if (e.target === catModal) closeCatModal(); });
    $('nc-add').addEventListener('click', addCat);
    $('cat-list').addEventListener('click', e => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const row = btn.closest('.cat-row');
      const id = row.dataset.cat;
      const act = btn.dataset.act;
      if (act === 'cat-edit') enterCatEdit(row);
      else if (act === 'cat-cancel') renderCatManager();
      else if (act === 'cat-save') saveCatEdit(row);
      else if (act === 'cat-del') deleteCat(id);
    });

    // 确认弹窗
    $('confirm-yes').addEventListener('click', () => closeConfirm(true));
    $('confirm-no').addEventListener('click', () => closeConfirm(false));
    confirmModal.addEventListener('mousedown', e => { if (e.target === confirmModal) closeConfirm(false); });

    // 快捷键
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (!confirmModal.hasAttribute('hidden')) closeConfirm(false);
        else if (!itemModal.hasAttribute('hidden')) closeItemModal();
        else if (!catModal.hasAttribute('hidden')) closeCatModal();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !itemModal.hasAttribute('hidden')) saveItem();
    });
  }

  // ---------------- 启动 ----------------

  initCollapse();
  bind();
  load();
})();
