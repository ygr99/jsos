// 书影音游 media-log —— 服务端：express + data/state.json（原子写）
// 数据模型：categories[]（书籍/影视/音乐/游戏 为系统分类，禁止删除）+ items[]（含年月日）
import express from 'express';
import { readFile, writeFile, rename, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');

app.use(express.json({ limit: '4mb' }));
app.use(express.static(join(__dirname, 'public')));

// ---------- 常量 ----------

/** 4 个系统分类：不能删除，读取状态时会强制补齐（防止被误删后数据错乱） */
const SYSTEM_CATEGORIES = [
  { id: 'book', name: '书籍', kind: 'book', emoji: '📚' },
  { id: 'movie', name: '影视', kind: 'movie', emoji: '🎬' },
  { id: 'music', name: '音乐', kind: 'music', emoji: '🎵' },
  { id: 'game', name: '游戏', kind: 'game', emoji: '🎮' },
];
const KINDS = ['book', 'movie', 'music', 'game', 'other'];
const STATUSES = ['done', 'doing', 'want'];

// ---------- 工具 ----------

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function isDate(s) {
  return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + 'T00:00:00'));
}

function defaultCategories() {
  return SYSTEM_CATEGORIES.map((c, i) => ({ ...c, system: true, order: i }));
}

function emptyState() {
  return { version: 1, categories: defaultCategories(), items: [], updatedAt: Date.now() };
}

async function ensureDir() {
  try { await mkdir(DATA_DIR, { recursive: true }); } catch {}
}

/** 读取状态；文件缺失/损坏 → 回退初始状态，绝不抛错 */
async function readState() {
  await ensureDir();
  let data;
  try {
    data = JSON.parse(await readFile(STATE_FILE, 'utf-8'));
  } catch {
    return emptyState();
  }
  if (!data || typeof data !== 'object') return emptyState();

  // 分类：补齐 4 个系统分类（用户删不掉，但旧数据可能缺）
  const cats = Array.isArray(data.categories) ? data.categories.filter(c => c && c.id) : [];
  for (const sys of SYSTEM_CATEGORIES) {
    const idx = cats.findIndex(c => c.id === sys.id);
    if (idx === -1) cats.push({ ...sys, system: true, order: cats.length });
    else cats[idx] = { ...cats[idx], system: true, kind: KINDS.includes(cats[idx].kind) ? cats[idx].kind : sys.kind };
  }
  data.categories = cats.map((c, i) => ({
    id: String(c.id),
    name: String(c.name ?? '未命名').trim() || '未命名',
    kind: KINDS.includes(c.kind) ? c.kind : 'other',
    emoji: String(c.emoji ?? '📦').trim() || '📦',
    system: Boolean(c.system),
    order: Number.isFinite(Number(c.order)) ? Number(c.order) : i,
  }));
  data.categories.sort((a, b) => a.order - b.order);

  // 条目：过滤脏数据；分类不存在时回落到第一个系统分类，避免记录"消失"
  const validIds = new Set(data.categories.map(c => c.id));
  const fallbackId = data.categories[0].id;
  const items = Array.isArray(data.items) ? data.items : [];
  data.items = items
    .filter(it => it && typeof it === 'object')
    .map(it => {
      const categoryId = validIds.has(it.categoryId) ? it.categoryId : fallbackId;
      const rating = Number(it.rating);
      return {
        id: String(it.id || newId()),
        title: String(it.title ?? '').trim() || '未命名',
        categoryId,
        status: STATUSES.includes(it.status) ? it.status : 'done',
        date: isDate(it.date) ? it.date : todayStr(),
        rating: Number.isFinite(rating) && rating > 0 ? Math.min(10, Math.round(rating * 10) / 10) : null,
        poster: String(it.poster ?? '').trim(),
        comment: String(it.comment ?? '').slice(0, 1000),
        createdAt: Number(it.createdAt) || Date.now(),
        updatedAt: Number(it.updatedAt) || Date.now(),
      };
    });

  data.version = 1;
  return data;
}

/** 原子写：临时文件 → rename，避免写一半被快照同步成坏数据 */
async function writeState(state) {
  await ensureDir();
  state.updatedAt = Date.now();
  const tmp = STATE_FILE + '.tmp';
  await writeFile(tmp, JSON.stringify(state, null, 2), 'utf-8');
  await rename(tmp, STATE_FILE);
  return state;
}

function normalizeItem(input, existing) {
  const base = existing || {};
  const now = Date.now();
  const rating = Number(input.rating);
  return {
    id: base.id || newId(),
    title: String(input.title ?? base.title ?? '').trim() || '未命名',
    categoryId: String(input.categoryId ?? base.categoryId ?? 'book'),
    status: STATUSES.includes(input.status) ? input.status : (base.status ?? 'done'),
    date: isDate(input.date) ? input.date : (isDate(base.date) ? base.date : todayStr()),
    rating: Number.isFinite(rating) && rating > 0 ? Math.min(10, Math.round(rating * 10) / 10) : null,
    poster: String(input.poster ?? base.poster ?? '').trim(),
    comment: String(input.comment ?? base.comment ?? '').slice(0, 1000),
    createdAt: base.createdAt ?? now,
    updatedAt: now,
  };
}

// ---------- 健康检查 ----------

app.get('/api/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

// ---------- 状态 ----------

app.get('/api/state', async (req, res) => {
  try { res.json(await readState()); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- 条目 CRUD ----------

app.post('/api/items', async (req, res) => {
  try {
    const state = await readState();
    const body = req.body || {};
    if (!String(body.title ?? '').trim()) return res.status(400).json({ error: '标题不能为空' });
    if (!state.categories.some(c => c.id === body.categoryId)) return res.status(400).json({ error: '分类不存在' });
    const item = normalizeItem(body, null);
    state.items.push(item);
    await writeState(state);
    res.json(item);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/items/:id', async (req, res) => {
  try {
    const state = await readState();
    const idx = state.items.findIndex(i => i.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'not found' });
    const body = req.body || {};
    if (body.categoryId && !state.categories.some(c => c.id === body.categoryId)) {
      return res.status(400).json({ error: '分类不存在' });
    }
    const updated = normalizeItem(body, state.items[idx]);
    state.items[idx] = updated;
    await writeState(state);
    res.json(updated);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/items/:id', async (req, res) => {
  try {
    const state = await readState();
    const before = state.items.length;
    state.items = state.items.filter(i => i.id !== req.params.id);
    if (state.items.length === before) return res.status(404).json({ error: 'not found' });
    await writeState(state);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- 分类管理（系统分类禁止删除，可改名/换图标/换类型） ----------

app.post('/api/categories', async (req, res) => {
  try {
    const state = await readState();
    const body = req.body || {};
    const name = String(body.name ?? '').trim();
    if (!name) return res.status(400).json({ error: '分类名不能为空' });
    const id = String(body.id ?? '').trim() || newId();
    if (state.categories.some(c => c.id === id)) return res.status(409).json({ error: '分类 ID 已存在' });
    const cat = {
      id,
      name,
      kind: KINDS.includes(body.kind) ? body.kind : 'other',
      emoji: String(body.emoji ?? '📦').trim() || '📦',
      system: false,
      order: state.categories.reduce((m, c) => Math.max(m, Number(c.order) || 0), -1) + 1,
    };
    state.categories.push(cat);
    await writeState(state);
    res.json(cat);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/categories/:id', async (req, res) => {
  try {
    const state = await readState();
    const cat = state.categories.find(c => c.id === req.params.id);
    if (!cat) return res.status(404).json({ error: 'not found' });
    const body = req.body || {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return res.status(400).json({ error: '分类名不能为空' });
      cat.name = name;
    }
    if (body.emoji !== undefined) cat.emoji = String(body.emoji).trim() || cat.emoji;
    if (body.kind !== undefined && KINDS.includes(body.kind)) cat.kind = body.kind;
    cat.system = Boolean(cat.system);
    await writeState(state);
    res.json(cat);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/categories/:id', async (req, res) => {
  try {
    const state = await readState();
    const cat = state.categories.find(c => c.id === req.params.id);
    if (!cat) return res.status(404).json({ error: 'not found' });
    if (cat.system) return res.status(403).json({ error: '系统分类不可删除' });
    const used = state.items.filter(i => i.categoryId === req.params.id).length;
    if (used) return res.status(409).json({ error: `该分类下还有 ${used} 条记录，请先移走或删除` });
    state.categories = state.categories.filter(c => c.id !== req.params.id);
    await writeState(state);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ---------- 导入导出 ----------

app.post('/api/import', async (req, res) => {
  try {
    const payload = req.body || {};
    if (!Array.isArray(payload.items)) return res.status(400).json({ error: '数据格式不正确' });
    const state = emptyState();
    const custom = Array.isArray(payload.categories)
      ? payload.categories.filter(c => c && c.id && !SYSTEM_CATEGORIES.some(s => s.id === c.id))
      : [];
    state.categories = defaultCategories().concat(
      custom.map((c, i) => ({
        id: String(c.id),
        name: String(c.name ?? '未命名').trim() || '未命名',
        kind: KINDS.includes(c.kind) ? c.kind : 'other',
        emoji: String(c.emoji ?? '📦').trim() || '📦',
        system: false,
        order: defaultCategories().length + i,
      }))
    );
    const validIds = new Set(state.categories.map(c => c.id));
    state.items = payload.items
      .filter(it => it && typeof it === 'object')
      .map(it => normalizeItem({ ...it, categoryId: validIds.has(it.categoryId) ? it.categoryId : 'book' }, { id: it.id }));
    await writeState(state);
    res.json({ ok: true, count: state.items.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/** 示例数据：仅在为空时写入，方便快速体验 */
app.post('/api/seed', async (req, res) => {
  try {
    const state = await readState();
    if (state.items.length && !req.body?.force) {
      return res.status(409).json({ error: '已有数据，未覆盖' });
    }
    const y = new Date().getFullYear();
    const samples = [
      { title: '百年孤独', categoryId: 'book', status: 'done', date: `${y}-08-18`, rating: 9.2, comment: '魔幻现实主义的顶峰，读完久久不能平静。' },
      { title: '活着', categoryId: 'book', status: 'done', date: `${y}-07-02`, rating: 9.0, comment: '人是为了活着本身而活着。' },
      { title: '三体', categoryId: 'book', status: 'done', date: `${y}-06-15`, rating: 8.8, comment: '黑暗森林那段最震撼。' },
      { title: '人类简史', categoryId: 'book', status: 'doing', date: `${y}-09-01`, rating: 8.4, comment: '认知革命那几章最好看。' },
      { title: '沙丘', categoryId: 'book', status: 'want', date: `${y}-09-04`, rating: null, comment: '看完电影补原著。' },
      { title: '沙丘', categoryId: 'movie', status: 'done', date: `${y}-08-12`, rating: 8.1, comment: '视听震撼，节奏偏慢。' },
      { title: '漫长的季节', categoryId: 'movie', status: 'done', date: `${y}-07-25`, rating: 9.4, comment: '打个响指吧，他说。' },
      { title: '瞬息全宇宙', categoryId: 'movie', status: 'want', date: `${y}-09-05`, rating: null, comment: '' },
      { title: 'Blue Note 精选', categoryId: 'music', status: 'done', date: `${y}-08-30`, rating: 8.8, comment: '通勤循环了一整周。' },
      { title: '五月天 · 后青春期的诗', categoryId: 'music', status: 'doing', date: `${y}-09-02`, rating: 8.0, comment: '青春回放。' },
      { title: '塞尔达传说：王国之泪', categoryId: 'game', status: 'done', date: `${y}-06-11`, rating: 9.6, comment: '120 小时，救公主。' },
      { title: '艾尔登法环', categoryId: 'game', status: 'doing', date: `${y}-09-03`, rating: 9.0, comment: '受苦但停不下来。' },
      { title: '黑神话：悟空', categoryId: 'game', status: 'want', date: `${y}-09-05`, rating: null, comment: '等一个打折。' },
    ];
    state.items = samples.map(s => normalizeItem(s, null));
    await writeState(state);
    res.json({ ok: true, count: state.items.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('*', (req, res) => res.sendFile(join(__dirname, 'public', 'index.html')));

app.listen(port, () => console.log(`media-log running on ${port}`));
