import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const KEYS_PATH = path.join(DATA_DIR, 'keys.json');
const HISTORY_PATH = path.join(DATA_DIR, 'history.json');
const SETTINGS_PATH = path.join(DATA_DIR, 'settings.json');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function genId(prefix) {
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
}

function readJSON(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), 'utf8');
      return fallback;
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
}

function getKeys() { return readJSON(KEYS_PATH, []); }
function saveKeys(keys) { writeJSON(KEYS_PATH, keys); }
function getHistory() { return readJSON(HISTORY_PATH, []); }
function saveHistory(h) { writeJSON(HISTORY_PATH, h); }
function getSettings() { return readJSON(SETTINGS_PATH, { pollingInterval: 300000, selectedWidgetKey: null }); }
function saveSettings(s) { writeJSON(SETTINGS_PATH, s); }

function maskToken(token) {
  if (!token || token.length < 12) return '***';
  return token.slice(0, 6) + '...' + token.slice(-4);
}

async function fetchBalance(token) {
  const resp = await fetch('https://api.deepseek.com/user/balance', {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json',
    },
  });
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`API error ${resp.status}: ${text}`);
  }
  return resp.json();
}

// --- Polling ---
let pollTimer = null;

async function pollAllKeys() {
  const keys = getKeys().filter(k => k.enabled);
  if (keys.length === 0) return;

  const history = getHistory();
  let changed = false;

  for (const key of keys) {
    try {
      const data = await fetchBalance(key.token);
      const info = data.balance_infos?.[0];
      if (info) {
        const record = {
          id: genId('h'),
          keyId: key.id,
          balance: parseFloat(info.total_balance) || 0,
          totalGrant: parseFloat(info.total_grant) || 0,
          totalUsed: parseFloat(info.total_used) || 0,
          timestamp: Date.now(),
        };
        history.push(record);
        changed = true;
      }
    } catch (e) {
      console.error(`Poll failed for ${key.label || key.id}:`, e.message);
    }
  }

  if (changed) {
    // Keep last 10000 records max
    const trimmed = history.length > 10000 ? history.slice(-10000) : history;
    saveHistory(trimmed);
  }
}

function startPolling() {
  stopPolling();
  const settings = getSettings();
  const interval = settings.pollingInterval || 300000;
  // Poll immediately on start, then on interval
  pollAllKeys();
  pollTimer = setInterval(pollAllKeys, interval);
}

function stopPolling() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}

// --- HTTP Server ---
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // --- API Routes ---

  // GET /api/keys
  if (pathname === '/api/keys' && req.method === 'GET') {
    const keys = getKeys().map(k => ({
      ...k,
      token: undefined,
      tokenMasked: maskToken(k.token),
    }));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(keys));
  }

  // POST /api/keys
  if (pathname === '/api/keys' && req.method === 'POST') {
    try {
      const body = JSON.parse(await readBody(req));
      if (!body.token || !body.token.startsWith('sk-')) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Invalid token format' }));
      }
      const keys = getKeys();
      const key = {
        id: genId('k'),
        label: body.label || 'Untitled',
        token: body.token,
        enabled: true,
        createdAt: Date.now(),
      };
      keys.push(key);
      saveKeys(keys);
      // Trigger immediate poll for this key
      try {
        const data = await fetchBalance(key.token);
        const info = data.balance_infos?.[0];
        if (info) {
          const history = getHistory();
          history.push({
            id: genId('h'),
            keyId: key.id,
            balance: parseFloat(info.total_balance) || 0,
            totalGrant: parseFloat(info.total_grant) || 0,
            totalUsed: parseFloat(info.total_used) || 0,
            timestamp: Date.now(),
          });
          saveHistory(history);
        }
      } catch { /* ignore first poll error */ }
      res.writeHead(201, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ...key, token: undefined, tokenMasked: maskToken(key.token) }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // PUT /api/keys/:id
  if (pathname.startsWith('/api/keys/') && req.method === 'PUT') {
    try {
      const keyId = pathname.split('/').pop();
      const body = JSON.parse(await readBody(req));
      const keys = getKeys();
      const idx = keys.findIndex(k => k.id === keyId);
      if (idx === -1) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'Key not found' }));
      }
      if (body.label !== undefined) keys[idx].label = body.label;
      if (body.token !== undefined) keys[idx].token = body.token;
      if (body.enabled !== undefined) keys[idx].enabled = body.enabled;
      saveKeys(keys);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ ...keys[idx], token: undefined, tokenMasked: maskToken(keys[idx].token) }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // DELETE /api/keys/:id
  if (pathname.startsWith('/api/keys/') && req.method === 'DELETE') {
    const keyId = pathname.split('/').pop();
    const keys = getKeys();
    const filtered = keys.filter(k => k.id !== keyId);
    if (filtered.length === keys.length) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Key not found' }));
    }
    saveKeys(filtered);
    // Also remove history for this key
    const history = getHistory().filter(h => h.keyId !== keyId);
    saveHistory(history);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ deleted: 1 }));
  }

  // GET /api/history?keyId=xxx&limit=100
  if (pathname === '/api/history' && req.method === 'GET') {
    const keyId = url.searchParams.get('keyId');
    const limit = parseInt(url.searchParams.get('limit') || '200', 10);
    let history = getHistory();
    if (keyId) history = history.filter(h => h.keyId === keyId);
    const result = history.slice(-limit);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(result));
  }

  // GET /api/balance/:keyId — fetch current balance
  if (pathname.startsWith('/api/balance/') && req.method === 'GET') {
    const keyId = pathname.split('/').pop();
    const key = getKeys().find(k => k.id === keyId);
    if (!key) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Key not found' }));
    }
    try {
      const data = await fetchBalance(key.token);
      const info = data.balance_infos?.[0];
      const record = {
        keyId: key.id,
        balance: parseFloat(info?.total_balance) || 0,
        totalGrant: parseFloat(info?.total_grant) || 0,
        totalUsed: parseFloat(info?.total_used) || 0,
        timestamp: Date.now(),
      };
      // Save to history
      const history = getHistory();
      history.push({ id: genId('h'), ...record });
      saveHistory(history);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(record));
    } catch (e) {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // GET /api/settings
  if (pathname === '/api/settings' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(getSettings()));
  }

  // PUT /api/settings
  if (pathname === '/api/settings' && req.method === 'PUT') {
    try {
      const body = JSON.parse(await readBody(req));
      const current = getSettings();
      const updated = { ...current, ...body };
      saveSettings(updated);
      // Restart polling if interval changed
      if (body.pollingInterval && body.pollingInterval !== current.pollingInterval) {
        startPolling();
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(updated));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // GET /api/widget/config — keys list for widget selection
  if (pathname === '/api/widget/config' && req.method === 'GET') {
    const keys = getKeys().filter(k => k.enabled).map(k => ({
      id: k.id,
      label: k.label,
    }));
    const settings = getSettings();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ keys, selectedKey: settings.selectedWidgetKey }));
  }

  // --- Static Files ---
  let decoded = decodeURIComponent(pathname);
  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }
  let target = path.resolve(path.join(ROOT, decoded));
  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }
  fs.readFile(target, (err, data) => {
    if (err) {
      // SPA fallback: serve index.html for any non-file route
      fs.readFile(path.join(ROOT, 'index.html'), (err2, indexData) => {
        if (err2) {
          res.writeHead(404);
          res.end('Not Found');
        } else {
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(indexData);
        }
      });
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  startPolling();
});

process.on('SIGTERM', () => { stopPolling(); server.close(); });
process.on('SIGINT', () => { stopPolling(); server.close(); });
