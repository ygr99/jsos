import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { TYPES, getQuote } from './lib/quote.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(join(__dirname, 'public')));

// 统一取句入口：GET /api/quote?type=hitokoto
// 抓取放服务端（直连优先、容器内失败兜底系统代理），前端只消费同源 JSON，零 CORS/COEP 问题
app.get('/api/quote', async (req, res) => {
  const type = String(req.query.type || 'hitokoto');
  const conf = TYPES[type];
  if (!conf) return res.status(400).json({ ok: false, error: `未知类型：${type}` });
  try {
    const { text, author } = await getQuote(type);
    res.json({ ok: true, type, name: conf.name, text, author: author || null });
  } catch (e) {
    res.status(502).json({ ok: false, type, error: e?.message || '获取失败' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`aggregate-hitokoto running on ${port}`));
