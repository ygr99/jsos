// appmanager 1.2.26 移动端小组件页冒烟：375px 窄视口验证侧边栏不挡内容
import { createRequire } from 'module';
import http from 'http';
import { readFileSync, existsSync } from 'fs';
import path from 'path';
const require = createRequire('C:/Users/99/.workbuddy/binaries/node/workspace/');
const puppeteer = require('puppeteer-core');

const DIST = 'C:/Users/99/jsos-apps/dev.jsos.appmanager/dist';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join(DIST, p);
  if (!existsSync(file) || p === '/') file = path.join(DIST, 'index.html');
  res.setHeader('Content-Type', MIME[path.extname(file)] || 'application/octet-stream');
  res.end(readFileSync(file));
});
await new Promise(r => server.listen(4225, r));

const browser = await puppeteer.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  headless: 'new', args: ['--no-sandbox'],
});
const page = await browser.newPage();
await page.setViewport({ width: 375, height: 667 }); // 移动端
page.on('pageerror', e => console.log('PAGE-ERROR:', e.message));
await page.evaluateOnNewDocument(() => {
  const icon = 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"><rect width="16" height="16" rx="4" fill="#ef4444"/></svg>');
  window.JSOS = {
    getApps: async () => [
      { id: 'calendar', name: '日历', icon, isRunning: true, widgets: [
        { id: 'calendar-card', name: '日历卡片', description: '周历', cols: 4, rows: 2 },
      ]},
      { id: 'weather', name: '天气', icon, isRunning: true, widgets: [
        { id: 'weather-simple', name: '天气简洁', description: '温度', cols: 2, rows: 1 },
      ]},
    ],
    getTheme: async () => 'light',
    onThemeChange: () => () => {},
    addWidget: async () => ({ success: true }),
    closeAppWindow: async () => {},
    toast: async () => {},
  };
});
await page.goto('http://localhost:4225/#/add-widget?hideNav=1', { waitUntil: 'networkidle0' });
await new Promise(r => setTimeout(r, 600));

// 初始 = 移动端展开态（默认展开，应有全屏遮罩 + aside 覆盖）
const expanded = await page.evaluate(() => {
  const aside = document.querySelector('aside');
  const overlay = aside.previousElementSibling;
  const card = document.querySelector('main .grid > button, main .grid > div');
  return {
    asideW: Math.round(aside.getBoundingClientRect().width),
    overlay: !!overlay && overlay.className.includes('fixed'),
    rootPad: getComputedStyle(document.getElementById('root').firstElementChild).paddingLeft,
    cardLeft: card ? Math.round(card.getBoundingClientRect().left) : null,
  };
});
console.log('移动端展开态:', JSON.stringify(expanded));
await page.screenshot({ path: 'C:/Users/99/jsos-apps/dev.jsos.appmanager/smoke-mobile-1.png' });

// 点遮罩收起 → 折叠态 56px 栏 + 内容右移不重叠
await page.click('aside > div button'); // 折叠按钮
await new Promise(r => setTimeout(r, 400));
const collapsed = await page.evaluate(() => {
  const aside = document.querySelector('aside');
  const card = document.querySelector('main .grid > button, main .grid > div');
  const asideR = aside.getBoundingClientRect();
  return {
    asideW: Math.round(asideR.width),
    cardLeft: card ? Math.round(card.getBoundingClientRect().left) : null,
    overlap: card ? card.getBoundingClientRect().left < asideR.right - 1 : null,
    rootPad: getComputedStyle(document.getElementById('root').firstElementChild).paddingLeft,
  };
});
console.log('移动端折叠态:', JSON.stringify(collapsed));
console.log(collapsed.overlap ? '!! 侧边栏仍挡住内容' : 'OK: 侧边栏不挡内容');
await page.screenshot({ path: 'C:/Users/99/jsos-apps/dev.jsos.appmanager/smoke-mobile-2.png' });

await browser.close();
server.close();
