// appmanager 1.2.25 小组件页冒烟：静态服务 dist + stub window.JSOS + puppeteer 真机渲染 /add-widget
import { createRequire } from 'module';
import http from 'http';
import { readFileSync, existsSync } from 'fs';
import path from 'path';
const require = createRequire('C:/Users/99/.workbuddy/binaries/node/workspace/');
const puppeteer = require('puppeteer-core');

const DIST = 'C:/Users/99/jsos-apps/dev.jsos.appmanager/dist';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join(DIST, p);
  if (!existsSync(file) || p === '/') file = path.join(DIST, 'index.html');
  res.setHeader('Content-Type', MIME[path.extname(file)] || 'application/octet-stream');
  res.end(readFileSync(file));
});
await new Promise(r => server.listen(4211, r));

const browser = await puppeteer.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  headless: 'new', args: ['--no-sandbox'],
});
const page = await browser.newPage();
await page.setViewport({ width: 900, height: 620 });
page.on('pageerror', e => console.log('PAGE-ERROR:', e.stack || e.message));
await page.evaluateOnNewDocument(() => {
  const du = (body) => 'data:image/svg+xml;base64,' + btoa(body);
  const iconSquare = du('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"><rect width="16" height="16" rx="4" fill="#ef4444"/></svg>');
  const iconOdd = du('<svg xmlns="http://www.w3.org/2000/svg" width="52" height="56" viewBox="0 0 64 64"><rect width="64" height="64" fill="#7c3aed"/></svg>');
  const iconNoAttr = du('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="#f59e0b"/></svg>');
  window.JSOS = {
    getApps: async () => [
      { id: 'calendar', name: '日历', icon: iconSquare, isRunning: true, widgets: [
        { id: 'calendar-card', name: '日历卡片', description: '周历、大日期、农历当月月历网格', cols: 4, rows: 2 },
        { id: 'schedule-card', name: '进度卡片', description: '距元旦天数、年月周进度', cols: 4, rows: 2 },
        { id: 'solar-term', name: '二十四节气', description: '当前节气与倒计时', cols: 2, rows: 2 },
      ]},
      { id: 'weather', name: '天气', icon: iconOdd, isRunning: true, widgets: [
        { id: 'weather-simple', name: '天气简洁', description: '当前温度和天气状况', cols: 2, rows: 1 },
        { id: 'weather-detail', name: '天气详细', description: '包含逐小时预报', cols: 4, rows: 2 },
      ]},
      { id: 'docs', name: '文档', icon: iconNoAttr, isRunning: true, widgets: [
        { id: 'docs-nav', name: '文档导航', description: '快速导航', cols: 3, rows: 1 },
      ]},
    ],
    getTheme: async () => 'light',
    onThemeChange: () => () => {},
    addWidget: async () => ({ success: true }),
    closeAppWindow: async () => {},
    toast: async () => {},
  };
});
await page.goto('http://localhost:4211/#/add-widget?hideNav=1', { waitUntil: 'networkidle0' });
await new Promise(r => setTimeout(r, 800));

const out = await page.evaluate(() => {
  const aside = document.querySelector('aside');
  const navBtns = aside ? [...aside.querySelectorAll('nav button')] : [];
  const q = s => document.querySelector(s);
  const icons = [...aside.querySelectorAll('button svg')].map(s => {
    const r = s.getBoundingClientRect();
    return { w: +r.width.toFixed(1), h: +r.height.toFixed(1) };
  });
  const imgs = [...aside.querySelectorAll('img')].map(i => {
    const r = i.getBoundingClientRect();
    return { rect: [+r.width.toFixed(1), +r.height.toFixed(1)], natural: [i.naturalWidth, i.naturalHeight] };
  });
  return {
    aside: !!aside,
    asideWidth: aside ? aside.getBoundingClientRect().width : null,
    navCount: navBtns.length,
    navTexts: navBtns.map(b => b.textContent.trim()),
    title: q('h1') ? q('h1').textContent : null,
    search: !!q('input[type="search"]'),
    cards: [...document.querySelectorAll('main .grid > button')].length,
    collapseIcon: icons[0] || null,
    sidebarImgs: imgs,
  };
});
console.log('初始渲染:', JSON.stringify(out, null, 2));
await page.screenshot({ path: 'C:/Users/99/jsos-apps/dev.jsos.appmanager/smoke-widget-1.png' });

// 点击"天气"分组 → 只剩 2 张卡
const btns = await page.$$('aside nav button');
await btns[2].click(); // 0=全部 1=日历 2=天气
await new Promise(r => setTimeout(r, 300));
const afterGroup = await page.evaluate(() => ({
  cards: [...document.querySelectorAll('main .grid > button')].length,
  activeText: document.querySelector('aside nav button.bg-primary\\/10')?.textContent.trim(),
}));
console.log('点击天气分组:', JSON.stringify(afterGroup));

// 搜索"节气" → 全部分组下应只剩 1 张卡
await btns[0].click();
await page.type('input[type="search"]', '节气');
await new Promise(r => setTimeout(r, 300));
const afterSearch = await page.evaluate(() => ({
  cards: [...document.querySelectorAll('main .grid > button')].length,
  allCount: document.querySelector('aside nav button span:last-child')?.textContent,
}));
console.log('搜索节气:', JSON.stringify(afterSearch));
await page.screenshot({ path: 'C:/Users/99/jsos-apps/dev.jsos.appmanager/smoke-widget-2.png' });

// 折叠侧边栏
const cBtn = await page.$('aside > div button');
await cBtn.click();
await new Promise(r => setTimeout(r, 400));
const collapsed = await page.evaluate(() => {
  const a = document.querySelector('aside');
  const imgs = [...a.querySelectorAll('img')].map(i => {
    const r = i.getBoundingClientRect();
    const cs = getComputedStyle(i);
    return { rect: [+r.width.toFixed(1), +r.height.toFixed(1)], shrink: cs.flexShrink, w: cs.width, maxW: cs.maxWidth };
  });
  const btn = a.querySelector('nav button.w-full') || a.querySelector('nav button');
  const nav = a.querySelector('nav');
  const ncs = getComputedStyle(nav);
  return {
    width: a.getBoundingClientRect().width,
    searchGone: !a.querySelector('input'),
    imgs,
    navW: nav.clientWidth, navPad: ncs.padding, navOverflow: ncs.overflowY,
    btnW: btn ? btn.clientWidth : null, btnPad: btn ? getComputedStyle(btn).padding : null,
    btnClassName: btn ? btn.className : null,
  };
});
console.log('折叠后:', JSON.stringify(collapsed));
await page.screenshot({ path: 'C:/Users/99/jsos-apps/dev.jsos.appmanager/smoke-widget-3.png' });

await browser.close();
server.close();
