// bump 版本 + 同步 publish.mjs
import fs from 'fs';
const ver = process.argv[2];
const dir = process.argv[3];
const pPath = dir + '/package.json';
const p = JSON.parse(fs.readFileSync(pPath, 'utf8'));
p.version = ver;
fs.writeFileSync(pPath, JSON.stringify(p, null, 2) + '\n');
let s = fs.readFileSync(dir + '/publish.mjs', 'utf8');
s = s.replace(/version: '[\d.]+'/, `version: '${ver}'`);
s = s.replace(/daily-brief-[\d.]+\.zip/, `daily-brief-${ver}.zip`);
fs.writeFileSync(dir + '/publish.mjs', s);
console.log('bumped ->', ver);
