/* RSS 阅读器前端逻辑 —— 移植自 99-起始页 RSSReader 组件，适配 JSOS：
 * - 订阅数据存服务端 DATA_DIR（/api/sources），置顶随数据一起持久化
 * - 抓取经服务端 /api/feed（容器内走平台代理），浏览器端 DOMParser 解析 RSS/Atom
 * - 正文图片经 /api/img 同源代理（COEP require-corp 下外链图片必经此）
 * - 主题跟随系统 / window.JSOS.onThemeChange
 */
const $ = (s) => document.querySelector(s);

const sidebarEl = $('#sidebar');
const feedListEl = $('#feed-list');
const statusEl = $('#status');
const emptyEl = $('#empty');
const feedTitleEl = $('#feed-title');
const listViewEl = $('#list-view');
const articleViewEl = $('#article-view');

let doc = { feeds: {}, pinned: [] }; // 服务端持久化的订阅数据
let currentSource = null;
let rssData = {}; // 名称 -> 解析结果（会话内缓存）

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const stripTags = (html) => String(html ?? '').replace(/<[^>]*>/g, '');

function formatDate(dateString) {
  if (!dateString) return '';
  try {
    return new Date(dateString).toLocaleString('zh-CN', {
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return dateString;
  }
}

/* ---------------- 服务端存储 ---------------- */

async function saveSources(next) {
  const r = await fetch('/api/sources', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(next),
  });
  const body = await r.json().catch(() => null);
  if (!r.ok || !body || body.code !== 200) throw new Error(body?.message || `保存失败（HTTP ${r.status}）`);
}

/* ---------------- 订阅列表 ---------------- */

function renderSources() {
  const feeds = doc.feeds || {};
  const pinned = doc.pinned || [];
  const pinnedSet = new Set(pinned);
  sidebarEl.innerHTML = '';
  const ordered = [...pinned.filter((p) => p in feeds), ...Object.keys(feeds).filter((n) => !pinnedSet.has(n))];
  if (!ordered.length) {
    sidebarEl.innerHTML = '<div class="sidebar-empty">暂无订阅源</div>';
    return;
  }
  for (const name of ordered) {
    const isPinned = pinnedSet.has(name);
    const el = document.createElement('div');
    el.className = 'source-item' + (name === currentSource ? ' active' : '');
    el.dataset.source = name;
    el.dataset.pinned = isPinned;
    el.innerHTML = `
      <svg class="source-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 11a9 9 0 0 1 9 9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M4 4a16 16 0 0 1 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><circle cx="5" cy="19" r="1.6" fill="currentColor"/></svg>
      <span class="source-name">${esc(name)}</span>
      <span class="source-actions">
        <button class="pin-btn" type="button" title="${isPinned ? '取消置顶' : '置顶'}">${isPinned ? '📍' : '📌'}</button>
        <button class="del-btn" type="button" title="删除订阅">🗑</button>
      </span>`;
    el.querySelector('.pin-btn').addEventListener('click', (e) => { e.stopPropagation(); togglePin(name); });
    el.querySelector('.del-btn').addEventListener('click', (e) => { e.stopPropagation(); deleteSource(name); });
    el.addEventListener('click', () => loadRSS(name));
    sidebarEl.appendChild(el);
  }
}

async function togglePin(name) {
  const pinned = doc.pinned.includes(name) ? doc.pinned.filter((p) => p !== name) : [name, ...doc.pinned];
  await saveSources({ ...doc, pinned }).catch((e) => console.error('保存失败', e));
  doc.pinned = pinned;
  renderSources();
}

async function deleteSource(name) {
  if (!confirm(`确定要删除「${name}」吗？`)) return;
  const feeds = { ...doc.feeds };
  delete feeds[name];
  const pinned = (doc.pinned || []).filter((p) => p !== name);
  try {
    await saveSources({ feeds, pinned });
  } catch (e) {
    return console.error('保存失败', e);
  }
  doc = { feeds, pinned };
  delete rssData[name];
  if (currentSource === name || !(currentSource in feeds)) {
    currentSource = null;
    hideArticle();
    feedListEl.innerHTML = '';
    const first = pinned[0] || Object.keys(feeds)[0] || null;
    if (first) loadRSS(first);
    else showNoSource();
  }
  renderSources();
}

/* ---------------- 内容加载与渲染 ---------------- */

function showStatus(msg, isError = false) {
  statusEl.hidden = false;
  statusEl.textContent = msg;
  statusEl.classList.toggle('is-error', isError);
  emptyEl.hidden = true;
}
const hideStatus = () => { statusEl.hidden = true; };
const showNoSource = () => {
  hideStatus();
  feedListEl.innerHTML = '';
  emptyEl.hidden = false;
  emptyEl.textContent = '暂无 RSS 源，请点右上角「添加订阅」';
  feedTitleEl.textContent = '';
};

// XML → 结构化数据（RSS 2.0 / Atom 双格式，与原起始页版本一致）
function parseXML(xmlDoc) {
  const isAtom = xmlDoc.querySelector('feed') !== null;
  const entries = [];
  let feedTitle = '';
  let feedLink = '';

  if (isAtom) {
    const feed = xmlDoc.querySelector('feed');
    feedTitle = feed.querySelector('title')?.textContent || '';
    feedLink = feed.querySelector('link[rel="alternate"]')?.getAttribute('href') || feed.querySelector('link')?.getAttribute('href') || '';
    for (const item of feed.querySelectorAll('entry')) {
      entries.push({
        title: item.querySelector('title')?.textContent || '',
        link: item.querySelector('link[rel="alternate"]')?.getAttribute('href') || item.querySelector('link')?.getAttribute('href') || '',
        pubDate: item.querySelector('published')?.textContent || item.querySelector('updated')?.textContent || '',
        author: item.querySelector('author > name')?.textContent || '',
        content: item.querySelector('content')?.textContent || item.querySelector('summary')?.textContent || '',
        id: entries.length,
      });
    }
  } else {
    const channel = xmlDoc.querySelector('channel');
    feedTitle = channel?.querySelector('title')?.textContent || '';
    feedLink = channel?.querySelector('link')?.textContent || '';
    for (const item of channel?.querySelectorAll('item') || []) {
      entries.push({
        title: item.querySelector('title')?.textContent || '',
        link: item.querySelector('link')?.textContent || '',
        pubDate: item.querySelector('pubDate')?.textContent || '',
        author: item.querySelector('author')?.textContent || item.querySelector('dc\\:creator')?.textContent || '',
        content: item.querySelector('content\\:encoded')?.textContent || item.querySelector('description')?.textContent || '',
        id: entries.length,
      });
    }
  }
  return { title: feedTitle, link: feedLink, entries };
}

async function loadRSS(name) {
  if (!name || !(name in doc.feeds)) return;
  currentSource = name;
  document.querySelectorAll('.source-item').forEach((el) => el.classList.toggle('active', el.dataset.source === name));
  feedTitleEl.textContent = name;
  hideArticle();

  if (rssData[name]) return displayRSS(rssData[name]);

  feedListEl.innerHTML = '';
  emptyEl.hidden = true;
  showStatus('正在加载…');
  try {
    const r = await fetch('/api/feed?url=' + encodeURIComponent(doc.feeds[name]));
    const body = await r.json().catch(() => null);
    if (!r.ok || body?.code !== 200) throw new Error(body?.message || `HTTP ${r.status}`);
    const xmlDoc = new DOMParser().parseFromString(body.data.xml, 'text/xml');
    if (xmlDoc.querySelector('parsererror')) throw new Error('返回内容不是有效的 XML');
    const data = parseXML(xmlDoc);
    rssData[name] = data;
    displayRSS(data);
  } catch (e) {
    showStatus('加载失败：' + e.message, true);
  }
}

function displayRSS(data) {
  hideStatus();
  feedTitleEl.textContent = data.title || currentSource || '';
  feedListEl.innerHTML = '';
  const entries = data.entries || [];
  if (!entries.length) {
    emptyEl.hidden = false;
    emptyEl.textContent = '该源暂无文章';
    return;
  }
  emptyEl.hidden = true;
  for (const item of entries) {
    const li = document.createElement('li');
    li.className = 'feed-item';
    li.dataset.id = String(item.id);
    let summary = stripTags(item.content).replace(/\s+/g, ' ').trim();
    if (summary.length > 150) summary = summary.slice(0, 150) + '…';
    li.innerHTML = `
      <a class="item-title" href="${esc(item.link)}" target="_blank" rel="noopener noreferrer">${esc(item.title) || '(无标题)'}</a>
      <div class="item-meta">
        <span class="item-date">${esc(formatDate(item.pubDate))}</span>
        ${item.author ? `<span class="item-author">作者：${esc(item.author)}</span>` : ''}
      </div>
      <div class="item-summary">${esc(summary)}</div>
      <a href="#" class="item-more">阅读全文</a>`;
    li.querySelector('.item-more').addEventListener('click', (e) => {
      e.preventDefault();
      viewArticle(Number(li.dataset.id));
    });
    feedListEl.appendChild(li);
  }
}

function viewArticle(id) {
  const data = rssData[currentSource];
  const article = data?.entries?.[id];
  if (!article) return;

  $('#article-title').textContent = article.title || '(无标题)';
  const meta = $('#article-meta');
  meta.innerHTML = `
    <span class="item-date">${esc(formatDate(article.pubDate))}</span>
    ${article.author ? `<span class="item-author">作者：${esc(article.author)}</span>` : ''}
    ${article.link ? `<a href="${esc(article.link)}" target="_blank" rel="noopener noreferrer">原文链接 ↗</a>` : ''}`;

  const contentEl = $('#article-content');
  // 剥掉脚本再注入；相对路径资源以文章链接为 base 归一
  contentEl.innerHTML = String(article.content ?? '').replace(/<script[\s\S]*?<\/script>/gi, '');
  const base = article.link || data.link || '';
  contentEl.querySelectorAll('img').forEach((img) => {
    const raw = img.getAttribute('src');
    if (!raw || raw.startsWith('data:')) return;
    try {
      img.src = '/api/img?url=' + encodeURIComponent(new URL(raw, base || undefined).href);
      img.loading = 'lazy';
    } catch {
      img.remove();
    }
  });
  contentEl.querySelectorAll('a').forEach((a) => {
    const raw = a.getAttribute('href');
    if (raw && !/^(https?:|mailto:|#)/i.test(raw)) {
      try {
        a.href = new URL(raw, base || undefined).href;
      } catch {
        a.removeAttribute('href');
      }
    }
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
  });

  listViewEl.style.display = 'none';
  articleViewEl.hidden = false;
  contentEl.parentElement.scrollTop = 0;
}

function hideArticle() {
  articleViewEl.hidden = true;
  listViewEl.style.display = '';
}

/* ---------------- 添加订阅弹窗 ---------------- */

const addModalEl = $('#add-modal');
const formErrorEl = $('#form-error');
const formSubmitEl = $('#form-submit');

function showFormError(msg) {
  formErrorEl.hidden = false;
  formErrorEl.textContent = msg;
}
function openModal() {
  $('#add-form').reset();
  formErrorEl.hidden = true;
  addModalEl.hidden = false;
  $('#source-name').focus();
}
const closeModal = () => { addModalEl.hidden = true; };

async function handleAddSubmit(e) {
  e.preventDefault();
  const name = $('#source-name').value.trim();
  const url = $('#source-url').value.trim();
  if (!name || !url) return showFormError('请填写完整信息');
  if (name in doc.feeds) return showFormError('该名称已存在');
  try {
    new URL(url);
  } catch {
    return showFormError('请输入有效的 URL');
  }

  formSubmitEl.disabled = true;
  showFormError('正在验证订阅源…');
  try {
    const r = await fetch('/api/feed?url=' + encodeURIComponent(url));
    const body = await r.json().catch(() => null);
    if (!r.ok || body?.code !== 200 || !body?.data?.xml) throw new Error(body?.message || `HTTP ${r.status}`);
    const xmlDoc = new DOMParser().parseFromString(body.data.xml, 'text/xml');
    if (xmlDoc.querySelector('parsererror') || !xmlDoc.querySelector('rss, feed')) {
      throw new Error('该地址不是有效的 RSS/Atom 源');
    }
    const feeds = { ...doc.feeds, [name]: url };
    await saveSources({ feeds, pinned: doc.pinned });
    doc.feeds = feeds;
    closeModal();
    loadRSS(name);
  } catch (err) {
    showFormError('验证失败：' + err.message);
  } finally {
    formSubmitEl.disabled = false;
  }
}

/* ---------------- 主题 ---------------- */

function applyTheme(t) {
  document.documentElement.classList.toggle('dark', t === 'dark');
}
function initTheme() {
  const mql = matchMedia('(prefers-color-scheme: dark)');
  applyTheme(mql.matches ? 'dark' : 'light');
  mql.addEventListener('change', (e) => applyTheme(e.matches ? 'dark' : 'light'));
  if (window.JSOS?.getTheme) {
    Promise.resolve(window.JSOS.getTheme()).then((t) => t && applyTheme(t)).catch(() => {});
  }
  if (window.JSOS?.onThemeChange) window.JSOS.onThemeChange(applyTheme);
}

/* ---------------- 初始化 ---------------- */

async function init() {
  initTheme();

  $('#add-btn').addEventListener('click', openModal);
  $('#modal-close').addEventListener('click', closeModal);
  $('#add-modal').addEventListener('click', (e) => { if (e.target === addModalEl) closeModal(); });
  $('#add-form').addEventListener('submit', handleAddSubmit);
  $('#back-btn').addEventListener('click', hideArticle);

  try {
    const r = await fetch('/api/sources');
    const body = await r.json();
    if (body?.code !== 200 || !body?.data) throw new Error(body?.message || '读取订阅失败');
    doc = body.data;
  } catch (e) {
    showStatus('读取订阅失败：' + e.message, true);
    return;
  }
  renderSources();
  const first = doc.pinned[0] || Object.keys(doc.feeds)[0];
  if (first) loadRSS(first);
  else showNoSource();
}

document.addEventListener('DOMContentLoaded', init);
