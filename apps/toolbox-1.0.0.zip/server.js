import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// JSOS CORS 代理（§7.5）：容器内 PROXY_URL/PROXY_KEY 由系统注入，本机直跑时直连
const PROXY_URL = process.env.PROXY_URL || '';
const PROXY_KEY = process.env.PROXY_KEY || '';

// 出站统一走代理安全形态（encoded 路径无裸 //，key 走 query 零 preflight）
function outbound(target) {
  if (PROXY_URL && PROXY_KEY) {
    return `${PROXY_URL}/${encodeURIComponent(target)}?x-cors-proxy-key=${encodeURIComponent(PROXY_KEY)}`;
  }
  return target;
}

app.use(express.static(join(__dirname, 'public')));

// 图片同源代理：JSOS 强制 COEP require-corp，无 CORP 头的跨域图片一律 ERR_BLOCKED_BY_RESPONSE
app.get('/api/img', async (req, res) => {
  const u = req.query.u || '';
  let target;
  try {
    target = new URL(u);
  } catch {
    return res.status(400).json({ error: 'invalid url' });
  }
  if (target.protocol !== 'http:' && target.protocol !== 'https:') {
    return res.status(400).json({ error: 'invalid protocol' });
  }
  try {
    const r = await fetch(outbound(target.href), {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/129.0.0.0 Safari/537.36' },
    });
    if (!r.ok) return res.status(r.status).json({ error: `upstream ${r.status}` });
    const type = r.headers.get('content-type') || 'image/png';
    const buf = Buffer.from(await r.arrayBuffer());
    res.set('Content-Type', type);
    res.set('Cache-Control', 'public, max-age=86400');
    res.set('Access-Control-Allow-Origin', '*');
    res.send(buf);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

// 图片上传代理（移植自起始页 /api/proxy-upload）：客户端发原始字节，
// 服务端手工拼 multipart 转发 img.remit.ee（免 multer/form-data 依赖）
app.post('/api/proxy-upload', express.raw({ type: '*/*', limit: '10mb' }), async (req, res) => {
  if (!req.body || !req.body.length) {
    return res.status(400).json({ success: false, error: '未收到图片文件' });
  }
  const filename = (decodeURIComponent(req.headers['x-filename'] || 'image.png') || 'image.png')
    .replace(/["\r\n\\]/g, '_');
  const mime = req.headers['x-file-type'] || 'application/octet-stream';
  const boundary = '----jsostoolbox' + Date.now();
  const pre = Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: ${mime}\r\n\r\n`
  );
  const post = Buffer.from(`\r\n--${boundary}--\r\n`);
  const body = Buffer.concat([pre, req.body, post]);

  try {
    const r = await fetch(outbound('https://img.remit.ee/api/upload'), {
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        // img.remit.ee 校验网页来源：必须带自身 Origin/Referer，否则 403"不允许直接调用API"
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/129.0.0.0 Safari/537.36',
        'Origin': 'https://img.remit.ee',
        'Referer': 'https://img.remit.ee/',
      },
      body,
    });
    const data = await r.json();
    res.status(r.ok ? 200 : 502).json(data);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`toolbox running on ${port}`));
