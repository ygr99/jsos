// 朋友圈 — 纯静态托管（express）
// 应用数据不落服务器：全部存浏览器 localStorage（帖子/资料）+ IndexedDB（上传的图片、音频、视频 Blob）
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(join(__dirname, 'public'), {
  setHeaders(res) {
    // 二进制资源（如未来扩展）走缓存，json 不缓存避免读到旧种子
    res.set('Cache-Control', 'no-cache');
  }
}));

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`moments running on ${port}`));
