// 侧边栏注入：先同步定好宽度（早于首次绘制，避免内容"被侧栏顶出来"）→ fetch 片段 → 高亮当前页 → 折叠开关
// 折叠状态存 localStorage（纯 UI 偏好，丢了无所谓；jsos AGENTS §6）
(function () {
  var STORAGE_KEY = "jiuyunjian.sidebar-collapsed";
  var EXPANDED_W = "200px";
  var COLLAPSED_W = "56px";

  var collapsed0 = false;
  try { collapsed0 = localStorage.getItem(STORAGE_KEY) === "1"; } catch (e) {}

  // ★ 必须在 fetch 之前同步执行：脚本在 </body> 前，此时尚未首次绘制，
  //   先把 --sidebar-w 与 has-sidebar 落好，内容从第一帧就处在正确位置 → 不会出现 0→200px 的位移动画
  document.documentElement.style.setProperty("--sidebar-w", collapsed0 ? COLLAPSED_W : EXPANDED_W);
  document.body.classList.add("has-sidebar");

  // 当前路由高亮：路径别名归一到导航项的 data-path
  // 文章详情归属博客；带 .html 后缀的也归一（否则从 /blog.html 进来时博客不高亮）
  function normalizePath(p) {
    if (p === "/index.html") return "/";
    if (p === "/article.html") return "/blog";
    if (p === "/blog.html") return "/blog";
    if (p === "/calendar.html") return "/calendar";
    if (p === "/sentences.html") return "/sentences";
    return p;
  }

  fetch("/sidebar.html")
    .then(function (r) { return r.text(); })
    .then(function (html) {
      var container = document.getElementById("sidebar-container");
      if (!container) return;
      container.innerHTML = html;

      var path = normalizePath(location.pathname);
      var links = container.querySelectorAll(".sidebar-nav a[data-path]");
      for (var i = 0; i < links.length; i++) {
        if (links[i].getAttribute("data-path") === path) links[i].classList.add("active");
      }

      var sidebar = container.querySelector(".app-sidebar");
      var btn = container.querySelector("#collapse-btn");
      var iconClose = btn && btn.querySelector(".icon-close");
      var iconOpen = btn && btn.querySelector(".icon-open");

      function apply(collapsed) {
        sidebar.classList.toggle("collapsed", collapsed);
        document.documentElement.style.setProperty("--sidebar-w", collapsed ? COLLAPSED_W : EXPANDED_W);
        btn.setAttribute("aria-label", collapsed ? "展开侧边栏" : "折叠侧边栏");
        btn.title = collapsed ? "展开侧边栏" : "折叠侧边栏";
        // SVGElement 没有 .hidden 这个 IDL 属性，必须写真实 attribute（jsos AGENTS §5.1）
        if (iconClose) iconClose.toggleAttribute("hidden", collapsed);
        if (iconOpen) iconOpen.toggleAttribute("hidden", !collapsed);
      }

      // 值已在首屏同步落好，这里只是把侧栏 DOM 与图标切到同一状态（不产生位移）
      apply(collapsed0);

      btn.addEventListener("click", function () {
        var next = !sidebar.classList.contains("collapsed");
        apply(next);
        try { localStorage.setItem(STORAGE_KEY, next ? "1" : "0"); } catch (e) {}
      });
    })
    .catch(function (e) { console.error("加载侧边栏失败:", e); });
})();
