import express from 'express';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

// [存储规范 §7.9] 数据存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/<appId>，
// 卸载勾选「同时删除应用数据」时由平台整目录清除）；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const TASKS_FILE = join(DATA_DIR, 'tasks.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

function readTasks() {
  try {
    if (!fs.existsSync(TASKS_FILE)) return [];
    const raw = fs.readFileSync(TASKS_FILE, 'utf8');
    if (!raw.trim()) return [];
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : (data.tasks || []);
  } catch {
    return [];
  }
}

function writeTasks(tasks) {
  const tmp = TASKS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify({ tasks }, null, 2));
  fs.renameSync(tmp, TASKS_FILE);
}

// 中国时区（UTC+8）当前时间，移植自 99-事项
function cnNow() {
  return new Date(Date.now() + 8 * 60 * 60 * 1000);
}

function cnISOString() {
  return cnNow().toISOString().replace('Z', '+08:00');
}

function getISOWeek(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 4 - (d.getDay() || 7));
  const yearStart = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// 生成带日期标识的 category：2026-09-12 today / 2026-37 week / 2026-09 month / 2026 year
function generateCategory(type) {
  const now = cnNow();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const w = getISOWeek(now);
  switch (type) {
    case 'today': return `${y}-${m}-${d} today`;
    case 'week': return `${y}-${w} week`;
    case 'month': return `${y}-${m} month`;
    case 'year': return `${y} year`;
    default: return `${y}-${m}-${d} today`;
  }
}

app.get('/api/tasks', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(readTasks());
});

app.post('/api/tasks', (req, res) => {
  const { title, detail, process, category, status } = req.body || {};
  if (!title || !String(title).trim()) {
    return res.status(400).json({ error: '事项标题不能为空' });
  }
  const tasks = readTasks();
  const task = {
    id: crypto.randomUUID(),
    title: String(title).trim(),
    detail: detail ? String(detail).trim() : '',
    process: process ? String(process).trim() : '',
    status: status || '待办',
    createdAt: cnISOString(),
    completedAt: null,
  };
  if (category) task.category = generateCategory(category);
  tasks.push(task);
  writeTasks(tasks);
  res.status(201).json(task);
});

app.put('/api/tasks/:id', (req, res) => {
  const tasks = readTasks();
  const task = tasks.find((t) => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: '事项不存在' });

  const { title, detail, process, category, status, createdAt, completedAt } = req.body || {};
  if (title !== undefined) task.title = String(title).trim();
  if (detail !== undefined) task.detail = detail ? String(detail).trim() : '';
  if (process !== undefined) task.process = process ? String(process).trim() : '';
  if (category !== undefined) task.category = category ? generateCategory(category) : undefined;
  if (status !== undefined) {
    task.status = status;
    if (status === '已完成' && !completedAt) task.completedAt = cnISOString();
    else if (status !== '已完成') task.completedAt = null;
  }
  if (createdAt !== undefined && createdAt) task.createdAt = createdAt;
  if (completedAt !== undefined) task.completedAt = completedAt;
  writeTasks(tasks);
  res.json(task);
});

app.delete('/api/tasks/:id', (req, res) => {
  const tasks = readTasks();
  const idx = tasks.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: '事项不存在' });
  tasks.splice(idx, 1);
  writeTasks(tasks);
  res.json({ ok: true });
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`todo running on ${port}`));
