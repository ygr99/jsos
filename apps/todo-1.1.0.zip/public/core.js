/**
 * todo 共享核心：服务端存储（workspace/data/<appId>/tasks.json）+ 今日待办计算
 *
 * 存储：§7.9 模式 A，数据经 /api/tasks 存到服务端 DATA_DIR（JSOS 容器内 =
 * workspace/data/<appId>，卸载勾选「同时删除应用数据」时整目录清除）。
 * 同步：主页面 ↔ 小组件用 BroadcastChannel 通知 + 60s/可见性兜底重拉。
 */

const SYNC_CHANNEL = 'todo-sync';

export async function loadTasks() {
  try {
    const res = await fetch('/api/tasks', { cache: 'no-store' });
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function createTask(payload) {
  const res = await fetch('/api/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || '创建失败');
  return res.json();
}

export async function updateTask(id, patch) {
  const res = await fetch(`/api/tasks/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  if (!res.ok) throw new Error('更新失败');
  return res.json();
}

export async function deleteTask(id) {
  const res = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('删除失败');
  return res.json();
}

/** 跨页面即时通知（同一容器内同源） */
export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage('tasks-updated');
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = () => cb();
  } catch {}
}

export function isToday(dateString, now = new Date()) {
  const d = new Date(dateString);
  return d.getFullYear() === now.getFullYear()
    && d.getMonth() === now.getMonth()
    && d.getDate() === now.getDate();
}

/**
 * 今日待办（小组件与「今日事项」tab 同一口径，移植自 99-事项）：
 * 今天创建且无 category 标记的事项中，未完成的（status !== '已完成'）。
 */
export function todayOpenTasks(tasks, now = new Date()) {
  return tasks.filter((t) => isToday(t.createdAt, now) && !t.category && t.status !== '已完成');
}
