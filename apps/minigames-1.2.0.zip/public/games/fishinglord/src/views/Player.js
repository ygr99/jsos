(function () {
  var ns = Q.use("fish"),
    game = ns.game;

  var Player = (ns.Player = function (props) {
    this.id = null;
    this.coin = 0;
    this.numCapturedFishes = 0;

    this.cannon = null;
    this.cannonMinus = null;
    this.cannonPlus = null;
    this.coinNum = null;

    props = props || {};
    Q.merge(this, props, true);

    this.init();
  });

  Player.prototype.init = function () {
    var me = this,
      power = 1;
    var isMobile = Q.isMobile;

    this.cannon = new ns.Cannon(ns.R.cannonTypes[power]);
    this.cannon.id = "cannon";
    this.cannon.x = game.bottom.x + (isMobile ? game.width * 0.5 : 425);
    this.cannon.y = game.bottom.y + (isMobile ? 30 : 60);
    this.cannon.y = game.height - (isMobile ? 20 : 10);

    // 调整按钮大小和位置
    var buttonScale = isMobile ? 1.5 : 1;
    var buttonSpacing = isMobile ? 180 : 140;
    var buttonY = game.bottom.y + (isMobile ? 20 : 36);

    this.cannonMinus = new Q.Button(ns.R.cannonMinus);
    this.cannonMinus.id = "cannonMinus";
    this.cannonMinus.x = game.bottom.x + (isMobile ? game.width * 0.2 : 340);
    this.cannonMinus.y = buttonY;
    this.cannonMinus.scaleX = this.cannonMinus.scaleY = buttonScale;
    this.cannonMinus.onEvent = function (e) {
      if (e.type == game.events[1]) {
        me.cannon.setPower(-1, true);
      }
    };

    this.cannonPlus = new Q.Button(ns.R.cannonPlus);
    this.cannonPlus.id = "cannonPlus";
    this.cannonPlus.x = this.cannonMinus.x + buttonSpacing;
    this.cannonPlus.y = buttonY;
    this.cannonPlus.scaleX = this.cannonPlus.scaleY = buttonScale;
    this.cannonPlus.onEvent = function (e) {
      if (e.type == game.events[1]) {
        me.cannon.setPower(1, true);
      }
    };

    this.coinNum = new ns.Num({
      id: "coinNum",
      src: ns.R.numBlack,
      max: 6,
      gap: 3,
      autoAddZero: true,
      scaleX: isMobile ? 1.2 : 1,
      scaleY: isMobile ? 1.2 : 1,
    });
    this.coinNum.x = game.bottom.x + (isMobile ? 40 : 20);
    this.coinNum.y = game.bottom.y + (isMobile ? 30 : 44);
    this.loadCoin(); // 加载保存的金币数据
    this.updateCoin(this.coin);

    game.stage.addChild(
      this.cannon,
      this.cannonMinus,
      this.cannonPlus,
      this.coinNum
    );
  };

  Player.prototype.fire = function (targetPoint) {
    var cannon = this.cannon,
      power = cannon.power,
      speed = 5;
    if (this.coin < power) return;

    //cannon fire
    var dir = ns.Utils.calcDirection(cannon, targetPoint),
      degree = dir.degree;
    if (degree == -90) degree = 0;
    else if (degree < 0 && degree > -90) degree = -degree;
    else if (degree >= 180 && degree <= 270) degree = 180 - degree;
    cannon.fire(degree);

    //fire a bullet
    var sin = Math.sin(degree * Q.DEG_TO_RAD),
      cos = Math.cos(degree * Q.DEG_TO_RAD);
    var bullet = new ns.Bullet(ns.R.bullets[power - 1]);
    bullet.x = cannon.x + (cannon.regY + 20) * sin;
    bullet.y = cannon.y - (cannon.regY + 20) * cos;
    bullet.rotation = degree;
    bullet.power = power;
    bullet.speedX = speed * sin;
    bullet.speedY = speed * cos;
    game.stage.addChild(bullet);

    //deduct coin
    this.updateCoin(-power, true);
  };

  Player.prototype.captureFish = function (fish) {
    this.updateCoin(fish.coin, true);
    this.numCapturedFishes++;
  };

  Player.prototype.updateCoin = function (coin, increase) {
    if (increase) {
      this.coin += coin;
    } else {
      this.coin = coin;
    }

    if (this.coin <= 0) {
      this.coin = 1000; // 自动重置金币为5000
      console.log("金币已重置为1000"); // 调试信息
    }

    if (this.coin > 999999) {
      this.coin = 999999;
    }

    this.coinNum.setValue(this.coin);
    this.saveCoin(); // 保存金币数据
  };
  Player.prototype.saveCoin = function () {
    localStorage.setItem("gameCoin", this.coin);
  };

  Player.prototype.loadCoin = function () {
    var savedCoin = localStorage.getItem("gameCoin");
    if (savedCoin !== null) {
      this.coin = parseInt(savedCoin, 10);
    } else {
      this.coin = 10000; // 默认初始金币数量
    }
  };
})();
