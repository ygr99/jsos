// 本机信息 —— 零依赖静态服务器（installCommand 为空，不装任何 npm 包）
// 除静态文件外只提供一个只读接口 /api/node：容器内 Node 的 os 模块快照。
// ⚠️ 该接口的值来自 WebContainer 内的模拟 Node，不等于真机硬件，前端必须标注清楚。
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const PORT = process.env.PORT || 3000;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const num = (v) => (Number.isFinite(v) ? v : null);

function nodeSnapshot() {
  const safe = (fn, fallback = null) => {
    try {
      return fn();
    } catch (e) {
      return fallback;
    }
  };
  const cpus = safe(() => os.cpus(), []) || [];
  return {
    platform: safe(() => os.platform()),
    type: safe(() => os.type()),
    release: safe(() => os.release()),
    arch: safe(() => os.arch()),
    endianness: safe(() => os.endianness()),
    hostname: safe(() => os.hostname()),
    uptimeSec: num(safe(() => Math.round(os.uptime()))),
    cpuCount: cpus.length,
    cpuModel: cpus[0] ? cpus[0].model : null,
    cpuSpeedMHz: cpus[0] ? cpus[0].speed : null,
    totalMem: num(safe(() => os.totalmem())),
    freeMem: num(safe(() => os.freemem())),
    loadavg: safe(() => os.loadavg()),
    networkInterfaces: safe(() => Object.keys(os.networkInterfaces() || {}), []),
    nodeVersion: process.version,
    processArch: process.arch,
    processPlatform: process.platform,
    heapLimit: num(safe(() => process.memoryUsage().heapTotal)),
    pid: safe(() => process.pid),
  };
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');

  if (url.pathname === '/api/node') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(JSON.stringify(nodeSnapshot()));
  }

  let rel = decodeURIComponent(url.pathname).replace(/^\/+/, '');
  let file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    return res.end('forbidden');
  }
  if (!rel || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    file = path.join(PUBLIC, 'index.html'); // SPA 回落（含 /widget/xxx）
  }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {
    'content-type': MIME[ext] || 'application/octet-stream',
    'cache-control': ext === '.html' ? 'no-store' : 'public, max-age=60',
  });
  res.end(fs.readFileSync(file));
});

server.listen(PORT, () => console.log(`system-info running on ${PORT}`));
