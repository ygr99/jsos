'use strict';

// Markdown 笔记 —— 基于 uTools「iker-Markdown笔记本」重构（Vditor 3.8.8）

// ---------- 小工具 ----------
const $ = s => document.querySelector(s);

function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

let toastTimer = null;
function toast(msg, type = 'info') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = type;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 2500);
}

async function api(url, body) {
  const r = await fetch(url, body ? {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  } : undefined);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `请求失败(${r.status})`);
  return data;
}

// ---------- 选项（UI 偏好，存 localStorage） ----------
const OPTIONS_KEY = 'mdnotes.options';
// 文件夹折叠状态按路径持久化：树重渲染/重开应用后都保持
// （否则任何一次重渲染都按"默认展开"重建——原插件 chokidar 刷新节点的同款 bug）
const COLLAPSED_KEY = 'mdnotes.collapsed-dirs';
const DEFAULT_OPTIONS = { mode: 'ir', fontSize: 'medium', contentTheme: 'light', codeTheme: 'github', lineNumber: false, counter: true };
let opts = { ...DEFAULT_OPTIONS, ...safeParse(localStorage.getItem(OPTIONS_KEY)) };

function safeParse(s) {
  try { return JSON.parse(s) || {}; } catch { return {}; }
}

function saveOptions() {
  localStorage.setItem(OPTIONS_KEY, JSON.stringify(opts));
  document.documentElement.style.setProperty('--md-font-size', opts.fontSize);
}

const CODE_THEMES = ['algol', 'arduino', 'colorful', 'emacs', 'fruity', 'github', 'igor', 'lovelace', 'manni', 'monokai', 'monokailight', 'native', 'rainbow_dash', 'rrt', 'swapoff', 'trac', 'vs', 'ant-design'];
const CONTENT_THEMES = ['light', 'ant-design', 'wechat', 'dark'];

const EMOJI = {
  '+1': '👍', '-1': '👎', '1st_place_medal': '🥇', anger: '💢', angry: '😠', anguished: '😧',
  balloon: '🎈', ballot_box: '🗳', ballot_box_with_check: '☑️', bamboo: '🎍', church: '⛪️',
  cinema: '🎦', circus_tent: '🎪', city_sunrise: '🌇', city_sunset: '🌆', cityscape: '🏙',
  cl: '🆑', clamp: '🗜', clap: '👏', clapper: '🎬', classical_building: '🏛', computer: '💻',
  computer_mouse: '🖱', confetti_ball: '🎊', confounded: '😖', confused: '😕', desktop_computer: '🖥',
  detective: '🕵', diamond_shape_with_a_dot_inside: '💠', grimacing: '😬', grin: '😁', grinning: '😀',
  guardsman: '💂', haircut: '💇', hankey: '💩', hash: '#️⃣', hatched_chick: '🐥', hatching_chick: '🐣',
  headphones: '🎧', hear_no_evil: '🙉', heart: '❤️', heart_decoration: '💟', heart_eyes: '😍',
  heart_eyes_cat: '😻', heartbeat: '💓', heartpulse: '💗', hearts: '♥️', heavy_check_mark: '✔️',
  heavy_division_sign: '➗', heavy_dollar_sign: '💲', heavy_exclamation_mark: '❗️',
  heavy_heart_exclamation: '❣️', heavy_minus_sign: '➖', heavy_multiplication_x: '✖️',
  heavy_plus_sign: '➕', helicopter: '🚁',
};

const UPLOAD_ICON = '<svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="icon"><g><title>background</title><rect fill="none" id="canvas_background" height="202" width="202" y="-1" x="-1"/></g><g> <title>Layer 1</title><g stroke="null" id="svg_3"><path stroke="null" id="svg_1" d="m22.15529,24.69377l0,150.61246l155.68942,0l0,-150.61246l-155.68942,0zm-7.07679,-13.69204l169.84301,0a7.07679,6.84602 0 0 1 7.07679,6.84602l0,164.30451a7.07679,6.84602 0 0 1 -7.07679,6.84602l-169.84301,0a7.07679,6.84602 0 0 1 -7.07679,-6.84602l0,-164.30451a7.07679,6.84602 0 0 1 7.07679,-6.84602z" fill="currentColor"/><path stroke="null" id="svg_2" d="m71.69283,52.07786q14.15358,0 14.15358,13.69204t-14.15358,13.69204q-14.15358,0 -14.15358,-13.69204t14.15358,-13.69204zm-43.91857,126.00786l-11.23795,-8.32476l47.79665,-60.34083a21.23038,20.53806 0 0 1 29.76499,-3.82008l0.41045,0.31492l27.17488,21.20897a7.07679,6.84602 0 0 0 9.94997,-1.0406l47.76835,-57.73934l11.0398,8.54383l-47.72588,57.72565l-0.05661,0.06846a21.23038,20.53806 0 0 1 -29.86406,3.0944l-27.17488,-21.19528l-0.14154,-0.10954a7.07679,6.84602 0 0 0 -9.90751,1.27336l-47.79665,60.34083z" fill="currentColor"/> </g> </g></svg>';

const TOOLBAR = [
  'emoji', 'headings', 'bold', 'italic', 'strike', 'link', '|',
  'list', 'ordered-list', 'check', 'outdent', 'indent', '|',
  'quote', 'line', 'code', 'inline-code', 'fullscreen', '|',
  { name: 'upload', tip: '添加图片', icon: UPLOAD_ICON },
  'table', '|',
];

const ICON_FOLDER = '<svg class="icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M878.08 448H241.92l-96 384h636.16l96-384zM832 384v-64H485.76L357.504 192H128v448l57.92-231.744A32 32 0 0 1 216.96 384H832zm-24.96 512H96a32 32 0 0 1-32-32V160a32 32 0 0 1 32-32h287.872l128.384 128H864a32 32 0 0 1 32 32v96h23.04a32 32 0 0 1 31.04 39.744l-112 448A32 32 0 0 1 807.04 896z"/></svg>';

// ---------- 全局状态 ----------
let tree = [];
let current = null;        // 当前打开的文档 {path, name, leaf}
let currentContent = '';
let vditor = null;
let readMode = false;
let saveTimer = null;
let countTimer = null;
let dirty = null;          // 待保存 {path, content}
let menuTarget = null;     // 右键菜单目标节点（null = 根目录）
let collapsedDirs = loadCollapsedDirs();

function loadCollapsedDirs() {
  try {
    const a = JSON.parse(localStorage.getItem(COLLAPSED_KEY));
    return new Set(Array.isArray(a) ? a : []);
  } catch {
    return new Set();
  }
}

function saveCollapsedDirs() {
  localStorage.setItem(COLLAPSED_KEY, JSON.stringify([...collapsedDirs]));
}

// ---------- 编辑器 ----------
function editorTheme() {
  return opts.contentTheme === 'dark' ? 'dark' : 'classic';
}

function createEditor(initialContent) {
  destroyEditor();
  $('#markdown').hidden = false;
  vditor = new Vditor('markdown', {
    cdn: '/vditor',
    mode: opts.mode,
    lang: 'zh_CN',
    // 图标符号表已内联进 index.html；置空跳过 Vditor 的运行时图标脚本加载
    // （其实现走同步 XHR 且"加载过就永久跳过"，容器里一旦失败本窗口图标全空白）
    icon: '',
    placeholder: '空空如也哦，写点什么吧！',
    height: '100%',
    cache: { enable: false },
    counter: { enable: true },   // 内部常开（内置显示靠 CSS 隐藏），数字由 updateCount 渲染到左下角
    hint: { delay: 200, emoji: EMOJI },
    preview: {
      delay: 500,
      maxWidth: 1000,
      actions: [],
      theme: { current: opts.contentTheme, path: '/vditor/dist/css/content-theme' },
      hljs: { style: opts.codeTheme, enable: true, lineNumber: opts.lineNumber },
      math: { engine: 'KaTeX', inlineDigit: false },
    },
    toolbar: TOOLBAR,
    upload: { handler: uploadHandler },
    input: onEditorInput,
    after: () => {
      if (initialContent) {
        try { vditor.setValue(initialContent); } catch {}
      }
      if (!current) {
        // 没有打开任何文档前禁止编辑（对齐原插件行为）
        try { vditor.disabled(); } catch {}
      }
      refreshOutline();
      updateCount();
    },
  });
}

function destroyEditor() {
  if (vditor) {
    try { vditor.destroy(); } catch {}
    vditor = null;
  }
}

function rebuildEditor() {
  const value = vditor ? vditor.getValue() : currentContent;
  createEditor(value);
}

function onEditorInput(value) {
  if (!current || readMode) return;
  dirty = { path: current.path, content: value };
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 700);
  clearTimeout(countTimer);
  countTimer = setTimeout(updateCount, 300);   // 等 Vditor 计数器先更新完
}

async function flushSave() {
  clearTimeout(saveTimer);
  const d = dirty;
  if (!d) return;
  dirty = null;
  if (!current || d.path !== current.path) return;
  try {
    await api('/api/save', d);
  } catch (e) {
    if (!dirty) dirty = d;   // 期间若有新输入，保留更新的 dirty，不回退成旧内容
    toast('保存失败：' + e.message, 'error');
  }
}

// 页面卸载前尽力兜底保存（iframe 关闭时）
window.addEventListener('pagehide', () => {
  if (dirty && current && dirty.path === current.path) {
    try {
      fetch('/api/save', {
        method: 'POST',
        keepalive: true,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dirty),
      });
    } catch {}
  }
});

function uploadHandler(files) {
  const file = files && files[0];
  if (!file) return null;
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const r = await api('/api/upload', { name: file.name, data: reader.result });
      if (vditor) vditor.insertValue(`![](${r.url})\n`);
      toast('图片已插入', 'success');
    } catch (e) {
      toast('存储图片失败：' + e.message, 'error');
    }
  };
  reader.readAsDataURL(file);
  return null;
}

// ---------- 阅读模式 ----------
function previewOpts(after) {
  return {
    cdn: '/vditor',
    lang: 'zh_CN',
    icon: '',
    theme: editorTheme(),
    after,
    preview: {
      delay: 0,
      maxWidth: 1000,
      theme: { current: opts.contentTheme, path: '/vditor/dist/css/content-theme' },
      hljs: { style: opts.codeTheme, enable: true, lineNumber: opts.lineNumber },
      math: { engine: 'KaTeX', inlineDigit: false },
    },
  };
}

function renderReadView() {
  const target = $('#read_modeview');
  target.innerHTML = '';
  Vditor.preview(target, currentContent, previewOpts(() => {
    try { Vditor.outlineRender(target, $('#markdown-outline')); } catch {}
  }));
}

async function enterRead() {
  if (readMode) return;
  await flushSave();
  if (vditor) currentContent = vditor.getValue();
  readMode = true;
  destroyEditor();
  $('#markdown').hidden = true;
  $('#readView').hidden = false;
  renderReadView();
}

async function exitRead() {
  if (!readMode) return;
  readMode = false;
  $('#readView').hidden = true;
  $('#read_modeview').innerHTML = '';
  if (current) {
    // 重新从服务端取内容，拿到最新（可能被其他窗口修改过）
    try {
      const r = await api('/api/file?path=' + encodeURIComponent(current.path));
      currentContent = r.content ?? '';
    } catch {}
  }
  createEditor(currentContent);
}

function syncReadUI() {
  $('#readModeSwitch').checked = readMode;
  $('#eyeOn').toggleAttribute('hidden', !readMode);
  $('#eyeOff').toggleAttribute('hidden', readMode);
}

async function toggleRead() {
  if (!current) {
    toast('请先打开一个文档', 'warning');
    return syncReadUI();
  }
  if (readMode) await exitRead(); else await enterRead();
  syncReadUI();
  updateCount();
}

// ---------- 大纲 ----------
function refreshOutline() {
  if (!vditor) return;
  try {
    vditor.vditor.outline.render(vditor.vditor, $('#markdown-outline'));
  } catch {}
}

// ---------- 字数统计（左下角，读 Vditor 内置计数器的数字） ----------
function updateCount() {
  const el = $('#countLabel');
  if (!current || readMode || !opts.counter) {
    el.hidden = true;
    return;
  }
  const counterEl = document.querySelector('.vditor-counter');
  const n = counterEl ? counterEl.textContent.trim() : '';
  if (/^\d+$/.test(n)) {
    el.hidden = false;
    el.textContent = n + ' 字';
  } else {
    el.hidden = true;
  }
}

// ---------- 文件树 ----------
async function loadTree() {
  try {
    tree = await api('/api/tree');
  } catch {
    return toast('加载文档列表失败', 'error');
  }
  renderTree();
}

function renderTree() {
  const bar = $('#fileListBar');
  bar.innerHTML = '';
  const frag = document.createDocumentFragment();
  buildTreeRows(tree, frag, 0);
  bar.appendChild(frag);
  highlightCurrent();
}

function buildTreeRows(nodes, container, depth) {
  for (const n of nodes) {
    const row = document.createElement('div');
    row.className = 'treeRow ' + (n.leaf ? 'itemFile' : 'itemFolder');
    row.style.paddingLeft = (8 + depth * 14) + 'px';
    row.dataset.path = n.path;
    row.innerHTML = (n.leaf ? '' : ICON_FOLDER) + `<span class="label">${esc(n.name)}</span>`;
    container.appendChild(row);
    row.addEventListener('click', () => {
      if (n.leaf) openFile(n);
      else {
        const kids = row.nextElementSibling;
        if (kids && kids.classList.contains('treeChildren')) {
          kids.classList.toggle('collapsed');
          if (kids.classList.contains('collapsed')) collapsedDirs.add(n.path);
          else collapsedDirs.delete(n.path);
          saveCollapsedDirs();
        }
      }
    });
    row.addEventListener('contextmenu', e => {
      e.preventDefault();
      e.stopPropagation();
      showMenu(e, n);
    });
    if (!n.leaf) {
      const kids = document.createElement('div');
      kids.className = 'treeChildren';
      if (collapsedDirs.has(n.path)) kids.classList.add('collapsed');
      buildTreeRows(n.children || [], kids, depth + 1);
      container.appendChild(kids);
    }
  }
}

function highlightCurrent() {
  document.querySelectorAll('.treeRow.current').forEach(el => el.classList.remove('current'));
  if (!current) return;
  const row = document.querySelector(`.treeRow[data-path="${CSS.escape(current.path)}"]`);
  if (row) row.classList.add('current');
}

async function openFile(node) {
  if (!node || !node.leaf) return;
  if (current && current.path === node.path) return;
  await flushSave();
  let content = '';
  try {
    const r = await api('/api/file?path=' + encodeURIComponent(node.path));
    content = r.content ?? '';
  } catch (e) {
    return toast('文件读取失败：' + e.message, 'error');
  }
  current = { path: node.path, name: node.name, leaf: true };
  currentContent = content;
  if (readMode) renderReadView(); else createEditor(content);
  highlightCurrent();
}

// ---------- 右键菜单 ----------
function showMenu(e, node) {
  menuTarget = node;
  const menu = $('#rightMenu');
  const isDirTarget = !node || !node.leaf;
  menu.querySelector('[data-op=createdir]').hidden = !isDirTarget;
  menu.querySelector('[data-op=createfile]').hidden = !isDirTarget;
  menu.querySelector('[data-op=rename]').hidden = !node;
  menu.querySelector('[data-op=delfile]').hidden = !node;
  menu.hidden = false;
  menu.style.left = Math.max(4, Math.min(e.clientX, window.innerWidth - 160)) + 'px';
  menu.style.top = Math.max(4, Math.min(e.clientY, window.innerHeight - 160)) + 'px';
}

function hideMenu() {
  $('#rightMenu').hidden = true;
}

function parentPathOf(path) {
  const i = path.lastIndexOf('/');
  return i === -1 ? '' : path.slice(0, i);
}

async function opCreate(kind) {
  const isDir = kind === 'dir';
  const base = menuTarget && !menuTarget.leaf ? menuTarget.path : '';
  const name = await promptModal(isDir ? '新建分类' : '新建文档', '请输入名称');
  if (!name) return;
  const rel = (base ? base + '/' : '') + name + (isDir || /\.md$/i.test(name) ? '' : '.md');
  try {
    await api(isDir ? '/api/mkdir' : '/api/create', { path: rel });
    toast('创建成功', 'success');
    await loadTree();
    if (!isDir) await openFile({ path: rel, name: rel.split('/').pop(), leaf: true });
  } catch (e) {
    toast('创建失败：' + e.message, 'error');
  }
}

async function opRename() {
  if (!menuTarget) return;
  const node = menuTarget;
  await flushSave();
  const defaultValue = node.leaf ? node.name.replace(/\.md$/i, '') : node.name;
  const raw = await promptModal('重命名：' + node.name, '请输入新名称', defaultValue);
  if (!raw) return;
  let newName = raw;
  if (node.leaf && !/\.md$/i.test(newName)) newName += '.md';
  const to = (parentPathOf(node.path) ? parentPathOf(node.path) + '/' : '') + newName;
  if (to === node.path) return;
  try {
    await api('/api/rename', { from: node.path, to });
    toast('重命名成功', 'success');
    const oldPath = node.path;
    // 折叠记录迁移：文件夹自身及子孙路径前缀替换
    if (collapsedDirs.has(oldPath)) {
      collapsedDirs.delete(oldPath);
      collapsedDirs.add(to);
    }
    for (const p of [...collapsedDirs]) {
      if (p.startsWith(oldPath + '/')) {
        collapsedDirs.delete(p);
        collapsedDirs.add(to + p.slice(oldPath.length));
      }
    }
    saveCollapsedDirs();
    await loadTree();
    if (current && current.path === oldPath) {
      current.path = to;
      current.name = newName;
      highlightCurrent();
    }
  } catch (e) {
    toast('重命名失败：' + e.message, 'error');
  }
}

async function opDelete() {
  if (!menuTarget) return;
  const node = menuTarget;
  const ok = await confirmModal('警告！', `操作无法撤回，确定删除「${node.name}」吗?`);
  if (!ok) return;
  try {
    await api('/api/delete', { path: node.path });
    toast('删除成功', 'success');
    // 清掉被删文件夹自身及子孙的折叠记录
    for (const p of [...collapsedDirs]) {
      if (p === node.path || p.startsWith(node.path + '/')) collapsedDirs.delete(p);
    }
    saveCollapsedDirs();
    if (current && (current.path === node.path || current.path.startsWith(node.path + '/'))) {
      current = null;
      currentContent = '';
      dirty = null;
      if (readMode) {
        readMode = false;
        $('#readView').hidden = true;
        $('#read_modeview').innerHTML = '';
        $('#markdown').hidden = false;
      }
      createEditor('');
    }
    await loadTree();
  } catch (e) {
    toast('删除失败：' + e.message, 'error');
  }
}

// ---------- 弹窗 ----------
let modalOnOk = null;
let modalOnCancel = null;

function promptModal(title, placeholder, value = '') {
  return new Promise(resolve => {
    $('#modalTitle').textContent = title;
    $('#modalMsg').textContent = '';
    const input = $('#modalInput');
    input.hidden = false;
    input.value = value;
    input.placeholder = placeholder || '';
    $('#modalMask').hidden = false;
    modalOnOk = () => {
      const v = input.value.trim();
      closeModal();
      resolve(v);
    };
    modalOnCancel = () => {
      closeModal();
      resolve(null);
    };
    setTimeout(() => input.focus(), 30);
  });
}

function confirmModal(title, message) {
  return new Promise(resolve => {
    $('#modalTitle').textContent = title;
    $('#modalMsg').textContent = message;
    $('#modalInput').hidden = true;
    $('#modalMask').hidden = false;
    modalOnOk = () => {
      closeModal();
      resolve(true);
    };
    modalOnCancel = () => {
      closeModal();
      resolve(false);
    };
  });
}

function closeModal() {
  $('#modalMask').hidden = true;
  modalOnOk = null;
  modalOnCancel = null;
}

// ---------- 设置抽屉 ----------
function openDrawer() {
  $('#drawer').hidden = false;
  $('#drawerMask').hidden = false;
  // 同步开关状态
  $('#fontSizeSel').value = opts.fontSize;
  $('#codeThemeSel').value = opts.codeTheme;
  $('#contentThemeSel').value = opts.contentTheme;
  $('#lineNumberSwitch').checked = opts.lineNumber;
  $('#counterSwitch').checked = opts.counter;
  const modeInput = document.querySelector(`#modeGroup input[value="${opts.mode}"]`);
  if (modeInput) modeInput.checked = true;
}

function closeDrawer() {
  $('#drawer').hidden = true;
  $('#drawerMask').hidden = true;
}

function applyTheme() {
  if (vditor) {
    try { vditor.setTheme(editorTheme(), opts.contentTheme, opts.codeTheme); } catch {}
  }
}

async function setEditMode(mode) {
  if (!['ir', 'sv', 'wysiwyg'].includes(mode)) return;
  opts.mode = mode;
  saveOptions();
  if (readMode || !vditor) return;
  const value = vditor.getValue();
  try {
    vditor.setCurrentEditMode(vditor.vditor, mode, '');
    vditor.setValue(value);
  } catch {
    createEditor(value);
  }
}

// ---------- 导出 ----------
function download(name, text) {
  const a = document.createElement('a');
  a.download = name;
  a.style.display = 'none';
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }));
  document.body.appendChild(a);
  a.click();
  a.remove();
}

async function exportMd() {
  if (!current) return toast('请先打开一个文档', 'warning');
  await flushSave();
  const value = readMode ? currentContent : (vditor ? vditor.getValue() : currentContent);
  download(/\.md$/i.test(current.name) ? current.name : current.name + '.md', value);
  toast('已导出 Markdown 文件', 'success');
}

async function exportPdf() {
  if (!current) return toast('请先打开一个文档', 'warning');
  await flushSave();
  if (!readMode) await enterRead();
  syncReadUI();
  toast('已进入阅读模式，正在打开打印对话框（可另存为 PDF）');
  setTimeout(() => {
    try { window.print(); } catch {}
  }, 350);
}

// ---------- 侧边栏 ----------
function setCollapsed(collapsed) {
  $('#sideBar').classList.toggle('collapsed', collapsed);
  $('#coolSideBar').hidden = !collapsed;
  localStorage.setItem('mdnotes.sidebar-collapsed', collapsed ? '1' : '0');
}

function switchTab(showFiles) {
  $('#fileListBar').hidden = !showFiles;
  $('#outlineBar').hidden = showFiles;
  // 两个 tab 按钮常显、高亮当前（原插件为单按钮切换，双按钮常显更不易误解）
  $('#tabFilesBtn').classList.toggle('active', showFiles);
  $('#tabOutlineBtn').classList.toggle('active', !showFiles);
  $('#addRootBtn').hidden = !showFiles;
}

// ---------- 初始化 ----------
function buildThemeSelects() {
  const codeSel = $('#codeThemeSel');
  codeSel.innerHTML = CODE_THEMES.map(t => `<option>${t}</option>`).join('');
  const contentSel = $('#contentThemeSel');
  contentSel.innerHTML = CONTENT_THEMES.map(t => `<option>${t}</option>`).join('');
}

function bindUI() {
  // 侧边栏
  $('#tabFilesBtn').addEventListener('click', () => switchTab(true));
  $('#tabOutlineBtn').addEventListener('click', () => switchTab(false));
  $('#collapseBtn').addEventListener('click', () => setCollapsed(true));
  $('#expandBtn').addEventListener('click', () => setCollapsed(false));
  $('#addRootBtn').addEventListener('click', () => {
    menuTarget = null;
    opCreate('dir');
  });

  // 文件树空白处右键 = 根目录操作
  $('#fileListBar').addEventListener('contextmenu', e => {
    if (e.target.closest('.treeRow')) return;
    e.preventDefault();
    showMenu(e, null);
  });

  // 右键菜单
  $('#rightMenu').addEventListener('click', e => {
    const btn = e.target.closest('.menuItem');
    if (!btn) return;
    const op = btn.dataset.op;
    hideMenu();
    if (op === 'createdir') opCreate('dir');
    else if (op === 'createfile') opCreate('file');
    else if (op === 'rename') opRename();
    else if (op === 'delfile') opDelete();
  });
  document.addEventListener('click', hideMenu);

  // 主区悬浮按钮
  $('#readToggle').addEventListener('click', toggleRead);
  $('#moreToggle').addEventListener('click', openDrawer);
  $('#drawerMask').addEventListener('click', closeDrawer);

  // 抽屉设置
  $('#fontSizeSel').addEventListener('change', e => {
    opts.fontSize = e.target.value;
    saveOptions();
  });
  $('#modeGroup').addEventListener('change', e => setEditMode(e.target.value));
  $('#codeThemeSel').addEventListener('change', e => {
    opts.codeTheme = e.target.value;
    saveOptions();
    applyTheme();
  });
  $('#contentThemeSel').addEventListener('change', e => {
    opts.contentTheme = e.target.value;
    saveOptions();
    applyTheme();
  });
  $('#lineNumberSwitch').addEventListener('change', e => {
    opts.lineNumber = e.target.checked;
    saveOptions();
    rebuildEditor();
  });
  $('#counterSwitch').addEventListener('change', e => {
    opts.counter = e.target.checked;
    saveOptions();
    updateCount();   // 计数器内部常开，开关只控制左下角显示，无需重建编辑器
  });
  $('#readModeSwitch').addEventListener('change', toggleRead);

  // 导出
  $('#exportMdBtn').addEventListener('click', exportMd);
  $('#exportPdfBtn').addEventListener('click', exportPdf);

  // 弹窗
  $('#modalOk').addEventListener('click', () => modalOnOk && modalOnOk());
  $('#modalCancel').addEventListener('click', () => modalOnCancel && modalOnCancel());
  $('#modalMask').addEventListener('click', e => {
    if (e.target.id === 'modalMask' && modalOnCancel) modalOnCancel();
  });
  $('#modalInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' && modalOnOk) modalOnOk();
  });

  // 全局按键
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      hideMenu();
      if (!$('#modalMask').hidden && modalOnCancel) modalOnCancel();
    }
  });

  // 大纲与字数统计定时刷新（对齐原插件 2s 节奏）
  setInterval(() => {
    if (!readMode && current) {
      refreshOutline();
      updateCount();
    }
  }, 2000);
}

async function init() {
  buildThemeSelects();
  bindUI();
  saveOptions();
  setCollapsed(localStorage.getItem('mdnotes.sidebar-collapsed') === '1');
  switchTab(true);
  await loadTree();
  createEditor('');
}

init();
