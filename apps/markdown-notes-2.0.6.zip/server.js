import express from 'express';
import { existsSync } from 'fs';
import { readFile, writeFile, readdir, mkdir, rm, rename } from 'fs/promises';
import { join, dirname, resolve, sep } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const NOTES_ROOT = join(DATA_DIR, 'notes');
const ASSETS_DIR = join(DATA_DIR, 'assets');

app.use(express.json({ limit: '25mb' }));
app.use('/assets', express.static(ASSETS_DIR));
app.use(express.static(join(__dirname, 'public')));

// ---------- 路径安全 ----------
// 所有路径都是相对 NOTES_ROOT 的相对路径，禁止目录穿越
function toAbs(rel) {
  if (typeof rel !== 'string' || !rel.trim() || rel.includes('\0')) return null;
  const abs = resolve(NOTES_ROOT, rel);
  if (abs !== NOTES_ROOT && !abs.startsWith(NOTES_ROOT + sep)) return null;
  return abs;
}

const ILLEGAL_CHARS = /[<>:"|?*\u0000-\u001f]/;
function validRel(rel) {
  if (typeof rel !== 'string' || !rel.trim()) return false;
  return rel.split(/[\\/]+/).every(s => s && s !== '.' && s !== '..' && !ILLEGAL_CHARS.test(s));
}

function bad(res, msg) {
  return res.status(400).json({ error: msg });
}

// ---------- 首装播种：对齐 uTools 原插件（默认记事本 + 使用必读） ----------
async function seedIfEmpty() {
  await mkdir(NOTES_ROOT, { recursive: true });
  const entries = await readdir(NOTES_ROOT);
  if (entries.length) return;
  const guide = await readFile(join(__dirname, 'guide.md'), 'utf8');
  await writeFile(join(NOTES_ROOT, '使用必读.md'), guide, 'utf8');
  await mkdir(join(NOTES_ROOT, '默认记事本'), { recursive: true });
}

// ---------- 文件树（目录在前，文件在后；跳过隐藏文件） ----------
async function buildTree(absDir, relBase) {
  let entries;
  try {
    entries = await readdir(absDir, { withFileTypes: true });
  } catch {
    return [];
  }
  const dirs = [], files = [];
  for (const e of entries) {
    if (e.name.startsWith('.')) continue;
    const rel = relBase ? relBase + '/' + e.name : e.name;
    if (e.isDirectory()) {
      dirs.push({ name: e.name, path: rel, leaf: false, children: await buildTree(join(absDir, e.name), rel) });
    } else if (e.isFile()) {
      files.push({ name: e.name, path: rel, leaf: true });
    }
  }
  return [...dirs, ...files];
}

app.get('/api/tree', async (req, res) => {
  try {
    await seedIfEmpty();
    res.json(await buildTree(NOTES_ROOT, ''));
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

// ---------- 读 / 写 ----------
app.get('/api/file', async (req, res) => {
  const abs = toAbs(req.query.path);
  if (!abs || abs === NOTES_ROOT) return bad(res, '非法路径');
  try {
    const content = await readFile(abs, 'utf8');
    res.json({ content });
  } catch {
    res.status(404).json({ error: '文件不存在' });
  }
});

app.post('/api/save', async (req, res) => {
  const { path: rel, content } = req.body || {};
  const abs = toAbs(rel);
  if (!abs || abs === NOTES_ROOT) return bad(res, '非法路径');
  try {
    await mkdir(dirname(abs), { recursive: true });
    // 原子写：先写临时文件再改名，避免写一半留下坏内容
    const tmp = abs + '.swaptmp';
    await writeFile(tmp, typeof content === 'string' ? content : '', 'utf8');
    await rename(tmp, abs);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

// ---------- 新建 / 重命名 / 删除 ----------
app.post('/api/mkdir', async (req, res) => {
  const rel = req.body?.path;
  if (!validRel(rel)) return bad(res, '名称含非法字符');
  const abs = toAbs(rel);
  if (!abs || abs === NOTES_ROOT) return bad(res, '非法路径');
  try {
    if (existsSync(abs)) {
      const st = (await readdir(abs).then(() => 'dir', () => 'file'));
      if (st === 'file') return bad(res, '同名文件已存在');
      return res.json({ ok: true }); // 同名目录已存在，幂等成功
    }
    await mkdir(abs, { recursive: true });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

app.post('/api/create', async (req, res) => {
  const rel = req.body?.path;
  if (!validRel(rel)) return bad(res, '名称含非法字符');
  const abs = toAbs(rel);
  if (!abs || abs === NOTES_ROOT) return bad(res, '非法路径');
  try {
    if (existsSync(abs)) return bad(res, '同名文件已存在');
    await mkdir(dirname(abs), { recursive: true });
    await writeFile(abs, '', 'utf8');
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

app.post('/api/rename', async (req, res) => {
  const { from, to } = req.body || {};
  if (!validRel(to)) return bad(res, '名称含非法字符');
  const absFrom = toAbs(from);
  const absTo = toAbs(to);
  if (!absFrom || absFrom === NOTES_ROOT || !absTo || absTo === NOTES_ROOT) return bad(res, '非法路径');
  try {
    if (!existsSync(absFrom)) return bad(res, '原文件不存在');
    if (existsSync(absTo)) return bad(res, '目标名称已存在');
    await mkdir(dirname(absTo), { recursive: true });
    await rename(absFrom, absTo);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

app.post('/api/delete', async (req, res) => {
  const abs = toAbs(req.body?.path);
  if (!abs || abs === NOTES_ROOT) return bad(res, '非法路径');
  try {
    if (!existsSync(abs)) return bad(res, '文件不存在');
    await rm(abs, { recursive: true });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

// ---------- 图片上传（前端传 dataURL，存 DATA_DIR/assets） ----------
app.post('/api/upload', async (req, res) => {
  const { name, data } = req.body || {};
  const m = typeof data === 'string' ? /^data:image\/(\w+);base64,(.+)$/.exec(data) : null;
  if (!m) return bad(res, '图片数据格式错误');
  try {
    await mkdir(ASSETS_DIR, { recursive: true });
    const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
    const base = String(name || 'image').replace(ILLEGAL_CHARS, '').replace(/[\\/]/g, '').slice(0, 50) || 'image';
    const file = `${base}-${Date.now()}.${ext}`;
    await writeFile(join(ASSETS_DIR, file), Buffer.from(m[2], 'base64'));
    res.json({ url: `/assets/${file}` });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`markdown-notes running on ${port}`));
