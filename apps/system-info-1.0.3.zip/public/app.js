/* 本机信息 —— 全部数据都在浏览器侧采集（应用 iframe 内能拿到的就这些，不做任何服务端探测） */

const $ = (s, r = document) => r.querySelector(s);

const safe = async (fn) => {
  try {
    return { ok: true, v: await fn() };
  } catch (e) {
    return { ok: false, e: (e && e.name ? e.name + ': ' : '') + ((e && e.message) || String(e)) };
  }
};
const u = (r, fallback = null) => (r && r.ok ? r.v : fallback);

const fmtBytes = (n) => {
  if (!Number.isFinite(n)) return '—';
  const gb = n / 1073741824;
  if (gb >= 1) return +gb.toFixed(2) + ' GB';
  return +(n / 1048576).toFixed(1) + ' MB';
};
const fmtNum = (n) => (Number.isFinite(n) ? n.toLocaleString('zh-CN') : '—');
const isWidget = () => !!document.body.dataset.widget;

/* ---------------- 显卡串解析 ---------------- */
// 形如 "ANGLE (AMD, AMD FirePro D500 (FireGL V) (0x0000679E) Direct3D11 vs_5_0 ps_5_0, D3D11)"
function parseRenderer(s) {
  if (!s) return { raw: '—', vendor: '', model: '', backend: '' };
  const raw = String(s);
  const backends = ['Direct3D11', 'Direct3D12', 'Direct3D9', 'OpenGL', 'Vulkan', 'Metal', 'D3D11', 'D3D12'];
  const backend = backends.find((b) => raw.includes(b)) || '';
  let vendor = '';
  let model = '';
  const m = raw.match(/^ANGLE \(([^,]+),\s*([\s\S]+)\)$/);
  if (m) {
    vendor = m[1].trim();
    model = m[2];
  } else {
    model = raw;
  }
  // 去掉驱动括号与后端串尾巴："(FireGL V) (0x0000679E) Direct3D11 vs_5_0 ps_5_0, D3D11"
  model = model
    .replace(/\s*\([^()]*\)/g, ' ')
    .replace(new RegExp(`\\s*(?:${backends.join('|')})[\\s\\S]*$`), ' ')
    .replace(/[,\s]+$/, '')
    .replace(/\s+/g, ' ')
    .trim();
  return { raw, vendor, model: model || raw, backend };
}
const isSoftwareGL = (s) => /swiftshader|software|llvmpipe|basic render/i.test(String(s || ''));

/* ---------------- 采集 ---------------- */
async function collect(quick = false) {
  const d = { at: Date.now(), quick };

  d.cores = navigator.hardwareConcurrency ?? null;
  d.deviceMemory = navigator.deviceMemory ?? null;
  d.jsHeap = performance.memory
    ? {
        limit: performance.memory.jsHeapSizeLimit,
        total: performance.memory.totalJSHeapSize,
        used: performance.memory.usedJSHeapSize,
      }
    : null;

  d.ua = navigator.userAgent;
  d.uaCH = u(
    await safe(async () => {
      if (!navigator.userAgentData) return null;
      const hi = await navigator.userAgentData.getHighEntropyValues([
        'architecture', 'bitness', 'model', 'platformVersion', 'uaFullVersion', 'fullVersionList', 'wow64', 'formFactors',
      ]);
      return { ...hi, mobile: navigator.userAgentData.mobile };
    })
  );

  d.screen = {
    w: screen.width, h: screen.height,
    aw: screen.availWidth, ah: screen.availHeight,
    dpr: devicePixelRatio,
    phys: [Math.round(screen.width * devicePixelRatio), Math.round(screen.height * devicePixelRatio)],
    colorDepth: screen.colorDepth,
    isExtended: screen.isExtended ?? null,
    orientation: screen.orientation ? screen.orientation.type : null,
    inner: [innerWidth, innerHeight],
  };
  d.mq = {};
  for (const q of ['(pointer: fine)', '(pointer: coarse)', '(hover: hover)', '(any-pointer: fine)',
    '(dynamic-range: high)', '(color-gamut: p3)', '(color-gamut: rec2020)', '(monochrome)',
    '(prefers-color-scheme: dark)', '(prefers-contrast: more)', '(forced-colors: active)',
    '(prefers-reduced-motion: reduce)']) {
    try { d.mq[q] = matchMedia(q).matches; } catch (e) { d.mq[q] = null; }
  }

  // 显卡：WebGL 的 ANGLE 报告串是目前唯一能读到真实 GPU 型号的常规途径
  d.gl = u(
    await safe(async () => {
      const rd = (gl, isGL2) => {
        if (!gl) return null;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const P = (k) => { try { return gl.getParameter(gl[k]); } catch (e) { return null; } };
        const out = {
          version: gl.getParameter(gl.VERSION),
          glsl: gl.getParameter(gl.SHADING_LANGUAGE_VERSION),
          renderer: gl.getParameter(gl.RENDERER),
          extensions: (gl.getSupportedExtensions() || []).length,
        };
        if (ext) {
          out.unmaskedVendor = gl.getParameter(ext.UNMASKED_VENDOR_WEBGL);
          out.unmaskedRenderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL);
        }
        // 这些能力枚举只在 WebGL2 语境下有效，对 WebGL1 调用会打 INVALID_ENUM 警告
        out.limits = isGL2
          ? {
              tex: P('MAX_TEXTURE_SIZE'),
              tex3d: P('MAX_3D_TEXTURE_SIZE'),
              layers: P('MAX_ARRAY_TEXTURE_LAYERS'),
              samples: P('MAX_SAMPLES'),
              viewport: P('MAX_VIEWPORT_DIMS'),
              uniforms: P('MAX_VERTEX_UNIFORM_VECTORS'),
              units: P('MAX_COMBINED_TEXTURE_IMAGE_UNITS'),
            }
          : null;
        return out;
      };
      const c1 = document.createElement('canvas');
      const c2 = document.createElement('canvas');
      const g1 = c1.getContext('webgl') || c1.getContext('experimental-webgl');
      const g2 = c2.getContext('webgl2');
      return { webgl1: rd(g1, false), webgl2: rd(g2, true) };
    })
  );
  d.gpuCard = parseRenderer(
    (d.gl && d.gl.webgl2 && d.gl.webgl2.unmaskedRenderer) ||
      (d.gl && d.gl.webgl1 && d.gl.webgl1.unmaskedRenderer) ||
      (d.gl && d.gl.webgl1 && d.gl.webgl1.renderer)
  );

  if (quick) return d;

  // WebGPU：只能拿到特性/上限，Chrome 152 实测 adapter.info 为空对象
  d.webgpu = u(
    await safe(async () => {
      if (!navigator.gpu) return null;
      const ad = await navigator.gpu.requestAdapter();
      if (!ad) return null;
      return {
        info: ad.info ? JSON.parse(JSON.stringify(ad.info)) : {},
        fallback: !!ad.isFallbackAdapter,
        features: [...ad.features],
        maxBuffer: ad.limits ? Number(ad.limits.maxBufferSize) : null,
        maxTex2D: ad.limits ? Number(ad.limits.maxTextureDimension2D) : null,
      };
    })
  );

  d.storage = u(
    await safe(async () => {
      const e = await navigator.storage.estimate();
      return {
        quota: e.quota,
        usage: e.usage,
        persisted: await navigator.storage.persisted(),
        opfs: typeof navigator.storage.getDirectory === 'function',
      };
    })
  );

  d.battery = u(
    await safe(async () => {
      if (!navigator.getBattery) return null;
      const b = await navigator.getBattery();
      return { level: b.level, charging: b.charging, chargingTime: b.chargingTime, dischargingTime: b.dischargingTime };
    })
  );

  d.net = {
    onLine: navigator.onLine,
    c: navigator.connection
      ? {
          effectiveType: navigator.connection.effectiveType,
          type: navigator.connection.type ?? null,
          downlink: navigator.connection.downlink,
          rtt: navigator.connection.rtt,
          saveData: navigator.connection.saveData,
        }
      : null,
  };

  d.audio = u(
    await safe(async () => {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      const ctx = new AC();
      const v = {
        sampleRate: ctx.sampleRate,
        baseLatency: ctx.baseLatency,
        outputLatency: ctx.outputLatency,
        maxChannels: ctx.destination.maxChannelCount,
      };
      await ctx.close();
      return v;
    })
  );

  d.devices = u(
    await safe(async () => {
      if (!navigator.mediaDevices) return null;
      const list = await navigator.mediaDevices.enumerateDevices();
      const by = (k) => list.filter((x) => x.kind === k);
      return {
        counts: {
          audioinput: by('audioinput').length,
          videoinput: by('videoinput').length,
          audiooutput: by('audiooutput').length,
        },
        named: list.filter((x) => x.label).map((x) => x.kind + ': ' + x.label),
        total: list.length,
      };
    })
  );

  d.input = {
    gamepads: u(
      await safe(async () => {
        const g = navigator.getGamepads ? [...navigator.getGamepads()] : [];
        return { slots: g.length, connected: g.filter(Boolean).map((x) => x.id) };
      })
    ),
    maxTouchPoints: navigator.maxTouchPoints ?? 0,
  };

  d.codecs = u(
    await safe(async () => {
      const out = {};
      if (!window.MediaSource) return null;
      for (const [k, t] of Object.entries({
        H264: 'video/mp4; codecs="avc1.640028"',
        HEVC: 'video/mp4; codecs="hvc1.1.6.L120.90"',
        AV1: 'video/mp4; codecs="av01.0.05M.08"',
        VP9: 'video/webm; codecs="vp9"',
        AAC: 'audio/mp4; codecs="mp4a.40.2"',
      })) out[k] = MediaSource.isTypeSupported(t);
      return out;
    })
  );

  d.wasm = u(
    await safe(async () => {
      const simd = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11]);
      const threads = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 0, 0, 11]);
      return {
        simd: WebAssembly.validate(simd),
        threads: WebAssembly.validate(threads),
        sab: typeof SharedArrayBuffer === 'function',
        isolated: !!self.crossOriginIsolated,
        webcodecs: typeof VideoDecoder === 'function',
      };
    })
  );

  d.intl = u(
    await safe(async () => {
      const o = Intl.DateTimeFormat().resolvedOptions();
      return { timeZone: o.timeZone, locale: o.locale, calendar: o.calendar, hourCycle: o.hourCycle };
    })
  );

  d.node = u(await safe(async () => {
    const r = await fetch('/api/node', { cache: 'no-store' });
    if (!r.ok) return null;
    return await r.json();
  }));

  return d;
}

/* ---------------- 视图组装 ---------------- */
function browserLabel(ch) {
  if (!ch || !ch.fullVersionList) return uaFallbackBrowser();
  const l = ch.fullVersionList.filter((b) => !/not.?a.?brand|chromium/i.test(b.brand));
  const b = (l.length ? l : ch.fullVersionList)[0];
  return b ? b.brand + ' ' + b.version : uaFallbackBrowser();
}
function uaFallbackBrowser() {
  const m = navigator.userAgent.match(/(Edg|Chrome|Firefox|Safari|OPR)\/([\d.]+)/);
  return m ? m[1] + ' ' + m[2] : '未知浏览器';
}
// 小组件里用的短名："Chrome 152"
function browserShort(ch) {
  const full = browserLabel(ch);
  const m = full.match(/^(.+?)\s+([\d.]+)$/);
  if (!m) return full;
  const brand = m[1].replace(/^(Google|Microsoft|Apple|Mozilla|Tencent)\s+/i, '');
  return brand + ' ' + m[2].split('.')[0];
}
const onOff = (v, on = '支持', off = '不支持') =>
  v === true ? { t: on, c: 'ok' } : v === false ? { t: off, c: 'no' } : { t: '未测到', c: 'no' };

function buildSections(d) {
  // 第三个参数只放行"行"自己的类（big / mono）；'badge' 是"值"级样式，
  // 值传 { t, c } 对象时 rowHtml 会自动给值加 badge 类。若把 'badge' 写到行上，
  // 整行会变成 inline-block 胶囊 → 两行挤在同一行并画出多余外框（1.0.0 的 bug），这里统一拦掉。
  const R = (k, v, cls) => ({ k, v, cls: cls === 'badge' ? '' : cls });
  const ch = d.uaCH;
  const gl = d.gl || {};
  const g2 = gl.webgl2 || {};
  const gc = d.gpuCard || {};
  const soft = isSoftwareGL(gc.raw);

  const S = [];

  // 1) 概览
  S.push({
    id: 'overview',
    name: '概览',
    icon: 'grid',
    sub: '这台机器的关键指标，全部由浏览器实测',
    hero: [
      { label: '逻辑核心', value: d.cores != null ? d.cores + ' 线程' : '—', sub: 'navigator.hardwareConcurrency', w: 1 },
      { label: '内存档位', value: d.deviceMemory != null ? d.deviceMemory + ' GB' : '—', sub: '浏览器分档值', w: 1 },
      { label: '显卡', value: gc.model || '—', wv: (gc.model || '—').replace(/^(AMD|Intel|NVIDIA|Apple|Qualcomm|ARM|Microsoft)\s+/i, ''), sub: gc.backend || '', w: 1 },
      { label: '屏幕', value: d.screen.phys[0] + '×' + d.screen.phys[1], sub: '缩放 ' + d.screen.dpr * 100 + '%', w: 1 },
      { label: '系统', value: ch ? ch.platform + ' ' + ch.platformVersion : '—', wv: ch ? ch.platform : '—', sub: 'UA-CH 上报', w: 1 },
      { label: '浏览器', value: browserLabel(ch), wv: browserShort(ch), sub: '内核 ' + (navigator.userAgent.match(/Chrome\/(\d+)/) || [, '—'])[1], w: 1 },
    ],
    cards: [
      {
        title: '一句话摘要',
        rows: [
          R('处理器', d.cores != null ? d.cores + ' 个逻辑核心' : '—'),
          R('内存', d.deviceMemory != null ? '约 ' + d.deviceMemory + ' GB（分档）' : '—'),
          R('独立显卡', gc.model || '—', 'big'),
          R('图形后端', gc.backend || '—'),
          R('渲染方式', soft ? { t: '软件渲染（可能无独显驱动）', c: 'warn' } : { t: '硬件加速', c: 'ok' }, 'badge'),
          R('屏幕', d.screen.phys[0] + '×' + d.screen.phys[1] + ' @ ' + d.screen.dpr + 'x'),
          R('外接显示器', { t: d.screen.isExtended ? '检测到多屏' : '单屏', c: 'badge' }, 'badge'),
          R('电源', d.battery ? (d.battery.charging ? '接电中 · ' + Math.round(d.battery.level * 100) + '%' : '电池供电 · ' + Math.round(d.battery.level * 100) + '%') : '—'),
        ],
      },
      {
        title: '本次扫描',
        rows: [
          R('扫描时间', new Date(d.at).toLocaleString('zh-CN')),
          R('运行环境', isWidget() ? '桌面小组件' : '应用窗口'),
          R('数据来源', '浏览器 API + 容器内 Node'),
          R('本地存储', '仅 UI 偏好'),
        ],
      },
    ],
  });

  // 小组件只要概览那一屏，后面几组依赖完整采集的数据，不能碰
  if (d.quick) return S;

  // 2) 处理器与内存
  S.push({
    id: 'cpu',
    name: '处理器与内存',
    icon: 'cpu',
    sub: '浏览器对 CPU / 内存只开放两个粗粒度值',
    cards: [
      {
        title: '处理器',
        note: '浏览器不暴露 CPU 型号与主频，只能拿到并发上限。',
        rows: [
          R('逻辑核心数', d.cores != null ? d.cores : '—', 'big'),
          R('架构', ch ? ch.architecture + (ch.wow64 ? ' (WOW64)' : '') : '—'),
          R('位数', ch ? ch.bitness + ' 位' : '—'),
          R('设备形态', ch && ch.formFactors ? ch.formFactors.join(', ') : '—'),
          R('是否移动端', ch ? { t: ch.mobile ? '是' : '否', c: ch.mobile ? 'warn' : 'ok' } : '—', 'badge'),
          R('CPU 型号 / 主频 / 温度', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
      {
        title: '内存',
        note: 'deviceMemory 是分档值（0.25/0.5/1/2/4/8…，上限 32），不是精确容量。',
        rows: [
          R('设备内存档位', d.deviceMemory != null ? d.deviceMemory + ' GB' : '—', 'big'),
          R('JS 堆上限', d.jsHeap ? fmtBytes(d.jsHeap.limit) : '—', 'big'),
          R('JS 堆已用', d.jsHeap ? fmtBytes(d.jsHeap.used) + ' / ' + fmtBytes(d.jsHeap.total) : '—'),
          R('堆占用率', d.jsHeap && d.jsHeap.total ? Math.round((d.jsHeap.used / d.jsHeap.total) * 100) + '%' : '—'),
          R('物理内存条型号 / 频率', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
    ],
  });

  // 3) 显卡与显示
  S.push({
    id: 'gpu',
    name: '显卡与显示',
    icon: 'monitor',
    sub: '显卡型号是浏览器能读到的、信息量最大的硬件标识',
    cards: [
      {
        title: '显卡',
        note: '来源：WebGL 的 ANGLE 报告串（浏览器为兼容性放开的字段）。',
        rows: [
          R('型号', gc.model || '—', 'big'),
          R('厂商', gc.vendor || (g2.unmaskedVendor ? String(g2.unmaskedVendor).replace(/^Google Inc\.\s*\(|\)$/g, '') : '—')),
          R('渲染后端', gc.backend || '—'),
          R('原始串', gc.raw || '—', 'mono'),
          R('硬件 / 软件渲染', { t: soft ? '软件渲染' : '硬件加速', c: soft ? 'warn' : 'ok' }, 'badge'),
        ],
      },
      {
        title: '图形能力',
        rows: [
          R('WebGL 1.0', { t: gl.webgl1 ? '可用' : '不可用', c: gl.webgl1 ? 'ok' : 'no' }, 'badge'),
          R('WebGL 2.0', { t: g2.version ? '可用' : '不可用', c: g2.version ? 'ok' : 'no' }, 'badge'),
          R('WebGL 扩展数', g2.extensions ?? '—'),
          R('最大纹理尺寸', g2.limits ? g2.limits.tex + ' px' : '—'),
          R('最大 3D 纹理', g2.limits && g2.limits.tex3d ? g2.limits.tex3d + ' px' : '—'),
          R('纹理数组层数', g2.limits ? g2.limits.layers : '—'),
          R('最大 MSAA 采样', g2.limits ? g2.limits.samples + 'x' : '—'),
          R('WebGPU', d.webgpu ? { t: '可用 · ' + d.webgpu.features.length + ' 项特性', c: 'ok' } : { t: '不可用', c: 'no' }, 'badge'),
          R('WebGPU 单缓冲上限', d.webgpu && d.webgpu.maxBuffer ? fmtBytes(d.webgpu.maxBuffer) : '—'),
        ],
      },
      {
        title: '显示',
        note: '物理分辨率 = CSS 像素 × devicePixelRatio，即 Windows 显示缩放的来源。',
        rows: [
          R('物理分辨率', d.screen.phys[0] + ' × ' + d.screen.phys[1], 'big'),
          R('逻辑分辨率', d.screen.w + ' × ' + d.screen.h),
          R('显示缩放', d.screen.dpr * 100 + '%（DPR ' + d.screen.dpr + '）'),
          R('可用工作区', d.screen.aw + ' × ' + d.screen.ah),
          R('窗口视口', d.screen.inner[0] + ' × ' + d.screen.inner[1]),
          R('色深', d.screen.colorDepth + ' 位'),
          R('多显示器', { t: d.screen.isExtended === null ? '未提供' : d.screen.isExtended ? '是' : '否', c: 'badge' }, 'badge'),
          R('HDR 高动态范围', onOff(d.mq['(dynamic-range: high)']), 'badge'),
          R('P3 广色域', onOff(d.mq['(color-gamut: p3)']), 'badge'),
          R('刷新率 / 显示器型号', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
    ],
  });

  // 4) 系统与浏览器
  S.push({
    id: 'system',
    name: '系统与浏览器',
    icon: 'info',
    sub: '操作系统与浏览器版本（UA-CH 高熵值）',
    cards: [
      {
        title: '操作系统',
        rows: [
          R('平台', ch ? ch.platform : '—', 'big'),
          R('平台版本', ch ? ch.platformVersion : '—'),
          R('设备型号', ch && ch.model ? ch.model : '（桌面端不提供）', 'mono'),
          R('语言', navigator.language + (navigator.languages ? ' · ' + navigator.languages.join(', ') : '')),
          R('时区', d.intl ? d.intl.timeZone : '—'),
          R('区域设置', d.intl ? d.intl.locale + ' · ' + d.intl.calendar + ' 历' : '—'),
          R('Windows 版本号 / 激活状态', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
      {
        title: '浏览器',
        rows: [
          R('名称与版本', browserLabel(ch), 'big'),
          R('完整版本', ch ? ch.uaFullVersion : '—', 'mono'),
          R('UA 全文', d.ua, 'mono'),
        ],
        tags: ch && ch.brands ? ch.brands.map((b) => b.brand + '/' + b.version) : [],
      },
    ],
  });

  // 5) 存储
  S.push({
    id: 'storage',
    name: '存储',
    icon: 'disk',
    sub: '浏览器只给"本站能占多少"，不给磁盘真实容量',
    cards: [
      {
        title: '站点存储配额',
        note: '配额是浏览器分给本站源的上限（Chrome 封顶 10 GB），不等于磁盘容量或剩余空间。',
        rows: [
          R('配额上限', d.storage ? fmtBytes(d.storage.quota) : '—', 'big'),
          R('已使用', d.storage ? fmtBytes(d.storage.usage) : '—'),
          R('使用率', d.storage && d.storage.quota ? ((d.storage.usage / d.storage.quota) * 100).toFixed(2) + '%' : '—'),
          R('已申请持久化', d.storage ? { t: d.storage.persisted ? '是' : '否', c: d.storage.persisted ? 'ok' : 'badge' } : '—', 'badge'),
          R('OPFS 私有文件系统', onOff(d.storage && d.storage.opfs), 'badge'),
          R('磁盘型号 / 容量 / 剩余空间', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
    ],
  });

  // 6) 网络与电源
  const c = d.net && d.net.c;
  S.push({
    id: 'net',
    name: '网络与电源',
    icon: 'wifi',
    sub: '浏览器给出的粗粒度网络与电源状态',
    cards: [
      {
        title: '网络',
        note: '有效连接类型与下行/延迟是浏览器按历史请求估算的粗值，不是测速结果。',
        rows: [
          R('在线状态', { t: d.net.onLine ? '在线' : '离线', c: d.net.onLine ? 'ok' : 'warn' }, 'badge'),
          R('有效连接类型', c ? c.effectiveType : '—', 'big'),
          R('下行估算', c && Number.isFinite(c.downlink) ? c.downlink + ' Mb/s' : '—'),
          R('往返延迟估算', c && Number.isFinite(c.rtt) ? c.rtt + ' ms' : '—'),
          R('省流模式', c ? (c.saveData ? '已开启' : '关闭') : '—'),
          R('网卡型号 / MAC / 局域网 IP', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
      {
        title: '电源',
        note: '电池状态在台式机上通常恒为"接电中 · 100%"。',
        rows: [
          R('电量', d.battery ? Math.round(d.battery.level * 100) + '%' : '—（不支持）', 'big'),
          R('充电状态', d.battery ? (d.battery.charging ? '接电中' : '电池供电') : '—'),
          R('充满剩余', d.battery && d.battery.chargingTime > 0 && Number.isFinite(d.battery.chargingTime) ? Math.round(d.battery.chargingTime / 60) + ' 分钟' : '—'),
          R('续航剩余', d.battery && d.battery.dischargingTime > 0 && Number.isFinite(d.battery.dischargingTime) ? Math.round(d.battery.dischargingTime / 60) + ' 分钟' : '—'),
        ],
      },
      {
        title: '音频硬件',
        rows: [
          R('采样率', d.audio ? d.audio.sampleRate + ' Hz' : '—', 'big'),
          R('输出声道数', d.audio ? d.audio.maxChannels : '—'),
          R('基础输出延迟', d.audio && Number.isFinite(d.audio.baseLatency) ? (d.audio.baseLatency * 1000).toFixed(1) + ' ms' : '—'),
          R('声卡型号', { t: '浏览器不开放', c: 'no' }, 'badge'),
        ],
      },
    ],
  });

  // 7) 媒体与输入
  const dev = d.devices;
  S.push({
    id: 'media',
    name: '媒体与输入',
    icon: 'camera',
    sub: '外设与编解码能力',
    cards: [
      {
        title: '摄像头 / 麦克风',
        note: '设备名称需要授权才可见；JSOS 应用 iframe 被权限策略禁止授权，因此标签恒为空。',
        rows: [
          R('麦克风数量', dev ? dev.counts.audioinput : '—'),
          R('摄像头数量', dev ? dev.counts.videoinput : '—'),
          R('音频输出数量', dev ? dev.counts.audiooutput : '—'),
          R('设备名称', dev && dev.named.length ? dev.named.join(' / ') : { t: '未授权（标签为空）', c: 'no' }, dev && dev.named.length ? 'mono' : 'badge'),
          R('摄像头型号 / 分辨率', { t: '需授权，应用内被禁止', c: 'no' }, 'badge'),
        ],
      },
      {
        title: '输入设备',
        rows: [
          R('精确指针（鼠标/笔）', onOff(d.mq['(pointer: fine)']), 'badge'),
          R('粗指针（触摸）', onOff(d.mq['(pointer: coarse)']), 'badge'),
          R('支持悬停', onOff(d.mq['(hover: hover)']), 'badge'),
          R('触摸点数', d.input.maxTouchPoints),
          R('手柄插槽', d.input.gamepads ? d.input.gamepads.slots : '—'),
          R('已连接手柄', d.input.gamepads && d.input.gamepads.connected.length ? d.input.gamepads.connected.join(' / ') : '无（插上后按一下键才会出现）'),
          R('键盘布局', { t: '应用 iframe 内被权限策略禁止', c: 'no' }, 'badge'),
        ],
      },
      {
        title: '视频 / 音频解码',
        note: '决定这台机器能硬解哪些格式（HEVC 常见于 4K 片源）。',
        rows: d.codecs
          ? Object.entries(d.codecs).map(([k, v]) =>
              R(k, v ? { t: '支持', c: 'ok' } : { t: '不支持', c: 'no' }, 'badge'))
          : [R('编解码查询', '不支持', '')],
      },
    ],
  });

  // 8) 能力探测
  const w = d.wasm || {};
  S.push({
    id: 'caps',
    name: '能力探测',
    icon: 'zap',
    sub: '是否具备跑 JSOS 容器 / 本地算力的条件',
    cards: [
      {
        title: 'WebAssembly 与隔离',
        note: 'SharedArrayBuffer 需要跨源隔离，是 WebContainer 启动的前提。',
        rows: [
          R('WASM SIMD', onOff(w.simd), 'badge'),
          R('WASM 线程', onOff(w.threads), 'badge'),
          R('SharedArrayBuffer', onOff(w.sab), 'badge'),
          R('跨源隔离', onOff(w.isolated), 'badge'),
          R('WebCodecs', onOff(w.webcodecs), 'badge'),
        ],
      },
      {
        title: '容器内 Node 运行时',
        note: '来自容器内 Node 的 os 模块（WebContainer 模拟值），仅供参照，不等于真机硬件。',
        rows: d.node
          ? [
              R('platform / arch', d.node.platform + ' / ' + d.node.arch),
              R('Node 版本', d.node.nodeVersion),
              R('os.release()', d.node.release || '—', 'mono'),
              R('os.cpus().length', d.node.cpuCount),
              R('os.cpus()[0].model', d.node.cpuModel || '—', 'mono'),
              R('os.totalmem()', d.node.totalMem ? fmtBytes(d.node.totalMem) : '—'),
              R('os.freemem()', d.node.freeMem ? fmtBytes(d.node.freeMem) : '—'),
              R('os.hostname()', d.node.hostname || '—', 'mono'),
              R('os.uptime()', d.node.uptimeSec != null ? Math.round(d.node.uptimeSec / 60) + ' 分钟' : '—'),
              R('网卡接口名', d.node.networkInterfaces && d.node.networkInterfaces.length ? d.node.networkInterfaces.join(', ') : '—', 'mono'),
            ]
          : [R('接口不可用', '—')],
      },
    ],
  });

  // 9) 拿不到的
  S.push({
    id: 'limit',
    name: '无法获取',
    icon: 'lock',
    sub: '浏览器的安全边界，不是本应用的问题',
    cards: [
      {
        warn: true,
        title: '以下信息在浏览器里永远读不到',
        note: '原因：同源策略 + 反指纹追踪策略。任何"网页版硬件检测"都拿不到这些，除非在本机另外跑一个助手进程。',
        rows: [
          R('CPU 型号 / 主频 / 缓存', { t: '不可获取', c: 'no' }, 'badge'),
          R('CPU 温度 / 风扇转速', { t: '不可获取', c: 'no' }, 'badge'),
          R('主板型号 / BIOS 版本', { t: '不可获取', c: 'no' }, 'badge'),
          R('内存条型号 / 频率 / 插槽', { t: '不可获取', c: 'no' }, 'badge'),
          R('硬盘型号 / 真实容量 / 剩余空间', { t: '不可获取', c: 'no' }, 'badge'),
          R('SMART / 磁盘健康', { t: '不可获取', c: 'no' }, 'badge'),
          R('主机名 / 用户名 / 序列号', { t: '不可获取', c: 'no' }, 'badge'),
          R('网卡 MAC / 局域网 IP', { t: '不可获取', c: 'no' }, 'badge'),
          R('Windows 版本号 / 激活状态', { t: '不可获取', c: 'no' }, 'badge'),
          R('当前运行进程 / 开机时长', { t: '不可获取', c: 'no' }, 'badge'),
        ],
      },
      {
        warn: true,
        title: 'JSOS 应用内额外被禁的能力',
        note: '应用窗口是跨源 iframe 且未声明 allow，WebUSB / 蓝牙 / 摄像头 / 定位等都被权限策略关闭（实测结果）。',
        rows: [
          R('WebUSB / WebSerial / WebHID', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('蓝牙', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('摄像头 / 麦克风（授权）', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('地理位置', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('剪贴板读写 API', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('多屏详情 / 全屏 API', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('MIDI', { t: '被权限策略禁止', c: 'no' }, 'badge'),
          R('游戏手柄', { t: '可用', c: 'ok' }, 'badge'),
          R('WebGL / WebGPU 显卡信息', { t: '可用', c: 'ok' }, 'badge'),
          R('CPU 核心数 / 内存档位', { t: '可用', c: 'ok' }, 'badge'),
        ],
      },
    ],
  });

  return S;
}

/* ---------------- 图标 ---------------- */
const ICONS = {
  grid: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  monitor: '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  disk: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  wifi: '<path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/>',
  camera: '<rect x="3" y="7" width="18" height="12" rx="2"/><circle cx="12" cy="13" r="3.2"/><path d="M8 7l1.5-2.5h5L16 7"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
};
const svgIcon = (n, cls) =>
  `<svg class="${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${
    ICONS[n] || ICONS.info
  }</svg>`;

/* ---------------- 渲染 ---------------- */
const esc = (s) =>
  String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function rowHtml(r) {
  let v = r.v;
  let extra = '';
  if (v && typeof v === 'object' && 't' in v) {
    extra = ' badge ' + (v.c === 'badge' ? '' : v.c || '');
    v = v.t;
  }
  return `<div class="row ${r.cls || ''}"><span class="k">${esc(r.k)}</span><span class="v${extra}">${esc(v === null || v === undefined ? '—' : v)}</span></div>`;
}
function cardHtml(c) {
  const tags = c.tags && c.tags.length
    ? `<div class="taglist">${c.tags.map((t) => `<span class="badge">${esc(t)}</span>`).join('')}</div>`
    : '';
  return `<div class="card${c.warn ? ' warn' : ''}">
    <h3><span class="tick"></span>${esc(c.title)}</h3>
    ${c.note ? `<p class="note">${esc(c.note)}</p>` : ''}
    <div class="rows">${c.rows.map(rowHtml).join('')}</div>
    ${tags}
  </div>`;
}
function viewHtml(s) {
  const cells = s.hero ? (isWidget() ? s.hero.filter((c) => c.w) : s.hero) : [];
  const hero = cells.length
    ? `<div class="hero">${cells
        .map((c) => `<div class="cell"><div class="label">${esc(c.label)}</div><div class="value">${esc(isWidget() && c.wv ? c.wv : c.value)}</div>${c.sub ? `<div class="sub">${esc(c.sub)}</div>` : ''}</div>`)
        .join('')}</div>`
    : '';
  // 小组件只渲染 4 格概览，卡片压根不入 DOM（不给 CSS 留隐藏的活干）
  const cards = isWidget() ? '' : `<div class="cards">${s.cards.map(cardHtml).join('')}</div>`;
  return `<div class="view" data-view="${s.id}">${hero}${cards}</div>`;
}

let STATE = { sections: [], active: 'overview', data: null };

function renderNav() {
  $('#nav').innerHTML = STATE.sections
    .map(
      (s) => `<button class="nav-item${s.id === STATE.active ? ' active' : ''}" data-nav="${s.id}" type="button" title="${esc(s.name)}">
        ${svgIcon(s.icon, 'nav-icon')}
        <span class="nav-label">${esc(s.name)}</span>
        <span class="nav-count">${countRows(s)}</span>
      </button>`
    )
    .join('');
  $('#nav')
    .querySelectorAll('[data-nav]')
    .forEach((b) => b.addEventListener('click', () => setActive(b.dataset.nav)));
}
const countRows = (s) => s.cards.reduce((n, c) => n + c.rows.length, 0);

function renderViews() {
  $('#views').innerHTML = STATE.sections.map(viewHtml).join('');
  setActive(STATE.active, true);
}

function setActive(id, silent) {
  STATE.active = id;
  const s = STATE.sections.find((x) => x.id === id) || STATE.sections[0];
  $('#views').querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.dataset.view === s.id));
  $('#nav').querySelectorAll('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.nav === s.id));
  if (!silent) {
    $('#page-title').textContent = s.name;
    $('#page-sub').textContent = s.sub || '';
  }
  const v = $('#views').querySelector('.view.active');
  if (v) v.scrollTop = 0;
  const sc = $('#views');
  if (sc) sc.scrollTop = 0;
}

function renderSideFoot(d) {
  const gl = (d.gl && d.gl.webgl2) || (d.gl && d.gl.webgl1) || {};
  $('#side-foot').innerHTML = `核心 ${d.cores ?? '—'} · 内存档 ${d.deviceMemory ?? '—'}GB<br>
    扫描于 ${new Date(d.at).toLocaleTimeString('zh-CN')}<br>
    ${esc(gl.version ? String(gl.version).replace(/\s*\(.*\)/, '') : '')}`;
}

/* ---------------- 复制（应用 iframe 内 clipboard API 被禁，用 execCommand 兜底） ---------------- */
async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) {
    /* 权限策略禁止 → 走兜底 */
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch (e) {
    return false;
  }
}

function toast(msg) {
  let t = $('.toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 1800);
}

/* ---------------- 扫描 ---------------- */
async function scan() {
  const line = $('#scanline');
  const btn = $('#btn-rescan');
  if (line) line.hidden = false;
  if (btn) btn.disabled = true;
  const t0 = performance.now();
  try {
    const quick = isWidget();
    const d = await collect(quick);
    STATE.data = d;
    STATE.sections = buildSections(d);
    if (!quick) renderNav();
    renderViews();
    renderSideFoot(d);
    if (line) {
      $('#scan-text').textContent = `扫描完成 · ${Math.round(performance.now() - t0)} ms`;
      setTimeout(() => {
        if (line) line.hidden = true;
      }, 1200);
    }
  } catch (e) {
    if (line) $('#scan-text').textContent = '扫描失败：' + ((e && e.message) || e);
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------------- 主题 / 初始化 ---------------- */
function applyTheme(t) {
  document.documentElement.classList.toggle('dark', t === 'dark');
}
function initTheme() {
  const mql = matchMedia('(prefers-color-scheme: dark)');
  applyTheme(mql.matches ? 'dark' : 'light');
  mql.addEventListener('change', (e) => applyTheme(e.matches ? 'dark' : 'light'));
  if (window.JSOS && window.JSOS.getTheme) {
    Promise.resolve(window.JSOS.getTheme()).then((t) => t && applyTheme(t)).catch(() => {});
    if (window.JSOS.onThemeChange) window.JSOS.onThemeChange((t) => applyTheme(t));
  }
}

function initCollapse() {
  const shell = $('#shell');
  const btn = $('#collapse-btn');
  const KEY = 'system-info.collapsed';
  const ICON_OPEN = svgIcon('lock'), ICON_SIDE = '';
  // 一对图标照仓库既定写法（daily-brief，AGENTS §5.1）：
  // 展开态 = lucide panel-left-close（竖线 + 指向左的箭头）；折叠态 = lucide panel-left（只有竖线，无箭头）
  const ICON_ATTR = 'width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  const EXPAND = `<svg ${ICON_ATTR}><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/></svg>`;
  const COLLAPSE = `<svg ${ICON_ATTR}><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/></svg>`;
  let collapsed = false;
  try {
    collapsed = localStorage.getItem(KEY) === '1';
  } catch (e) {}
  const apply = (v) => {
    shell.classList.toggle('collapsed', v);
    btn.innerHTML = v ? EXPAND : COLLAPSE;
    btn.setAttribute('aria-label', v ? '展开侧边栏' : '折叠侧边栏');
    navTitles(v);
    try {
      localStorage.setItem(KEY, v ? '1' : '0');
    } catch (e) {}
  };
  const navTitles = (v) => {
    $('#nav')
      .querySelectorAll('[data-nav]')
      .forEach((b) => {
        if (v) b.title = b.querySelector('.nav-label').textContent;
      });
  };
  btn.addEventListener('click', () => apply(!shell.classList.contains('collapsed')));
  apply(collapsed);
}

async function main() {
  const m = location.pathname.match(/^\/widget\/([a-z0-9-]+)/i);
  if (m) document.body.dataset.widget = m[1];
  if (isWidget()) {
    document.title = '本机概览';
    const t = $('#page-title');
    if (t) t.textContent = '本机概览';
    if ($('#shell')) $('#shell').classList.add('collapsed');
  }
  initTheme();
  if (!isWidget()) initCollapse();
  if (!isWidget()) {
    $('#btn-rescan').addEventListener('click', scan);
    $('#btn-copy').addEventListener('click', async () => {
      const ok = await copyText(JSON.stringify(STATE.data, null, 2));
      toast(ok ? '已复制本机信息 JSON' : '复制失败，请手动选择');
    });
    if (window.JSOS && window.JSOS.onLocaleChange) {
      window.JSOS.onLocaleChange(() => {});
    }
  }
  await scan();
}

main();
