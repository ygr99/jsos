import express from 'express';
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>日期时间</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:#1e1e2e;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none}
#clock{text-align:center;font-size:3.5rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.3)}
@media(max-width:480px){#clock{font-size:2rem}}
</style>
</head>
<body>
<div id="clock"></div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  document.getElementById('clock').textContent=y+'年'+mo+'月'+da+'日 '+wd+wn+'周 '+h+':'+mi;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

app.get('/widget/clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:transparent;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none;overflow:hidden}
#clock{text-align:center}
.date{font-size:1rem;font-weight:500;opacity:.85;letter-spacing:1px}
.time{font-size:2.8rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.4);line-height:1.2}
.seconds{font-size:1.2rem;font-weight:400;opacity:.6;margin-left:4px}
</style>
</head>
<body>
<div id="clock">
  <div class="date" id="date"></div>
  <div class="time"><span id="time"></span><span class="seconds" id="seconds"></span></div>
</div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  const s=String(n.getSeconds()).padStart(2,'0');
  document.getElementById('date').textContent=y+'\u5E74'+mo+'\u6708'+da+'\u65E5 '+wd+wn+'\u5468';
  document.getElementById('time').textContent=h+':'+mi;
  document.getElementById('seconds').textContent=s;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

// 模拟时钟小组件（3×3 格 = 304px 见方）
// 写实路线：普通家用挂钟 —— 白塑料外壳 + 米白纸面 + 黑色粗体数字 + 黑漆时针分针 + 红秒针，
// 加弧面玻璃高光/边缘内阴影、指针在纸面上的投影、整机悬浮投影。**背景全透明**，桌面上只浮着一只钟。
// 写实参照：jsos-apps/toolbox/public/tools/airConditioner（白塑机身 + 真实投影 + 实物质感的大方向）。
// 尺寸表（viewBox 200，圆心 100）：外壳 r88 / 玻璃压圈 r83 / 纸面 r82 / 刻度 68~78 / 数字环 r57 /
// 时针 0.52Rd、分针 0.72Rd、秒针 0.78Rd（Rd=82）。刻度与数字由脚本生成，避免手写 60 行。
app.get('/widget/analog-clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>模拟时钟</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{background:transparent;overflow:hidden;-webkit-user-select:none;user-select:none;display:flex;align-items:center;justify-content:center}
svg{display:block;width:100%;height:100%;filter:drop-shadow(0 2px 3px rgba(16,20,26,.30)) drop-shadow(0 7px 13px rgba(16,20,26,.18))}
</style>
</head>
<body>
<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
<defs>
<linearGradient id="ck-case" x1="0.12" y1="0" x2="0.72" y2="1">
<stop offset="0" stop-color="#ffffff"/>
<stop offset="0.4" stop-color="#f5f7f9"/>
<stop offset="0.76" stop-color="#e4e8ec"/>
<stop offset="1" stop-color="#cbd1d8"/>
</linearGradient>
<radialGradient id="ck-dial" cx="0.42" cy="0.33" r="0.92">
<stop offset="0" stop-color="#fffefc"/>
<stop offset="0.58" stop-color="#f8f6f1"/>
<stop offset="0.86" stop-color="#eeebe4"/>
<stop offset="1" stop-color="#dfdcd2"/>
</radialGradient>
<radialGradient id="ck-vin" cx="0.5" cy="0.5" r="0.5">
<stop offset="0.66" stop-color="#0b0d10" stop-opacity="0"/>
<stop offset="1" stop-color="#0b0d10" stop-opacity="0.20"/>
</radialGradient>
<linearGradient id="ck-gloss" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#ffffff" stop-opacity="0.60"/>
<stop offset="0.45" stop-color="#ffffff" stop-opacity="0.16"/>
<stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
</linearGradient>
<linearGradient id="ck-hand" x1="0" y1="0" x2="1" y2="0">
<stop offset="0" stop-color="#3c424a"/>
<stop offset="0.26" stop-color="#0f1215"/>
<stop offset="0.56" stop-color="#2e343c"/>
<stop offset="1" stop-color="#090b0e"/>
</linearGradient>
<radialGradient id="ck-cap" cx="0.34" cy="0.27" r="0.88">
<stop offset="0" stop-color="#aab1ba"/>
<stop offset="0.5" stop-color="#535a64"/>
<stop offset="1" stop-color="#1d2127"/>
</radialGradient>
<clipPath id="ck-dial-clip"><circle cx="100" cy="100" r="82"/></clipPath>
</defs>

<circle id="ck-body" cx="100" cy="100" r="88" fill="url(#ck-case)"/>
<circle cx="100" cy="100" r="88" fill="none" stroke="#b3b9c1" stroke-width="0.7"/>
<circle cx="100" cy="100" r="83" fill="none" stroke="#a6adb6" stroke-width="1.6"/>
<circle cx="100" cy="100" r="82" fill="url(#ck-dial)"/>

<g id="ck-ticks"></g>
<g id="ck-nums" text-anchor="middle" font-family="'Segoe UI','Microsoft YaHei',system-ui,sans-serif" font-weight="600" font-size="20" fill="#1c2024"></g>
<text x="100" y="64" text-anchor="middle" font-family="'Segoe UI',system-ui,sans-serif" font-size="4.2" letter-spacing="1.4" fill="#a9b0b8">JSOS</text>

<circle cx="100" cy="100" r="82" fill="url(#ck-vin)"/>
<g clip-path="url(#ck-dial-clip)">
<ellipse cx="56" cy="42" rx="78" ry="52" fill="url(#ck-gloss)" transform="rotate(-26 56 42)"/>
<ellipse cx="152" cy="152" rx="54" ry="27" fill="url(#ck-gloss)" opacity="0.3" transform="rotate(-26 152 152)"/>
</g>

<g id="ck-needles" style="filter:drop-shadow(0.6px 0.9px 0.45px rgba(0,0,0,.34))">
<path id="ck-hour" d="M96.6,104.5 A3.4,3.4 0 0 1 103.4,104.5 L101.7,55 A1.7,1.7 0 0 0 98.3,55 Z" fill="url(#ck-hand)"/>
<path id="ck-minute" d="M97.2,111.5 A2.8,2.8 0 0 1 102.8,111.5 L101.3,26 A1.3,1.3 0 0 0 98.7,26 Z" fill="url(#ck-hand)"/>
<circle cx="100" cy="100" r="5" fill="url(#ck-cap)"/>
<circle cx="98.2" cy="98.2" r="1.4" fill="#ffffff" opacity="0.5"/>
</g>

<g id="ck-second">
<line x1="100" y1="22" x2="100" y2="113" stroke="#cf2b21" stroke-width="1.1"/>
<circle cx="100" cy="106" r="2.6" fill="#cf2b21"/>
<circle cx="100" cy="100" r="2.7" fill="#cf2b21"/>
</g>
</svg>
<script>
(function(){
  var C=100,NS='http://www.w3.org/2000/svg';
  var ticks=document.getElementById('ck-ticks');
  for(var i=0;i<60;i++){
    var hour=i%5===0, a=i*6*Math.PI/180, r1=hour?68:73, r2=78;
    var l=document.createElementNS(NS,'line');
    l.setAttribute('x1',(C+r1*Math.sin(a)).toFixed(2));
    l.setAttribute('y1',(C-r1*Math.cos(a)).toFixed(2));
    l.setAttribute('x2',(C+r2*Math.sin(a)).toFixed(2));
    l.setAttribute('y2',(C-r2*Math.cos(a)).toFixed(2));
    l.setAttribute('stroke',hour?'#1c2024':'#454b53');
    l.setAttribute('stroke-width',hour?3.2:1.1);
    l.setAttribute('stroke-linecap',hour?'butt':'round');
    ticks.appendChild(l);
  }
  var nums=document.getElementById('ck-nums');
  for(var h=1;h<=12;h++){
    var b=h*30*Math.PI/180;
    var t=document.createElementNS(NS,'text');
    t.setAttribute('x',(C+57*Math.sin(b)).toFixed(2));
    t.setAttribute('y',(C-57*Math.cos(b)).toFixed(2));
    t.setAttribute('dy','0.35em');
    t.textContent=String(h);
    nums.appendChild(t);
  }
  var hourHand=document.getElementById('ck-hour');
  var minuteHand=document.getElementById('ck-minute');
  var secondHand=document.getElementById('ck-second');
  var timer=null;
  function rotate(el,deg){el.setAttribute('transform','rotate('+deg.toFixed(2)+' '+C+' '+C+')');}
  function tick(){
    var n=new Date();
    var s=n.getSeconds()+n.getMilliseconds()/1000;
    var mi=n.getMinutes();
    var h=n.getHours()%12;
    rotate(secondHand,s*6);
    rotate(minuteHand,(mi+s/60)*6);
    rotate(hourHand,(h+mi/60)*30);
    timer=setTimeout(tick,1000-(Date.now()%1000)+5);
  }
  // 标签页被切走时定时器会被节流，回来时立刻对时（保持单条定时链）
  document.addEventListener('visibilitychange',function(){
    if(!document.hidden){clearTimeout(timer);tick();}
  });
  tick();
})();
</script>
</body>
</html>`);
});

// 霓虹发光数字时钟小组件（4×3 格 = 408×304 内容区）
// 卡片自绘底色 + 四周彩虹辉光（body / html 仍透明，辉光要留在 408×304 内不被容器裁掉：
// 卡片 328×~142 → 左右各 40px，辉光外扩 = inset 4 + blur 26 = 30px ✓）。
// 不加载任何外站资源：JSOS 强制 COEP require-corp，CDN 的字体 / 图标会被拦成空白且拖慢首屏，
// 所以辉光菜单用内联 SVG，数字用系统字体栈 + tabular-nums（等宽数字，跳秒不抖）。
// 12/24 小时制按小组件实例记忆（__jsos_wid，无参数时退回全局键）；纯 UI 偏好，存前端即可。
app.get('/widget/neon-clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>霓虹时钟</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:transparent;overflow:hidden;
  -webkit-user-select:none;user-select:none;font-variant-numeric:tabular-nums;
  font-family:"Segoe UI","PingFang SC","Microsoft YaHei",system-ui,sans-serif}
#card{position:relative;display:flex;flex-direction:column;align-items:center;width:340px;padding:22px 26px;
  border-radius:16px;background:#2e2e44;color:#fff;box-shadow:0 5px 25px rgba(14,21,37,.8)}
/* 两层辉光：::after 是紧贴卡片的一圈实色（霓虹灯管本身），::before 是大半径的雾（照到桌面上的光）。
   只有一层 blur(26px) 时颜色被摊薄，实测在壁纸上几乎看不出彩色，所以两层叠。 */
#card::before,#card::after{content:'';position:absolute;z-index:-1;border-radius:20px;
  background:linear-gradient(45deg,#24ff6d,#2f93f1,#ff5e9a);background-size:200% 200%;animation:glow 10s ease infinite}
#card::before{inset:-4px;filter:blur(26px)}
#card::after{inset:-2px;filter:blur(9px);opacity:.75}
@keyframes glow{0%,100%{background-position:0 50%}50%{background-position:100% 50%}}
#time{display:flex;align-items:center;justify-content:center}
.num,.colon{display:flex;align-items:center;justify-content:center;font-weight:600;line-height:94px}
.num{width:92px;font-size:68px}
.colon{font-size:46px;color:#8f8fa6}
#h{background:linear-gradient(90deg,#634dff,#5fd4ff)}
#m{background:linear-gradient(90deg,#ff5e9e,#ffb960)}
/* #side 必须给 min-width：右上位是「周X / 上午 / 下午」三种二/三字文案，
   宽度不钉死会让整列随内容变化、日期行在两种制式下宽度不一致（周内还会每天挪） */
#side{display:flex;flex-direction:column;align-items:center;min-width:52px;margin-left:8px;font-size:17px;font-weight:500}
#period{transform:translateY(-5px);background:linear-gradient(90deg,#f7b63f,#faf879)}
#sec{transform:translateY(5px);background:linear-gradient(90deg,#24ff6d,#2f93f1)}
#date{margin-top:4px;font-size:22px;font-weight:500;background:linear-gradient(90deg,#ae4af6,#ff98d1)}
/* 渐变文字必须写在 #h/#m 这些 id 规则之后：#h{background:...} 是简写，会把 background-clip 重置成
   border-box，而 id 的优先级高于 .num 类 —— 写成 .num 时数字会因 text-fill 透明而整个看不见。 */
#h,#m,#period,#sec,#date{-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}
#menu-btn{position:absolute;top:9px;right:11px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;
  color:#c6c6dc;cursor:pointer;z-index:2}
#menu-btn svg{width:15px;height:15px;fill:currentColor}
#menu{position:absolute;top:7px;right:9px;z-index:3;display:flex;align-items:center;gap:9px;padding:8px 12px;
  border-radius:8px;background:#353e54;box-shadow:0 5px 25px rgba(0,0,0,.5);
  visibility:hidden;opacity:0;transition:opacity .25s ease,visibility .25s ease}
#menu.open{visibility:visible;opacity:1}
#menu-label{font-size:12px;white-space:nowrap;color:#efefef}
#switch{position:relative;width:32px;height:14px;border-radius:8px;background:#485470;cursor:pointer;
  box-shadow:inset 2px 2px 4px rgba(255,255,255,.1),inset -2px -2px 4px rgba(0,0,0,.2)}
#switch::before{content:'';position:absolute;top:0;left:50%;width:14px;height:14px;margin-left:-7px;border-radius:50%;
  background:#ff5e9a;box-shadow:0 0 10px #ff5e9a;transform:translateX(-9px);
  transition:transform .25s ease,background .25s ease}
#switch.on::before{background:#0bff8d;box-shadow:0 0 10px #0bff8d;transform:translateX(9px)}
</style>
</head>
<body>
<div id="card">
  <div id="menu-btn" title="切换小时制">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/>
    </svg>
  </div>
  <div id="menu">
    <span id="menu-label">24 小时制</span>
    <span id="switch" class="on" title="切换 12 / 24 小时制"></span>
  </div>
  <div id="time">
    <span class="num" id="h">00</span>
    <span class="colon">:</span>
    <span class="num" id="m">00</span>
    <div id="side">
      <span id="period">周_</span>
      <span id="sec">00</span>
    </div>
  </div>
  <div id="date">0月0日</div>
</div>
<script>
(function(){
  function $(id){return document.getElementById(id)}
  var hEl=$('h'),mEl=$('m'),sEl=$('sec'),pEl=$('period'),dEl=$('date');
  var btn=$('menu-btn'),menu=$('menu'),sw=$('switch'),label=$('menu-label');
  var WEEK=['周日','周一','周二','周三','周四','周五','周六'];
  // 制式按小组件实例记忆；平台没追加 __jsos_wid 时（旧缓存 iframe / 浏览器直接打开）退回全局键
  var wid=new URLSearchParams(location.search).get('__jsos_wid');
  var KEY='datetime.neon-clock.hour-format'+(wid?'.'+wid:'');
  var fmt='24';
  try{var saved=localStorage.getItem(KEY);if(saved==='12'||saved==='24'){fmt=saved;}}catch(e){}
  function pad(n){return n<10?'0'+n:''+n}
  function paintMode(){
    sw.classList.toggle('on',fmt==='24');
    label.textContent=fmt==='24'?'24 小时制':'12 小时制';
  }
  var timer=null;
  function tick(){
    var n=new Date(),h=n.getHours(),p;
    if(fmt==='12'){
      // 12 小时制要把 0 点折成 12（参考稿写的 hours>12?hours%12:hours 会让午夜显示成 00）
      p=h<12?'上午':'下午';
      h=h%12;
      if(h===0)h=12;
    }else{
      // 24 制没有上/下午，那一格改放星期 —— 两种制式都不留空位，也不用删元素
      p=WEEK[n.getDay()];
    }
    hEl.textContent=pad(h);
    mEl.textContent=pad(n.getMinutes());
    sEl.textContent=pad(n.getSeconds());
    pEl.textContent=p;
    dEl.textContent=(n.getMonth()+1)+'月'+n.getDate()+'日';
    timer=setTimeout(tick,1000-(Date.now()%1000)+5);
  }
  btn.addEventListener('click',function(e){e.stopPropagation();menu.classList.toggle('open')});
  sw.addEventListener('click',function(){
    fmt=fmt==='24'?'12':'24';
    try{localStorage.setItem(KEY,fmt);}catch(e){}
    paintMode();
    clearTimeout(timer);
    tick();
  });
  document.addEventListener('click',function(e){
    if(!menu.contains(e.target)&&!btn.contains(e.target))menu.classList.remove('open');
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')menu.classList.remove('open')});
  // 标签页被切走时定时器会被节流，回到前台立即对时（保持单条定时链，无重入）
  document.addEventListener('visibilitychange',function(){
    if(!document.hidden){clearTimeout(timer);tick();}
  });
  paintMode();
  tick();
})();
</script>
</body>
</html>`);
});

app.listen(port, () => console.log(`running on ${port}`));
