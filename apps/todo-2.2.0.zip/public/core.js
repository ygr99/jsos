/**
 * todo 共享核心：服务端存储（workspace/data/<appId>/tasks.json）+ 今日待办计算
 *
 * 数据模型（2.0）：一个事项只有「计划日期 date」（YYYY-MM-DD），没有分类。
 * 视图全是查询：今日 = date ≤ 今天（逾期滚入今天）；本周/本月/本年 = 落在区间内的未完成事项。
 * 存储：§7.9 模式 A；同步：BroadcastChannel + 60s/可见性兜底。
 */

const SYNC_CHANNEL = 'todo-sync';

export function todayStr(now = new Date()) {
  const p = (x) => String(x).padStart(2, '0');
  return `${now.getFullYear()}-${p(now.getMonth() + 1)}-${now.getDate()}`;
}

export async function loadTasks() {
  try {
    const res = await fetch('/api/tasks', { cache: 'no-store' });
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export async function createTask(payload) {
  const res = await fetch('/api/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || '创建失败');
  return res.json();
}

export async function updateTask(id, patch) {
  const res = await fetch(`/api/tasks/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  if (!res.ok) throw new Error('更新失败');
  return res.json();
}

export async function deleteTask(id) {
  const res = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('删除失败');
  return res.json();
}

/** 跨页面即时通知（同一容器内同源） */
export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage('tasks-updated');
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = () => cb();
  } catch {}
}

/**
 * 今日待办（小组件口径）：计划日期 ≤ 今天（逾期滚入今天）且状态为 待办/进行中（已完成/已放弃不算）。
 */
export function todayOpenTasks(tasks, now = new Date()) {
  const today = todayStr(now);
  return tasks.filter((t) => t.date <= today && (t.status === '待办' || t.status === '进行中'));
}
