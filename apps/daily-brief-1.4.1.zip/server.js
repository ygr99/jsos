/**
 * 每日速览 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 两个"每日"数据接口：
 *   /api/daily-movie    爬 cikeee.com 首页"每日电影"模块
 *   /api/daily-english  爬 dict.eudic.net 每日一句
 * 数据按【日期】缓存（同一天重复请求直接回缓存，跨天自动刷新）。
 *
 * 抓取放服务端：目标站无 CORS 头，浏览器直连会被拦。
 * 直连失败时自动回退 JSOS CORS 代理（PROXY_URL / PROXY_KEY 为
 * JSOS 注入的环境变量；本机直跑没有这两个变量，直连本来就能通）。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { setProxyConfig, getProxyConfig } from './lib/crawl.js';
import { getDailyMovie } from './lib/daily/movie.js';
import { getDailyEnglish } from './lib/daily/english.js';
import { getAiNews } from './lib/daily/ainews.js';
import { getAibotNews } from './lib/daily/aibot.js';
import { getNews60s } from './lib/daily/news60s.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

// JSOS 启动时注入的 CORS 代理配置（容器内直连外站会被 CORS 拦，抓取层失败时自动回退）。
// 本机直跑没有这两个变量 → 不注入，直连本来就能通。
if (process.env.PROXY_URL) {
  setProxyConfig({ url: process.env.PROXY_URL, key: process.env.PROXY_KEY || '' });
}

const app = express();
app.use(express.json());

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  ok(res, {
    service: 'daily-brief',
    proxyConfigured: !!getProxyConfig(),
    time: new Date().toISOString(),
  });
});

/* ------------------------------ 每日数据 ------------------------------ */

/** 按时间窗口缓存装饰器：窗口内重复请求直接返回缓存（按天/按小时） */
function ttlCache(fetcher, windowMs) {
  let cachedAt = 0;
  let cacheData = null;
  return async () => {
    if (cacheData && Date.now() - cachedAt < windowMs) return { ...cacheData, _cached: true };
    const data = await fetcher();
    cacheData = data;
    cachedAt = Date.now();
    return { ...data, _cached: false };
  };
}

const movieCache = ttlCache(getDailyMovie, 24 * 3600 * 1000);      // 电影按天
const englishCache = ttlCache(getDailyEnglish, 24 * 3600 * 1000);  // 英语按天
const aiNewsCache = ttlCache(getAiNews, 3600 * 1000);              // 量子位 AI 快讯按小时（时效性强）
const aibotNewsCache = ttlCache(getAibotNews, 3600 * 1000);        // AI 工具集快讯按小时
const news60sCache = ttlCache(getNews60s, 24 * 3600 * 1000);       // 每天60秒读懂世界按天

app.get('/api/daily-movie', async (req, res) => {
  try {
    const data = await movieCache();
    delete data._cached;
    ok(res, data);
  } catch (err) {
    fail(res, `每日电影获取失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/aibot-news', async (req, res) => {
  try {
    const data = await aibotNewsCache();
    delete data._cached;
    ok(res, data);
  } catch (err) {
    fail(res, `AI 工具集快讯获取失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/news-60s', async (req, res) => {
  try {
    const data = await news60sCache();
    delete data._cached;
    ok(res, data);
  } catch (err) {
    fail(res, `每天60秒读懂世界获取失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/daily-english', async (req, res) => {
  try {
    const data = await englishCache();
    delete data._cached;
    ok(res, data);
  } catch (err) {
    fail(res, `每日英语获取失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/ai-news', async (req, res) => {
  try {
    const data = await aiNewsCache();
    delete data._cached;
    ok(res, data);
  } catch (err) {
    fail(res, `AI 快讯获取失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 工具 ------------------------------ */

function ok(res, data) { res.json({ ok: true, ...data }); }
function fail(res, error, status = 500) { res.status(status).json({ ok: false, error }); }

/* ------------------------------ 发音音频代理 ------------------------------ */

// 欧路发音接口（api.frdic.com）有 Referer/CORP 校验，容器 iframe 里直接播会被拦
// → 服务端代理音频流（白名单限定欧路域名）
const AUDIO_ALLOWLIST = ['api.frdic.com'];

app.get('/api/audio', async (req, res) => {
  const url = String(req.query.url || '');
  let host;
  try {
    host = new URL(url).host;
  } catch {
    return fail(res, '音频地址无效', 400);
  }
  if (!AUDIO_ALLOWLIST.includes(host)) return fail(res, '音频域名不在白名单', 403);

  try {
    const upstream = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/126.0', Referer: 'https://dict.eudic.net/' },
      signal: AbortSignal.timeout(15000),
    });
    if (!upstream.ok || !upstream.body) return fail(res, `音频获取失败（HTTP ${upstream.status}）`, 502);
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const reader = upstream.body.getReader();
    const pump = async () => {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
      res.end();
    };
    await pump();
  } catch (err) {
    fail(res, `音频代理失败：${err?.message || '未知错误'}`, 502);
  }
});

/* ------------------------------ 静态文件与回退 ------------------------------ */

app.use(express.static(join(__dirname, 'public')));

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`daily-brief running on ${port}`));
