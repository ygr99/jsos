/* 朋友圈 — JSOS 应用
 * 存储策略：帖子/资料存 localStorage，上传的图片·音频·视频 Blob 存 IndexedDB（浏览器缓存，不落服务器）
 */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const SVG_PLAY = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>';
  const SVG_PAUSE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z"/></svg>';
  const SVG_HEART = '<svg class="heart" viewBox="0 0 24 24" width="15" height="15" fill="#576b95"><path d="M12 20.5S3.5 14.9 3.5 9.3A4.8 4.8 0 0 1 12 6.4a4.8 4.8 0 0 1 8.5 2.9c0 5.6-8.5 11.2-8.5 11.2z"/></svg>';
  const SVG_COMMENT = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9 9 0 0 1-3.9-.9L3 20.5l1.5-4.6A8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4z"/></svg>';
  const AVATAR_FALLBACK = 'default-avatar.jpg';

  // ============ IndexedDB：二进制资源 ============
  const DB_NAME = 'jsos-moments';
  const DB_STORE = 'assets';
  let _dbp = null;

  function db() {
    if (!_dbp) {
      _dbp = new Promise((res, rej) => {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(DB_STORE)) req.result.createObjectStore(DB_STORE); };
        req.onsuccess = () => res(req.result);
        req.onerror = () => rej(req.error);
      });
    }
    return _dbp;
  }
  async function assetPut(blob, fixedKey) {
    const key = fixedKey || 'a_' + uid();
    const d = await db();
    await new Promise((res, rej) => {
      const tx = d.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).put(blob, key);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error);
    });
    return 'asset:' + key;
  }
  async function assetAll() {
    const d = await db();
    return new Promise((res, rej) => {
      const tx = d.transaction(DB_STORE, 'readonly');
      const os = tx.objectStore(DB_STORE);
      const vals = os.getAll();
      const keys = os.getAllKeys();
      tx.oncomplete = () => {
        const out = {};
        keys.result.forEach((k, i) => { out[k] = vals.result[i]; });
        res(out);
      };
      tx.onerror = () => rej(tx.error);
    });
  }
  async function assetDel(key) {
    const d = await db();
    await new Promise((res) => {
      const tx = d.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).delete(key);
      tx.oncomplete = () => res();
      tx.onerror = () => res();
    });
  }

  // 资源键 → 可用的 objectURL
  const urlMap = new Map();
  async function refreshUrlMap() {
    const all = await assetAll();
    for (const k of Object.keys(all)) {
      const key = 'asset:' + k;
      if (urlMap.has(key)) URL.revokeObjectURL(urlMap.get(key));
      urlMap.set(key, URL.createObjectURL(all[k]));
    }
  }
  function resolve(u) {
    if (!u) return '';
    if (typeof u === 'string' && u.startsWith('asset:')) return urlMap.get(u) || '';
    return u;
  }
  function assetKey(u) {
    return typeof u === 'string' && u.startsWith('asset:') ? u.slice(6) : null;
  }

  // ============ localStorage：帖子与资料 ============
  const LS_KEY = 'jsos.moments.v1';
  let state = null;
  let keyword = '';

  function loadState() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        if (s && Array.isArray(s.posts)) return s;
      }
    } catch (e) { console.warn('[moments] 读取本地缓存失败', e); }
    return null;
  }
  function saveState() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); }
    catch (e) { toast('本地存储写入失败：' + e.message); }
  }
  function findPost(id) { return state.posts.find((p) => p.id === id); }

  function parseDate(s) {
    if (!s) return 0;
    const m = String(s).match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[^\d]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
    if (!m) return 0;
    return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)).getTime();
  }
  function hasHTML(content) {
    return (content || []).some((t) => /<[a-zA-Z/][^>]*>/.test(String(t)));
  }
  function normalize(p) {
    const content = Array.isArray(p.content) ? p.content.slice() : String(p.content || '').split(/\n+/).filter((x) => x.trim() !== '');
    return {
      id: p.id || 'p_' + uid(),
      author: p.author || '',
      avatar: p.avatar || '',
      title: p.title || '',
      content,
      // 种子数据里部分正文含 <a> 链接，标记为可信 HTML 原样渲染；用户新发布的走转义
      html: p.html === undefined ? hasHTML(content) : !!p.html,
      images: Array.isArray(p.images) ? p.images.slice() : [],
      date: p.date || '',
      ts: p.ts || parseDate(p.date) || 0,
      location: p.location || '',
      music: p.music || null,
      video: p.video || null,
      livePhoto: p.livePhoto || null,
      comments: Array.isArray(p.comments) ? p.comments.slice() : [],
      likes: Array.isArray(p.likes) ? p.likes.slice() : [],
      local: !!p.local
    };
  }

  const pad2 = (n) => String(n).padStart(2, '0');
  function fmtTime(ts) {
    const d = new Date(ts);
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  function dateText(p) {
    // 种子数据沿用其原始日期串；本地发布的走智能时间（刚刚 / x 分钟前 / 昨天 …）
    if (p.date && !p.local) return p.date;
    return fmtSmart(p.ts || parseDate(p.date));
  }
  function fmtSmart(ts) {
    if (!ts) return '';
    const now = Date.now();
    const diff = (now - ts) / 1000;
    if (diff >= 0 && diff < 60) return '刚刚';
    if (diff >= 0 && diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
    const d = new Date(ts), n = new Date();
    if (diff >= 0 && diff < 86400 && d.getDate() === n.getDate()) return Math.floor(diff / 3600) + ' 小时前';
    const y = new Date(now - 86400000);
    if (d.getFullYear() === y.getFullYear() && d.getMonth() === y.getMonth() && d.getDate() === y.getDate()) return '昨天 ' + fmtTime(ts);
    if (d.getFullYear() === n.getFullYear()) return (d.getMonth() + 1) + ' 月 ' + d.getDate() + ' 日 ' + fmtTime(ts);
    return d.getFullYear() + ' 年 ' + (d.getMonth() + 1) + ' 月 ' + d.getDate() + ' 日';
  }
  function fmtDateTime(ts) {
    const d = new Date(ts);
    const w = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' 周' + w + ' ' + fmtTime(ts);
  }

  // ============ 渲染 ============
  function renderUser() {
    const u = state.user || {};
    const bg = $('#banner-background');
    const b = resolve(u.banner);
    bg.style.backgroundImage = b ? `url("${b}")` : 'url("default-cover.jpg")';
    $('#user-name').textContent = (u.name || '我') + '的朋友圈';
    $('#user-avatar').src = resolve(u.avatar) || AVATAR_FALLBACK;
    $('#banner-subinfo').innerHTML = u.subinfo || '';
  }

  // 兼容：video.iframe 既可能是完整 <iframe ...> 片段，也可能直接是 URL
  function iframeSrc(v) {
    let s = String(v || '').trim().replace(/^`+|`+$/g, '').trim(); // 剥掉误粘贴的反引号
    const m = s.match(/src\s*=\s*["']([^"']+)["']/i);
    let url = m ? m[1] : s;
    if (url.startsWith('//')) url = 'https:' + url;
    return url;
  }

  // 外链视频（B 站 / 抖音，只有 bvid/vid，没有可直链的 src）→ 内嵌官方 embed 播放器。
  // 依赖主站 COEP: credentialless（require-corp 会拦 player.bilibili.com / open.douyin.com）。
  // externalVideoCard 为降级方案，credentialless 确认可行后删除。
  function embeddedVideoIframe(v) {
    let url = '';
    if (v.type === 'bilibili') {
      const bv = (String(v.bvid || '').match(/BV[0-9A-Za-z]+/) || [])[0];
      if (bv) url = 'https://player.bilibili.com/player.html?bvid=' + bv + '&autoplay=0';
      else if (v.iframe) url = iframeSrc(v.iframe);
    } else if (v.type === 'douyin') {
      if (v.iframe) url = iframeSrc(v.iframe);
      else if (v.vid) url = 'https://open.douyin.com/player/embed?vid=' + encodeURIComponent(v.vid) + '&autoplay=0';
    }
    url = String(url || '').trim().replace(/^`+|`+$/g, '').trim(); // 最终兜底：剥掉首尾反引号
    if (!url) return externalVideoCard(v);
    return `<div class="post-video${v.type === 'douyin' ? ' douyin' : ''}"><iframe src="${esc(url)}" allowfullscreen scrolling="no" frameborder="0" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe></div>`;
  }

  // 降级方案：点击外链卡片在新窗口打开（credentialless 确认可行后删除本函数及 videoHTML 中的引用）
  function externalVideoCard(v) {
    let url = '';
    let label = '打开视频';
    if (v.type === 'bilibili') {
      if (v.bvid) url = 'https://www.bilibili.com/video/' + v.bvid;
      else {
        const s = v.iframe ? iframeSrc(v.iframe) : '';
        url = s ? s.replace('player.bilibili.com/player.html', 'www.bilibili.com/video') : '';
      }
      label = '在 B 站观看';
    } else if (v.type === 'douyin' && v.vid) {
      url = 'https://www.douyin.com/video/' + v.vid;
      label = '在抖音观看';
    }
    if (!url) return '';
    const poster = v.poster
      ? `<img class="video-card-cover" src="${esc(resolve(v.poster))}" alt="">`
      : '<div class="video-card-cover"></div>';
    return `<div class="post-video post-video-card">
      <a class="video-card" href="${esc(url)}" target="_blank" rel="noopener noreferrer">
        ${poster}
        <div class="video-card-overlay">
          <div class="video-card-play">▶</div>
          <div class="video-card-title">${esc(label)}</div>
        </div>
      </a>
    </div>`;
  }

  function videoHTML(v) {
    if (!v) return '';
    // 仅 bvid/iframe/douyin-vid（无真实 src）→ 内嵌官方 embed 播放器
    if (v.type === 'bilibili' && !v.src) return embeddedVideoIframe(v);
    if (v.type === 'douyin' && v.vid && !v.src) return embeddedVideoIframe(v);

    const src = resolve(v.src || '');
    if (!src) return '';
    const poster = v.poster ? ` poster="${esc(resolve(v.poster))}"` : '';
    return `<div class="post-video${v.type === 'douyin' ? ' douyin' : ''}"><video src="${esc(src)}"${poster} preload="metadata" playsinline controls></video></div>`;
  }

  function musicHTML(m) {
    if (!m) return '';
    const url = resolve(m.url || '');
    if (!url) return '';
    const cover = resolve(m.cover || '');
    return `<div class="post-music">
      <div class="mp-top">
        <img class="mp-cover" src="${esc(cover)}" alt="">
        <div class="mp-meta">
          <div class="mp-title">${esc(m.title || '未知歌曲')}</div>
          <div class="mp-artist">${esc(m.author || '未知歌手')}</div>
        </div>
        <button class="mp-play" data-playing="0" aria-label="播放">${SVG_PLAY}</button>
      </div>
      <div class="mp-bar"><div class="mp-prog"></div></div>
      <div class="mp-time"><span class="mp-cur">00:00</span><span class="mp-dur">--:--</span></div>
      <div class="mp-lrc">${esc(m.title || '')}</div>
      <audio preload="metadata" src="${esc(url)}"></audio>
    </div>`;
  }

  function galleryHTML(p) {
    const imgs = (p.images || []).map(resolve).filter(Boolean);
    if (!imgs.length) return '';
    const n = Math.min(imgs.length, 9);
    const items = imgs.map((src, i) => `<img src="${esc(src)}" alt="图片 ${i + 1}" loading="lazy" data-gallery="${esc(p.id)}" data-idx="${i}">`).join('');
    return `<div class="post-gallery pg-${n}">${items}</div>`;
  }

  function liveHTML(lp) {
    if (!lp) return '';
    const img = resolve(lp.image), vid = resolve(lp.video);
    if (!img || !vid) return '';
    return `<div class="post-live" data-video="${esc(vid)}">
      <video class="live-video" poster="${esc(img)}" muted playsinline preload="none"></video>
      <div class="live-controls">
        <button class="live-toggle" data-state="static"><span class="dot"></span>LIVE</button>
        <button class="live-mute" data-muted="true">🔇</button>
      </div>
    </div>`;
  }

  function asideHTML(p) {
    const likes = p.likes || [];
    const comments = p.comments || [];
    if (!likes.length && !comments.length) return '';
    let h = '';
    if (likes.length) {
      h += `<div class="post-likes">${SVG_HEART}<div class="names">${likes.map((n) => `<b>${esc(n)}</b>`).join('、')}</div></div>`;
    }
    if (comments.length) {
      h += '<div class="post-comments">' + comments.map((c, i) => {
        const who = c.authorLink
          ? `<a href="${esc(c.authorLink)}" target="_blank" rel="noopener noreferrer">${esc(c.author || '匿名')}</a>`
          : esc(c.author || '匿名');
        const reply = c.replyTo ? `<span class="c-name"> 回复 ${esc(c.replyTo)}</span>` : '';
        return `<div class="comment-item"><span class="c-name">${who}</span>${reply}<span class="c-text">：${esc(c.text || '')}</span><span class="c-del" data-act="delcomment" data-i="${i}">删除</span></div>`;
      }).join('') + '</div>';
    }
    return `<aside class="post-aside">${h}</aside>`;
  }

  function postHTML(p) {
    const avatar = resolve(p.avatar) || resolve(state.user.avatar) || AVATAR_FALLBACK;
    const name = p.author || state.user.name || '我';
    const raw = (t) => (p.html ? String(t) : esc(t));
    const paras = (p.content || []).map((t) => (t === '' ? '<p><br></p>' : `<p>${raw(t)}</p>`)).join('');
    const long = (p.content || []).length > 3;
    return `<article class="post" data-id="${esc(p.id)}">
      <div class="post-avatar"><img src="${esc(avatar)}" alt="" loading="lazy"></div>
      <div class="post-main">
        <header class="post-header">
          <div class="post-title">${esc(name)}</div>
          <button class="post-del" data-act="del">删除</button>
        </header>
        <section class="post-content">
          <div class="post-text${long ? ' collapsed' : ''}">${paras}${long ? '<a class="post-toggle" data-act="toggle">全文</a>' : ''}</div>
          ${videoHTML(p.video)}
          ${musicHTML(p.music)}
          ${galleryHTML(p)}
          ${liveHTML(p.livePhoto)}
        </section>
        <footer class="post-footer">
          <div class="post-info"><span>${esc(dateText(p))}</span>${p.location ? `<span class="post-loc">${esc(p.location)}</span>` : ''}</div>
          <div class="post-fun"><div class="fun-ico" data-act="fun" title="互动"></div></div>
        </footer>
        ${asideHTML(p)}
      </div>
    </article>`;
  }

  function matchKeyword(p) {
    if (!keyword) return true;
    const hay = [p.author, p.location, p.title, ...(p.content || [])].join(' ').toLowerCase();
    return hay.includes(keyword.toLowerCase());
  }

  function render() {
    renderUser();
    const list = state.posts.slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
    const shown = list.filter(matchKeyword);
    const box = $('#posts');
    box.innerHTML = shown.length
      ? shown.map(postHTML).join('')
      : `<div class="empty">${keyword ? '没有匹配的朋友圈' : '还没有内容，点右上角「发布」写下第一条'}</div>`;
    $('#autoload').textContent = shown.length ? '没有更多了' : '';
    bindLivePhotos();
    bindMusic();
  }

  // ============ 媒体绑定 ============
  function bindLivePhotos() {
    $$('.post-live').forEach((box) => {
      if (box.dataset.bound) return;
      box.dataset.bound = '1';
      const video = box.querySelector('video');
      const toggle = box.querySelector('.live-toggle');
      const mute = box.querySelector('.live-mute');
      video.muted = true;
      video.loop = true;
      video.playsInline = true;
      let timer = null, manual = false;
      const setMute = (m) => { video.muted = m; mute.dataset.muted = String(m); mute.textContent = m ? '🔇' : '🔊'; };
      const start = (unmute) => {
        if (!video.src) video.src = box.dataset.video;
        if (unmute) setMute(false);
        const pr = video.play();
        if (pr && pr.catch) pr.catch(() => {});
        toggle.dataset.state = 'playing';
      };
      const stop = () => {
        video.pause();
        video.currentTime = 0;
        toggle.dataset.state = 'static';
        setMute(true);
      };
      box.addEventListener('mouseenter', () => { if (manual) return; timer = setTimeout(() => start(false), 350); });
      box.addEventListener('mouseleave', () => { clearTimeout(timer); if (!manual) stop(); });
      toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        if (toggle.dataset.state === 'static') { manual = true; start(true); }
        else { manual = false; stop(); }
      });
      mute.addEventListener('click', (e) => { e.stopPropagation(); setMute(!video.muted); });
    });
  }

  function parseLRC(text) {
    const s = String(text || '');
    const re = /\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
    const marks = [];
    let m;
    while ((m = re.exec(s))) {
      marks.push({ t: +m[1] * 60 + +m[2] + (m[3] ? Number('0.' + m[3]) : 0), index: m.index, end: m.index + m[0].length });
    }
    const out = [];
    marks.forEach((mk, i) => {
      const stop = i + 1 < marks.length ? marks[i + 1].index : s.length;
      const txt = s.slice(mk.end, stop).trim();
      if (txt) out.push({ t: mk.t, txt });
    });
    return out;
  }

  function bindMusic() {
    $$('.post-music').forEach((el) => {
      if (el.dataset.bound) return;
      el.dataset.bound = '1';
      const audio = el.querySelector('audio');
      const play = el.querySelector('.mp-play');
      const bar = el.querySelector('.mp-bar');
      const prog = el.querySelector('.mp-prog');
      const cur = el.querySelector('.mp-cur');
      const dur = el.querySelector('.mp-dur');
      const lrcEl = el.querySelector('.mp-lrc');
      const p = findPost(el.closest('.post').dataset.id);
      const lrc = parseLRC(p && p.music ? p.music.lrc : '');
      const fmt = (s) => {
        if (!isFinite(s) || s < 0) return '00:00';
        return pad2(Math.floor(s / 60)) + ':' + pad2(Math.floor(s % 60));
      };
      play.addEventListener('click', () => {
        $$('audio').forEach((a) => { if (a !== audio) a.pause(); });
        if (audio.paused) { const pr = audio.play(); if (pr && pr.catch) pr.catch(() => toast('音频播放失败')); }
        else audio.pause();
      });
      audio.addEventListener('play', () => { play.dataset.playing = '1'; play.innerHTML = SVG_PAUSE; });
      audio.addEventListener('pause', () => { play.dataset.playing = '0'; play.innerHTML = SVG_PLAY; });
      audio.addEventListener('loadedmetadata', () => { dur.textContent = fmt(audio.duration); });
      audio.addEventListener('timeupdate', () => {
        const d = audio.duration || 0;
        prog.style.width = (d ? (audio.currentTime / d) * 100 : 0) + '%';
        cur.textContent = fmt(audio.currentTime);
        dur.textContent = fmt(d);
        if (lrc.length) {
          let line = '';
          for (let i = 0; i < lrc.length; i++) if (audio.currentTime + 0.2 >= lrc[i].t) line = lrc[i].txt;
          if (line && lrcEl.textContent !== line) lrcEl.textContent = line;
        }
      });
      audio.addEventListener('ended', () => { prog.style.width = '0%'; });
      bar.addEventListener('click', (e) => {
        const r = bar.getBoundingClientRect();
        const pct = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
        if (audio.duration) audio.currentTime = pct * audio.duration;
      });
    });
  }

  // ============ 互动：点赞 / 评论 / 删除 ============
  function clearFunBox() { $$('.fun-box').forEach((n) => n.remove()); }

  $('#posts').addEventListener('click', (e) => {
    const actEl = e.target.closest('[data-act]');
    if (actEl) {
      const art = actEl.closest('.post');
      const p = art ? findPost(art.dataset.id) : null;
      const act = actEl.dataset.act;
      if (act === 'fun' && p) {
        const fun = actEl.parentElement;
        const exist = fun.querySelector('.fun-box');
        clearFunBox();
        if (exist) return;
        const liked = (p.likes || []).includes('我');
        const box = document.createElement('div');
        box.className = 'fun-box';
        box.innerHTML = `<button data-act="like">${SVG_HEART.replace('class="heart"', 'style="width:13px;height:13px"')} ${liked ? '取消' : '赞'}</button><button data-act="comment">${SVG_COMMENT} 评论</button>`;
        fun.appendChild(box);
        return;
      }
      if (act === 'like' && p) {
        p.likes = p.likes || [];
        const i = p.likes.indexOf('我');
        if (i >= 0) p.likes.splice(i, 1); else p.likes.push('我');
        saveState();
        clearFunBox();
        render();
        return;
      }
      if (act === 'comment' && p) {
        clearFunBox();
        let aside = art.querySelector('.post-aside');
        if (!aside) {
          aside = document.createElement('aside');
          aside.className = 'post-aside';
          art.querySelector('.post-main').appendChild(aside);
        }
        let ci = aside.querySelector('.comment-input');
        if (!ci) {
          ci = document.createElement('div');
          ci.className = 'comment-input';
          ci.innerHTML = '<input type="text" placeholder="说点什么…" maxlength="200"><button data-act="sendcomment">发送</button>';
          aside.appendChild(ci);
        }
        ci.querySelector('input').focus();
        return;
      }
      if (act === 'sendcomment') {
        const input = actEl.parentElement.querySelector('input');
        const text = input.value.trim();
        if (!text) return;
        p.comments = p.comments || [];
        p.comments.push({ author: state.user.name || '我', text, ts: Date.now() });
        saveState();
        render();
        toast('评论已发布');
        return;
      }
      if (act === 'delcomment' && p) {
        p.comments.splice(+actEl.dataset.i, 1);
        saveState();
        render();
        return;
      }
      if (act === 'toggle') {
        const wrap = art.querySelector('.post-text');
        const collapsed = wrap.classList.toggle('collapsed');
        actEl.textContent = collapsed ? '全文' : '收起';
        return;
      }
      if (act === 'del' && p) {
        if (!confirm('删除这条朋友圈？其本地图片/音视频也会从浏览器缓存中移除。')) return;
        removePost(p);
        return;
      }
    }
    const img = e.target.closest('img[data-gallery]');
    if (img) openLightbox(img.dataset.gallery, +img.dataset.idx);
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.post-fun') && !e.target.closest('.comment-input')) clearFunBox();
  });

  function collectAssetKeys(p) {
    const keys = [];
    const push = (u) => { const k = assetKey(u); if (k) keys.push(k); };
    (p.images || []).forEach(push);
    if (p.video) { push(p.video.src); push(p.video.poster); }
    if (p.music) { push(p.music.url); push(p.music.cover); }
    if (p.livePhoto) { push(p.livePhoto.image); push(p.livePhoto.video); }
    return keys;
  }

  async function removePost(p) {
    const keys = collectAssetKeys(p);
    state.posts = state.posts.filter((x) => x.id !== p.id);
    saveState();
    for (const k of keys) await assetDel(k);
    await refreshUrlMap();
    render();
    toast('已删除');
  }

  // ============ 图片灯箱 ============
  let lbList = [], lbIdx = 0;
  function openLightbox(postId, idx) {
    const p = findPost(postId);
    if (!p) return;
    lbList = (p.images || []).map(resolve).filter(Boolean);
    if (!lbList.length) return;
    lbIdx = Math.min(Math.max(idx, 0), lbList.length - 1);
    showLB();
  }
  function showLB() {
    $('#lb-img').src = lbList[lbIdx];
    $('#lb-index').textContent = (lbIdx + 1) + ' / ' + lbList.length;
    $('#lightbox').hidden = false;
  }
  function closeLB() { $('#lightbox').hidden = true; }
  $('.lb-close').addEventListener('click', closeLB);
  $('#lightbox').addEventListener('click', (e) => { if (e.target.id === 'lightbox') closeLB(); });
  $('.lb-nav.prev').addEventListener('click', () => { lbIdx = (lbIdx - 1 + lbList.length) % lbList.length; showLB(); });
  $('.lb-nav.next').addEventListener('click', () => { lbIdx = (lbIdx + 1) % lbList.length; showLB(); });
  document.addEventListener('keydown', (e) => {
    if ($('#lightbox').hidden === false) {
      if (e.key === 'Escape') closeLB();
      if (e.key === 'ArrowLeft') $('.lb-nav.prev').click();
      if (e.key === 'ArrowRight') $('.lb-nav.next').click();
      return;
    }
    if (e.key === 'Escape') { clearFunBox(); closeModal('composer'); closeModal('profile'); }
  });

  // ============ 弹窗 ============
  function openModal(id) { $('#' + id).hidden = false; }
  function closeModal(id) { $('#' + id).hidden = true; }
  $$('[data-close]').forEach((el) => el.addEventListener('click', () => closeModal(el.dataset.close)));

  // ---------- 发布 ----------
  const draft = { images: [], video: null, videoLink: null, music: null, live: null };
  let pendingFiles = { video: null, audio: null, cover: null, liveImg: null, liveVid: null };

  function renderThumbs() {
    const box = $('#c-images');
    box.innerHTML = draft.images.map((src, i) => `<div class="thumb"><img src="${esc(resolve(src))}" alt=""><button data-rm="${i}" type="button">×</button></div>`).join('');
    $('#c-img-count').textContent = draft.images.length + '/9';
  }
  $('#c-images').addEventListener('click', (e) => {
    const b = e.target.closest('[data-rm]');
    if (!b) return;
    draft.images.splice(+b.dataset.rm, 1);
    renderThumbs();
  });

  $('#c-image-input').addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    for (const f of files) {
      if (draft.images.length >= 9) { toast('最多 9 张图片'); break; }
      draft.images.push(await assetPut(f));
    }
    e.target.value = '';
    await refreshUrlMap();
    renderThumbs();
  });

  function bindSeg(segId, attr, onPick) {
    $('#' + segId).addEventListener('click', (e) => {
      const b = e.target.closest('.seg-btn');
      if (!b) return;
      $$('#' + segId + ' .seg-btn').forEach((n) => n.classList.remove('active'));
      b.classList.add('active');
      onPick(b.dataset[attr]);
    });
  }
  bindSeg('c-video-seg', 'vt', (v) => {
    $('#c-video-local').hidden = v !== 'local';
    $('#c-video-link').hidden = v !== 'link';
    draft.videoMode = v;
    if (v !== 'local') { draft.video = null; pendingFiles.video = null; $('#c-video-name').textContent = '选择视频文件'; }
    if (v !== 'link') draft.videoLink = null;
  });
  bindSeg('c-music-seg', 'mt', (v) => {
    $('#c-music-box').hidden = v === 'none';
    if (v === 'none') { draft.music = null; }
  });
  bindSeg('c-live-seg', 'lt', (v) => {
    $('#c-live-box').hidden = v === 'none';
    if (v === 'none') draft.live = null;
  });

  $('#c-video-input').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pendingFiles.video = f;
    $('#c-video-name').textContent = '已选：' + f.name;
  });
  $('#c-audio-input').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pendingFiles.audio = f;
    $('#c-audio-name').textContent = '已选：' + f.name;
  });
  $('#c-cover-input').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pendingFiles.cover = await assetPut(f);
    $('#c-cover-name').textContent = '已选：' + f.name;
  });
  $('#c-live-img-input').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pendingFiles.liveImg = await assetPut(f);
    $('#c-live-img-name').textContent = '已选：' + f.name;
  });
  $('#c-live-vid-input').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pendingFiles.liveVid = f;
    $('#c-live-vid-name').textContent = '已选：' + f.name;
  });

  function resetComposer() {
    draft.images = [];
    draft.video = null;
    draft.videoLink = null;
    draft.music = null;
    draft.live = null;
    draft.videoMode = 'none';
    pendingFiles = { video: null, audio: null, cover: null, liveImg: null, liveVid: null };
    $('#c-text').value = '';
    $('#c-location').value = '';
    $('#c-author').value = '';
    $('#c-video-value').value = '';
    $('#c-music-title').value = '';
    $('#c-music-author').value = '';
    $('#c-music-lrc').value = '';
    $('#c-video-name').textContent = '选择视频文件';
    $('#c-audio-name').textContent = '选择音频';
    $('#c-cover-name').textContent = '选择封面';
    $('#c-live-img-name').textContent = '选择封面照片';
    $('#c-live-vid-name').textContent = '选择实况视频';
    $('#c-video-local').hidden = true;
    $('#c-video-link').hidden = true;
    $('#c-music-box').hidden = true;
    $('#c-live-box').hidden = true;
    $$('.seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.vt === 'none' || b.dataset.mt === 'none' || b.dataset.lt === 'none'));
    $('#c-tip').textContent = '';
    renderThumbs();
  }

  async function publish() {
    const btn = $('#c-submit');
    btn.disabled = true;
    btn.textContent = '发表中…';
    try {
      const text = $('#c-text').value.trim();
      const paragraphs = text ? text.split(/\r?\n/).map((s) => s.trim()).filter((s) => s !== '') : [];

      if (pendingFiles.video) draft.video = { type: 'local', src: await assetPut(pendingFiles.video) };
      const vv = $('#c-video-value').value.trim().replace(/^`+|`+$/g, '').trim();
      if (draft.videoMode === 'link' && vv) {
        const vt = $('#c-video-type').value;
        if (vt === 'bilibili') {
          const bv = (vv.match(/BV[0-9A-Za-z]+/) || [vv])[0];
          draft.videoLink = { type: 'bilibili', bvid: bv };
        } else if (vt === 'douyin') {
          draft.videoLink = { type: 'douyin', vid: vv };
        } else {
          draft.videoLink = { type: 'direct', src: vv };
        }
      }
      if (pendingFiles.audio) {
        draft.music = {
          title: $('#c-music-title').value.trim() || pendingFiles.audio.name.replace(/\.[^.]+$/, ''),
          author: $('#c-music-author').value.trim() || '未知歌手',
          url: await assetPut(pendingFiles.audio),
          cover: pendingFiles.cover || '',
          lrc: $('#c-music-lrc').value.trim()
        };
      }
      if (pendingFiles.liveImg && pendingFiles.liveVid) {
        draft.live = { image: pendingFiles.liveImg, video: await assetPut(pendingFiles.liveVid) };
      }

      const has = paragraphs.length || draft.images.length || draft.video || draft.videoLink || draft.music || draft.live;
      if (!has) { $('#c-tip').textContent = '写点什么，或至少加一张图片'; return; }

      const post = normalize({
        id: 'p_' + uid(),
        author: $('#c-author').value.trim() || state.user.name || '我',
        avatar: state.user.avatar || '',
        content: paragraphs,
        images: draft.images.slice(),
        ts: Date.now(),
        date: fmtDateTime(Date.now()),
        location: $('#c-location').value.trim(),
        video: draft.video || draft.videoLink || null,
        music: draft.music,
        livePhoto: draft.live,
        local: true
      });
      state.posts.unshift(post);
      saveState();
      resetComposer();
      closeModal('composer');
      await refreshUrlMap();
      render();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      toast('已发布');
    } catch (err) {
      console.error(err);
      $('#c-tip').textContent = '发布失败：' + err.message;
    } finally {
      btn.disabled = false;
      btn.textContent = '发表';
    }
  }

  $('#btn-new').addEventListener('click', () => { $('#c-tip').textContent = ''; openModal('composer'); });
  $('#c-cancel').addEventListener('click', () => { resetComposer(); closeModal('composer'); });
  $('#c-submit').addEventListener('click', publish);

  // ---------- 资料 ----------
  const pdraft = { avatar: null, banner: null };
  function renderProfile() {
    const u = state.user || {};
    $('#p-name').value = u.name || '';
    $('#p-subinfo').value = u.subinfo || '';
    pdraft.avatar = u.avatar || '';
    pdraft.banner = u.banner || '';
    $('#p-preview').innerHTML = `<img src="${esc(resolve(u.avatar) || AVATAR_FALLBACK)}" alt=""><div class="pv-banner" style="background-image:url('${esc(resolve(u.banner))}')"></div>`;
  }
  $('#btn-profile').addEventListener('click', () => { renderProfile(); openModal('profile'); });
  $('#p-avatar-input').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pdraft.avatar = await assetPut(f);
    $('#p-preview img').src = resolve(pdraft.avatar);
    e.target.value = '';
  });
  $('#p-banner-input').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    pdraft.banner = await assetPut(f);
    $('.pv-banner').style.backgroundImage = `url("${resolve(pdraft.banner)}")`;
    e.target.value = '';
  });
  $('#p-save').addEventListener('click', async () => {
    state.user = { ...state.user, name: $('#p-name').value.trim() || '我', subinfo: $('#p-subinfo').value.trim(), avatar: pdraft.avatar, banner: pdraft.banner };
    saveState();
    await refreshUrlMap();
    closeModal('profile');
    render();
    toast('资料已保存');
  });
  $('#p-reset').addEventListener('click', async () => {
    const seed = await fetch('./seed.json').then((r) => r.json()).catch(() => null);
    const su = (seed && seed.user) || {};
    state.user = { name: su.name || '我', avatar: su.avatar || '', banner: su.banner || '', subinfo: su.subinfo || '' };
    saveState();
    await refreshUrlMap();
    renderProfile();
    render();
    toast('已恢复默认资料');
  });

  // ---------- 搜索 ----------
  $('#search').addEventListener('input', (e) => { keyword = e.target.value.trim(); render(); });

  // ============ 备份：导出 / 导入 ============
  function blobToDataURL(blob) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(fr.result);
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(blob);
    });
  }
  async function exportBackup() {
    try {
      toast('正在打包备份…');
      const all = await assetAll();
      const assets = {};
      for (const k of Object.keys(all)) assets[k] = await blobToDataURL(all[k]);
      const data = { app: 'jsos-moments', version: 1, exportedAt: new Date().toISOString(), user: state.user, posts: state.posts, assets };
      const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = '朋友圈备份-' + new Date().toISOString().slice(0, 10) + '.json';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 8000);
      toast('备份已导出（' + Object.keys(assets).length + ' 个附件）');
    } catch (err) {
      console.error(err);
      toast('导出失败：' + err.message);
    }
  }
  async function importBackup(file) {
    try {
      const data = JSON.parse(await file.text());
      if (!data || !Array.isArray(data.posts)) throw new Error('不是有效的朋友圈备份文件');
      if (!confirm('导入备份将覆盖同 ID 的朋友圈与资料，继续？')) return;
      toast('正在恢复…');
      const assets = data.assets || {};
      for (const k of Object.keys(assets)) {
        const v = assets[k];
        if (typeof v === 'string' && v.startsWith('data:')) {
          try { await assetPut(await (await fetch(v)).blob(), k); } catch (e) { console.warn('资源恢复失败', k, e); }
        }
      }
      const map = new Map(state.posts.map((p) => [p.id, p]));
      data.posts.forEach((np) => { const p = normalize(np); map.set(p.id, p); });
      state.posts = Array.from(map.values());
      if (data.user) state.user = { ...state.user, ...data.user };
      saveState();
      await refreshUrlMap();
      render();
      toast('已恢复 ' + data.posts.length + ' 条朋友圈');
    } catch (err) {
      console.error(err);
      toast('导入失败：' + err.message);
    }
  }
  $('#p-export').addEventListener('click', exportBackup);
  $('#p-import').addEventListener('click', () => $('#p-import-file').click());
  $('#p-import-file').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (f) await importBackup(f);
    e.target.value = '';
  });

  // ---------- 搜索：点击 🔍 弹出 / 关闭搜索行 ----------
  const searchToggle = (() => {
    let open = false;
    const row = $('#search-row');
    const input = $('#search');
    const focus = () => { setTimeout(() => input.focus(), 30); };
    const toggle = () => {
      open = !open;
      row.hidden = !open;
      if (open) focus(); else input.value = '';
    };
    $('#btn-search-toggle').addEventListener('click', toggle);
    row.addEventListener('click', (e) => { if (e.target.closest('[data-act="close-search"]')) toggle(); });
    document.addEventListener('keydown', (e) => {
      if (open && e.key === 'Escape') toggle();
    });
    return { isOpen: () => open };
  })();

  // ============ Toast ============
  let toastTimer = null;
  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
  }

  // 图片加载失败时弱化显示（远端图不可达时不影响排版）
  document.addEventListener('error', (e) => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.broken) {
      t.dataset.broken = '1';
      t.style.background = '#f2f2f2';
      t.style.minWidth = '40px';
      t.style.minHeight = '40px';
    }
  }, true);

  // ============ 启动 ============
  async function boot() {
    state = loadState();
    if (!state) {
      let seed = null;
      try { seed = await fetch('./seed.json').then((r) => r.json()); }
      catch (e) { console.warn('[moments] 种子数据加载失败', e); }
      state = {
        version: 1,
        user: { name: (seed && seed.user && seed.user.name) || '我', avatar: (seed && seed.user && seed.user.avatar) || '', banner: (seed && seed.user && seed.user.banner) || '', subinfo: (seed && seed.user && seed.user.subinfo) || '' },
        posts: ((seed && seed.posts) || []).map(normalize)
      };
      saveState();
    }
    state.posts = state.posts.map(normalize);
    await refreshUrlMap();
    resetComposer();
    render();
  }

  boot();
})();
