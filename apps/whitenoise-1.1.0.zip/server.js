/**
 * 白噪音（whitenoise）服务端
 * ---------------------------------------------------------------
 * 声音目录：lib/sounds.json（60 个声音 / 250 个变体，从泡泡白噪音
 *   www.ppbzy.com 的公开目录数据整理而来）。音频文件来自其公开 CDN：
 *     {CDN}/audio/{CategoryEn}/{folder}/{variantId}_{quality}.m4a
 *   quality = 64 | 128 | 320（lofi 类与 noQuality 声音无后缀）。
 *   ⚠️ 该 CDN **不返回 Access-Control-Allow-Origin**，容器内 <audio> 直链
 *   播放虽不受 CORS 限制，但一旦需要读字节就会失败 —— 因此这里提供
 *   /api/audio 同源代理作为兜底（透传 Range，支持拖动进度）。
 *
 * 播放数据存储：§7.9 模式 A —— 混音方案 / 音量等经 /api/state 原子写
 *   DATA_DIR/state.json（平台卸载勾选删数据时整目录清除）。
 */
import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { Readable } from 'stream';
import { outbound } from './lib/http.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

// [存储规范 §7.9] 容器内 = workspace/data/whitenoise；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const SOUNDS = JSON.parse(fs.readFileSync(join(__dirname, 'lib', 'sounds.json'), 'utf8'));
const SOUND_BY_ID = new Map(SOUNDS.map((s) => [s.id, s]));
// 内置推荐声景预设（音源全部校验过，见 lib/presets.json）
const PRESETS = JSON.parse(fs.readFileSync(join(__dirname, 'lib', 'presets.json'), 'utf8'));
const CDN = 'https://cdn.gameziyuan.shop/audio';
const QUALITY = { low: '_64', medium: '_128', high: '_320' };

/** 按声音 id / 变体 id / 音质 构造 CDN 直链 */
function buildAudioUrl(soundId, variantId, quality = 'low') {
  const snd = SOUND_BY_ID.get(soundId);
  if (!snd) return null;
  const v = snd.variants.find((x) => x.id === variantId) || snd.variants[0];
  const enc = (p) => p.split('/').map(encodeURIComponent).join('/');
  const suffix = snd.category === 'lofi' || snd.noQuality ? '' : QUALITY[quality] || QUALITY.low;
  return `${CDN}/${enc(snd.catEn)}/${enc(snd.folder)}/${encodeURIComponent(v.id + suffix + '.m4a')}`;
}

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'whitenoise' }));

/* ------------------------------ 声音目录 ------------------------------ */

app.get('/api/sounds', (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.json(SOUNDS);
});

/** 推荐声景预设（内置，客户端只读） */
app.get('/api/presets', (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.json(PRESETS.presets);
});

/** 解析播放地址（前端也可自行拼，这里便于调试/统一） */
app.get('/api/url', (req, res) => {
  const { sound, variant, quality } = req.query;
  const url = buildAudioUrl(String(sound || ''), String(variant || ''), String(quality || 'low'));
  if (!url) return res.status(404).json({ error: 'unknown sound' });
  res.json({ url });
});

/* --------------------------- 音频同源代理 --------------------------- */
/* CDN 无 CORS 头；本代理透传 Range，前端 audio.src 用同源地址即可播放/拖动 */

const PASS_HEADERS = ['content-type', 'content-length', 'content-range', 'accept-ranges', 'cache-control'];

app.get('/api/audio', async (req, res) => {
  const soundId = String(req.query.sound || '');
  const variantId = String(req.query.variant || '');
  const quality = String(req.query.quality || 'low');
  const target = buildAudioUrl(soundId, variantId, quality);
  if (!target) return res.status(404).send('unknown sound');

  try {
    const headers = { 'User-Agent': 'Mozilla/5.0', Referer: 'https://www.ppbzy.com/' };
    if (req.headers.range) headers.Range = req.headers.range;
    const { res: up } = await outbound(target, { headers, timeout: 60000 });
    if (!up.ok && up.status !== 206) return res.status(up.status).send('upstream error');

    res.status(up.status);
    for (const h of PASS_HEADERS) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    if (!up.headers.get('content-type')) res.setHeader('Content-Type', 'audio/x-m4a');
    res.setHeader('Cache-Control', 'public, max-age=86400');

    if (!up.body) return res.end();
    const nodeStream = Readable.fromWeb(up.body);
    nodeStream.on('error', () => res.end());       // 分段流必须挂 error handler
    res.on('close', () => nodeStream.destroy());
    nodeStream.pipe(res);
  } catch (e) {
    if (!res.headersSent) res.status(502).send('proxy failed: ' + e.message);
    else res.end();
  }
});

/* ------------------------------ 状态存储 ------------------------------ */

app.get('/api/state', (_req, res) => {
  try {
    if (!fs.existsSync(STATE_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  if (!req.body || typeof req.body !== 'object') return res.status(400).json({ error: 'bad body' });
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(req.body));
    fs.renameSync(tmp, STATE_FILE);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('*', (_req, res) => res.sendFile(join(__dirname, 'public', 'index.html')));

app.listen(port, () => console.log(`whitenoise running on ${port}`));
