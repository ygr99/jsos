// 侧边栏：片段由服务端注入 HTML（server.js 的 renderSidebar），当前页高亮也已由服务端标好。
// 这里只做两件事：① 在首次绘制前同步定好宽度；② 折叠开关（状态存 localStorage，纯 UI 偏好，jsos AGENTS §6）
(function () {
  var STORAGE_KEY = "jiuyunjian.sidebar-collapsed";
  var EXPANDED_W = "200px";
  var COLLAPSED_W = "56px";

  var sidebar = document.querySelector("#sidebar-container .app-sidebar");
  var btn = document.querySelector("#collapse-btn");
  if (!sidebar || !btn) {
    console.error("侧边栏片段缺失：检查 views/*.html 的 <!--@sidebar--> 占位与服务端注入");
    return;
  }

  var iconClose = btn.querySelector(".icon-close");
  var iconOpen = btn.querySelector(".icon-open");

  var collapsed0 = false;
  try { collapsed0 = localStorage.getItem(STORAGE_KEY) === "1"; } catch (e) {}

  // ★ 必须同步执行（脚本在 </body> 前，此时尚未首次绘制）：先把 --sidebar-w 与 has-sidebar 落好，
  //   内容从第一帧就处在正确位置 → 不会出现 0→200px 的位移动画
  document.documentElement.style.setProperty("--sidebar-w", collapsed0 ? COLLAPSED_W : EXPANDED_W);
  document.body.classList.add("has-sidebar");

  function apply(collapsed) {
    sidebar.classList.toggle("collapsed", collapsed);
    document.documentElement.style.setProperty("--sidebar-w", collapsed ? COLLAPSED_W : EXPANDED_W);
    btn.setAttribute("aria-label", collapsed ? "展开侧边栏" : "折叠侧边栏");
    btn.title = collapsed ? "展开侧边栏" : "折叠侧边栏";
    // SVGElement 没有 .hidden 这个 IDL 属性，必须写真实 attribute（jsos AGENTS §5.1）
    if (iconClose) iconClose.toggleAttribute("hidden", collapsed);
    if (iconOpen) iconOpen.toggleAttribute("hidden", !collapsed);
  }

  apply(collapsed0);

  btn.addEventListener("click", function () {
    var next = !sidebar.classList.contains("collapsed");
    apply(next);
    try { localStorage.setItem(STORAGE_KEY, next ? "1" : "0"); } catch (e) {}
  });
})();
