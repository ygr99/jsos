import { generateFaceSVG } from './face/generate.js';
import { loadState, saveState, createSync } from './common.js';

const btn = document.getElementById('widget-btn');
const faceView = document.getElementById('face-view');

let currentSvg = '';

function render(svg) {
  currentSvg = svg;
  faceView.innerHTML = svg;
  btn.classList.remove('pop');
  void btn.offsetWidth;
  btn.classList.add('pop');
}

function generate() {
  const { svg } = generateFaceSVG({ backgroundType: 'random' });
  render(svg);
  saveState(svg);
  sync.notify(svg);
}

btn.addEventListener('click', generate);

const sync = createSync((svg) => {
  if (svg && svg !== currentSvg) render(svg);
});

(async function init() {
  const state = await loadState();
  if (state && typeof state.svg === 'string' && state.svg.startsWith('<svg')) {
    render(state.svg);
  } else {
    generate(); // 首装播种：无状态时生成一张并保存，供主应用共享
  }
})();
