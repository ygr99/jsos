import { generateFaceSVG } from './face/generate.js';
import { loadState, saveState, createSync } from './common.js';

const faceView = document.getElementById('face-view');
const faceCard = document.getElementById('face-card');
const btnGenerate = document.getElementById('btn-generate');
const btnDownload = document.getElementById('btn-download');
const bgType = document.getElementById('bg-type');
const bgColor = document.getElementById('bg-color');

// 背景偏好属"丢了无所谓"的 UI 偏好，允许放 localStorage
const BG_PREF_KEY = 'ugly-avatar.bg';
let currentSvg = '';

const sync = createSync((svg) => {
  if (svg && svg !== currentSvg) render(svg);
});

// 主题自适应：JSOS 优先，缺省用系统偏好
(function initTheme() {
  const apply = (t) => document.documentElement.classList.toggle('dark', t === 'dark');
  try {
    if (window.JSOS && typeof window.JSOS.getTheme === 'function') {
      Promise.resolve(window.JSOS.getTheme()).then(apply).catch(() => {});
      if (typeof window.JSOS.onThemeChange === 'function') window.JSOS.onThemeChange(apply);
    } else if (window.matchMedia) {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      apply(mq.matches ? 'dark' : 'light');
      if (mq.addEventListener) mq.addEventListener('change', (e) => apply(e.matches ? 'dark' : 'light'));
    }
  } catch {}
})();

function render(svg) {
  currentSvg = svg;
  faceView.innerHTML = svg;
  faceCard.classList.remove('pop');
  void faceCard.offsetWidth; // 重启动画
  faceCard.classList.add('pop');
}

function generate() {
  const pref = readBgPref();
  const { svg, background } = generateFaceSVG({
    backgroundType: pref.type,
    backgroundCustomColor: pref.color,
  });
  render(svg);
  saveState(svg);
  sync.notify(svg);
  return background;
}

// 换背景不换脸：只替换背景 rect 的 fill（对齐上游"背景是即时属性"的行为）
function recolor(svg, color) {
  const next = svg.replace(
    /(<rect x="-100" y="-100" width="100%" height="100%" fill=")[^"]*("\s*\/>)/,
    '$1' + color + '$2'
  );
  render(next);
  saveState(next);
  sync.notify(next);
}

function readBgPref() {
  let type = 'random';
  let color = '#ffffff';
  try {
    const raw = localStorage.getItem(BG_PREF_KEY);
    if (raw) {
      const v = JSON.parse(raw);
      if (v.type === 'random' || v.type === 'transparent' || v.type === 'custom') type = v.type;
      if (typeof v.color === 'string' && /^#[0-9a-f]{6}$/i.test(v.color)) color = v.color;
    }
  } catch {}
  return { type, color };
}

function writeBgPref(pref) {
  try {
    localStorage.setItem(BG_PREF_KEY, JSON.stringify(pref));
  } catch {}
}

// 下载固定 512×512（头像标准尺寸；给 SVG 注入固有尺寸保证 canvas 清晰）
function downloadPNG() {
  if (!currentSvg) return;
  const sized = currentSvg.replace(
    /^<svg /,
    '<svg width="512" height="512" '
  );
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, 512, 512);
    const a = document.createElement('a');
    a.download = 'ugly-avatar.png';
    a.href = canvas.toDataURL('image/png');
    a.click();
  };
  img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(sized)));
}

// 生成是 <50ms 的同步纯计算，直接执行；勿用 rAF 延帧——后台页 rAF 永不触发（Chrome 节流）
btnGenerate.addEventListener('click', () => {
  generate();
});
btnDownload.addEventListener('click', downloadPNG);

bgType.addEventListener('change', () => {
  const pref = { type: bgType.value, color: bgColor.value };
  writeBgPref(pref);
  bgColor.style.display = pref.type === 'custom' ? '' : 'none';
  if (currentSvg) {
    if (pref.type === 'custom') {
      recolor(currentSvg, pref.color);
    } else if (pref.type === 'transparent') {
      recolor(currentSvg, 'transparent');
    } else {
      recolor(currentSvg, generateFaceSVG({ backgroundType: 'random' }).background);
    }
  }
});
bgColor.addEventListener('input', () => {
  const pref = { type: bgType.value, color: bgColor.value };
  writeBgPref(pref);
  if (currentSvg && pref.type === 'custom') recolor(currentSvg, pref.color);
});

(async function init() {
  const pref = readBgPref();
  bgType.value = pref.type;
  bgColor.value = pref.color;
  bgColor.style.display = pref.type === 'custom' ? '' : 'none';

  const state = await loadState();
  if (state && typeof state.svg === 'string' && state.svg.startsWith('<svg')) {
    render(state.svg);
  } else {
    generate(); // 首装播种：无状态时生成一张并保存
  }
})();
