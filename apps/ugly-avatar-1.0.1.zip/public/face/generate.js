// 生成编排层 —— 从上游 FaceGenerator.vue 提取改写。
// 上游用 Vue 响应式渲染、模板里散布 Math.random()，无法从少量参数重建同一张脸；
// 这里改为一次性做完所有随机决定、拼出完整 SVG 字符串，主应用与小组件共享同一份产物。
// 生成逻辑（参数区间、概率、元素顺序）逐条对应上游模板，勿随意改动。
import * as faceShape from './face_shape.js';
import * as eyeShape from './eye_shape.js';
import * as hairLines from './hair_lines.js';
import * as mouthShape from './mouth_shape.js';

function randomFromInterval(min, max) {
  return Math.random() * (max - min) + min;
}

// 点集转 polyline points 串；兼容 [x,y] 数组与 {x,y} 对象两种形态，保留 2 位小数足够 200×200 视口
function ptsToStr(pts) {
  return pts
    .map((p) => {
      const x = Array.isArray(p) ? p[0] : p.x;
      const y = Array.isArray(p) ? p[1] : p.y;
      return x.toFixed(2) + ',' + y.toFixed(2);
    })
    .join(' ');
}

const HAIR_COLORS = [
  'rgb(0, 0, 0)', // Black
  'rgb(44, 34, 43)', // Dark Brown
  'rgb(80, 68, 68)', // Medium Brown
  'rgb(167, 133, 106)', // Light Brown
  'rgb(220, 208, 186)', // Blond
  'rgb(233, 236, 239)', // Platinum Blond
  'rgb(165, 42, 42)', // Red
  'rgb(145, 85, 61)', // Auburn
  'rgb(128, 128, 128)', // Grey
  'rgb(185, 55, 55)', // fire
  'rgb(255, 192, 203)', // Pastel Pink
  'rgb(255, 105, 180)', // Bright Pink
  'rgb(230, 230, 250)', // Lavender
  'rgb(64, 224, 208)', // Turquoise
  'rgb(0, 191, 255)', // Bright Blue
  'rgb(148, 0, 211)', // Deep Purple
  'rgb(50, 205, 50)', // Lime Green
  'rgb(255, 165, 0)', // Vivid Orange
  'rgb(220, 20, 60)', // Crimson Red
  'rgb(192, 192, 192)', // Silver
];

const BACKGROUND_COLORS = [
  'rgb(245, 245, 220)', // Soft Beige
  'rgb(176, 224, 230)', // Pale Blue
  'rgb(211, 211, 211)', // Light Grey
  'rgb(152, 251, 152)', // Pastel Green
  'rgb(255, 253, 208)', // Cream
  'rgb(230, 230, 250)', // Muted Lavender
  'rgb(188, 143, 143)', // Dusty Rose
  'rgb(135, 206, 235)', // Sky Blue
  'rgb(245, 255, 250)', // Mint Cream
  'rgb(245, 222, 179)', // Wheat
  'rgb(47, 79, 79)', // Dark Slate Gray
  'rgb(72, 61, 139)', // Dark Slate Blue
  'rgb(60, 20, 20)', // Dark Brown
  'rgb(25, 25, 112)', // Midnight Blue
  'rgb(139, 0, 0)', // Dark Red
  'rgb(85, 107, 47)', // Olive Drab
  'rgb(128, 0, 128)', // Purple
  'rgb(0, 100, 0)', // Dark Green
  'rgb(0, 0, 139)', // Dark Blue
  'rgb(105, 105, 105)', // Dim Gray
];

const FUZZY_FILTER =
  '<filter id="fuzzy"><feTurbulence baseFrequency="0.05" numOctaves="3" type="turbulence" result="noise"/><feDisplacementMap in="SourceGraphic" in2="noise" scale="2"/></filter>';

// 生成一张完整的丑脸 SVG（viewBox -100 -100 200 200）
// opts: { backgroundType: 'random'|'transparent'|'custom', backgroundCustomColor: '#rrggbb' }
export function generateFaceSVG(opts = {}) {
  const backgroundType = opts.backgroundType || 'random';
  const faceScale = 1.8;

  const faceResults = faceShape.generateFaceCountourPoints();
  const face = faceResults.face;
  const faceHeight = faceResults.height;
  const faceWidth = faceResults.width;
  const center = faceResults.center; // 恒为 [0,0]，模板里直接内联进 transform

  const eyes = eyeShape.generateBothEyes(faceWidth / 2);
  const left = eyes.left;
  const right = eyes.right;

  const eyeRightUpper = right.upper;
  const eyeRightLower = right.lower;
  const eyeRightCountour = right.upper.slice(10, 90).concat(right.lower.slice(10, 90).reverse());
  const eyeLeftUpper = left.upper;
  const eyeLeftLower = left.lower;
  const eyeLeftCountour = left.upper.slice(10, 90).concat(left.lower.slice(10, 90).reverse());

  const distanceBetweenEyes = randomFromInterval(faceWidth / 4.5, faceWidth / 4);
  const eyeHeightOffset = randomFromInterval(faceHeight / 8, faceHeight / 6);
  const leftEyeOffsetX = randomFromInterval(-faceWidth / 20, faceWidth / 10);
  const leftEyeOffsetY = randomFromInterval(-faceHeight / 50, faceHeight / 50);
  const rightEyeOffsetX = randomFromInterval(-faceWidth / 20, faceWidth / 10);
  const rightEyeOffsetY = randomFromInterval(-faceHeight / 50, faceHeight / 50);

  // 瞳孔位置：从上下眼睑各取一点插值
  const leftInd0 = Math.floor(randomFromInterval(10, left.upper.length - 10));
  const rightInd0 = Math.floor(randomFromInterval(10, right.upper.length - 10));
  const leftInd1 = Math.floor(randomFromInterval(10, left.upper.length - 10));
  const rightInd1 = Math.floor(randomFromInterval(10, right.upper.length - 10));
  const leftLerp = randomFromInterval(0.2, 0.8);
  const rightLerp = randomFromInterval(0.2, 0.8);
  const leftPupilShiftY =
    left.upper[leftInd0][1] * leftLerp + left.lower[leftInd1][1] * (1 - leftLerp);
  const rightPupilShiftY =
    right.upper[rightInd0][1] * rightLerp + right.lower[rightInd1][1] * (1 - rightLerp);
  const leftPupilShiftX =
    left.upper[leftInd0][0] * leftLerp + left.lower[leftInd1][0] * (1 - leftLerp);
  const rightPupilShiftX =
    right.upper[rightInd0][0] * rightLerp + right.lower[rightInd1][0] * (1 - rightLerp);

  // 头发：4 种画法按上游概率参与，条数按各自系数
  const numHairLines = [];
  for (let i = 0; i < 4; i++) numHairLines.push(Math.floor(randomFromInterval(0, 50)));
  let hairs = [];
  if (Math.random() > 0.3) {
    hairs = hairLines.generateHairLines0(face, numHairLines[0] * 1 + 10);
  }
  if (Math.random() > 0.3) {
    hairs = hairs.concat(hairLines.generateHairLines1(face, numHairLines[1] / 1.5 + 10));
  }
  if (Math.random() > 0.5) {
    hairs = hairs.concat(hairLines.generateHairLines2(face, numHairLines[2] * 3 + 10));
  }
  if (Math.random() > 0.5) {
    hairs = hairs.concat(hairLines.generateHairLines3(face, numHairLines[3] * 3 + 10));
  }

  const rightNoseCenterX = randomFromInterval(faceWidth / 18, faceWidth / 12);
  const rightNoseCenterY = randomFromInterval(0, faceHeight / 5);
  const leftNoseCenterX = randomFromInterval(-faceWidth / 18, -faceWidth / 12);
  const leftNoseCenterY =
    rightNoseCenterY + randomFromInterval(-faceHeight / 30, faceHeight / 20);

  let hairColor;
  let dyeColorOffset = '50%';
  if (Math.random() > 0.1) {
    hairColor = HAIR_COLORS[Math.floor(Math.random() * 10)];
  } else {
    hairColor = 'url(#rainbowGradient)';
    dyeColorOffset = randomFromInterval(0, 100) + '%';
  }

  const mouthChoice = Math.floor(Math.random() * 3);
  let mouthPoints;
  if (mouthChoice === 0) {
    mouthPoints = mouthShape.generateMouthShape0(face, faceHeight, faceWidth);
  } else if (mouthChoice === 1) {
    mouthPoints = mouthShape.generateMouthShape1(face, faceHeight, faceWidth);
  } else {
    mouthPoints = mouthShape.generateMouthShape2(face, faceHeight, faceWidth);
  }

  // ---- 以下拼 SVG 字符串，元素顺序与上游模板一致 ----
  let background;
  if (backgroundType === 'transparent') {
    background = 'transparent';
  } else if (backgroundType === 'custom' && opts.backgroundCustomColor) {
    background = opts.backgroundCustomColor;
  } else {
    background = BACKGROUND_COLORS[Math.floor(Math.random() * BACKGROUND_COLORS.length)];
  }

  const defs = [];
  defs.push(
    '<clipPath id="leftEyeClipPath"><polyline points="' + ptsToStr(eyeLeftCountour) + '"/></clipPath>',
    '<clipPath id="rightEyeClipPath"><polyline points="' + ptsToStr(eyeRightCountour) + '"/></clipPath>',
    FUZZY_FILTER
  );
  if (hairColor === 'url(#rainbowGradient)') {
    const stops = [
      HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)],
      HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)],
      HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)],
    ];
    defs.push(
      '<linearGradient id="rainbowGradient" x1="0%" y1="0%" x2="100%" y2="0%">' +
        '<stop offset="0%" style="stop-color: ' + stops[0] + ';  stop-opacity: 1"/>' +
        '<stop offset="' + dyeColorOffset + '" style="stop-color: ' + stops[1] + ';  stop-opacity: 1"/>' +
        '<stop offset="100%" style="stop-color: ' + stops[2] + ';  stop-opacity: 1"/>' +
        '</linearGradient>'
    );
  }

  // 眼白组与五官组的 transform，同上游模板表达式（center 恒为 [0,0]）
  const rightEyeTransform =
    'translate(' + (center[0] + distanceBetweenEyes + rightEyeOffsetX) +
    ' ' + -(-center[1] + eyeHeightOffset + rightEyeOffsetY) + ')';
  const leftEyeTransform =
    'translate(' + -(center[0] + distanceBetweenEyes + leftEyeOffsetX) +
    ' ' + -(-center[1] + eyeHeightOffset + leftEyeOffsetY) + ')';

  const pupilCircles = (shiftX, shiftY, clipId) => {
    let s = '';
    for (let i = 0; i < 10; i++) {
      s +=
        '<circle r="' + (Math.random() * 2 + 3.0).toFixed(2) +
        '" cx="' + (shiftX + Math.random() * 5 - 2.5).toFixed(2) +
        '" cy="' + (shiftY + Math.random() * 5 - 2.5).toFixed(2) +
        '" stroke="black" fill="none" stroke-width="1.0" filter="url(#fuzzy)" clip-path="url(#' + clipId + ')"/>';
    }
    return s;
  };

  const noseCircles = (centerX, centerY) => {
    let s = '';
    for (let i = 0; i < 10; i++) {
      s +=
        '<circle r="' + (Math.random() * 2 + 1.0).toFixed(2) +
        '" cx="' + (centerX + Math.random() * 4 - 2).toFixed(2) +
        '" cy="' + (centerY + Math.random() * 4 - 2).toFixed(2) +
        '" stroke="black" fill="none" stroke-width="1.0" filter="url(#fuzzy)"/>';
    }
    return s;
  };

  let noseSvg;
  if (Math.random() > 0.5) {
    noseSvg =
      '<g id="pointNose"><g id="rightNose">' + noseCircles(rightNoseCenterX, rightNoseCenterY) +
      '</g><g id="leftNose">' + noseCircles(leftNoseCenterX, leftNoseCenterY) + '</g></g>';
  } else {
    noseSvg =
      '<g id="lineNose"><path d="M ' + leftNoseCenterX + ' ' + leftNoseCenterY +
      ', Q' + rightNoseCenterX + ' ' + rightNoseCenterY * 1.5 +
      ',' + (leftNoseCenterX + rightNoseCenterX) / 2 + ' ' + -eyeHeightOffset * 0.2 +
      '" fill="none" stroke="black" stroke-width="3" stroke-linejoin="round" filter="url(#fuzzy)"/></g>';
  }

  const hairSvg = hairs
    .map(
      (h) =>
        '<polyline points="' + ptsToStr(h) + '" fill="none" stroke="' + hairColor +
        '" stroke-width="2" stroke-linejoin="round" filter="url(#fuzzy)"/>'
    )
    .join('');

  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-100 -100 200 200">' +
    '<defs>' + defs.join('') + '</defs>' +
    '<title>That\'s an ugly face</title>' +
    '<desc>CREATED BY XUAN TANG, MORE INFO AT TXSTC55.GITHUB.IO</desc>' +
    '<rect x="-100" y="-100" width="100%" height="100%" fill="' + background + '"/>' +
    '<polyline id="faceContour" points="' + ptsToStr(face) + '" fill="#ffc9a9" stroke="black" stroke-width="' +
    (3.0 / faceScale).toFixed(3) + '" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    '<g transform="' + rightEyeTransform + '">' +
    '<polyline id="rightCountour" points="' + ptsToStr(eyeRightCountour) + '" fill="white" stroke="white" stroke-width="0.0" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    '</g>' +
    '<g transform="' + leftEyeTransform + '">' +
    '<polyline id="leftCountour" points="' + ptsToStr(eyeLeftCountour) + '" fill="white" stroke="white" stroke-width="0.0" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    '</g>' +
    '<g transform="' + rightEyeTransform + '">' +
    '<polyline id="rightUpper" points="' + ptsToStr(eyeRightUpper) + '" fill="none" stroke="black" stroke-width="' +
    (3.0 / faceScale).toFixed(3) + '" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    '<polyline id="rightLower" points="' + ptsToStr(eyeRightLower) + '" fill="none" stroke="black" stroke-width="' +
    (4.0 / faceScale).toFixed(3) + '" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    pupilCircles(rightPupilShiftX, rightPupilShiftY, 'rightEyeClipPath') +
    '</g>' +
    '<g transform="' + leftEyeTransform + '">' +
    '<polyline id="leftUpper" points="' + ptsToStr(eyeLeftUpper) + '" fill="none" stroke="black" stroke-width="' +
    (4.0 / faceScale).toFixed(3) + '" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    '<polyline id="leftLower" points="' + ptsToStr(eyeLeftLower) + '" fill="none" stroke="black" stroke-width="' +
    (4.0 / faceScale).toFixed(3) + '" stroke-linejoin="round" filter="url(#fuzzy)"/>' +
    pupilCircles(leftPupilShiftX, leftPupilShiftY, 'leftEyeClipPath') +
    '</g>' +
    '<g id="hairs">' + hairSvg + '</g>' +
    noseSvg +
    '<g id="mouth"><polyline points="' + ptsToStr(mouthPoints) +
    '" fill="rgb(215,127,140)" stroke="black" stroke-width="3" stroke-linejoin="round" filter="url(#fuzzy)"/></g>' +
    '</svg>';

  return { svg, background };
}
