// 主应用与小组件共享的同步层：服务端 /api/state（当前头像 SVG）+ BroadcastChannel 即时互通
export const STATE_URL = '/api/state';

export async function loadState() {
  try {
    const res = await fetch(STATE_URL);
    if (!res.ok) return null;
    return await res.json(); // 无状态时服务端返回 null
  } catch {
    return null;
  }
}

export async function saveState(svg) {
  try {
    await fetch(STATE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ svg }),
    });
  } catch {
    // 保存失败不阻塞界面，下次换头像会再写
  }
}

// token 过滤自己发的广播；60s + visibilitychange 兜底重拉（对齐 days-matter 模式 A 惯例）
export function createSync(onRemoteChange) {
  const myToken = (crypto.randomUUID && crypto.randomUUID()) || String(Math.random());
  let bc = null;
  try {
    bc = new BroadcastChannel('ugly-avatar-sync');
  } catch {
    bc = null; // 极老环境无 BroadcastChannel，退化为纯重拉
  }
  if (bc) {
    bc.onmessage = (e) => {
      if (e.data && e.data.token !== myToken && typeof e.data.svg === 'string') {
        onRemoteChange(e.data.svg);
      }
    };
  }
  const notify = (svg) => {
    if (bc) {
      try {
        bc.postMessage({ token: myToken, svg });
      } catch {}
    }
  };
  const refresh = async () => {
    const state = await loadState();
    if (state && typeof state.svg === 'string') onRemoteChange(state.svg);
  };
  const timer = setInterval(refresh, 60000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refresh();
  });
  return { notify, refresh, close: () => clearInterval(timer) };
}
