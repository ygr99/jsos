// 丑丑头像 —— 零依赖 node:http 服务：静态文件 + /api/state（当前头像 SVG）
import http from 'node:http';
import { promises as fsp } from 'node:fs';
import { join, extname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

async function readState() {
  try {
    return await fsp.readFile(STATE_FILE, 'utf8');
  } catch {
    return null;
  }
}

async function writeState(body) {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  const tmp = STATE_FILE + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(body));
  await fsp.rename(tmp, STATE_FILE);
}

async function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath);
  if (rel === '/' || rel === '') rel = '/index.html';
  // 防目录穿越
  const resolved = normalize(join(__dirname, 'public', rel));
  if (!resolved.startsWith(join(__dirname, 'public'))) {
    res.writeHead(403).end('Forbidden');
    return;
  }
  try {
    const data = await fsp.readFile(resolved);
    res.writeHead(200, { 'Content-Type': MIME[extname(resolved).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not Found');
  }
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const path = u.pathname;

  if (path === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  if (path === '/api/state') {
    if (req.method === 'GET') {
      const raw = await readState();
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(raw === null ? 'null' : raw);
      return;
    }
    if (req.method === 'POST') {
      let chunks = [];
      let size = 0;
      req.on('data', (c) => {
        size += c.length;
        if (size > 2 * 1024 * 1024) req.destroy(); // 状态就一个 SVG，2MB 上限足够
        else chunks.push(c);
      });
      req.on('end', async () => {
        try {
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          if (!body || typeof body.svg !== 'string' || !body.svg.startsWith('<svg') || body.svg.length > 1024 * 1024) {
            res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({ error: 'invalid state body' }));
            return;
          }
          await writeState(body);
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ ok: true }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ error: 'bad json' }));
        }
      });
      return;
    }
    res.writeHead(405).end('Method Not Allowed');
    return;
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405).end('Method Not Allowed');
    return;
  }
  await serveStatic(req, res, path);
});

server.listen(PORT, () => {
  console.log(`[ugly-avatar] listening on http://localhost:${PORT}`);
});
