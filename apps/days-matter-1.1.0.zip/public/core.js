/**
 * days-matter 共享核心：IndexedDB 读写 + 日期计算 + 卸载自清
 *
 * 存储：容器内同源 IndexedDB（DB: days-matter / store: kv / key: events），
 * 每次操作独立 open/close，避免长连接阻塞 deleteDatabase。
 * 同步：IndexedDB 没有 storage 事件，跨页面（主页面 ↔ 小组件）用 BroadcastChannel 通知。
 * 自清：平台「卸载同时删除应用数据」→ 窗口/小组件 URL 追加 __jsos_wipe=<t>
 *      （见 jsos 主仓库 [jsos-local-wipe] 补丁）→ guardWipe() 清空本应用全部客户端存储。
 */

export const DEFAULT_EVENTS = [
  { name: '元旦', date: '2027-01-01', type: 'countdown', icon: '🎉', isPinned: false },
  { name: '春节', date: '2027-02-06', type: 'countdown', icon: '🧧', isPinned: false },
  { name: '发工资', date: '15', type: 'monthly', icon: '💰', isPinned: false },
  { name: '来到世界', date: '2000-01-01', type: 'passed', icon: '👶', isPinned: false },
  { name: '开始工作', date: '2020-07-01', type: 'passed', icon: '💼', isPinned: false },
];

const DB_NAME = 'days-matter';
const STORE = 'kv';
const KEY = 'events';
const SYNC_CHANNEL = 'days-matter-sync';

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadEvents() {
  try {
    const db = await openDb();
    const val = await new Promise((resolve, reject) => {
      const rq = db.transaction(STORE, 'readonly').objectStore(STORE).get(KEY);
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => reject(rq.error);
    });
    db.close();
    return Array.isArray(val) ? val : null;
  } catch {
    return null;
  }
}

export async function saveEvents(events) {
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(events, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch (e) {
    console.error('保存日子数据失败:', e);
    return;
  }
  notifyChange();
}

/** 跨页面通知（IndexedDB 无 storage 事件） */
export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage('events-updated');
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = () => cb();
  } catch {}
}

/**
 * 卸载删数据自清：URL 带 __jsos_wipe=<t> 且 t 比水位（__jsos_last_wipe）新时，
 * 清掉本应用全部客户端存储（days-matter.* LS 键 + 整个 IndexedDB 库）。
 * 主页面与小组件都会调用，水位保证同一标记只执行一次。
 */
export async function guardWipe() {
  const t = parseInt(new URLSearchParams(location.search).get('__jsos_wipe') || '0');
  if (!t) return;
  const last = parseInt(localStorage.getItem('__jsos_last_wipe') || '0');
  if (t <= last) return;
  Object.keys(localStorage)
    .filter((k) => k.startsWith('days-matter.'))
    .forEach((k) => localStorage.removeItem(k));
  await new Promise((resolve) => {
    const q = indexedDB.deleteDatabase(DB_NAME);
    q.onsuccess = q.onerror = q.onblocked = () => resolve();
  });
  localStorage.setItem('__jsos_last_wipe', String(t));
}

/**
 * 每月重复事件的下一次日期（date 为 1-31 的字符串/数字）
 * 该月没有对应日期（如2月30日）时取该月最后一天
 */
export function nextMonthlyDate(dayOfMonth, now = new Date()) {
  const day = parseInt(dayOfMonth);
  let d = new Date(now.getFullYear(), now.getMonth(), day);
  if (now.getDate() >= day) d = new Date(now.getFullYear(), now.getMonth() + 1, day);
  if (d.getDate() !== day) d = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  return d;
}

/**
 * 处理全部事件，附加 daysLeft（passed 类型为已过天数，取正）与 nextDate
 */
export function processEvents(events, now = new Date()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const DAY = 1000 * 60 * 60 * 24;

  return (events || []).map((event) => {
    if (event.type === 'monthly') {
      const d = nextMonthlyDate(event.date, today);
      return { ...event, daysLeft: Math.ceil((d - today) / DAY), nextDate: fmt(d) };
    }
    const d = new Date(event.date);
    d.setHours(0, 0, 0, 0);
    const diff = Math.ceil((d - today) / DAY);
    if (event.type === 'passed') return { ...event, daysLeft: Math.abs(diff), nextDate: fmt(d) };
    return { ...event, daysLeft: diff, nextDate: fmt(d) };
  });
}

function fmt(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 小组件展示对象：置顶优先，否则取剩余天数最近的 countdown/monthly（daysLeft > 0）
 */
export function pickWidgetEvent(processed) {
  const pinned = processed.filter((e) => e.isPinned);
  if (pinned.length) return pinned[0];
  const valid = processed
    .filter((e) => e.type === 'countdown' || e.type === 'monthly')
    .filter((e) => e.daysLeft > 0)
    .sort((a, b) => a.daysLeft - b.daysLeft);
  return valid.length ? valid[0] : null;
}
