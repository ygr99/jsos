// minigames 侧边栏搜索（§7.8 实践）冒烟：静态服务 public/ + puppeteer
import { createRequire } from 'module';
import http from 'http';
import { readFileSync, existsSync } from 'fs';
import path from 'path';
const require = createRequire('C:/Users/99/.workbuddy/binaries/node/workspace/');
const puppeteer = require('puppeteer-core');

const PUB = 'C:/Users/99/jsos-apps/minigames/public';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  let file = path.join(PUB, p);
  if (!existsSync(file) || p === '/') file = path.join(PUB, 'index.html');
  res.setHeader('Content-Type', MIME[path.extname(file)] || 'application/octet-stream');
  res.end(readFileSync(file));
});
await new Promise(r => server.listen(4222, r));

const browser = await puppeteer.launch({
  executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  headless: 'new', args: ['--no-sandbox'],
});
const page = await browser.newPage();
await page.setViewport({ width: 1200, height: 760 });
page.on('pageerror', e => console.log('PAGE-ERROR:', e.message));
const grab = () => page.evaluate(() => ({
  searchInSidebar: !!document.querySelector('.sidebar .search-box'),
  searchInTopbar: !!document.querySelector('.topbar #search'),
  navTexts: [...document.querySelectorAll('.nav .nav-item')].map(b => b.textContent.replace(/\s+/g, '')),
  cards: document.querySelectorAll('.game-card').length,
  topbarCount: document.getElementById('count').textContent,
  empty: getComputedStyle(document.getElementById('empty-tip')).display !== 'none',
}));
const type = async q => {
  // 直接设值 + 派发 input（三连击替换在 CDP 下不可靠，会追加成"棋类方块"）
  await page.evaluate(val => {
    const i = document.getElementById('search');
    i.value = val;
    i.dispatchEvent(new Event('input', { bubbles: true }));
  }, q);
  await new Promise(r => setTimeout(r, 150));
};

await page.goto('http://localhost:4222/', { waitUntil: 'networkidle0' });
console.log('1 初始:', JSON.stringify(await grab()));

await type('棋类'); // 分组名匹配 → 棋类对战 3 个
console.log('2 搜"棋类":', JSON.stringify(await grab()));

await type('方块'); // 描述匹配 → 俄罗斯方块
console.log('3 搜"方块":', JSON.stringify(await grab()));

const clearVisible = await page.evaluate(() => !document.getElementById('search-clear').hidden);
await page.click('#search-clear');
await new Promise(r => setTimeout(r, 150));
console.log('4 清除按钮: 点击前可见 =', clearVisible, ', 点击后:', JSON.stringify(await grab()));

// 分类 + 搜索叠加：益智分类 + 搜"塔"
await page.evaluate(() => {
  [...document.querySelectorAll('.nav .nav-item')].find(b => b.textContent.includes('益智')).click();
});
await type('塔');
console.log('5 益智分类+搜"塔":', JSON.stringify(await grab()));

// 折叠态
await page.click('#collapse-btn');
await new Promise(r => setTimeout(r, 300));
const t5 = await page.evaluate(() => ({
  searchHidden: getComputedStyle(document.querySelector('.search-box')).display === 'none',
  sidebarWidth: document.querySelector('.sidebar').getBoundingClientRect().width,
}));
console.log('6 折叠态:', JSON.stringify(t5));
await page.screenshot({ path: 'C:/Users/99/jsos-apps/minigames/smoke-sidebar-search.png' });

await browser.close();
server.close();
