// 桌面宠物小组件：宠物住在桌面上，点击宠物切换动作，名字牌上的 ⇄ 按钮切换宠物
// 数据经 /api/state 存服务端 DATA_DIR（与主界面共享），BroadcastChannel 跨 iframe 同步
// 每个小组件实例独立：平台给 iframe 追加 __jsos_wid=<实例id>，各实例用 localStorage
// 记住自己显示的宠物；⇄ 只影响本实例，不改全局 currentPetId（其他小组件和主界面不跟跳）
import {
  loadData, saveData, applyDecay, SpriteAnimator, ANIM_KEYS, sheetUrlOf,
  defaultData, onExternalChange,
} from './pet-core.js';

let data = defaultData();
let animator = null;

// 平台注入的小组件实例 id（老平台/直接打开页面时为空 → 退回跟随全局的旧行为）
const WID = new URLSearchParams(location.search).get('__jsos_wid') || '';
const SEL_KEY = 'virtual-pet.widget-selection';

function loadSel() {
  try { return JSON.parse(localStorage.getItem(SEL_KEY) || '{}'); } catch { return {}; }
}

function saveSel(map) {
  try { localStorage.setItem(SEL_KEY, JSON.stringify(map)); } catch {}
}

// 本实例记住的宠物 id（宠物已被删除则顺手清理并回退 null）
function selectedPetId() {
  if (!WID) return null;
  const map = loadSel();
  const id = map[WID];
  if (!id) return null;
  if (!data.pets.some(p => p.id === id)) {
    delete map[WID];
    saveSel(map);
    return null;
  }
  return id;
}

function currentPet() {
  const sel = selectedPetId();
  return data.pets.find(p => p.id === (sel || data.currentPetId)) || data.pets[0];
}

function render() {
  const pet = currentPet();
  if (!pet) return;
  document.getElementById('pet-name').textContent = pet.name;
  // 只有一只宠物时没有可切换的对象，隐藏按钮
  document.getElementById('pet-switch-btn').style.display = data.pets.length > 1 ? '' : 'none';
  if (animator && animator.sheetUrl !== sheetUrlOf(pet)) {
    animator.setSheet(sheetUrlOf(pet));
    animator.play(pet.currentAnimation || 'idle');
  }
}

async function reload() {
  data = await loadData();
  render();
}

function tick() {
  const pet = currentPet();
  if (!pet) return;
  applyDecay(pet);
  saveData(data);   // 衰减写回，主界面经 BroadcastChannel 同步
  render();
}

async function init() {
  data = await loadData();
  const pet = currentPet();
  if (pet) applyDecay(pet);

  animator = new SpriteAnimator(document.getElementById('pet-sprite'), {
    sheetUrl: sheetUrlOf(pet || {}),
    displayWidth: 140,
  });
  animator.play((pet && pet.currentAnimation) || 'idle');

  // 点击宠物切换动作（并保存偏好，主界面同步）
  document.getElementById('pet-sprite').addEventListener('click', () => {
    const p = currentPet();
    if (!p) return;
    const idx = ANIM_KEYS.indexOf(animator.currentAnimation);
    const next = ANIM_KEYS[(idx + 1) % ANIM_KEYS.length];
    animator.play(next);
    p.currentAnimation = next;
    saveData(data);
  });

  // 名字牌 ⇄ 按钮：循环切换本实例显示的宠物。有实例 id 时只记录自己的选择，
  // 不动全局 currentPetId（其他小组件与主界面不受影响）；无实例 id 时退回旧行为
  document.getElementById('pet-switch-btn').addEventListener('click', () => {
    if (data.pets.length < 2) return;
    const cur = currentPet();
    if (!cur) return;
    const idx = Math.max(0, data.pets.findIndex(p => p.id === cur.id));
    const next = data.pets[(idx + 1) % data.pets.length];
    if (WID) {
      const map = loadSel();
      map[WID] = next.id;
      saveSel(map);
      render();
    } else {
      applyDecay(next);
      data.currentPetId = next.id;
      saveData(data);
      render();
    }
    animator.setSheet(sheetUrlOf(next));
    animator.play(next.currentAnimation || 'idle');
  });

  // 主界面/其他窗口改动 → 拉取服务端最新状态
  onExternalChange(reload);

  render();
  setInterval(tick, 60000);
}

document.addEventListener('DOMContentLoaded', init);
