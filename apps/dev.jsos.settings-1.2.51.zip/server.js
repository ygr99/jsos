import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PROXY_CONFIG_PATH = path.join(DATA_DIR, 'proxy-configs.json');

// 确保 DATA_DIR 存在
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 默认代理配置（2026-09-05 切换自建 jsos-cors-proxy）
const DEFAULT_PROXY_URL = 'https://proxy.xn--4gqta1h0zg9yuu7a.fun';
const LEGACY_PROXY_URL = 'https://cors-proxy.jsos.dev';

const DEFAULT_DATA = {
  configs: [
    {
      id: 'default',
      name: '默认代理',
      url: DEFAULT_PROXY_URL,
      key: 'hello-world',
      isDefault: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  ],
  activeId: 'default',
};

// MIME 类型映射
const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/** 云同步：统一 JSON 响应 */
function sendJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

/** 读原始请求体：云同步要按**字节**透传给 OSS，不能当字符串处理 */
function readBodyBuffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/* ---------------- 云同步（数据存阿里云 OSS） ----------------
 * 链路：前端 → 本服务（同源，无 CORS 问题）
 *              → 向 {PROXY_URL}/oss-sign 取预签名 URL（经平台代理，请求仅几百字节）
 *              → 直连 OSS 传输数据（**不经平台代理**，因此没有 4 MB 体积上限）
 *
 * 对象名固定为 jsos-sync/<同步码>.json —— 同步码既是密钥也是路径，
 * 所以不需要任何额外的元信息存储：查询就是一次 HEAD。
 *
 * 安全：AK/SK 只存在于签名服务（Vercel 环境变量）里，本服务与前端都碰不到。
 *
 * ⚠️ 查询（meta）为什么只签发 URL、把 HEAD 交给前端做 —— 2026-09-22 实测：
 *   容器内 fetch 打 OSS HEAD **读不到 content-length**（响应里只有
 *   last-modified / content-type / etag），于是面板把体积显示成 0 B；
 *   同一个 URL 在普通 Chrome 里 HEAD 能正常拿到 content-length（383 B 的对象实测）。
 *   即容器运行时对响应头做了筛选，而浏览器不会。
 *   Content-Length / Last-Modified 都属 CORS 安全列表响应头，跨源直接可读，
 *   不需要给 bucket 加 ExposeHeaders。
 *   （push 返回的 bytes 是本服务按收到的字节数算的，与响应头无关，始终准确。） */
const CLOUD_CODE_RE = /^[A-Za-z0-9_-]{8,64}$/;
const CLOUD_PREFIX = 'jsos-sync/';

/* WebDAV 云同步的模块级状态（不能放在请求处理器里，否则每个请求都重置） */
const WEBDAV_CONFIG_PATH = path.join(DATA_DIR, 'webdav-config.json');
/** 直连可用性：null=未探测 / true=可用 / false=本会话直接走代理 */
let __davDirectUsable = null;

/** 当前生效的代理配置（云同步借它去要 OSS 签名） */
function activeProxy() {
  try {
    const cfg = readProxyConfig();
    const list = Array.isArray(cfg.configs) ? cfg.configs : [];
    const hit = list.find(c => c.id === cfg.activeId) || list.find(c => c.isDefault) || list[0];
    if (hit && hit.url) {
      return { url: String(hit.url).replace(/\/+$/, ''), key: String(hit.key || '') };
    }
  } catch { /* 落到默认 */ }
  return { url: DEFAULT_PROXY_URL, key: 'hello-world' };
}

/** 同步码 → 对象 key（非法字符一律拒绝，避免路径注入） */
function cloudObjectKey(code) {
  if (!CLOUD_CODE_RE.test(String(code || ''))) return null;
  return CLOUD_PREFIX + code + '.json';
}

/** 向 /oss-sign 要一条预签名 URL */
async function signedOssUrl(objectKey, op) {
  const { url, key } = activeProxy();
  const qs = new URLSearchParams({ key: objectKey, op, 'x-cors-proxy-key': key });
  const r = await fetch(`${url}/oss-sign?${qs.toString()}`);
  let j = null;
  try { j = await r.json(); } catch { j = null; }
  if (!j || !j.ok) throw new Error((j && j.message) || `签名服务返回 ${r.status}`);
  return j.url;
}

function readProxyConfig() {
  try {
    if (!fs.existsSync(PROXY_CONFIG_PATH)) {
      fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(DEFAULT_DATA, null, 2), 'utf8');
      return DEFAULT_DATA;
    }
    const raw = fs.readFileSync(PROXY_CONFIG_PATH, 'utf8');
    const data = JSON.parse(raw);
    // 兼容：确保有 default 配置
    if (!data.configs || !Array.isArray(data.configs)) {
      return DEFAULT_DATA;
    }
    // 迁移：官方旧代理地址 → 自建 jsos-cors-proxy（升级保数据的容器自动切换）
    let migrated = false;
    for (const c of data.configs) {
      if (c.url === LEGACY_PROXY_URL) {
        c.url = DEFAULT_PROXY_URL;
        c.updatedAt = Date.now();
        migrated = true;
      }
    }
    if (migrated) writeProxyConfig(data);
    const hasDefault = data.configs.some(c => c.isDefault);
    if (!hasDefault) {
      data.configs.unshift(DEFAULT_DATA.configs[0]);
    }
    if (!data.activeId) {
      data.activeId = 'default';
    }
    return data;
  } catch {
    return DEFAULT_DATA;
  }
}

function writeProxyConfig(data) {
  fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(data, null, 2), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  // CORS headers for API
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // API: proxy configs
  if (pathname === '/api/proxy-configs') {
    try {
      if (req.method === 'GET') {
        const data = readProxyConfig();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(data));
      }
      if (req.method === 'PUT') {
        const body = await readBody(req);
        const data = JSON.parse(body);
        writeProxyConfig(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: true }));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  /* ---------------- 云同步 API（数据存 OSS，预签名直传） ---------------- */

  if (pathname === '/api/cloud-sync/meta' || pathname === '/api/cloud-sync/push' || pathname === '/api/cloud-sync/pull') {
    const code = url.searchParams.get('code') || '';
    const objectKey = cloudObjectKey(code);
    if (!objectKey) {
      return sendJson(res, 400, { ok: false, error: '同步码格式无效：需 8-64 位，仅限字母、数字、下划线与连字符' });
    }

    // 查询：只签发一条 head 用的 URL，**HEAD 由前端自己做**（见下面注释）
    if (pathname === '/api/cloud-sync/meta') {
      try {
        const signed = await signedOssUrl(objectKey, 'head');
        return sendJson(res, 200, { ok: true, url: signed });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }

    // 上传：取签名 → 直连 OSS PUT（数据不经平台代理，故无体积上限）
    if (pathname === '/api/cloud-sync/push') {
      let body;
      try {
        body = await readBodyBuffer(req);
      } catch {
        return sendJson(res, 400, { ok: false, error: '读取请求体失败' });
      }
      if (!body || body.length === 0) {
        return sendJson(res, 400, { ok: false, error: '请求体为空' });
      }
      // 覆盖前先确认这是一份 JSOS 备份：否则一次误调用就会把云端好备份冲掉
      // （对象名由同步码决定，写进去就是覆盖，没有版本可回退）。
      let parsed = null;
      try { parsed = JSON.parse(body.toString('utf8')); } catch { parsed = null; }
      if (!parsed) {
        return sendJson(res, 400, { ok: false, error: '请求体不是合法 JSON' });
      }
      if (!parsed._version || !parsed.databases || typeof parsed.databases !== 'object') {
        return sendJson(res, 400, { ok: false, error: '请求体不是 JSOS 备份结构（缺少 _version / databases）' });
      }
      try {
        const signed = await signedOssUrl(objectKey, 'put');
        // ⚠️ 绝不要设置 Content-Type：OSS 的 URL 签名要求该头为空，否则 SignatureDoesNotMatch
        const r = await fetch(signed, { method: 'PUT', body });
        if (!r.ok) {
          const txt = await r.text().catch(() => '');
          return sendJson(res, 502, { ok: false, error: `上传到 OSS 失败 (${r.status}) ${String(txt).slice(0, 200)}` });
        }
        return sendJson(res, 200, { ok: true, bytes: body.length, syncDate: new Date().toISOString() });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: errMsg(e) });
      }
    }

    // 恢复：取签名 → 直连 OSS GET
    if (pathname === '/api/cloud-sync/pull') {
      try {
        const signed = await signedOssUrl(objectKey, 'get');
        const r = await fetch(signed);
        if (r.status === 404) {
          return sendJson(res, 404, { ok: false, error: '服务器上没有该同步码的备份' });
        }
        if (!r.ok) {
          return sendJson(res, 502, { ok: false, error: `从 OSS 下载失败 (${r.status})` });
        }
        const backup = await r.text();
        return sendJson(res, 200, { ok: true, backup });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }
  }

  /* ---------------- WebDAV 云同步（用户自备存储，2026-09-23 加） ----------------
   * 背景：OSS 是开发者的 bucket（存储/流量都记在开发者账上），换成「用户自己填
   * WebDAV 设置」，每个用户用自己的网盘（坚果云 / InfiniCLOUD / 自建 Nextcloud 等），
   * 开发者零成本。与 OSS 后端并存，WebDAV 为默认。
   *
   * 链路：前端 → 本服务（同源）→ davFetch：
   *   ① 先直连目标 WebDAV —— 容器内 fetch 走浏览器网络栈，只有目标自己回 CORS 头
   *      （自建 Nextcloud/Alist 配好跨域）才能成功，好处是不经任何中转、无体积上限；
   *   ② 直连失败（绝大多数公共 WebDAV 服务不回 CORS 头，坚果云 2026-09-23 实测 401 时
   *      无任何 ACAO）→ 落回自建 jsos-cors-proxy（encoded 路径 + query key 形态，
   *      jsos-apps/AGENTS.md §5.5 实测唯一可用形态）。经代理受 Vercel 函数请求体
   *      上限约束（实测 4.4 MB → 413）。
   *   直连可用性在本进程内记忆：失败一次后本次会话直接走代理，不再每次白跑预检。
   *
   * ⚠️ 代理的预检白名单必须含 PROPFIND/MKCOL（proxy.js 2026-09-23 加），部署中的
   *    代理没更新前，经代理的 PROPFIND/MKCOL 会被浏览器预检直接拦死。
   *
   * ⚠️ 容器内非标准 HTTP 方法（PROPFIND/MKCOL）的 fetch 可能**永久挂起**
   *    （2026-09-23 真机实测 test 端点一直 pending；标准方法 GET/PUT/HEAD 正常）。
   *    对策：所有 davFetch 带超时；test 用 OPTIONS、meta 超时后回退 HEAD、
   *    MKCOL 失败时上传报错并提示手动建目录。PROPFIND 在能用的环境里仍是首选
   *    （响应体 XML 里能拿到体积，绕开容器读不到 content-length 的限制）。
   *
   * 目录不存在不预先创建（绝大多数服务器的 MKCOL 语义一致）：PUT 撞 409 时逐级
   * MKCOL（已存在回 405，视为成功）后重试 PUT。
   */

  const WEBDAV_AUTH_ERR = 'WebDAV 认证失败：账号或密码不对（坚果云需使用「应用密码」，不是登录密码）';

  function normalizeWebdavConfig(raw) {
    const cfg = {
      url: String((raw && raw.url) || '').trim().replace(/\/+$/, ''),
      user: String((raw && raw.user) || '').trim(),
      pass: String((raw && raw.pass) || ''),
      dir: String((raw && raw.dir) || 'jsos-sync').trim() || 'jsos-sync',
    };
    if (!/^https?:\/\//i.test(cfg.url)) return null;
    // 目录只拒绝危险片段（路径穿越 / 反斜杠），允许中文、空格等（拼 URL 时逐段编码）
    const segs = cfg.dir.split('/').filter(Boolean);
    if (!segs.length || segs.some(s => s === '.' || s === '..' || s.includes('\\'))) return null;
    return cfg;
  }

  function readWebdavConfig() {
    try {
      if (!fs.existsSync(WEBDAV_CONFIG_PATH)) return null;
      return normalizeWebdavConfig(JSON.parse(fs.readFileSync(WEBDAV_CONFIG_PATH, 'utf8')));
    } catch { return null; }
  }

  function writeWebdavConfig(cfg) {
    fs.writeFileSync(WEBDAV_CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
  }

  /** 同步码 + 配置 → 远端目录 / 文件 URL（目录段逐段 encodeURIComponent） */
  function webdavUrls(cfg, code) {
    const segs = cfg.dir.split('/').filter(Boolean).map(s => encodeURIComponent(s));
    return {
      dirUrl: cfg.url + '/' + segs.join('/'),
      fileUrl: cfg.url + '/' + segs.join('/') + '/' + encodeURIComponent(code) + '.json',
    };
  }

  function davAuth(cfg) {
    if (!cfg.user && !cfg.pass) return null;
    return 'Basic ' + Buffer.from(cfg.user + ':' + cfg.pass, 'utf8').toString('base64');
  }

  /** 先直连、失败再代理（jsos-apps/AGENTS.md §5.5 的出站原则）。
   * ⚠️ 必须带超时：2026-09-23 真机实测，容器内 fetch 打 PROPFIND（非标准方法）会
   * **永久挂起**（直连腿与代理腿皆疑，标准方法 GET/PUT/HEAD 无此问题），不设超时
   * 整个请求就永远 pending。直连腿 8s 探路，代理腿按业务给 15~90s。 */
  async function fetchWithTimeout(url, init, ms) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), ms);
    try {
      return await fetch(url, { ...(init || {}), signal: ctrl.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  async function davFetch(url, init, proxyMs) {
    if (__davDirectUsable !== false) {
      try {
        const r = await fetchWithTimeout(url, init, 8000);
        __davDirectUsable = true;
        return { resp: r, via: 'direct' };
      } catch { __davDirectUsable = false; }
    }
    const { url: proxyUrl, key } = activeProxy();
    const proxied = `${proxyUrl}/${encodeURIComponent(url)}?x-cors-proxy-key=${encodeURIComponent(key)}`;
    return { resp: await fetchWithTimeout(proxied, init, proxyMs || 60000), via: 'proxy' };
  }

  /** PUT 撞 409（目录不存在）时逐级 MKCOL；201/405（已存在）都算成功。
   *  MKCOL 也可能被容器网络垫层卡死 → 15s 超时按失败处理，push 会给出手动建目录的提示。 */
  async function webdavEnsureDir(cfg) {
    const base = cfg.url;
    const segs = cfg.dir.split('/').filter(Boolean).map(s => encodeURIComponent(s));
    const auth = davAuth(cfg);
    for (let i = 0; i < segs.length; i++) {
      const u = base + '/' + segs.slice(0, i + 1).join('/');
      try {
        const { resp } = await davFetch(u, { method: 'MKCOL', headers: auth ? { authorization: auth } : {} }, 15000);
        if (![201, 405, 301, 409].includes(resp.status)) return false;
      } catch { return false; }
    }
    return true;
  }

  /** 错误信息带 cause 链（undici 的 fetch failed 真正原因在 e.cause 里） */
  function errMsg(e) {
    let m = String((e && e.message) || e);
    if (e && e.cause && e.cause.message) m += '（' + e.cause.message + '）';
    return m;
  }

  if (pathname === '/api/cloud-sync/webdav/config') {
    try {
      if (req.method === 'GET') {
        return sendJson(res, 200, { ok: true, config: readWebdavConfig() });
      }
      if (req.method === 'PUT') {
        const body = JSON.parse(await readBody(req));
        const cfg = normalizeWebdavConfig(body);
        if (!cfg) {
          return sendJson(res, 400, { ok: false, error: 'WebDAV 地址无效：需以 http(s):// 开头，且目录不含 .. 或 \\' });
        }
        writeWebdavConfig(cfg);
        return sendJson(res, 200, { ok: true });
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: e.message });
    }
  }

  if (pathname === '/api/cloud-sync/webdav/test') {
    if (req.method !== 'POST') { res.writeHead(405); return res.end('Method Not Allowed'); }
    try {
      let raw = await readBody(req);
      if (!raw || !raw.trim()) raw = '{}';   // 空 body 按「没填地址」处理，别 500
      const cfg = normalizeWebdavConfig(JSON.parse(raw));
      if (!cfg) return sendJson(res, 400, { ok: false, error: 'WebDAV 地址无效：需以 http(s):// 开头' });
      const { dirUrl } = webdavUrls(cfg, 'x');   // x 只为凑 URL 形状，实际探测的是目录
      // ⚠️ 全用标准方法（PROPFIND 在容器内会挂死，见 davFetch 注释；坚果云对
      //    HEAD/OPTIONS 目录探针还会回 401/400，2026-09-23 实测）。
      //    用 GET 探测文件：401=凭据错；404/200=连接成功（404 只说明还没有备份，
      //    目录缺失会在上传时自动创建，MKCOL 失败再由 push 报错引导）。
      const auth = davAuth(cfg);
      const probeUrl = dirUrl + '/' + encodeURIComponent('jsos-probe.json');
      const r = await davFetch(probeUrl, { method: 'GET', headers: auth ? { authorization: auth } : {} }, 20000);
      if (r.resp.status === 401 || r.resp.status === 403) {
        return sendJson(res, 200, { ok: false, error: WEBDAV_AUTH_ERR });
      }
      if (r.resp.ok || r.resp.status === 404) {
        return sendJson(res, 200, { ok: true, via: r.via });
      }
      return sendJson(res, 200, { ok: false, error: `WebDAV 服务器返回 ${r.resp.status}（${r.via === 'proxy' ? '经代理' : '直连'}）` });
    } catch (e) {
      return sendJson(res, 502, { ok: false, error: '连接失败：' + errMsg(e) });
    }
  }

  if (pathname === '/api/cloud-sync/webdav/meta' || pathname === '/api/cloud-sync/webdav/push' || pathname === '/api/cloud-sync/webdav/pull') {
    const code = url.searchParams.get('code') || '';
    if (!CLOUD_CODE_RE.test(code)) {
      return sendJson(res, 400, { ok: false, error: '同步码格式无效：需 8-64 位，仅限字母、数字、下划线与连字符' });
    }
    const cfg = readWebdavConfig();
    if (!cfg) {
      return sendJson(res, 400, { ok: false, error: '尚未配置 WebDAV：请先填写服务器地址并保存' });
    }
    const { fileUrl } = webdavUrls(cfg, code);
    const auth = davAuth(cfg);

    // 查询：**只用 GET**（整文件 GET 兜底经验证最可靠，2026-09-23 升级为主路）。
    // PROPFIND 彻底移除：容器内非标准方法会被网络垫层卡死（挂起一次还连累
    // 后续请求报 fetch failed），且 GET 已能拿到全部所需信息——
    // 404=无备份；200=有备份，体积=响应体字节长（精确），时间=last-modified 头。
    // 代价是状态查询会下载整份备份（剥离后通常只有几 MB），可接受。
    if (pathname === '/api/cloud-sync/webdav/meta') {
      try {
        const { resp } = await davFetch(fileUrl, { method: 'GET', headers: auth ? { authorization: auth } : {} }, 30000);
        if (resp.status === 404) return sendJson(res, 200, { ok: true, exists: false });
        if (resp.status === 401 || resp.status === 403) return sendJson(res, 502, { ok: false, error: WEBDAV_AUTH_ERR });
        if (!resp.ok) return sendJson(res, 502, { ok: false, error: `WebDAV 查询失败 (${resp.status})` });
        const lm = resp.headers.get('last-modified');
        const d = lm ? new Date(lm) : null;
        const buf = await resp.arrayBuffer().catch(() => null);
        // 时间优先从备份内容里的 _syncDate 取（上传时写入，2026-09-23 加）——
        // 容器 fetch 会把 last-modified 响应头滤掉，头部不可靠。
        let syncDate = d && !isNaN(d.getTime()) ? d.toISOString() : '';
        if (buf && !syncDate) {
          try {
            const j = JSON.parse(Buffer.from(buf).toString('utf8'));
            if (j && j._syncDate) {
              const d2 = new Date(j._syncDate);
              if (!isNaN(d2.getTime())) syncDate = d2.toISOString();
            }
          } catch { /* 非 JSON/无字段就算了 */ }
        }
        return sendJson(res, 200, {
          ok: true,
          exists: true,
          bytes: buf ? buf.byteLength : null,
          syncDate,
        });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: '查询失败：' + errMsg(e) });
      }
    }

    // 上传：覆盖前校验备份结构（同 OSS，见下方 push 的注释），409 时建目录重试
    if (pathname === '/api/cloud-sync/webdav/push') {
      let body;
      try {
        body = await readBodyBuffer(req);
      } catch {
        return sendJson(res, 400, { ok: false, error: '读取请求体失败' });
      }
      if (!body || body.length === 0) {
        return sendJson(res, 400, { ok: false, error: '请求体为空' });
      }
      let parsed = null;
      try { parsed = JSON.parse(body.toString('utf8')); } catch { parsed = null; }
      if (!parsed) return sendJson(res, 400, { ok: false, error: '请求体不是合法 JSON' });
      if (!parsed._version || !parsed.databases || typeof parsed.databases !== 'object') {
        return sendJson(res, 400, { ok: false, error: '请求体不是 JSOS 备份结构（缺少 _version / databases）' });
      }
      try {
        let { resp } = await davFetch(fileUrl, { method: 'PUT', headers: auth ? { authorization: auth } : {}, body }, 90000);
        if (resp.status === 409) {
          const created = await webdavEnsureDir(cfg);
          if (created) {
            resp = (await davFetch(fileUrl, { method: 'PUT', headers: auth ? { authorization: auth } : {}, body }, 90000)).resp;
          } else {
            return sendJson(res, 502, { ok: false, error: `远端目录（${cfg.dir}）不存在且自动创建失败：可在网盘网页端手动建好目录后重试` });
          }
        }
        if (resp.status === 401 || resp.status === 403) return sendJson(res, 502, { ok: false, error: WEBDAV_AUTH_ERR });
        if (resp.status === 413) return sendJson(res, 502, { ok: false, error: '上传失败：经代理中转的单次体积上限约 4 MB（自建 WebDAV 开启 CORS 可直连、无上限）' });
        if (!resp.ok) {
          const txt = await resp.text().catch(() => '');
          return sendJson(res, 502, { ok: false, error: `上传到 WebDAV 失败 (${resp.status}) ${String(txt).slice(0, 200)}` });
        }
        return sendJson(res, 200, { ok: true, bytes: body.length, syncDate: new Date().toISOString() });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: errMsg(e) });
      }
    }

    // 恢复：GET 文件
    if (pathname === '/api/cloud-sync/webdav/pull') {
      try {
        const { resp } = await davFetch(fileUrl, { method: 'GET', headers: auth ? { authorization: auth } : {} }, 90000);
        if (resp.status === 404) {
          return sendJson(res, 404, { ok: false, error: '服务器上没有该同步码的备份' });
        }
        if (resp.status === 401 || resp.status === 403) {
          return sendJson(res, 502, { ok: false, error: WEBDAV_AUTH_ERR });
        }
        if (!resp.ok) {
          return sendJson(res, 502, { ok: false, error: `从 WebDAV 下载失败 (${resp.status})` });
        }
        const backup = await resp.text();
        return sendJson(res, 200, { ok: true, backup });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }
  }

  // Static file serving
  let decoded = decodeURIComponent(pathname);

  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }

  let target = path.resolve(path.join(ROOT, decoded));

  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  // 目录默认 index.html
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }

  fs.readFile(target, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

server.listen(process.env.PORT, () => console.log(process.env.PORT));
