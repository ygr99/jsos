// 桌面宠物小组件：宠物住在桌面上，点击切换动作，状态条实时显示
// 数据经 /api/state 存服务端 DATA_DIR（与主界面共享），BroadcastChannel 跨 iframe 同步
import {
  loadData, saveData, applyDecay, SpriteAnimator, ANIM_KEYS, sheetUrlOf,
  defaultData, onExternalChange,
} from './pet-core.js';

let data = defaultData();
let animator = null;

function currentPet() {
  return data.pets.find(p => p.id === data.currentPetId) || data.pets[0];
}

function render() {
  const pet = currentPet();
  if (!pet) return;
  document.getElementById('pet-name').textContent = pet.name;
  document.getElementById('w-hunger').style.width = pet.hunger + '%';
  document.getElementById('w-mood').style.width = pet.happiness + '%';
  document.getElementById('w-energy').style.width = pet.energy + '%';
  if (animator.sheetUrl !== sheetUrlOf(pet)) animator.setSheet(sheetUrlOf(pet));
}

async function reload() {
  data = await loadData();
  render();
}

function tick() {
  const pet = currentPet();
  if (!pet) return;
  applyDecay(pet);
  saveData(data);   // 衰减写回，主界面经 BroadcastChannel 同步
  render();
}

async function init() {
  data = await loadData();
  const pet = currentPet();
  if (pet) applyDecay(pet);

  animator = new SpriteAnimator(document.getElementById('pet-sprite'), {
    sheetUrl: sheetUrlOf(pet || {}),
    displayWidth: 150,
  });
  animator.play((pet && pet.currentAnimation) || 'idle');

  // 点击宠物切换动作（并保存偏好，主界面同步）
  document.getElementById('pet-sprite').addEventListener('click', () => {
    const p = currentPet();
    if (!p) return;
    const idx = ANIM_KEYS.indexOf(animator.currentAnimation);
    const next = ANIM_KEYS[(idx + 1) % ANIM_KEYS.length];
    animator.play(next);
    p.currentAnimation = next;
    saveData(data);
  });

  // 主界面/其他窗口改动 → 拉取服务端最新状态
  onExternalChange(reload);

  render();
  setInterval(tick, 60000);
}

document.addEventListener('DOMContentLoaded', init);
