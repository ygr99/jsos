// petdex 宠物库：拉取 petdex.dev 全量目录 → 裁剪索引落盘 → 本地搜索/筛选/分页
// 零依赖，只用 Node 内置模块（与仓库「服务端零依赖」约定一致）。
//
// 为什么走 manifest 而不用 /api/pets/search：
//   search 端点实测**不带 Access-Control-Allow-Origin**（2026-10-04 curl 核对），
//   容器内 fetch 受 CORS 约束 → 必失败，得再挂一层平台代理。
//   manifest（307 → assets.petdex.dev）两跳都带 ACAO:*，可直连。
//   4874 条在内存里做搜索/分类/排序/分页是纯本地操作，比 search + manifest
//   双缓存 + 降级混源（uTools 插件那套）简单一个数量级。
//   代价是拿不到安装量/likeCount —— 那些字段只在 search 端点里有，故不提供热度排序。
//
// ⚠️ 缩略图**必须直连 assets 的最终地址**，不能走 /api/pets/<slug>/thumb：
//   那个 API 端点是 308 跳到 assets.petdex.dev/pets/<slug>/thumb.webp，而**这一跳不带
//   ACAO**（2026-10-04 curl 核对）→ 容器内 fetch 被 CORS 拦掉 → 整页缩略图全 404。
//   manifest 的 307 带 ACAO 所以它能直连。别拿本机 curl 测了就算数：
//   宿主机 Node 的 https.get 不受 CORS 约束，只有容器内才受限（真机实测 4874 只全「无预览」）。
import https from 'node:https';
import { existsSync, mkdirSync, readFileSync, writeFileSync, statSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';

const MANIFEST_URL = 'https://petdex.dev/api/manifest';
// 缩略图：主地址是 assets 的最终路径（带 ACAO，容器内可直连）；
// THUMB_API_URL 是官方 API 端点，仅作 404 时的兜底 —— 它 308 到同一张图但那一跳不带 ACAO，
// 容器内必被 CORS 拦，所以不能当主地址。
const THUMB_URL = (slug) => 'https://assets.petdex.dev/pets/' + encodeURIComponent(slug) + '/thumb.webp';
const THUMB_API_URL = (slug) => 'https://petdex.dev/api/pets/' + encodeURIComponent(slug) + '/thumb';

const INDEX_TTL = 24 * 3600 * 1000;   // 目录缓存 1 天
const THUMB_TTL = 7 * 24 * 3600 * 1000; // 缩略图缓存 7 天（纯预览，坏了重下就是 2.5KB）

// 分类就是 petdex 的全部三类（character / creature / object），由前端展示
// slug 会拼进文件名，必须严白名单 —— 否则 /api/library/thumb/..%2f.. 就能穿越目录
const SLUG_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/i;

// DATA_DIR 由 server.js 启动时注入：索引/缩略图落在 DATA_DIR/dex/（与应用自身数据分开，
// 随卸载一并清除），精灵图复用 uploads/ —— 那里已经有静态路由
let dexRoot = '';
let uploadRoot = '';
export function configure(dataDir, uploadsDir) {
  dexRoot = join(dataDir, 'dex');
  uploadRoot = uploadsDir;
}

function ensureDir(dir) { if (!existsSync(dir)) mkdirSync(dir, { recursive: true }); return dir; }
function indexFile() { return join(ensureDir(dexRoot), 'index.json'); }
function thumbFile(slug) { return join(ensureDir(join(dexRoot, 'thumbs')), slug + '.webp'); }

// ---------- HTTP ----------

function httpGet(url, asBuffer, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'user-agent': 'virtual-pet' } }, (res) => {
      // 跨主机重定向：manifest 307 → assets.petdex.dev；thumb 308 → 同域 /pets/<slug>/thumb.webp
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.destroy();
        return resolve(httpGet(new URL(res.headers.location, url).href, asBuffer, timeoutMs));
      }
      if (res.statusCode !== 200) { res.destroy(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        resolve(asBuffer ? buf : buf.toString('utf8'));
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error('请求超时')));
  });
}

// 缩略图单独一个函数而不是给 httpGet 加参数：要读 content-type ——
// 坏 slug 会回 404 text/plain，当成图片存下去就是一张永远加载不出来的坏缓存（而且缓存 7 天）
function httpGetImage(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'user-agent': 'virtual-pet', accept: 'image/webp,image/*' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.destroy();
        return resolve(httpGetImage(new URL(res.headers.location, url).href));
      }
      if (res.statusCode !== 200) { res.destroy(); return reject(new Error('HTTP ' + res.statusCode)); }
      const type = String(res.headers['content-type'] || '');
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        if (!type.startsWith('image/')) return reject(new Error('返回的不是图片：' + type));
        resolve(Buffer.concat(chunks));
      });
    });
    req.on('error', reject);
    req.setTimeout(30000, () => req.destroy(new Error('缩略图下载超时')));
  });
}

// ---------- 索引 ----------

let memIndex = null;        // { fetchedAt, total, kinds, pets }
let memIndexStale = false;  // 「刷新目录」把它置脏：下次用到先去网络拉一次，拉不到再退回旧的
let inflight = null;        // 在途的拉取 promise —— 冷启动并发请求共用一次 1.65MB 下载

// 裁成 6 个字段：1.65MB → 950KB。description / zipUrl / petJsonUrl 用不上，不带。
// kind 计数在这里现算 —— 它是全库计数，不随筛选收窄。
function project(raw) {
  const pets = [];
  const kinds = {};
  for (const p of raw) {
    const slug = String(p.slug || '').toLowerCase();
    if (!SLUG_RE.test(slug)) continue;                 // 非法 slug 直接丢，不进索引
    const kind = String(p.kind || '');
    pets.push({
      slug,
      name: String(p.displayName || slug),
      kind,
      rows: Number(p.spriteVersionNumber) === 2 ? 11 : 9,   // Codex 网格 V1=8×9 / V2=8×11
      by: p.submittedBy || '',
      url: p.spritesheetUrl || '',
    });
    kinds[kind] = (kinds[kind] || 0) + 1;
  }
  // 先按名称排一次：让「名称」排序与分页都稳定（不排的话分页会随刷新跳动）
  pets.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
  return { total: pets.length, kinds, pets };
}

function readDiskIndex() {
  try {
    const j = JSON.parse(readFileSync(indexFile(), 'utf8'));
    if (!Array.isArray(j.pets) || !j.pets.length) return null;
    return j;
  } catch (e) { return null; }   // 没缓存 / 缓存坏了都当没有：下次成功拉取会覆盖它
}

async function getIndex(opts = {}) {
  const force = !!opts.refresh;
  const fresh = (c) => c && Date.now() - c.fetchedAt < INDEX_TTL;
  if (!force && !memIndexStale) {
    if (fresh(memIndex)) return memIndex;
    const disk = memIndex || readDiskIndex();
    if (fresh(disk)) { memIndex = disk; return disk; }
  }
  // 冷启动时前端可能并发好几个请求（切 tab + 搜索 + 加载更多），
  // 不共用的话每次都要下 1.65MB
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const raw = JSON.parse(await httpGet(MANIFEST_URL, false, 60000));
      const list = Array.isArray(raw) ? raw : (raw.pets || raw.data || []);
      if (!list.length) throw new Error('petdex 返回的目录是空的');
      const idx = Object.assign({ fetchedAt: Date.now() }, project(list));
      memIndex = idx;
      memIndexStale = false;
      try { writeFileSync(indexFile(), JSON.stringify(idx)); } catch (e) { /* 缓存写不进去不该让浏览失败 */ }
      return idx;
    } catch (e) {
      const disk = memIndex || readDiskIndex();
      if (disk) { memIndex = disk; return disk; }   // 网络挂了 → 退回旧目录
      throw new Error('宠物目录获取失败：' + (e.message || e));
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

// ---------- 查询 ----------

// 筛选/排序/分页全在内存做；cursor 是偏移量（与 petdex search 端点语义一致）
export async function library(opts = {}) {
  const idx = await getIndex(opts);
  const q = String(opts.q || '').trim().toLowerCase();
  const kind = String(opts.kind || '');
  const sort = opts.sort === 'random' ? 'random' : 'name';
  const cursor = Math.max(0, Number(opts.cursor) || 0);
  const limit = Math.min(Math.max(Number(opts.limit) || 24, 1), 60);

  let list = idx.pets;
  if (kind) list = list.filter((p) => p.kind === kind);
  if (q) list = list.filter((p) => p.name.toLowerCase().includes(q) || p.slug.includes(q));
  if (sort === 'random') list = list.slice().sort((a, b) => hash(a.slug) - hash(b.slug));
  const page = list.slice(cursor, cursor + limit);
  return {
    fetchedAt: idx.fetchedAt,
    total: list.length,
    kinds: idx.kinds,
    pets: page,
    cursor,
    hasMore: cursor + page.length < list.length,
  };
}

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

// ---------- 缩略图 ----------

// 必须经服务端同源转发：assets.petdex.dev 只有 ACAO 没有 CORP，
// 而 JSOS 强制 COEP: require-corp → 前端 <img> 直连那张图必被拦。
export async function thumb(slug) {
  const s = String(slug || '').toLowerCase();
  if (!SLUG_RE.test(s)) return null;
  const file = thumbFile(s);
  let old = null;
  try { const st = statSync(file); if (st.size > 0) old = st; } catch (e) {}
  if (old && Date.now() - old.mtimeMs < THUMB_TTL) return file;
  // 两级地址：主用 assets 最终地址；它 404（少数 slug 没有预览图）时再退回官方 API 端点。
  // 两条路都不带 ACAO 的那条在容器内必然被 CORS 拦，所以顺序不能反。
  for (const url of [THUMB_URL(s), THUMB_API_URL(s)]) {
    try {
      writeFileSync(file, await httpGetImage(url));
      return file;
    } catch (e) { /* 试下一条 */ }
  }
  // 都抓不到（断网 / 端点抽风）→ 有过期的旧图也照用：有图总比占位强
  return old ? file : null;
}

// ---------- 精灵图下载 ----------

// 同 slug 已落盘就直接复用，不重复走网络（「重新下载」除外，走 refresh）
export async function fetchSprite(slug, opts = {}) {
  const s = String(slug || '').toLowerCase();
  if (!SLUG_RE.test(s)) throw new Error('非法的宠物标识');
  const entry = (await getIndex()).pets.find((p) => p.slug === s);
  if (!entry) throw new Error('宠物库中没有这只宠物');
  if (!entry.url) throw new Error('该宠物缺少精灵图地址');

  const existing = existingSprite(s);
  if (existing && !opts.refresh) {
    return { url: existing, name: entry.name, rows: entry.rows, cached: true };
  }
  const buf = await httpGet(entry.url, true, 90000);
  if (buf.length < 1024) throw new Error('下载到的精灵图异常（太小）');
  const name = `dex_${s}.${/\.webp(\?|$)/i.test(entry.url) ? 'webp' : 'png'}`;
  writeFileSync(join(uploadRoot, name), buf);
  return { url: '/uploads/' + name, name: entry.name, rows: entry.rows, bytes: buf.length, cached: false };
}

function existingSprite(slug) {
  for (const ext of ['webp', 'png']) {
    const name = `dex_${slug}.${ext}`;
    try { if (statSync(join(uploadRoot, name)).size > 0) return '/uploads/' + name; } catch (e) {}
  }
  return null;
}

// 卸下宠物时清掉素材，避免 DATA_DIR 越攒越大（它会被平台快照进 IndexedDB，有配额）
export function removeSprite(slug) {
  const s = String(slug || '').toLowerCase();
  if (!SLUG_RE.test(s)) return false;
  let removed = false;
  for (const ext of ['webp', 'png']) {
    try { unlinkSync(join(uploadRoot, `dex_${s}.${ext}`)); removed = true; } catch (e) {}
  }
  return removed;
}
