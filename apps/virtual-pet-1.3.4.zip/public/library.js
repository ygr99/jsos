// 宠物库前端：搜索 / 分类 / 排序 / 分页 / 下载 / 切换
// 目录查询打 /api/library（服务端内存里筛），缩略图打 /api/library/thumb（同源，绕开 COEP）
import { newPet } from './pet-core.js';

const PAGE_SIZE = 24;

// 排序选项：只有名称和随机。安装量/热度排序需要 petdex 的 search 端点，
// 而它不带 ACAO → 容器内拿不到，故不提供（详见 petdex.js 顶部注释）。
const SORTS = [
  { key: 'name', label: '名称' },
  { key: 'random', label: '随机' },
];

// 分类 = petdex 的全部三类（character / creature / object）+ 一个「全部」
const KIND_TABS = [
  { key: '', label: '全部' },
  { key: 'character', label: '角色' },
  { key: 'creature', label: '生物' },
  { key: 'object', label: '物品' },
];

let ctx = null;          // { data, persist, refreshPet, afterPetSwitched, renderPetList, showToast }
let q = '';
let kind = '';
let sort = 'name';
let cursor = 0;
let total = 0;
let hasMore = false;
let loading = false;
let loaded = false;      // 是否已经拉过一次（tab 首次切入才拉）
let inFlight = new Map(); // slug → true，防止同一只重复点

export function initLibrary(context) {
  ctx = context;
  bindEvents();
}

function bindEvents() {
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // 防抖：4874 条在服务端筛很快，但每敲一下就发请求没必要
  let timer = null;
  document.getElementById('lib-search').addEventListener('input', (e) => {
    q = e.target.value.trim();
    clearTimeout(timer);
    timer = setTimeout(() => reload(), 260);
  });

  document.getElementById('lib-refresh').addEventListener('click', () => {
    document.getElementById('lib-refresh').classList.add('spinning');
    reload(true);
  });

  document.getElementById('lib-more').addEventListener('click', () => loadMore());

  // 事件委托：卡片是动态生成的
  document.getElementById('lib-grid').addEventListener('click', (e) => {
    const btn = e.target.closest('.lib-act');
    if (!btn) return;
    const slug = btn.dataset.slug;
    if (!slug) return;
    if (btn.dataset.mode === 'use') usePet(slug);
    else downloadPet(slug, btn);
  });
}

function switchView(view) {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  document.getElementById('view-my').hidden = view !== 'my';
  document.getElementById('view-library').hidden = view !== 'library';
  // 首次切入才拉目录：应用启动就吃 1.65MB 没必要
  if (view === 'library' && !loaded) reload();
}

async function reload(refreshIndex) {
  cursor = 0;
  loading = true;
  const meta = document.getElementById('lib-meta');
  meta.textContent = '正在加载宠物目录…';
  meta.classList.remove('lib-error');
  document.getElementById('lib-refresh').classList.add('spinning');
  try {
    const r = await query({ refresh: refreshIndex });
    total = r.total;
    hasMore = r.hasMore;
    loaded = true;
    renderKinds(r.kinds);
    renderGrid(r.pets, true);
    renderMeta(r);
  } catch (e) {
    meta.textContent = '加载失败：' + (e.message || e);
    meta.classList.add('lib-error');
    document.getElementById('lib-grid').innerHTML = '';
  } finally {
    loading = false;
    document.getElementById('lib-refresh').classList.remove('spinning');
  }
}

async function loadMore() {
  if (loading || !hasMore) return;
  loading = true;
  const btn = document.getElementById('lib-more');
  btn.textContent = '加载中…';
  try {
    const r = await query({ cursor });
    total = r.total;
    hasMore = r.hasMore;
    cursor = r.cursor;
    renderGrid(r.pets, false);
    renderMeta(r);
  } catch (e) {
    ctx.showToast('加载失败：' + (e.message || e));
  } finally {
    loading = false;
    btn.textContent = '加载更多';
    updateMore();
  }
}

function query(extra) {
  const p = new URLSearchParams();
  if (q) p.set('q', q);
  if (kind) p.set('kind', kind);
  if (sort !== 'name') p.set('sort', sort);
  p.set('cursor', String((extra && extra.cursor) || 0));
  p.set('limit', String(PAGE_SIZE));
  if (extra && extra.refresh) p.set('refresh', '1');
  return fetch('/api/library?' + p.toString(), { cache: 'no-store' }).then(async (res) => {
    const d = await res.json();
    if (!res.ok) throw new Error(d.error || ('HTTP ' + res.status));
    return d;
  });
}

function renderMeta(r) {
  const d = new Date(r.fetchedAt || Date.now());
  const pad = (n) => String(n).padStart(2, '0');
  const stamp = `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const el = document.getElementById('lib-meta');
  el.classList.remove('lib-error');
  el.innerHTML = '共 ' + r.total + ' 只 · 目录更新于 ' + stamp +
    ' · 来源 <a href="https://petdex.dev" target="_blank">petdex.dev</a>';
}

function renderKinds(kinds) {
  const box = document.getElementById('lib-kinds');
  box.innerHTML = '';
  KIND_TABS.forEach(k => {
    const b = document.createElement('button');
    b.className = 'lib-kind' + (k.key === kind ? ' active' : '');
    const n = k.key ? (kinds && kinds[k.key]) || 0 : total;
    b.textContent = k.label + ' ' + n;
    b.addEventListener('click', () => {
      if (kind === k.key) return;
      kind = k.key;
      renderKinds(kinds);
      reload();
    });
    box.appendChild(b);
  });
  const sel = document.createElement('select');
  sel.className = 'lib-sort';
  SORTS.forEach(s => {
    const o = document.createElement('option');
    o.value = s.key;
    o.textContent = '排序：' + s.label;
    if (s.key === sort) o.selected = true;
    sel.appendChild(o);
  });
  sel.addEventListener('change', () => { sort = sel.value; reload(); });
  box.appendChild(sel);
}

function renderGrid(pets, replace) {
  const grid = document.getElementById('lib-grid');
  if (replace) grid.innerHTML = '';
  pets.forEach(p => grid.appendChild(buildCard(p)));
  updateMore();
}

function buildCard(p) {
  const card = document.createElement('div');
  card.className = 'lib-card';
  const installed = installedPetOf(p.slug);
  const current = installed && installed.id === ctx.data.currentPetId;

  card.innerHTML =
    '<div class="lib-thumb" data-slug="' + p.slug + '">…</div>' +
    '<div class="lib-name" title="' + escapeHtml(p.name) + '">' + escapeHtml(p.name) +
      (p.rows === 11 ? '<span class="lib-v2" title="11 行精灵图">V2</span>' : '') + '</div>' +
    '<div class="lib-by">' + escapeHtml(p.by ? 'by ' + p.by : p.slug) + '</div>';

  const btn = document.createElement('button');
  btn.className = 'lib-act';
  btn.dataset.slug = p.slug;
  if (installed) {
    btn.textContent = current ? '使用中' : '使用';
    btn.classList.add('use');
    if (current) { btn.classList.add('busy'); btn.disabled = true; }
    else btn.dataset.mode = 'use';
  } else {
    btn.textContent = '下载';
  }
  card.appendChild(btn);

  // 缩略图懒加载：一次只取当前页 24 张（每张 2.5KB），进视口才请求
  //
  // 用 Image() 预加载而不是直接设 background-image —— 后者加载失败**不触发** error
  // 事件（2026-10-04 puppeteer 实测：0 次），少数没有预览的 slug 会一直停在「…」。
  // Image 有真实的 onerror，才能给出确定的失败态。
  const thumb = card.querySelector('.lib-thumb');
  const io = new IntersectionObserver((entries) => {
    if (!entries.some(e => e.isIntersecting)) return;
    io.disconnect();
    thumb.textContent = '';
    // 同源代理：petdex 的图只有 ACAO 没有 CORP，JSOS 强制 COEP，前端直连那张图必被拦
    const url = '/api/library/thumb/' + encodeURIComponent(p.slug);
    const img = new Image();
    img.onload = () => { thumb.style.backgroundImage = 'url(' + url + ')'; };
    img.onerror = () => { thumb.textContent = '无预览'; };
    img.src = url;
  }, { rootMargin: '200px' });
  io.observe(thumb);

  return card;
}

function updateMore() {
  const btn = document.getElementById('lib-more');
  btn.hidden = !hasMore;
  document.getElementById('lib-more-info').textContent =
    '已显示 ' + document.querySelectorAll('.lib-card').length + ' / ' + total;
}

function installedPetOf(slug) {
  return ctx.data.pets.find(p => p.slug === slug) || null;
}

async function downloadPet(slug, btn) {
  if (inFlight.has(slug)) return;
  const exist = installedPetOf(slug);
  inFlight.set(slug, true);
  btn.classList.add('busy');
  btn.classList.remove('use');
  const label = btn.textContent;
  btn.textContent = '下载中…';
  try {
    const r = await fetch('/api/library/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ slug, refresh: !!exist }),
    }).then(async (res) => {
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || ('HTTP ' + res.status));
      return d;
    });

    if (exist) {
      // 已有 → 只换精灵图（对应截图里的「重新下载」）
      exist.spritesheetUrl = r.url;
      exist.rows = r.rows;
    } else {
      const p = newPet(r.name, r.url, r.rows);
      p.id = 'dex_' + slug + '_' + Date.now();
      p.slug = slug;
      ctx.data.pets.push(p);
      ctx.data.currentPetId = p.id;
    }
    ctx.persist();
    ctx.refreshPet();
    ctx.afterPetSwitched();
    refreshCardStates();
    ctx.showToast(exist ? '已更新「' + r.name + '」的精灵图' : '已添加「' + r.name + '」');
  } catch (e) {
    ctx.showToast('下载失败：' + (e.message || e));
    btn.classList.remove('busy');
    btn.textContent = label;
  } finally {
    inFlight.delete(slug);
  }
}

// 刷新网格里所有卡片的按钮态（下载完成后 / 删除宠物后）
function refreshCardStates() {
  document.querySelectorAll('.lib-card').forEach(card => {
    const btn = card.querySelector('.lib-act');
    if (!btn) return;
    const installed = installedPetOf(btn.dataset.slug);
    if (!installed) return;
    const current = installed.id === ctx.data.currentPetId;
    btn.classList.add('use');
    btn.classList.toggle('busy', current);
    btn.disabled = current;
    btn.textContent = current ? '使用中' : '使用';
    if (!current) btn.dataset.mode = 'use';
  });
}

function usePet(slug) {
  const p = installedPetOf(slug);
  if (p) switchToPet(p.id);
}

function switchToPet(petId) {
  if (ctx.data.currentPetId === petId) return;
  ctx.data.currentPetId = petId;
  ctx.persist();
  ctx.refreshPet();
  ctx.afterPetSwitched();
  refreshCardStates();
}

export function onLibraryDataChanged() {
  if (document.getElementById('view-library').hidden) return;
  refreshCardStates();
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
