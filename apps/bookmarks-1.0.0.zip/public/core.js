/**
 * bookmarks 共享核心（普通脚本，挂在 window.BM 上；主页面与小组件共用）
 *
 * 存储：数据经 /api/state 存到服务端 DATA_DIR（JSOS 容器内 = workspace/data/bookmarks，
 * 平台卸载勾选「同时删除应用数据」时整目录清除——唯一会被真正清理的位置）。
 * 同步：主页面 ↔ 小组件用 BroadcastChannel 通知 + 60s/可见性兜底轮询。
 */
(function () {
  const SYNC_CHANNEL = 'bookmarks-sync';
  const SYNC_TOKEN = Math.random().toString(36).slice(2) + Date.now().toString(36);

  const DEFAULT_WIDGET_TITLE = '常用书签';

  /** 首次启动（服务端还没有数据文件）时的示例书签 */
  const SEED_STATE = {
    widgetTitle: DEFAULT_WIDGET_TITLE,
    bookmarks: [
      { id: 'seed-github', title: 'GitHub', url: 'https://github.com', desktop: true, createdAt: 0 },
      { id: 'seed-chatgpt', title: 'ChatGPT', url: 'https://chatgpt.com', desktop: true, createdAt: 0 },
      { id: 'seed-youtube', title: 'YouTube', url: 'https://www.youtube.com', desktop: true, createdAt: 0 },
      { id: 'seed-gmail', title: 'Gmail', url: 'https://mail.google.com', desktop: true, createdAt: 0 },
      { id: 'seed-figma', title: 'Figma', url: 'https://www.figma.com', desktop: true, createdAt: 0 },
      { id: 'seed-notion', title: 'Notion', url: 'https://www.notion.so', desktop: true, createdAt: 0 },
    ],
  };

  /* ---------- URL 工具 ---------- */

  /** 主机名（去掉 www.），用于卡片副标题与默认标题 */
  function hostOf(url) {
    try {
      return new URL(url).hostname.replace(/^www\./i, '');
    } catch {
      return String(url || '').replace(/^https?:\/\//i, '').split('/')[0];
    }
  }

  /** 归一化 URL：补协议、去 hash、去尾斜杠；非法（非 http/https）返回 '' */
  function normalizeUrl(input) {
    let s = String(input == null ? '' : input).trim();
    if (!s) return '';
    s = s.replace(/^[<(["'“”‘’]+/, '').replace(/[>)\]"',。；;]+$/, '').trim();
    if (!s) return '';
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
      if (/^[a-z][a-z0-9+.-]*:/i.test(s) && !/^https?:/i.test(s)) return ''; // javascript: / mailto: 等一律丢弃
      s = 'https://' + s;
    }
    let url;
    try {
      url = new URL(s);
    } catch {
      return '';
    }
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
    url.hash = '';
    let out = url.href;
    if (out.endsWith('/')) out = out.slice(0, -1);
    return out;
  }

  /** 去重用的比较键（协议头之外全部小写归一） */
  function urlKey(url) {
    return normalizeUrl(url).toLowerCase();
  }

  function decodeEntities(s) {
    return String(s || '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"')
      .replace(/&#0*39;|&apos;/gi, "'")
      .replace(/&#x0*27;/gi, "'")
      .replace(/&amp;/gi, '&')
      .replace(/&#(\d+);/g, (m, d) => {
        const n = parseInt(d, 10);
        return n > 0 && n < 0x10ffff ? String.fromCodePoint(n) : m;
      })
      .replace(/&#x([0-9a-f]+);/gi, (m, h) => {
        const n = parseInt(h, 16);
        return n > 0 && n < 0x10ffff ? String.fromCodePoint(n) : m;
      });
  }

  function newId() {
    return 'b_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  /* ---------- 解析：批量粘贴 ---------- */

  /**
   * 支持的每行写法：
   *   [标题](https://url)      /  - [标题](https://url)
   *   标题 | 网址               （全角 ｜ 同样识别；网址也可写在前面）
   *   网址 标题                 /  标题 网址
   *   https://url              纯网址（裸域名 example.com 自动补 https://）
   */
  function parsePasted(text) {
    const out = [];
    for (const raw of String(text || '').split(/\r?\n/)) {
      let line = raw.trim();
      if (!line) continue;
      line = line.replace(/^[-*+•·]\s+/, '').replace(/^\d+[.)]\s+/, '').trim();
      if (!line) continue;

      let title = '';
      let url = '';

      const md = line.match(/\[([^\]]*)\]\(\s*<?([^)>\s]+)>?\s*\)/);
      if (md) {
        title = md[1];
        url = md[2];
      } else {
        const segs = line
          .split(/\s*[|｜]\s*/)
          .map((s) => s.trim())
          .filter((s) => s !== '');
        if (segs.length >= 2) {
          const last = normalizeUrl(segs[segs.length - 1]);
          const first = normalizeUrl(segs[0]);
          if (last) {
            url = last;
            title = segs.slice(0, -1).join(' | ');
          } else if (first) {
            url = first;
            title = segs.slice(1).join(' | ');
          }
        }
        if (!url) {
          const toks = line.split(/\s+/).filter(Boolean);
          if (toks.length === 1) {
            url = normalizeUrl(toks[0]);
          } else {
            let idx = -1;
            for (let i = 0; i < toks.length; i++) {
              const t = toks[i];
              if (/^https?:\/\//i.test(t) || /^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(t)) {
                idx = i;
                break;
              }
            }
            if (idx >= 0) {
              url = normalizeUrl(toks[idx]);
              title = toks
                .filter((_, i) => i !== idx)
                .join(' ')
                .replace(/^[-–—:：|｜]\s*/, '')
                .trim();
            }
          }
        }
      }

      url = normalizeUrl(url);
      if (!url) continue;
      title = decodeEntities(title)
        .trim()
        .replace(/^["'“”‘’]+|["'“”‘’]+$/g, '')
        .trim();
      out.push({ title: title || hostOf(url), url });
    }
    return out;
  }

  /* ---------- 解析：浏览器导出的书签 HTML ---------- */

  function parseHtmlBookmarks(html) {
    const out = [];
    const src = String(html || '');
    const re = /<a\s[^>]*href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(src))) {
      const href = (m[1] || m[2] || m[3] || '').trim();
      const url = normalizeUrl(href);
      if (!url) continue;
      const title = decodeEntities(String(m[4] || '').replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim();
      out.push({ title: title || hostOf(url), url });
    }
    return out;
  }

  /**
   * 与既有书签做去重合并：库内重复 + 本批自身重复都算「重复」
   * @returns {{list: Array, added: number, dup: number}}
   */
  function mergeWithExisting(existing, incoming) {
    const seen = new Set((existing || []).map((b) => urlKey(b.url)));
    const list = [];
    let dup = 0;
    for (const it of incoming || []) {
      const key = urlKey(it.url);
      if (!key || seen.has(key)) {
        dup++;
        continue;
      }
      seen.add(key);
      list.push(it);
    }
    return { list, added: list.length, dup };
  }

  function toBookmark(it, desktop) {
    return {
      id: newId(),
      title: String(it.title || '').trim() || hostOf(it.url),
      url: it.url,
      desktop: !!desktop,
      createdAt: Date.now(),
    };
  }

  /* ---------- 服务端状态 ---------- */

  async function loadState() {
    try {
      const res = await fetch('/api/state', { cache: 'no-store' });
      if (!res.ok) return null;
      const data = await res.json();
      if (!data || !Array.isArray(data.bookmarks)) return null;
      return {
        bookmarks: data.bookmarks,
        widgetTitle: data.widgetTitle || DEFAULT_WIDGET_TITLE,
      };
    } catch {
      return null;
    }
  }

  async function saveState(state) {
    const res = await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    notifyChange();
    return true;
  }

  /** 跨页面即时通知（消息带本页 token，监听侧过滤自己发的回声） */
  function notifyChange() {
    try {
      const ch = new BroadcastChannel(SYNC_CHANNEL);
      ch.postMessage({ token: SYNC_TOKEN, at: Date.now() });
      ch.close();
    } catch {}
  }

  function onExternalChange(cb) {
    try {
      const ch = new BroadcastChannel(SYNC_CHANNEL);
      ch.addEventListener('message', (e) => {
        if (e.data && e.data.token === SYNC_TOKEN) return;
        cb();
      });
    } catch {}
  }

  function iconUrl(url) {
    return '/api/icon?u=' + encodeURIComponent(url);
  }

  window.BM = {
    DEFAULT_WIDGET_TITLE,
    SEED_STATE,
    hostOf,
    normalizeUrl,
    urlKey,
    decodeEntities,
    newId,
    parsePasted,
    parseHtmlBookmarks,
    mergeWithExisting,
    toBookmark,
    loadState,
    saveState,
    notifyChange,
    onExternalChange,
    iconUrl,
  };
})();
