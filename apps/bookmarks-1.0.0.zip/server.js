import express from 'express';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

// [存储规范] 使用数据一律存服务端 DATA_DIR（容器内 = workspace/data/bookmarks，
// 平台卸载勾选「同时删除应用数据」时整目录清除）；本机直跑回落 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'bookmarks.json');
const ICON_DIR = join(DATA_DIR, 'icons');
fs.mkdirSync(ICON_DIR, { recursive: true });

// JSOS CORS 代理：容器内由平台注入，本机直跑时直连
const PROXY_URL = process.env.PROXY_URL || '';
const PROXY_KEY = process.env.PROXY_KEY || '';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36';

function outbound(target) {
  if (PROXY_URL && PROXY_KEY) {
    return `${PROXY_URL}/${encodeURIComponent(target)}?x-cors-proxy-key=${encodeURIComponent(PROXY_KEY)}`;
  }
  return target;
}

app.use(express.json({ limit: '8mb' }));
app.use(express.static(join(__dirname, 'public')));

/* ==================== 状态读写 ==================== */

const DEFAULT_WIDGET_TITLE = '常用书签';

function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./i, '');
  } catch {
    return String(url || '').slice(0, 60);
  }
}

/** 服务端只做「形状校验 + 归一化」，id 由前端生成并原样保留 */
function cleanState(body) {
  if (!body || typeof body !== 'object') return null;
  if (!Array.isArray(body.bookmarks)) return null;

  const seen = new Set();
  const bookmarks = [];
  for (const it of body.bookmarks) {
    if (!it || typeof it !== 'object') continue;
    const url = typeof it.url === 'string' ? it.url.trim() : '';
    if (!/^https?:\/\//i.test(url)) continue;

    let id = typeof it.id === 'string' && it.id.trim() ? it.id.trim() : '';
    if (!id || seen.has(id)) id = 'b_' + crypto.randomBytes(8).toString('hex');
    seen.add(id);

    let title = typeof it.title === 'string' ? it.title.trim() : '';
    if (title.length > 200) title = title.slice(0, 200);

    bookmarks.push({
      id,
      title: title || hostOf(url),
      url,
      desktop: it.desktop !== false,
      createdAt: Number.isFinite(it.createdAt) ? it.createdAt : Date.now(),
    });
  }

  const wt =
    typeof body.widgetTitle === 'string' && body.widgetTitle.trim()
      ? body.widgetTitle.trim().slice(0, 24)
      : DEFAULT_WIDGET_TITLE;

  return { bookmarks, widgetTitle: wt };
}

app.get('/api/state', (req, res) => {
  try {
    res.setHeader('Cache-Control', 'no-store');
    if (!fs.existsSync(STATE_FILE)) return res.json(null);
    res.json(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  const state = cleanState(req.body);
  if (!state) return res.status(400).json({ error: 'invalid state' });
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state));
    fs.renameSync(tmp, STATE_FILE);
    res.json({ ok: true, count: state.bookmarks.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ==================== 网站图标（favicon.im + 本地缓存） ==================== */

const ICON_MAX_BYTES = 512 * 1024;
const MISS_TTL = 30 * 60 * 1000; // 负缓存 30 分钟，避免坏域名反复打上游
const missCache = new Map();

function sniffType(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.length > 6 && buf.slice(0, 3).toString('latin1') === 'GIF') return 'image/gif';
  if (buf.length > 12 && buf.slice(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.length > 4 && buf[0] === 0x00 && buf[1] === 0x00 && buf[2] === 0x01) return 'image/x-icon';
  const head = buf.slice(0, 400).toString('utf8').trim().toLowerCase();
  if (head.includes('<svg')) return 'image/svg+xml';
  return 'image/png';
}

// 上游并发限流：一次导入 200 条书签时别把 favicon.im 打爆
const MAX_UPSTREAM = 6;
let running = 0;
const waiting = [];
function acquire() {
  if (running < MAX_UPSTREAM) {
    running++;
    return Promise.resolve();
  }
  return new Promise((resolve) => waiting.push(resolve));
}
function release() {
  running--;
  const next = waiting.shift();
  if (next) {
    running++;
    next();
  }
}

async function fetchUpstreamIcon(host) {
  await acquire();
  try {
    const target = `https://a.favicon.im/${encodeURIComponent(host)}?larger=true&throw-error-on-404=true`;
    const r = await fetch(outbound(target), { headers: { 'User-Agent': UA } });
    if (!r.ok) return { status: r.status === 404 ? 404 : 502 };
    const buf = Buffer.from(await r.arrayBuffer());
    if (!buf.length || buf.length > ICON_MAX_BYTES) return { status: 404 };
    return { status: 200, buf };
  } catch {
    return { status: 502 };
  } finally {
    release();
  }
}

app.get('/api/icon', async (req, res) => {
  const raw = String(req.query.u || '').trim();
  let host = '';
  try {
    host = new URL(raw).hostname;
  } catch {
    host = raw.replace(/^https?:\/\//i, '').split('/')[0].split(':')[0];
  }
  if (!host || !/^[a-z0-9.-]{2,80}$/i.test(host)) return res.status(400).end();

  const file = join(ICON_DIR, crypto.createHash('sha1').update(host).digest('hex') + '.bin');
  if (fs.existsSync(file)) {
    const buf = fs.readFileSync(file);
    res.set('Content-Type', sniffType(buf));
    res.set('Cache-Control', 'public, max-age=604800');
    return res.send(buf);
  }

  const missAt = missCache.get(host);
  if (missAt && Date.now() - missAt < MISS_TTL) return res.status(404).end();

  const got = await fetchUpstreamIcon(host);
  if (got.status !== 200) {
    if (got.status === 404) missCache.set(host, Date.now());
    return res.status(got.status === 404 ? 404 : 502).end();
  }

  try {
    fs.writeFileSync(file, got.buf);
  } catch {}
  missCache.delete(host);
  res.set('Content-Type', sniffType(got.buf));
  res.set('Cache-Control', 'public, max-age=604800');
  res.send(got.buf);
});

/* ==================== 小组件入口 ==================== */

app.get('/widget/bookmarks', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'widget.html'));
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`bookmarks running on ${port}`));
