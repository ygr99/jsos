/* ==========================================================================
   白噪音 whitenoise — 混音器前端
   ---------------------------------------------------------------------------
   • 声音目录来自 /api/sounds（60 声音 / 250 变体）
   • 每路声音 = 独立 <audio>（loop），音量 = 总音量 × 分路音量
   • CDN 直链播放优先（<audio> 不受 CORS 限制，零代理开销）；
     失败自动降级到同源 /api/audio 代理（CDN 无 ACAO 头时的兜底）
   • 混音状态经 /api/state 持久化（§7.9 模式 A）
   ========================================================================== */

const $ = (id) => document.getElementById(id);

const CDN = 'https://cdn.gameziyuan.shop/audio';
const QUALITY = { low: '_64', medium: '_128', high: '_320' };

/** 分类顺序 + 中文名 + 图标（与参考设计一致） */
const CATS = [
  { id: 'all', label: '全部' },
  { id: 'background', label: '自然' },
  { id: 'place', label: '场所' },
  { id: 'asmr', label: 'ASMR' },
  { id: 'ambient', label: '环境' },
  { id: 'noise', label: '噪音' },
  { id: 'other', label: '其他' },
  { id: 'lofi', label: 'Lofi' },
];

/** 每个声音的主题色（低饱和，用于图标块） */
const TONES = {
  background: '#3b82f6', place: '#f59e0b', asmr: '#8b5cf6',
  ambient: '#0f9488', noise: '#6b7280', other: '#ec4899', lofi: '#6366f1',
};

/** 声音 → 简约线性图标 path（按 id 归类，未命中的用通用声波） */
const ICONS = {
  waves: 'M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5s2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1M2 12c.6.5 1.2 1 2.5 1S7 12 9.5 12s2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1M2 18c.6.5 1.2 1 2.5 1s2.5-2 5-2 2.4 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1',
  birds: 'M16 7h.01M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20',
  fire: 'M12 3c1.5 3 4 4.5 4 8a4 4 0 0 1-8 0c0-1.5.5-2.5 1.2-3.2.3 1.2 1 1.7 1.8 1.7 1.2 0 1.5-1 1.5-2 0-1.6-.5-3-.5-4.5Z',
  rain: 'M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2M16 14v6M8 14v6M12 16v6',
  stream: 'M3 6h18M3 12h18M3 18h18',
  wind: 'M12.8 19.6A2 2 0 1 0 14 16H2M17.5 8a2.5 2.5 0 1 1 2 4H2M9.8 4.4A2 2 0 1 1 11 8H2',
  forest: 'M12 22v-6M12 16l4-3.5-4 .5 4-3.5-4 .5L12 8 8 9.5l4-.5-4 3.5 4-.5L12 16Z',
  road: 'M4 20 8 4M20 20 16 4M12 6v3M12 13v3',
  frog: 'M6 14a6 6 0 0 1 12 0v2H6zM9 11h.01M15 11h.01',
  night: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z',
  thunder: 'M6 16.3A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 .5 9m-5 0-3 5h4l-3 5',
  waterfall: 'M8 3h8l-1 18H9zM4 8c1 1 2 1 3 0M17 13c1 1 2 1 3 0',
  snow: 'M12 3v18M4 8l16 8M20 8 4 16',
  bells: 'M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10.3 21a2 2 0 0 0 3.4 0',
  cafe: 'M4 8h13v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5zM17 9h2a3 3 0 0 1 0 6h-2',
  chants: 'M10 9h4M12 7v5M14 21v-3a2 2 0 0 0-4 0v3M6 21V7l6-4 6 4v14',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM12 7v5l3 2',
  keyboard: 'M3 6h18v12H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10',
  cat: 'M12 5c-1.8-2-5-2.8-6.4-2.2-1.4.6.4 7 .4 7A7 7 0 0 0 12 21a7 7 0 0 0 6-11.2s1.8-6.4.4-7C17 2.2 13.8 3 12 5Z',
  vacuum: 'M10 12h4M10 8h4M14 21v-3a2 2 0 0 0-4 0v3M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16',
  space: 'M12 3a9 9 0 1 0 9 9M12 12l6-6M15 6h-3v-3',
  train: 'M4 6h16v10H4zM7 20l2-4M17 20l-2-4M8 13h.01M16 13h.01',
  plane: 'M17.8 19.8 16 14l-3 3v4l-2 2-2-2v-4l-3-3-1.8 5.8L2 18l3-6V7l-2-3 4-1 5 5h4a3 3 0 0 1 0 6h-2l-1.2 5.8z',
  basketball: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM2 12h20M12 2v20M5 5a14 14 0 0 1 0 14M19 5a14 14 0 0 0 0 14',
  supermarket: 'M6 2 4 6v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6l-2-4zM4 6h16M9 10a3 3 0 0 0 6 0',
  city: 'M6 21V9l6-4 6 4v12M10 21v-5h4v5M2 21h20',
  barber: 'M6 3 18 15M6 21 18 9M9 6a3 3 0 1 0 0 0M9 18a3 3 0 1 0 0 0',
  bubbles: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM17 20a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
  chips: 'M4 8h16v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM9 8v-2a3 3 0 0 1 6 0v2',
  printer: 'M6 9V3h12v6M6 18H4v-6h16v6h-2M8 14h8v7H8z',
  engine: 'M6 9h3V6h6v3h3l2 3v5h-2v2H6v-2H4v-5zM9 3v3',
  boat: 'M4 18 12 4l8 14M6 18v2M18 18v2M3 22h18',
  whale: 'M3 12c2 4 5 6 9 6s7-2 9-5c-1-1-3-1-4 0-1-4-5-6-9-5-3 .7-5 2-5 4Z M6 8 4 5M9 7 8 4',
  breath: 'M12 3v18M8 8l4-5 4 5M8 16l4 5 4-5',
  magma: 'M12 22 4 12h4l2-3 3 2 3-4 1 5h4z',
  walk: 'M13 4a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM11 21l1-5-3-3 1-5 4 2 3 1M9 13l-2 4',
  white_noise: 'M2 8h4l3-5 3 18 3-13 2 5h5',
  pink_noise: 'M2 12c3 0 3-6 6-6s3 12 6 12 3-9 6-9',
  brown_noise: 'M4 4v16M8 8v8M12 6v12M16 10v4M20 8v8',
  lofi: 'M9 18V5l10-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM19 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
  default: 'M12 6v12M9 9v6M15 9v6M6 11v2M18 11v2',
};
const iconPath = (id) => ICONS[id] || ICONS.default;

/* ------------------------------ 状态 ------------------------------ */

const state = {
  sounds: [],
  active: {},          // id -> { variant, volume }  （音量 0-100）
  master: 80,
  cat: 'all',
  q: '',
  playing: false,
};

const audio = new Map();  // id -> HTMLAudioElement

/* ------------------------------ 工具 ------------------------------ */

const enc = (p) => p.split('/').map(encodeURIComponent).join('/');

function buildUrl(snd, variantId, quality = 'low') {
  const v = snd.variants.find((x) => x.id === variantId) || snd.variants[0];
  const suffix = snd.category === 'lofi' || snd.noQuality ? '' : QUALITY[quality] || QUALITY.low;
  return `${CDN}/${enc(snd.catEn)}/${enc(snd.folder)}/${encodeURIComponent(v.id + suffix + '.m4a')}`;
}
/** 同源代理兜底地址（CDN 无 ACAO 头时的退路） */
function proxyUrl(snd, variantId, quality = 'low') {
  return `/api/audio?sound=${encodeURIComponent(snd.id)}&variant=${encodeURIComponent(variantId)}&quality=${quality}`;
}
const byId = (id) => state.sounds.find((s) => s.id === id);

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, 1800);
}

/** 把 range 的已填充比例写进 CSS 变量（webkit 轨道渐变用） */
function paintRange(el) {
  const min = +el.min || 0, max = +el.max || 100;
  el.style.setProperty('--fill', ((el.value - min) / (max - min) * 100).toFixed(1) + '%');
}

/* ------------------------------ 音频引擎 ------------------------------ */

function ensureAudio(id) {
  if (audio.has(id)) return audio.get(id);
  const snd = byId(id);
  if (!snd) return null;
  const a = new Audio();
  a.loop = true;
  a.preload = 'auto';
  // 直链优先；加载失败降级同源代理
  a.addEventListener('error', () => {
    const st = state.active[id];
    if (!st || a.dataset.fallback === '1') return;
    a.dataset.fallback = '1';
    a.src = proxyUrl(snd, st.variant);
    if (state.playing) a.play().catch(() => {});
  });
  audio.set(id, a);
  return a;
}

function applyVolume(id) {
  const a = audio.get(id);
  const st = state.active[id];
  if (!a || !st) return;
  const v = (st.volume / 100) * (state.master / 100);
  a.volume = Math.max(0, Math.min(1, v));
}

function startSound(id, autoplay = true) {
  const snd = byId(id);
  const st = state.active[id];
  if (!snd || !st) return;
  const a = ensureAudio(id);
  if (a.dataset.fallback !== '1') {
    const want = buildUrl(snd, st.variant);
    if (a.src !== want) a.src = want;
  } else {
    const want = proxyUrl(snd, st.variant);
    if (a.src !== want) a.src = want;
  }
  applyVolume(id);
  if (autoplay && state.playing) a.play().catch(() => {});
}

function stopSound(id, keepSrc = false) {
  const a = audio.get(id);
  if (!a) return;
  a.pause();
  if (!keepSrc) { a.src = ''; audio.delete(id); }
}

function toggleSound(id) {
  const on = id in state.active;
  if (on) {
    delete state.active[id];
    stopSound(id);
  } else {
    const snd = byId(id);
    state.active[id] = { variant: snd.variants[0].id, volume: 60 };
    startSound(id);
    if (!state.playing) setPlaying(true);
  }
  persist();
  render();
}

function setPlaying(p) {
  state.playing = p;
  document.body.classList.toggle('playing', p);
  for (const id of Object.keys(state.active)) {
    if (p) startSound(id); else audio.get(id)?.pause();
  }
  // 总开关不持久化"播放中"（下次打开自动尊重用户上一次的动作，但不静默出声）
  persist();
}

/* ------------------------------ 渲染 ------------------------------ */

function matchSound(s, q) {
  if (!q) return true;
  const k = q.toLowerCase();
  return s.name.toLowerCase().includes(k)
    || s.id.toLowerCase().includes(k)
    || s.variants.some((v) => v.name.toLowerCase().includes(k));
}

function currentList() {
  const q = state.q.trim();
  return state.sounds.filter((s) => {
    if (state.cat === 'playing') { if (!(s.id in state.active)) return false; }
    else if (state.cat !== 'all' && s.category !== state.cat) return false;
    return matchSound(s, q);
  });
}

function renderTabs() {
  const tabs = $('tabs');
  const playingCount = Object.keys(state.active).length;
  const list = CATS.filter((c) => c.id !== 'playing');
  if (playingCount) list.splice(1, 0, { id: 'playing', label: '播放中' });
  tabs.innerHTML = list.map((c) => {
    const n = c.id === 'all' ? state.sounds.length
      : c.id === 'playing' ? playingCount
      : state.sounds.filter((s) => s.category === c.id).length;
    return `<button class="tab${state.cat === c.id ? ' active' : ''}" data-cat="${c.id}">${c.label}</button>`;
  }).join('');
  tabs.querySelectorAll('.tab').forEach((b) => {
    b.onclick = () => { state.cat = b.dataset.cat; render(); };
  });
}

function renderGrid() {
  const list = currentList();
  const grid = $('grid');
  const isEmpty = list.length === 0;
  $('empty').hidden = !isEmpty;
  if (isEmpty) {
    $('empty').querySelector('b').textContent = state.q ? `没有找到「${state.q}」` : '这个分类还没有声音';
    $('empty').querySelector('span').textContent = state.q ? '试试换个关键词，或清空搜索' : '切换其他分类看看';
  }

  grid.innerHTML = list.map((s) => {
    const on = s.id in state.active;
    const st = state.active[s.id];
    const tone = TONES[s.category] || '#0f9488';
    const sub = on && st.variant !== s.variants[0].id
      ? s.variants.find((v) => v.id === st.variant)?.name || s.name
      : s.variants.length > 1 ? `${s.variants.length} 种音效` : (s.variants[0]?.name || '');
    return `
    <div class="card${on ? ' active' : ''}" data-id="${s.id}">
      <div class="card-main">
        <div class="card-icon" style="--tone:${tone}">
          <svg viewBox="0 0 24 24"><path d="${iconPath(s.id)}"/></svg>
        </div>
        <div class="card-text">
          <div class="card-name" title="${s.name}">${s.name}</div>
          <div class="card-sub">${sub}</div>
        </div>
        <div class="card-acts">
          ${s.variants.length > 1 ? `
          <button class="mini-btn" data-act="variant" title="切换音效">
            <svg viewBox="0 0 24 24" class="i"><path d="M16 5H3M11 12H3M11 19H3M21 16V5M18 16a3 3 0 1 0 6 0 3 3 0 0 0-6 0" transform="scale(.85) translate(2 2)"/></svg>
          </button>` : ''}
          ${on ? `<div class="bars"><i></i><i></i><i></i><i></i></div>` : ''}
          <button class="mini-btn play${on ? '' : ''}" data-act="play" title="${on ? '停止' : '播放'}">
            ${on
              ? `<svg viewBox="0 0 24 24" class="i"><path d="M18 6 6 18M6 6l12 12"/></svg>`
              : `<svg viewBox="0 0 24 24" class="i"><path d="M7 4.5a1.5 1.5 0 0 1 2.28-1.28l10.5 6.5a1.5 1.5 0 0 1 0 2.56l-10.5 6.5A1.5 1.5 0 0 1 7 17.5z" fill="currentColor" stroke="none"/></svg>`}
          </button>
        </div>
      </div>
      ${on ? `
      <div class="card-vol">
        <svg viewBox="0 0 24 24" class="i vol-ico"><path d="M11 4.7a.7.7 0 0 0-1.2-.5L6.4 7.6A1.4 1.4 0 0 1 5.4 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.4a1.4 1.4 0 0 1 1 .4l3.4 3.4a.7.7 0 0 0 1.2-.5z"/></svg>
        <input type="range" min="0" max="100" value="${st.volume}" data-vol="${s.id}" aria-label="${s.name} 音量">
        <span class="vol-num">${st.volume}</span>
      </div>` : ''}
    </div>`;
  }).join('');

  grid.querySelectorAll('input[data-vol]').forEach((el) => {
    paintRange(el);
    el.oninput = () => {
      const id = el.dataset.vol;
      const v = +el.value;
      state.active[id].volume = v;
      el.parentElement.querySelector('.vol-num').textContent = v;
      paintRange(el);
      applyVolume(id);
      persistDebounced();
    };
    el.onchange = () => renderChips();
  });

  grid.querySelectorAll('.card').forEach((card) => {
    const id = card.dataset.id;
    card.querySelector('[data-act="play"]')?.addEventListener('click', (e) => {
      e.stopPropagation(); toggleSound(id);
    });
    card.querySelector('[data-act="variant"]')?.addEventListener('click', (e) => {
      e.stopPropagation(); openVariants(id);
    });
    card.addEventListener('click', (e) => {
      if (e.target.closest('input,button')) return;
      toggleSound(id);
    });
  });

  renderChips();
}

function renderChips() {
  const ids = Object.keys(state.active);
  const box = $('chips');
  if (!ids.length) {
    $('now-title').textContent = '正在播放';
    box.innerHTML = '<span class="chip-count">点击声音卡片添加 / 移除</span>';
    return;
  }
  $('now-title').textContent = state.playing ? '正在播放' : '已暂停';
  box.innerHTML = ids.map((id) => {
    const s = byId(id);
    const muted = state.active[id].volume === 0 || state.master === 0;
    return `<span class="chip${muted ? ' muted' : ''}" data-chip="${id}" title="点击移除"><span class="dot"></span>${s.name}</span>`;
  }).join('') + `<span class="chip-count">${ids.length} 个混音中</span>`;
  box.querySelectorAll('[data-chip]').forEach((c) => {
    c.onclick = () => toggleSound(c.dataset.chip);
  });
}

function render() {
  renderTabs();
  renderGrid();
  const anyOn = Object.keys(state.active).length > 0;
  $('play-btn').style.opacity = anyOn ? '1' : '.55';
}

/* ------------------------------ 变体弹窗 ------------------------------ */

let vmSound = null;
function openVariants(id) {
  const s = byId(id);
  if (!s) return;
  vmSound = id;
  $('vm-title').textContent = s.name + ' · 选择音效';
  const cur = state.active[id]?.variant || s.variants[0].id;
  $('vm-body').innerHTML = s.variants.map((v) => `
    <button class="vitem${v.id === cur ? ' sel' : ''}" data-v="${encodeURIComponent(v.id)}">
      <span>${v.name}</span>${v.id === cur ? '<span class="tick">当前</span>' : ''}
    </button>`).join('');
  $('vm-body').querySelectorAll('.vitem').forEach((b) => {
    b.onclick = () => {
      const vid = decodeURIComponent(b.dataset.v);
      if (!(id in state.active)) {
        state.active[id] = { variant: vid, volume: 60 };
        startSound(id);
        if (!state.playing) setPlaying(true);
      } else {
        state.active[id].variant = vid;
        startSound(id);
      }
      closeVariants();
      persist();
      render();
    };
  });
  $('variant-modal').hidden = false;
}
function closeVariants() { $('variant-modal').hidden = true; vmSound = null; }

/* ------------------------------ 持久化 ------------------------------ */

let saveTimer = null;
function persistDebounced() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 400);
}
async function persist() {
  try {
    await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: state.active, master: state.master, cat: state.cat }),
    });
  } catch { /* 静默：偏好存不下来不影响使用 */ }
}
async function load() {
  try {
    const r = await fetch('/api/state');
    const s = await r.json();
    if (s && typeof s === 'object') {
      if (s.active && typeof s.active === 'object') {
        for (const [id, v] of Object.entries(s.active)) {
          if (byId(id)) state.active[id] = { variant: v.variant, volume: +v.volume || 60 };
        }
      }
      if (typeof s.master === 'number') state.master = s.master;
      if (typeof s.cat === 'string' && CATS.some((c) => c.id === s.cat)) state.cat = s.cat;
    }
  } catch { /* 首次启动没有存档 */ }
}

/* ------------------------------ 导入导出 ------------------------------ */

function doExport() {
  const data = { app: 'whitenoise', version: 1, active: state.active, master: state.master };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'whitenoise-mix.json';
  a.click();
  URL.revokeObjectURL(a.href);
  toast('已导出混音方案');
}

function doImport(file) {
  const fr = new FileReader();
  fr.onload = () => {
    try {
      const d = JSON.parse(fr.result);
      const src = d.active && typeof d.active === 'object' ? d.active : d;
      const next = {};
      for (const [id, v] of Object.entries(src)) {
        if (byId(id) && v && typeof v === 'object') next[id] = { variant: v.variant, volume: +v.volume || 60 };
      }
      const n = Object.keys(next).length;
      if (!n) return toast('没有可导入的声音');
      for (const id of Object.keys(state.active)) stopSound(id);
      state.active = next;
      if (typeof d.master === 'number') state.master = d.master;
      $('vol-slider').value = state.master;
      $('vol-val').textContent = state.master;
      paintRange($('vol-slider'));
      setPlaying(true);
      persist();
      render();
      toast(`已导入 ${n} 个声音`);
    } catch { toast('文件格式不正确'); }
  };
  fr.readAsText(file);
}

/* ------------------------------ 总控 ------------------------------ */

function setMaster(v) {
  state.master = v;
  $('vol-slider').value = v;
  $('vol-val').textContent = v;
  paintRange($('vol-slider'));
  document.body.classList.toggle('muted', v === 0);
  for (const id of Object.keys(state.active)) applyVolume(id);
  renderChips();
  persistDebounced();
}

function clearAll() {
  for (const id of Object.keys(state.active)) stopSound(id);
  state.active = {};
  setPlaying(false);
  document.body.classList.remove('playing');
  persist();
  render();
}

/* ------------------------------ 启动 ------------------------------ */

async function init() {
  const r = await fetch('/api/sounds');
  state.sounds = await r.json();

  await load();

  // 恢复上次的混音（不自动出声音，等用户点播放 —— 浏览器自动播放策略友好）
  for (const id of Object.keys(state.active)) startSound(id, false);
  document.body.classList.remove('playing');

  setMaster(state.master);
  render();

  $('play-btn').onclick = () => {
    if (!Object.keys(state.active).length) return toast('先点选一个声音吧');
    setPlaying(!state.playing);
    renderChips();
  };
  $('vol-slider').oninput = (e) => setMaster(+e.target.value);
  $('search-input').oninput = (e) => { state.q = e.target.value; renderGrid(); renderTabs(); };
  $('vol-btn').onclick = () => setMaster(state.master === 0 ? 80 : 0);
  $('btn-clear').onclick = clearAll;
  $('btn-export').onclick = doExport;
  $('btn-import').onclick = () => $('import-file').click();
  $('import-file').onchange = (e) => { if (e.target.files[0]) doImport(e.target.files[0]); e.target.value = ''; };
  $('vm-close').onclick = closeVariants;
  $('variant-modal').onclick = (e) => { if (e.target.id === 'variant-modal') closeVariants(); };
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeVariants();
    if (e.key === ' ' && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) {
      e.preventDefault();
      $('play-btn').click();
    }
  });
}

init();
