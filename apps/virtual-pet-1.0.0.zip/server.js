import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { mkdirSync, writeFileSync, existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// 运行时数据目录（不上架打包）：上传的精灵图存这里
const dataDir = join(__dirname, 'data');
const uploadDir = join(dataDir, 'uploads');
if (!existsSync(uploadDir)) mkdirSync(uploadDir, { recursive: true });

app.use(express.json({ limit: '20mb' }));
app.use(express.static(join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// 精灵图上传：前端把文件转 base64 JSON 提交（免 multipart 依赖）
app.post('/api/upload', (req, res) => {
  try {
    const { name, data } = req.body || {};
    const m = typeof data === 'string' ? data.match(/^data:image\/(png|webp|jpeg|jpg|gif);base64,(.+)$/) : null;
    if (!m) return res.status(400).json({ error: '仅支持 image base64 data URL' });
    const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
    const file = `pet_${Date.now()}.${ext}`;
    writeFileSync(join(uploadDir, file), Buffer.from(m[2], 'base64'));
    res.json({ url: `/uploads/${file}` });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`virtual-pet running on ${port}`));
