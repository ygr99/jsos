// 桌面宠物 · 主界面逻辑（移植自 99-起始页 VirtualPet 组件，数据直存 localStorage，无 iframe 通信）
import {
  loadData, saveData, applyDecay, gainExperience, expNeeded,
  SpriteAnimator, ANIMATIONS, ANIM_KEYS, sheetUrlOf, newPet,
} from './pet-core.js';

let data = loadData();
let pet = getCurrentPet();
let animator = null;
const previewAnimators = [];

function getCurrentPet() {
  return data.pets.find(p => p.id === data.currentPetId) || data.pets[0];
}

function persist() {
  saveData(data);
}

function refreshPet() {
  pet = getCurrentPet();
}

// ---------- 渲染 ----------

function initAnimationButtons() {
  const box = document.getElementById('animation-controls');
  box.innerHTML = '';
  ANIM_KEYS.forEach(key => {
    const btn = document.createElement('button');
    btn.className = 'anim-btn';
    btn.setAttribute('data-anim', key);
    btn.textContent = ANIMATIONS[key].name;
    btn.addEventListener('click', () => {
      animator.play(key);
      pet.currentAnimation = key;
      persist();
      updateAnimationButtons();
    });
    box.appendChild(btn);
  });
}

function updateAnimationButtons() {
  document.querySelectorAll('.anim-btn').forEach(b =>
    b.classList.toggle('active', b.getAttribute('data-anim') === pet.currentAnimation));
}

function updatePetDisplay() {
  document.getElementById('pet-name').textContent = pet.name;
  document.getElementById('pet-level').textContent = 'Lv.' + pet.level;

  const hungerBar = document.getElementById('hunger-bar');
  const happinessBar = document.getElementById('happiness-bar');
  const energyBar = document.getElementById('energy-bar');
  const expBar = document.getElementById('exp-bar');
  const petAvatar = document.getElementById('pet-avatar');

  hungerBar.style.width = pet.hunger + '%';
  happinessBar.style.width = pet.happiness + '%';
  energyBar.style.width = pet.energy + '%';
  hungerBar.style.backgroundColor = pet.hunger <= 20 ? '#f44336' : '#ffc107';

  petAvatar.classList.remove('hungry', 'happy', 'tired');
  if (pet.hunger <= 20) petAvatar.classList.add('hungry');
  else if (pet.happiness >= 80) petAvatar.classList.add('happy');
  else if (pet.energy <= 20) petAvatar.classList.add('tired');

  document.getElementById('hunger-value').textContent = Math.round(pet.hunger) + '%';
  document.getElementById('happiness-value').textContent = Math.round(pet.happiness) + '%';
  document.getElementById('energy-value').textContent = Math.round(pet.energy) + '%';

  const need = expNeeded(pet);
  expBar.style.width = ((pet.experience / need) * 100) + '%';
  document.getElementById('exp-value').textContent = pet.experience + '/' + need;

  updateButtonStates();
}

function updateButtonStates() {
  const playBtn = document.getElementById('play-btn');
  if (pet.hunger <= 0 || pet.energy < 10) {
    playBtn.style.opacity = '0.5';
    playBtn.title = pet.hunger <= 0 ? '宠物太饿了，需要先喂食！' : '宠物太累了，需要休息！';
  } else {
    playBtn.style.opacity = '';
    playBtn.title = '';
  }
}

function renderPetList() {
  previewAnimators.forEach(p => p.stop());
  previewAnimators.length = 0;

  const list = document.getElementById('pet-list');
  list.innerHTML = '';
  data.pets.forEach(p => {
    const card = document.createElement('div');
    card.className = 'pet-card' + (p.id === data.currentPetId ? ' active' : '');
    card.innerHTML =
      '<div class="pet-card-actions">' +
        '<button class="pet-action-btn pet-edit-btn" title="编辑">✎</button>' +
        '<button class="pet-action-btn pet-delete-btn" title="删除">✕</button>' +
      '</div>' +
      '<div class="pet-card-icon" data-id="' + p.id + '">' +
        ((!p.spritesheetUrl && p.id !== 'default') ? '<i>🐾</i>' : '') +
      '</div>' +
      '<div class="pet-card-name">' + escapeHtml(p.name) + '</div>';
    card.addEventListener('click', e => {
      if (e.target.closest('.pet-action-btn')) return;
      data.currentPetId = p.id;
      refreshPet();
      persist();
      afterPetSwitched();
    });
    list.appendChild(card);

    if (p.spritesheetUrl || p.id === 'default') {
      const iconEl = card.querySelector('.pet-card-icon[data-id="' + p.id + '"]');
      // 列表预览：静态首帧（避免一屏多个 setInterval）
      drawSpriteFrame(iconEl, sheetUrlOf(p), p.currentAnimation || 'idle');
    }
  });

  list.querySelectorAll('.pet-edit-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      openEditModal(btn.closest('.pet-card').querySelector('.pet-card-icon').getAttribute('data-id'));
    });
  });
  list.querySelectorAll('.pet-delete-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      openDeleteModal(btn.closest('.pet-card').querySelector('.pet-card-icon').getAttribute('data-id'));
    });
  });
}

// 取动画第一帧画成小头像
function drawSpriteFrame(el, url, animName) {
  const a = ANIMATIONS[animName] || ANIMATIONS.idle;
  const scale = 50 / 192;
  el.style.backgroundImage = "url('" + url + "')";
  el.style.backgroundRepeat = 'no-repeat';
  el.style.imageRendering = 'pixelated';
  el.style.backgroundSize = (8 * 192 * scale) + 'px ' + (9 * 208 * scale) + 'px';
  el.style.backgroundPosition = (-(a.frames[0] * 192 * scale)) + 'px ' + (-(a.row * 208 * scale)) + 'px';
}

function afterPetSwitched() {
  animator.setSheet(sheetUrlOf(pet));
  animator.play(pet.currentAnimation || 'idle');
  updatePetDisplay();
  updateAnimationButtons();
  renderPetList();
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ---------- 交互动作 ----------

function feed() {
  pet.hunger = Math.min(100, pet.hunger + 20);
  pet.energy = Math.min(100, pet.energy + 5);
  afterAction(5, '宠物吃得很开心！');
}

function play() {
  if (pet.hunger <= 0) { showToast('宠物太饿了，需要先喂食！'); return; }
  if (pet.energy < 10) { showToast('宠物太累了，需要休息！'); return; }
  pet.happiness = Math.min(100, pet.happiness + 20);
  pet.energy = Math.max(0, pet.energy - 10);
  pet.hunger = Math.max(0, pet.hunger - 5);
  afterAction(10, '宠物玩得很开心！');
}

function rest() {
  pet.energy = Math.min(100, pet.energy + 30);
  afterAction(3, '宠物休息得很好！');
}

function afterAction(exp, msg) {
  const newLevel = gainExperience(pet, exp);
  persist();
  updatePetDisplay();
  renderPetList();
  showToast(msg);
  if (newLevel) showToast('恭喜！你的宠物升级到了' + newLevel + '级！');
}

// ---------- 编辑 / 删除 ----------

function openEditModal(petId) {
  const p = data.pets.find(x => x.id === petId);
  if (!p) return;
  document.getElementById('edit-name-input').value = p.name;
  document.getElementById('edit-url-input').value = p.spritesheetUrl || '';
  document.getElementById('edit-modal').classList.add('show');
  document.getElementById('edit-confirm-btn').onclick = () => {
    const newName = document.getElementById('edit-name-input').value.trim();
    const newUrl = document.getElementById('edit-url-input').value.trim();
    if (!newName) { showToast('名称不能为空'); return; }
    p.name = newName;
    p.spritesheetUrl = newUrl;
    persist();
    document.getElementById('edit-modal').classList.remove('show');
    refreshPet();
    afterPetSwitched();
    showToast('修改成功');
  };
}

function openDeleteModal(petId) {
  const p = data.pets.find(x => x.id === petId);
  if (!p) return;
  document.getElementById('delete-msg').textContent = '确定要删除 "' + p.name + '" 吗？';
  document.getElementById('delete-modal').classList.add('show');
  document.getElementById('delete-confirm-btn').onclick = () => {
    data.pets = data.pets.filter(x => x.id !== petId);
    if (data.currentPetId === petId) data.currentPetId = data.pets[0] ? data.pets[0].id : null;
    persist();
    document.getElementById('delete-modal').classList.remove('show');
    refreshPet();
    if (pet) {
      afterPetSwitched();
    } else {
      data.pets.push(newPet('哆啦'));
      data.currentPetId = data.pets[0].id;
      persist();
      refreshPet();
      afterPetSwitched();
    }
    showToast('已删除');
  };
}

// ---------- 新增宠物（上传精灵图） ----------

async function handleUpload() {
  const name = document.getElementById('upload-name').value.trim();
  const urlInput = document.getElementById('upload-url').value.trim();
  if (!name) { showToast('请输入宠物名称'); return; }
  if (!urlInput) { showToast('请填写精灵图URL或选择文件上传'); return; }
  data.pets.push(newPet(name, urlInput));
  data.currentPetId = data.pets[data.pets.length - 1].id;
  persist();
  refreshPet();
  afterPetSwitched();
  showToast('宠物已添加！');
  document.getElementById('upload-name').value = '';
  document.getElementById('upload-url').value = '';
  document.getElementById('upload-file').value = '';
}

async function uploadFile(file) {
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('读取文件失败'));
    reader.readAsDataURL(file);
  });
  const resp = await fetch('/api/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: file.name, data: dataUrl }),
  });
  const d = await resp.json();
  if (d.url) return d.url;
  throw new Error(d.error || '未知错误');
}

// ---------- Toast ----------

function showToast(message) {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = message;
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity = '1'; }, 10);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3000);
}

// ---------- 启动 ----------

function tick() {
  applyDecay(pet);
  persist();
  updatePetDisplay();
}

function init() {
  applyDecay(pet);
  persist();

  animator = new SpriteAnimator(document.getElementById('pet-sprite'), {
    sheetUrl: sheetUrlOf(pet),
    displayWidth: 176,
  });
  document.getElementById('sprite-container').addEventListener('click', () => {
    const idx = ANIM_KEYS.indexOf(animator.currentAnimation);
    const next = ANIM_KEYS[(idx + 1) % ANIM_KEYS.length];
    animator.play(next);
    pet.currentAnimation = next;
    persist();
    updateAnimationButtons();
  });
  animator.onAnimChange = () => {};

  initAnimationButtons();
  updatePetDisplay();
  updateAnimationButtons();
  renderPetList();

  document.getElementById('feed-btn').addEventListener('click', feed);
  document.getElementById('play-btn').addEventListener('click', play);
  document.getElementById('rest-btn').addEventListener('click', rest);

  document.getElementById('upload-file-btn').addEventListener('click', () => document.getElementById('upload-file').click());
  document.getElementById('upload-file').addEventListener('change', async function () {
    if (this.files && this.files[0]) {
      const file = this.files[0];
      document.getElementById('upload-name').value = file.name.replace(/\.[^.]+$/, '');
      showToast('正在上传...');
      try {
        const url = await uploadFile(file);
        document.getElementById('upload-url').value = url;
        showToast('上传成功！');
      } catch (e) {
        showToast('上传失败：' + e.message);
      }
    }
  });
  document.getElementById('upload-submit-btn').addEventListener('click', handleUpload);

  document.getElementById('edit-cancel-btn').addEventListener('click', () => document.getElementById('edit-modal').classList.remove('show'));
  document.getElementById('delete-cancel-btn').addEventListener('click', () => document.getElementById('delete-modal').classList.remove('show'));

  // 状态随时间衰减（幂等，可与其他窗口/小组件并行）
  setInterval(tick, 60000);
}

document.addEventListener('DOMContentLoaded', init);
