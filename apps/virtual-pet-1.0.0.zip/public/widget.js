// 桌面宠物小组件：宠物住在桌面上，点击切换动作，状态条实时显示
// 数据与主界面共享 localStorage（同源），storage 事件跨 iframe 同步
import {
  loadData, saveData, applyDecay, SpriteAnimator, ANIM_KEYS, sheetUrlOf,
} from './pet-core.js';

let data = loadData();
let animator = null;

function currentPet() {
  return data.pets.find(p => p.id === data.currentPetId) || data.pets[0];
}

function render() {
  const pet = currentPet();
  if (!pet) return;
  document.getElementById('pet-name').textContent = pet.name;
  document.getElementById('w-hunger').style.width = pet.hunger + '%';
  document.getElementById('w-mood').style.width = pet.happiness + '%';
  document.getElementById('w-energy').style.width = pet.energy + '%';
  if (animator.sheetUrl !== sheetUrlOf(pet)) animator.setSheet(sheetUrlOf(pet));
}

function reload() {
  data = loadData();
  render();
}

function tick() {
  const pet = currentPet();
  if (!pet) return;
  applyDecay(pet);
  saveData(data);   // 衰减写回，主界面经 storage 事件同步
  render();
}

function init() {
  const pet = currentPet();
  if (pet) applyDecay(pet);

  animator = new SpriteAnimator(document.getElementById('pet-sprite'), {
    sheetUrl: sheetUrlOf(pet || {}),
    displayWidth: 150,
  });
  animator.play((pet && pet.currentAnimation) || 'idle');

  // 点击宠物切换动作（并保存偏好，主界面同步）
  document.getElementById('pet-sprite').addEventListener('click', () => {
    const p = currentPet();
    if (!p) return;
    const idx = ANIM_KEYS.indexOf(animator.currentAnimation);
    const next = ANIM_KEYS[(idx + 1) % ANIM_KEYS.length];
    animator.play(next);
    p.currentAnimation = next;
    saveData(data);
  });

  // 主界面/其他窗口改动 → 同步（本 iframe 自己写不触发 storage，由 tick 兜底）
  window.addEventListener('storage', reload);

  render();
  setInterval(tick, 60000);
}

document.addEventListener('DOMContentLoaded', init);
