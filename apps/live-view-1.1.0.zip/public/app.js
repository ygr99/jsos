/**
 * 直播视界 —— 前端逻辑
 * ---------------------------------------------------------------
 * 数据：/api/state（模式 A，服务端 DATA_DIR 持久化）
 * 房间状态：/api/room/:platform/:roomId（服务端归一化）
 * 图片：/api/img?u=（同源代理，COEP 要求）
 * 主题：html.dark + matchMedia + window.JSOS?.onThemeChange
 */
'use strict';

const PLATFORM_META = {
  douyu: { name: '斗鱼', color: '#ff5d23' },
  bilibili: { name: 'B站', color: '#23ade5' },
  douyin: { name: '抖音', color: '#111111' }, // 用户拍板：抖音徽章用黑色（原红色与浅色封面撞色）
};

const PLACEHOLDER_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="320" height="180" fill="#8a86f0"/><text x="160" y="96" font-size="16" fill="#ffffff" text-anchor="middle" font-family="sans-serif">暂无封面</text></svg>'
  );

let streams = [];            // [{platform, roomId, customName, tags}]
const roomData = new Map();  // key → {ok:true, room} | {ok:false, error}
const pendingFetch = new Set(); // 正在拉取的 key
let currentFilter = { platform: 'all', tag: 'all' };
let editingKey = null;       // 编辑模式的 key；null = 添加模式
let refreshSeq = 0;          // 刷新序号（防止旧响应覆盖新状态）
let toastTimer = null;

const $ = (sel) => document.querySelector(sel);
const grid = $('#cardGrid');
const keyOf = (s) => `${s.platform}-${s.roomId}`;

/* ------------------------------ 主题 ------------------------------ */

function applyTheme(theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
}

function initTheme() {
  try {
    const saved = localStorage.getItem('live-view.theme-override'); // UI 偏好，丢了无所谓
    if (saved === 'dark' || saved === 'light') {
      applyTheme(saved);
      return;
    }
  } catch { /* ignore */ }
  applyTheme(matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    applyTheme(e.matches ? 'dark' : 'light');
  });
  window.JSOS?.onThemeChange?.(applyTheme);
}

/* ------------------------------ 工具 ------------------------------ */

function showToast(msg, type = 'info') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast' + (type === 'error' ? ' is-error' : type === 'success' ? ' is-success' : '');
  el.toggleAttribute('hidden', false);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toggleAttribute('hidden', true), 2600);
}

function imgProxy(url) {
  if (!url) return '';
  return '/api/img?u=' + encodeURIComponent(url);
}

function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function displayName(stream) {
  if (stream.customName) return stream.customName;
  const d = roomData.get(keyOf(stream));
  if (d?.ok && d.room?.name) return d.room.name;
  return `${PLATFORM_META[stream.platform]?.name || stream.platform} · ${stream.roomId}`;
}

function getAllTags() {
  const set = new Set();
  streams.forEach((s) => (s.tags || []).forEach((t) => set.add(t)));
  return [...set];
}

/* ------------------------------ 数据加载 ------------------------------ */

async function loadState() {
  const r = await fetch('/api/state');
  const j = await r.json();
  streams = Array.isArray(j?.streams) ? j.streams : [];
}

async function saveState() {
  const r = await fetch('/api/state', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ streams }),
  });
  const j = await r.json();
  if (!j?.ok) throw new Error(j?.error || '保存失败');
}

async function fetchRoomData(stream) {
  const key = keyOf(stream);
  pendingFetch.add(key);
  renderCards();
  try {
    const r = await fetch(`/api/room/${stream.platform}/${encodeURIComponent(stream.roomId)}`);
    const j = await r.json();
    roomData.set(key, j?.ok ? { ok: true, room: j.room } : { ok: false, error: j?.error || `HTTP ${r.status}` });
  } catch (e) {
    roomData.set(key, { ok: false, error: e?.message || '网络错误' });
  } finally {
    pendingFetch.delete(key);
  }
}

async function refreshAll() {
  const seq = ++refreshSeq;
  $('#refreshBtn').disabled = true;
  await Promise.all(streams.map((s) => fetchRoomData(s)));
  if (seq === refreshSeq) {
    renderTagPills();
    renderCards();
    $('#refreshBtn').disabled = false;
  }
}

/* ------------------------------ 渲染 ------------------------------ */

function cardSkeletonHTML() {
  return `
    <div class="lv-skel-cover"></div>
    <div class="lv-skel-body">
      <div class="lv-skel-line w60"></div>
      <div class="lv-skel-line"></div>
      <div class="lv-skel-line w40"></div>
    </div>`;
}

function cardBodyHTML(stream) {
  const meta = PLATFORM_META[stream.platform] || { name: stream.platform, color: '#6c5ce7' };
  const d = roomData.get(keyOf(stream));

  if (d && !d.ok) {
    return `
      <div class="lv-body">
        <div class="lv-error-msg">加载失败：${esc(d.error)}</div>
        <div class="lv-actions">
          <button class="btn btn-ghost lv-retry" type="button" data-key="${esc(keyOf(stream))}">重试</button>
          <button class="btn btn-danger-soft lv-del" type="button" data-key="${esc(keyOf(stream))}">删除</button>
        </div>
      </div>`;
  }

  const room = d?.ok ? d.room : null;
  const isLive = room ? room.isLive : false;
  const coverRaw = room?.coverUrl || room?.avatarUrl || '';
  const avatarRaw = room?.avatarUrl || '';
  const name = displayName(stream);
  const category = room?.category || '';
  const hot = room?.hot || '';
  const roomUrl = room?.roomUrl
    || (meta.name && `${{ douyu: 'https://www.douyu.com/', bilibili: 'https://live.bilibili.com/', douyin: 'https://live.douyin.com/' }[stream.platform] || ''}${stream.roomId}`);

  return `
    <div class="lv-cover" data-url="${esc(roomUrl)}" title="点击进入直播间">
      ${coverRaw
        ? `<img src="${esc(imgProxy(coverRaw))}" alt="${esc(name)}" loading="lazy"
              onerror="this.onerror=null;this.src='${PLACEHOLDER_IMG}'">`
        : '<div class="lv-noimg">暂无封面</div>'}
      <span class="lv-badge-platform" style="background-color:${esc(meta.color)}">${esc(meta.name)}</span>
      ${room ? `<span class="lv-badge-status ${isLive ? 'is-live' : 'is-off'}">${isLive ? '直播中' : '未开播'}</span>` : ''}
      ${hot ? `<span class="lv-badge-hot">${esc(hot)}</span>` : ''}
    </div>
    <div class="lv-body">
      <div class="lv-anchor">
        ${avatarRaw ? `<img class="lv-avatar" src="${esc(imgProxy(avatarRaw))}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : ''}
        <span class="lv-name" title="${esc(name)}">${esc(name)}</span>
      </div>
      ${category ? `<div class="lv-category" title="${esc(category)}">${esc(category)}</div>` : '<div class="lv-category lv-empty-line">&nbsp;</div>'}
      <div class="lv-tags${(stream.tags || []).length ? '' : ' lv-tags-empty'}">${(stream.tags || []).map((t) => `<span class="lv-tag">${esc(t)}</span>`).join('')}</div>
      <div class="lv-actions">
        <button class="btn btn-ghost lv-edit" type="button" data-key="${esc(keyOf(stream))}">编辑</button>
        <button class="btn btn-danger-soft lv-del" type="button" data-key="${esc(keyOf(stream))}">删除</button>
      </div>
    </div>`;
}

function filteredStreams() {
  return streams.filter((s) => {
    if (currentFilter.platform !== 'all' && s.platform !== currentFilter.platform) return false;
    if (currentFilter.tag !== 'all' && !(s.tags || []).includes(currentFilter.tag)) return false;
    return true;
  });
}

function renderCards() {
  const list = filteredStreams();
  $('#emptyState').toggleAttribute('hidden', streams.length > 0);
  $('#filterEmpty').toggleAttribute('hidden', !(streams.length > 0 && list.length === 0));

  const keyed = list.map((s) => ({ s, d: roomData.get(keyOf(s)) }));
  // 分组：直播中一组，其余（未开播/加载失败/加载中）一组，中间有分割线；
  // 没有任何"直播中"（或还没拉到数据）时不分组，保持单个网格
  const live = keyed.filter((k) => k.d?.ok && k.d.room.isLive);
  const rest = keyed.filter((k) => !(k.d?.ok && k.d.room.isLive));

  const cardHTML = ({ s }) => {
    const hasData = roomData.has(keyOf(s));
    const isPending = pendingFetch.has(keyOf(s)) && !hasData;
    return `
      <article class="lv-card${isPending ? ' skeleton' : ''}${hasData && !roomData.get(keyOf(s)).ok ? ' is-error' : ''}" data-key="${esc(keyOf(s))}">
        ${isPending ? cardSkeletonHTML() : cardBodyHTML(s)}
      </article>`;
  };

  let html = '';
  if (live.length) {
    html += `<div class="grid lv-grid">${live.map(cardHTML).join('')}</div>`;
  }
  if (live.length && rest.length) {
    html += `<div class="lv-section-divider" role="separator" aria-label="未开播"><span>未开播</span></div>`;
  }
  if (rest.length) {
    html += `<div class="grid lv-grid">${rest.map(cardHTML).join('')}</div>`;
  }
  grid.innerHTML = html;

  updateStats();
  bindCardEvents();
}

function updateStats() {
  let live = 0;
  let known = 0;
  streams.forEach((s) => {
    const d = roomData.get(keyOf(s));
    if (d?.ok) {
      known++;
      if (d.room.isLive) live++;
    }
  });
  $('#liveCount').textContent = known ? String(live) : '-';
  $('#nonLiveCount').textContent = known ? String(known - live) : '-';
}

function renderTagPills() {
  const box = $('#tagPills');
  const tags = getAllTags();
  box.innerHTML = ['all', ...tags]
    .map((t, i) => {
      const active = currentFilter.tag === t;
      const label = t === 'all' ? '全部标签' : t;
      return `<button class="pill pill-tag${active ? ' active' : ''}" data-tag="${esc(t)}" type="button"${i === 0 ? '' : ''}>${esc(label)}</button>`;
    })
    .join('');
  box.querySelectorAll('.pill-tag').forEach((btn) => {
    btn.addEventListener('click', () => {
      currentFilter.tag = btn.dataset.tag;
      renderTagPills();
      renderCards();
    });
  });
}

/* ------------------------------ 卡片事件 ------------------------------ */

function findStream(key) {
  return streams.find((s) => keyOf(s) === key);
}

function bindCardEvents() {
  grid.querySelectorAll('.lv-cover[data-url]').forEach((el) => {
    el.addEventListener('click', () => {
      const url = el.dataset.url;
      if (url) window.open(url, '_blank', 'noopener'); // 跳外部站点，_blank 是唯一合理场景
    });
  });

  grid.querySelectorAll('.lv-retry').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const s = findStream(btn.dataset.key);
      if (!s) return;
      roomData.delete(keyOf(s));
      await fetchRoomData(s);
      renderCards();
    });
  });

  grid.querySelectorAll('.lv-edit').forEach((btn) => {
    btn.addEventListener('click', () => openModal(findStream(btn.dataset.key)));
  });

  // 两步确认删除（iframe 里 confirm() 不可靠）
  grid.querySelectorAll('.lv-del').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (btn.dataset.armed !== '1') {
        btn.dataset.armed = '1';
        btn.textContent = '确认删除？';
        setTimeout(() => {
          if (btn.isConnected) {
            btn.dataset.armed = '';
            btn.textContent = '删除';
          }
        }, 3000);
        return;
      }
      const key = btn.dataset.key;
      streams = streams.filter((s) => keyOf(s) !== key);
      roomData.delete(key);
      try {
        await saveState();
        showToast('已删除', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
      renderTagPills();
      renderCards();
    });
  });
}

/* ------------------------------ 添加 / 编辑弹窗 ------------------------------ */

function openModal(stream = null) {
  editingKey = stream ? keyOf(stream) : null;
  $('#modalTitle').textContent = stream ? '编辑直播间' : '添加直播间';
  $('#submitBtn').textContent = stream ? '保存' : '添加';

  const sel = $('#fPlatform');
  const roomIdInput = $('#fRoomId');
  if (stream) {
    sel.value = stream.platform;
    sel.disabled = true;
    roomIdInput.value = stream.roomId;
    roomIdInput.disabled = true;
  } else {
    sel.disabled = false;
    roomIdInput.value = '';
    roomIdInput.disabled = false;
  }
  $('#fCustomName').value = stream?.customName || '';
  $('#fTags').value = (stream?.tags || []).join(',');
  $('#formError').toggleAttribute('hidden', true);
  $('#submitBtn').disabled = false;
  $('#modalMask').toggleAttribute('hidden', false);
  (stream ? $('#fCustomName') : roomIdInput).focus();
}

function closeModal() {
  $('#modalMask').toggleAttribute('hidden', true);
  editingKey = null;
}

async function submitForm(e) {
  e.preventDefault();
  const errEl = $('#formError');
  const showErr = (msg) => {
    errEl.textContent = msg;
    errEl.toggleAttribute('hidden', false);
  };

  const platform = $('#fPlatform').value;
  const roomId = $('#fRoomId').value.trim();
  const customName = $('#fCustomName').value.trim();
  const tags = $('#fTags').value.split(',').map((t) => t.trim()).filter(Boolean);

  if (!roomId) return showErr('请输入房间号');

  const submitBtn = $('#submitBtn');
  submitBtn.disabled = true;

  try {
    if (editingKey) {
      // 编辑：只改 customName / tags
      const s = findStream(editingKey);
      if (!s) throw new Error('条目不存在');
      s.customName = customName;
      s.tags = tags;
      await saveState();
      closeModal();
      showToast('已保存', 'success');
      renderTagPills();
      renderCards();
      return;
    }

    // 添加：先验证房间可取
    if (streams.some((s) => s.platform === platform && s.roomId === roomId)) {
      submitBtn.disabled = false;
      return showErr('该直播间已存在');
    }
    const r = await fetch(`/api/room/${platform}/${encodeURIComponent(roomId)}`);
    const j = await r.json();
    if (!j?.ok) throw new Error(j?.error || '无法获取直播间信息，请检查房间号');

    const stream = { platform, roomId, customName, tags };
    streams.push(stream);
    await saveState();
    closeModal();
    showToast('添加成功', 'success');
    renderTagPills();
    renderCards();
    await fetchRoomData(stream);
    renderCards();
  } catch (err) {
    showErr(err?.message || '操作失败');
    submitBtn.disabled = false;
  }
}

/* ------------------------------ 初始化 ------------------------------ */

function bindStaticEvents() {
  $('#platformPills').querySelectorAll('.pill').forEach((btn) => {
    btn.addEventListener('click', () => {
      $('#platformPills').querySelectorAll('.pill').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter.platform = btn.dataset.platform;
      renderCards();
    });
  });

  $('#refreshBtn').addEventListener('click', refreshAll);
  $('#addBtn').addEventListener('click', () => openModal(null));
  $('#cancelBtn').addEventListener('click', closeModal);
  $('#modalMask').addEventListener('click', (e) => {
    if (e.target === $('#modalMask')) closeModal();
  });
  $('#streamForm').addEventListener('submit', submitForm);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('#modalMask').hasAttribute('hidden')) closeModal();
  });
}

async function init() {
  initTheme();
  bindStaticEvents();
  try {
    await loadState();
  } catch (e) {
    showToast('加载直播源失败', 'error');
  }
  renderTagPills();
  renderCards();
  if (streams.length) refreshAll();
}

init();
