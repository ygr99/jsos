/**
 * WorkBuddy 积分 — 积分消耗统计
 * ---------------------------------------------------------------
 * 零依赖：只用 Node 内置模块（http/fs/path/url）。
 * 选它而非 express 是为了省掉 installCommand 与 node_modules 体积。
 * cookie 落 DATA_DIR，不进前端存储。
 */

import { createServer } from 'node:http';
import { readFileSync, writeFileSync, mkdirSync, renameSync, existsSync } from 'node:fs';
import { join, dirname, extname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchUsage, fetchSummary, MAX_SPAN_DAYS } from './lib/workbuddy.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const PORT = process.env.PORT || 4020;
const PUBLIC_DIR = join(__dirname, 'public');

mkdirSync(DATA_DIR, { recursive: true });

/* ---------------- 凭据存储（单文档 JSON） ---------------- */

const CREDS_FILE = join(DATA_DIR, 'credentials.json');
let credsCache = null;

/**
 * 注意「读不到」不能写进 credsCache：进程启动时 DATA_DIR 的快照恢复可能晚于第一个请求，
 * 一旦把空对象缓存住，这个进程余生都会报「未配置」，而用户的 cookie 其实几秒后就落盘了。
 */
function loadCreds() {
  if (credsCache) return credsCache;
  try {
    credsCache = JSON.parse(readFileSync(CREDS_FILE, 'utf8'));
  } catch {
    return {};
  }
  return credsCache;
}

function saveCreds(next) {
  const tmp = CREDS_FILE + '.tmp';
  writeFileSync(tmp, JSON.stringify(next, null, 2), 'utf8');
  renameSync(tmp, CREDS_FILE);
  credsCache = next;
}

/** 对外只回传「配没配」，绝不回传凭据本身 */
function publicCreds() {
  const c = loadCreds();
  return { configured: Boolean(c.cookie), updatedAt: c.updatedAt || null };
}

/* ---------------- 日期区间 ---------------- */

const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

const RANGE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * 把请求的区间参数解析为 { start, end, label, preset }
 * preset ∈ today | week | month | lastMonth | custom
 * 不传 preset 时默认今天。
 */
function resolveRange(preset, start, end) {
  const now = new Date();
  const today = fmt(now);
  const mk = (s, e, label, p) => ({ start: s, end: e, label, preset: p });

  if (preset === 'custom') {
    if (!RANGE_RE.test(start || '') || !RANGE_RE.test(end || '')) {
      return { error: '自选区间需要提供合法的 start 与 end（YYYY-MM-DD）' };
    }
    if (start > end) return { error: '开始日期不能晚于结束日期' };
    if (end > today) return { error: '结束日期不能晚于今天' };
    const span = Math.round((new Date(end) - new Date(start)) / 86400000);
    if (span + 1 > MAX_SPAN_DAYS) {
      return { error: `单次最多查 ${MAX_SPAN_DAYS} 天，当前选了 ${span + 1} 天` };
    }
    return { range: mk(start, end, `${start} ~ ${end}`, 'custom') };
  }

  if (preset === 'week') {
    // 周一为一周之始
    const dow = (now.getDay() + 6) % 7;
    const mon = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dow);
    return { range: mk(fmt(mon), today, '本周', 'week') };
  }
  if (preset === 'month') {
    return {
      range: mk(fmt(new Date(now.getFullYear(), now.getMonth(), 1)), today, '本月', 'month'),
    };
  }
  if (preset === 'lastMonth') {
    const y = now.getFullYear();
    const m = now.getMonth(); // 上月 = 本月的 month - 1
    const first = new Date(y, m - 1, 1);
    const last = new Date(y, m, 0);
    return {
      range: mk(fmt(first), fmt(last), '上月', 'lastMonth'),
      note: last > now ? '（本月尚未结束，统计到今天）' : '',
    };
  }
  // 默认：今天
  return { range: mk(today, today, '今天', 'today') };
}

/* ---------------- 统计聚合 ---------------- */

const round2 = (n) => Math.round(n * 100) / 100;

function dayKey(ts) {
  return fmt(new Date(ts));
}

function aggregate(records) {
  const byDay = new Map();
  const byModel = new Map();
  let total = 0;

  for (const r of records) {
    total += r.credit;
    const dk = dayKey(r.ts);
    byDay.set(dk, (byDay.get(dk) || 0) + r.credit);
    byModel.set(r.model, (byModel.get(r.model) || 0) + r.credit);
  }

  const toSorted = (m) => [...m.entries()]
    .map(([key, credit]) => ({ key, credit: round2(credit) }))
    .sort((a, b) => b.credit - a.credit);

  // 明细只回消耗最高的 100 条：单条 input 可达数 KB，全量会让首屏 payload 过大
  const topDetail = [...records]
    .sort((a, b) => b.credit - a.credit)
    .slice(0, 100)
    .map((r) => ({
      time: r.ts ? new Date(r.ts).toLocaleString('zh-CN', { hour12: false }) : '—',
      credit: r.credit,
      model: r.model,
      prompt: r.prompt || '',
    }));

  return {
    total: round2(total),
    count: records.length,
    byDay: [...byDay.entries()]
      .map(([date, credit]) => ({ date, credit: round2(credit) }))
      .sort((a, b) => a.date.localeCompare(b.date)),
    byModel: toSorted(byModel),
    topDetail,
  };
}

/* ---------------- HTTP 工具 ---------------- */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
};

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    // 小组件每次点刷新都要拿最新数据，不给任何一层（预览 SW / HTTP 缓存）留可缓存的余地
    'cache-control': 'no-store',
  });
  res.end(body);
}

function readBody(req, limit = 256 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('请求体过大')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new Error('请求体不是合法 JSON')); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  // favicon 由页面内联 data URL 承担，容器里请求静态文件会 404，这里直接 204
  if (pathname === '/favicon.ico') {
    res.writeHead(204);
    return res.end();
  }
  const rel = pathname === '/' ? '/index.html' : pathname;
  // 防目录穿越：规范化后必须仍在 public 目录内
  const target = normalize(join(PUBLIC_DIR, rel));
  if (!target.startsWith(PUBLIC_DIR) || !existsSync(target)) {
    return sendJson(res, 404, { error: 'Not Found' });
  }
  const body = readFileSync(target);
  res.writeHead(200, {
    'content-type': MIME[extname(target)] || 'application/octet-stream',
    'content-length': body.length,
  });
  res.end(body);
}

/* ---------------- 路由 ---------------- */

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const path = url.pathname;
  const q = url.searchParams;

  try {
    /* --- meta：默认区间在今天 --- */
    if (path === '/api/meta' && req.method === 'GET') {
      const { range, note } = resolveRange('today');
      return sendJson(res, 200, {
        maxSpanDays: MAX_SPAN_DAYS,
        defaultRange: { ...range, note: note || '' },
        credentials: publicCreds(),
        proxyConfigured: Boolean(process.env.PROXY_URL),
      });
    }

    /* --- 凭据读写 --- */
    if (path === '/api/credentials' && req.method === 'POST') {
      const { cookie } = await readBody(req);
      const c = loadCreds();
      if (cookie === null || cookie === undefined || cookie === '') {
        delete c.cookie;
        delete c.updatedAt;
      } else {
        if (typeof cookie !== 'string') return sendJson(res, 400, { error: 'cookie 必须是字符串' });
        c.cookie = cookie.trim();
        c.updatedAt = new Date().toISOString();
      }
      saveCreds(c);
      return sendJson(res, 200, { ok: true, credentials: publicCreds() });
    }

    /* --- 小组件数据：今天消耗 + 积分余额（一次给全，前端不再二次请求） --- */
    if (path === '/api/widget' && req.method === 'GET') {
      const cred = loadCreds();
      if (!cred.cookie) {
        return sendJson(res, 200, { configured: false, today: 0, balance: 0 });
      }
      const { range } = resolveRange('today');
      try {
        const [records, summary] = await Promise.all([
          fetchUsage(cred.cookie, range),
          fetchSummary(cred.cookie).catch(() => null),
        ]);
        const agg = aggregate(records);
        const balance = (summary?.packages || []).reduce((a, p) => a + (p.remain || 0), 0);
        return sendJson(res, 200, {
          configured: true,
          today: agg.total,
          count: agg.count,
          balance: round2(balance),
          planName: summary?.planName || '—',
          fetchedAt: new Date().toISOString(),
        });
      } catch (err) {
        // 小组件面积小，直接把错误当成展示内容，不抛给前端
        return sendJson(res, 200, {
          configured: true,
          error: err.status === 401 ? '凭据已失效' : (err.message || '拉取失败'),
          today: 0, balance: 0, count: 0,
        });
      }
    }

    /* --- 用量查询 --- */
    if (path === '/api/usage' && req.method === 'GET') {
      const { range, error, note } = resolveRange(
        q.get('preset') || 'today', q.get('start'), q.get('end')
      );
      if (error) return sendJson(res, 400, { error });

      const cred = loadCreds();
      if (!cred.cookie) {
        return sendJson(res, 428, { error: '尚未配置凭据', needCredential: true });
      }

      try {
        const [records, summary] = await Promise.all([
          fetchUsage(cred.cookie, range),
          fetchSummary(cred.cookie).catch(() => null),
        ]);
        return sendJson(res, 200, {
          ...range, note: note || '',
          ...aggregate(records),
          summary,
          fetchedAt: new Date().toISOString(),
        });
      } catch (err) {
        const unauthorized = err.status === 401;
        return sendJson(res, unauthorized ? 401 : 502, {
          error: err.message || '拉取失败',
          needCredential: unauthorized,
          detail: err.raw || null,
          via: err.via || null,
        });
      }
    }

    /* --- 静态资源 --- */
    if (req.method === 'GET' || req.method === 'HEAD') {
      return serveStatic(req, res, path);
    }

    return sendJson(res, 405, { error: 'Method Not Allowed' });
  } catch (err) {
    return sendJson(res, 400, { error: err.message || '请求处理失败' });
  }
});

server.listen(PORT, () => {
  console.log(`workbuddy-credit listening on ${PORT} (DATA_DIR=${DATA_DIR}, proxy=${process.env.PROXY_URL || 'none/direct'})`);
});
