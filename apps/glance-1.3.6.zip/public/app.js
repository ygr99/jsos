/* 关注数（glance）前端 —— 无框架、无依赖
   只有一种记法：写绝对值（体重 / 余额 / 关注数）—— 每次记下"此刻是多少"
   涨跌颜色按「语义」走（better: up / down / null），不按方向一刀切
   小组件只读，绑定关系存服务端（per-instance 状态不能只放前端） */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  const D = {
    wall: $('#wall'), empty: $('#empty'), count: $('#count'), chips: $('#chips'),
    addBtn: $('#add-btn'), deskBtn: $('#desk-btn'), deskMenu: $('#desk-menu'),
    drawer: $('#drawer'), drawerMask: $('#drawer-mask'),
    modalMask: $('#modal-mask'), modal: $('#modal'), toast: $('#toast'),
  };

  const APP_ID = 'glance';
  const UNITS = ['kg', '斤', '¥', '元', '个', '次', 'ml', '公里', '步', '岁'];
  const WIDGETS = [
    { id: 'wall', label: '关注数墙', desc: '最多 6 个，4×2' },
    { id: 'wall-lg', label: '关注数全览', desc: '最多 24 个，8×4' },
    { id: 'metric', label: '单个关注数', desc: '盯住其中一个，2×2（放进桌面后再点一下选哪个）' },
  ];

  let metrics = [];
  let openId = null;
  let editLogId = null;
  let wizard = null;        // 新增指标的分步状态；null = 不在新增流程
  let pendingConfirm = null;

  /* ---------------- 工具 ---------------- */

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

  function fmtNum(v, decimals) {
    if (!isNum(v)) return '—';
    return v.toLocaleString('zh-CN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  }
  const signed = (v, decimals) => (!isNum(v) || v === 0 ? '0' : (v > 0 ? '+' : '−') + fmtNum(Math.abs(v), decimals));

  const pad2 = (n) => String(n).padStart(2, '0');
  const dayKey = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const fmtTime = (t) => { const d = new Date(t); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };
  const fmtDay = (t) => { const d = new Date(t); return pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); };
  function dayLabel(t) {
    const k = dayKey(t), today = dayKey(Date.now());
    if (k === today) return '今天';
    if (k === today - 86400000) return '昨天';
    const d = new Date(t);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }

  // 涨跌色跟语义走：越大越好 → 涨=好色；越小越好 → 跌=好色；不判断 → 灰
  function tone(m, delta) {
    if (!delta || !m.better) return 'flat';
    const good = m.better === 'up' ? delta > 0 : delta < 0;
    return good ? 'good' : 'bad';
  }

  function toast(msg) {
    const jsos = window.JSOS;
    if (jsos && typeof jsos.toast === 'function') {
      try { Promise.resolve(jsos.toast({ title: msg, type: 'default' })).catch(() => {}); return; } catch { /* 落到自绘 */ }
    }
    D.toast.textContent = msg;
    D.toast.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { D.toast.hidden = true; }, 2000);
  }
  const fail = (e) => toast(e && e.message ? e.message : '操作失败');

  /* ---------------- 跨页同步（主界面 ↔ 小组件，同源） ---------------- */

  let bc = null;
  try { bc = new BroadcastChannel('glance'); } catch { /* 老浏览器没有就算了 */ }
  const notifyChange = () => { try { bc?.postMessage({ t: Date.now() }); } catch { /* ignore */ } };

  /* ---------------- 主题 ---------------- */

  const applyTheme = (t) => document.documentElement.classList.toggle('dark', t === 'dark');
  async function initTheme() {
    let t = null;
    try { t = await window.JSOS?.getTheme?.(); } catch { t = null; }
    if (!t) t = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    applyTheme(t);
    try { window.JSOS?.onThemeChange?.((x) => applyTheme(x)); } catch { /* 本机直跑没有 JSOS */ }
    window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', (e) => {
      if (!window.JSOS?.getTheme) applyTheme(e.matches ? 'dark' : 'light');
    });
  }

  /* ---------------- API ---------------- */

  async function api(path, opts) {
    const res = await fetch(path, {
      method: (opts && opts.method) || 'GET',
      headers: opts && opts.body ? { 'content-type': 'application/json' } : undefined,
      body: opts && opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch { data = null; }
    if (!res.ok) throw new Error((data && data.error) || `请求失败（${res.status}）`);
    return data;
  }

  function absorb(data) {
    if (!data || !data.metric) return null;
    const i = metrics.findIndex((x) => x.id === data.metric.id);
    if (i >= 0) metrics[i] = data.metric; else metrics.push(data.metric);
    return data.metric;
  }

  async function createMetric(payload) { absorb(await api('/api/metrics', { method: 'POST', body: payload })); notifyChange(); renderWall(); }
  async function patchMetric(id, patch) {
    const m = absorb(await api(`/api/metrics/${id}`, { method: 'PATCH', body: patch }));
    notifyChange(); renderWall();
    // 抽屉正开着就重绘 —— 否则「置顶」点完按钮文案不翻面、改名/配色也不生效（1.3.3 修的 bug）
    if (m && openId === id) renderDrawer();
  }
  async function removeMetric(id) {
    const data = await api(`/api/metrics/${id}`, { method: 'DELETE' });
    metrics = metrics.filter((m) => m.id !== id);
    if (openId === id) closeDrawer();
    notifyChange();
    renderWall();
    return data;
  }
  async function addLog(id, payload) {
    const m = absorb(await api(`/api/metrics/${id}/log`, { method: 'POST', body: payload }));
    notifyChange(); renderWall();
    if (openId === id) renderDrawer();
    return m;
  }
  async function patchLog(id, logId, patch) {
    absorb(await api(`/api/metrics/${id}/log/${logId}`, { method: 'PATCH', body: patch }));
    notifyChange(); renderWall();
    if (openId === id) renderDrawer();
  }
  async function removeLog(id, logId) {
    absorb(await api(`/api/metrics/${id}/log/${logId}`, { method: 'DELETE' }));
    notifyChange(); renderWall();
    if (openId === id) renderDrawer();
  }

  /* ---------------- 趋势线 / 图表 ---------------- */

  function sparkSVG(m) {
    const W = 56, H = 20;
    const pts = (m.logs || []).filter((l) => isNum(l.v)).slice(-12).map((l) => l.v);
    if (pts.length < 2) return `<svg class="spark" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"></svg>`;
    const min = Math.min(...pts), max = Math.max(...pts), span = max - min || 1;
    const stepX = W / (pts.length - 1);
    const d = pts.map((p, i) => `${(i * stepX).toFixed(1)},${(H - 2 - ((p - min) / span) * (H - 5)).toFixed(1)}`).join(' ');
    return `<svg class="spark" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"><polyline points="${d}" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  // 少于 2 个点就不画线 —— 两个点之间连一条直线不是"趋势"，是噪声（看着像图坏了）
  function chartHTML(m) {
    const W = 380, H = 116, PX = 6, PY = 12;
    const pts = (m.logs || []).filter((l) => isNum(l.v)).slice(-30);
    if (pts.length < 2) return `<div class="chart"><p class="chart-empty">记满 2 次才会出现趋势线</p></div>`;
    const vals = pts.map((l) => l.v);
    let min = Math.min(...vals), max = Math.max(...vals);
    if (max - min === 0) { min -= 1; max += 1; }
    const span = max - min || 1;
    const stepX = (W - PX * 2) / (pts.length - 1);
    const coords = vals.map((v, i) => [PX + i * stepX, H - PY - ((v - min) / span) * (H - PY * 2)]);
    const line = coords.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
    const area = `${PX},${H - PY} ${line} ${(PX + (pts.length - 1) * stepX).toFixed(1)},${H - PY}`;
    const last = coords[coords.length - 1];
    const first = pts[0], tail = pts[pts.length - 1];
    return `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="数值趋势">
      <polygon points="${area}" fill="var(--accent-soft)"/>
      <polyline points="${line}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
      <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="3.5" fill="var(--accent)"/>
    </svg>
    <div class="chart-legend"><span>${fmtDay(first.t)} · ${fmtNum(first.v, m.decimals)}</span><span>${fmtDay(tail.t)} · ${fmtNum(tail.v, m.decimals)}</span></div></div>`;
  }

  /* ---------------- 卡片墙 ---------------- */

  // 排序：置顶的排前面；同为置顶按「后置顶的排最前」（pinnedAt 倒序，1.3.4 方案 A）；
  // 没置顶的按创建顺序。旧数据没有 pinnedAt 当作 0，排在新置顶之后。
  const sortedMetrics = () => metrics.slice().sort((a, b) => {
    const pa = a.pinned ? 1 : 0, pb = b.pinned ? 1 : 0;
    if (pa !== pb) return pb - pa;
    if (pa) return (b.pinnedAt ? Date.parse(b.pinnedAt) : 0) - (a.pinnedAt ? Date.parse(a.pinnedAt) : 0);
    return (a.order || 0) - (b.order || 0);
  });

  // 脚注三态：今天真的变了 → 「今日 ±x」（语义色）；今天没变（哪怕记过起手值）→ 「较上次 没变」；从没记过 → 引导去记
  function cardHTML(m) {
    const t = tone(m, m.todayDelta);
    const noVal = !isNum(m.value);
    const valueHTML = noVal
      ? '<span class="card-value is-empty">还没有值</span>'
      : `<span class="card-value">${fmtNum(m.value, m.decimals)}${m.unit ? `<em>${esc(m.unit)}</em>` : ''}</span>`;
    let foot;
    if (noVal) foot = '<span class="card-delta tone-flat">点开记一个值</span>';
    else if (m.todayDelta) foot = `<span class="card-delta tone-${t}">今日 ${signed(m.todayDelta, m.decimals)}</span>`;
    else if (m.lastLogAt) foot = '<span class="card-delta tone-flat">较上次 没变</span>';
    else foot = '<span class="card-delta tone-flat">刚创建</span>';
    return `<div class="card tone-${t}${openId === m.id ? ' is-open' : ''}" data-id="${esc(m.id)}" role="button" tabindex="0" aria-label="${esc(m.name)}详情">
      <span class="card-rail"></span>
      <span class="card-body">
        <span class="card-head"><span class="card-name">${esc(m.name)}</span>${m.pinned ? '<span class="card-pin">置顶</span>' : ''}</span>
        ${valueHTML}
        <span class="card-foot">${foot}<span class="tone-${t}">${sparkSVG(m)}</span></span>
      </span>
    </div>`;
  }

  function renderWall() {
    const list = sortedMetrics();
    D.count.textContent = list.length ? `${list.length} 项` : '';
    D.wall.innerHTML = list.map(cardHTML).join('');
    D.empty.hidden = list.length > 0;
    D.wall.hidden = list.length === 0;
  }

  /* ---------------- 详情抽屉 ---------------- */

  function progressHTML(m) {
    if (!isNum(m.target) || m.target === 0) return '';
    const cur = isNum(m.value) ? m.value : 0;
    // 基准 = 开始追踪时的值。不能用「当前 ÷ 目标」—— 那样"还差 4.7 kg"会显示成 95% 满，是假的。
    const base = isNum(m.startValue) ? m.startValue : cur;
    const denom = m.target - base;
    let pct;
    if (denom === 0) pct = cur === m.target ? 100 : 0;
    else pct = Math.max(0, Math.min(100, ((cur - base) / denom) * 100));
    const left = m.better === 'down' ? cur - m.target : m.target - cur;
    const done = left <= 0;
    return `<div>
      <div class="progress-row"><span>目标 ${fmtNum(m.target, m.decimals)} ${esc(m.unit)}</span><span>${done ? '已达成' : '还差 ' + fmtNum(Math.abs(left), m.decimals)}</span></div>
      <div class="progress"><i style="width:${pct.toFixed(1)}%"></i></div>
    </div>`;
  }

  function logRows(m) {
    const logs = (m.logs || []).slice().reverse().slice(0, 40);
    if (!logs.length) return '<p class="log-empty">还没有记录。</p>';
    const out = [];
    let curDay = null;
    for (const l of logs) {
      const label = dayLabel(l.t);
      if (label !== curDay) { curDay = label; out.push(`<p class="log-group-date">${esc(label)}</p>`); }
      if (editLogId === l.id) {
        out.push(`<div class="log-row" data-log="${esc(l.id)}">
          <span class="log-time">${fmtTime(l.t)}</span>
          <span class="inline-edit">
            <input type="number" step="any" class="js-edit-v" value="${esc(l.v)}" />
            <input type="text" class="js-edit-note" placeholder="备注" value="${esc(l.note || '')}" />
            <button class="btn btn-primary js-save-log" type="button">保存</button>
            <button class="btn js-cancel-log" type="button">取消</button>
          </span>
        </div>`);
        continue;
      }
      const main = `<span class="log-value">${fmtNum(l.v, m.decimals)}</span><span class="log-delta tone-${tone(m, l.delta)}">${signed(l.delta, m.decimals)}</span>`;
      out.push(`<div class="log-row" data-log="${esc(l.id)}">
        <span class="log-time">${fmtTime(l.t)}</span>
        <span class="log-main">${main}${l.note ? `<span class="log-note">${esc(l.note)}</span>` : ''}</span>
        <span class="log-acts">
          <button class="btn btn-ghost btn-icon js-edit" type="button" title="改这一条">改</button>
          <button class="btn btn-ghost btn-icon js-del" type="button" data-confirm-key="${esc('log:' + l.id)}" title="撤销这一条">撤销</button>
        </span>
      </div>`);
    }
    return out.join('');
  }

  function drawerHTML(m) {
    const unit = esc(m.unit);
    const hasVal = isNum(m.value);
    const t = tone(m, m.todayDelta);

    const note = m.logCount
      ? `今日 ${m.todayCount ? signed(m.todayDelta, m.decimals) : '—'} · 共 ${m.logCount} 条`
      : '还没有记录，先记一个当前值';

    const valueHTML = hasVal
      ? `<div class="big-value" id="drawer-value">${fmtNum(m.value, m.decimals)}${m.unit ? `<em>${unit}</em>` : ''}</div>`
      : '<div class="big-value is-empty" id="drawer-value">—</div>';

    // 步进按钮的标签必须显示步进本值（±0.5 就是 ±0.5）——
    // 不能走 signed(s, m.decimals)：decimals=0 时 −0.5 会被四舍五入成「−1」，按钮写着 −1 实际记 −0.5
    const stepLabel = (s) => (s > 0 ? '+' + s : s < 0 ? '−' + Math.abs(s) : '0');
    const steps = (m.quickSteps || []).map((s) =>
      `<button class="btn js-add-step" type="button" data-step="${esc(String(s))}">${stepLabel(s)}</button>`
    ).join('');

    const entry = '<div class="entry-row"><input type="number" step="any" id="d-input" placeholder="现在的值，例如 62.4" /><button class="btn btn-primary" id="d-record" type="button">记录</button></div>';

    return `
    <header class="drawer-head">
      <div>
        <h2 class="drawer-title">${esc(m.name)}</h2>
        ${m.unit ? `<p class="drawer-sub">${unit}</p>` : ''}
      </div>
      <div style="display:flex;gap:4px;align-items:center">
        <button class="btn btn-ghost js-edit-metric" type="button">编辑</button>
        <button class="btn btn-ghost btn-del js-del-metric" type="button" data-confirm-key="${esc('metric:' + m.id)}">删除</button>
        <button class="btn btn-ghost btn-icon js-pin" type="button">${m.pinned ? '取消置顶' : '置顶'}</button>
        <button class="btn btn-ghost btn-icon js-close" type="button" title="关闭">✕</button>
      </div>
    </header>
    <div class="drawer-body">
      <div class="big-label">当前值</div>
      ${valueHTML}
      <p class="big-note tone-${t}">${note}</p>
      ${progressHTML(m)}
      ${entry}
      <div class="step-row">${steps}<button class="btn js-focus-input" type="button">自定义</button></div>

      <div class="section">
        <p class="section-title">趋势</p>
        ${chartHTML(m)}
      </div>

      <div class="section">
        <p class="section-title">记录</p>
        ${logRows(m)}
      </div>
    </div>`;
  }

  function renderDrawer() {
    const m = metrics.find((x) => x.id === openId);
    if (!m) { closeDrawer(); return; }
    D.drawer.innerHTML = drawerHTML(m);
    wireDrawer(m);
    resetConfirm();
  }

  function openDrawer(id) {
    openId = id;
    editLogId = null;
    D.drawer.hidden = false;
    D.drawerMask.hidden = window.innerWidth >= 880; // 宽屏不遮住卡片墙
    renderWall();
    renderDrawer();
    closeMenu();
  }
  function closeDrawer() {
    openId = null; editLogId = null; pendingConfirm = null;
    D.drawer.hidden = true; D.drawerMask.hidden = true;
    renderWall();
  }

  // 两段式确认（不用原生 confirm：iframe / 沙箱里不保证可用）
  function armConfirm(btn, key, label) {
    if (pendingConfirm && pendingConfirm.key === key) {
      clearTimeout(pendingConfirm.timer);
      pendingConfirm = null;
      return true;
    }
    pendingConfirm = { key, timer: setTimeout(() => { pendingConfirm = null; restoreConfirm(); }, 3000) };
    btn.dataset.original = btn.textContent;
    btn.textContent = label;
    return false;
  }
  const restoreConfirm = () => $$('[data-confirm-key]').forEach((b) => { if (b.dataset.original) b.textContent = b.dataset.original; });
  const resetConfirm = () => { pendingConfirm = null; };

  function wireDrawer(m) {
    const d = D.drawer;
    const input = $('#d-input', d);

    $('.js-close', d)?.addEventListener('click', closeDrawer);
    $('.js-pin', d)?.addEventListener('click', () => patchMetric(m.id, { pinned: !m.pinned }).catch(fail));
    $('.js-focus-input', d)?.addEventListener('click', () => input?.focus());

    $('#d-record', d)?.addEventListener('click', () => {
      const raw = (input?.value ?? '').trim();
      if (raw === '') { toast('请输入数值'); input?.focus(); return; }
      const n = Number(raw);
      if (!Number.isFinite(n)) { toast('数值不合法'); return; }
      addLog(m.id, { v: n }).then(() => { if (input) input.value = ''; }).catch(fail);
    });
    input?.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#d-record', d)?.click(); });

    $$('.js-add-step', d).forEach((b) => b.addEventListener('click', () => {
      const step = Number(b.dataset.step);
      if (!Number.isFinite(step)) return;
      // ⚠️ 没有当前值时不能从 0 开始加减 —— 那会把「体重」点成 −2.0
      if (!isNum(m.value)) { toast('先记一个当前值，再用加减'); input?.focus(); return; }
      addLog(m.id, { v: m.value + step }).catch(fail);
    }));

    $$('.log-row', d).forEach((row) => {
      const logId = row.dataset.log;
      $('.js-edit', row)?.addEventListener('click', () => { editLogId = logId; renderDrawer(); });
      $('.js-cancel-log', row)?.addEventListener('click', () => { editLogId = null; renderDrawer(); });
      $('.js-save-log', row)?.addEventListener('click', async () => {
        const raw = ($('.js-edit-v', row)?.value ?? '').trim();
        const note = ($('.js-edit-note', row)?.value ?? '').trim();
        if (raw === '') { toast('请输入数值'); return; }
        const n = Number(raw);
        if (!Number.isFinite(n)) { toast('数值不合法'); return; }
        try {
          await patchLog(m.id, logId, { note, v: n });
          editLogId = null;
          renderDrawer();
        } catch (e) { fail(e); }
      });
      $('.js-del', row)?.addEventListener('click', (e) => {
        const btn = e.currentTarget;
        if (!armConfirm(btn, 'log:' + logId, '确认撤销？')) return;
        pendingConfirm = null;
        removeLog(m.id, logId).catch(fail);
      });
    });

    $('.js-edit-metric', d)?.addEventListener('click', () => openModal(m));
    $('.js-del-metric', d)?.addEventListener('click', (e) => {
      const btn = e.currentTarget;
      const warn = m.logCount ? `确认删除？(${m.logCount} 条)` : '确认删除？';
      if (!armConfirm(btn, 'metric:' + m.id, warn)) return;
      pendingConfirm = null;
      removeMetric(m.id).then(() => toast('已删除')).catch(fail);
    });
  }

  /* ---------------- 新增：单页表单 ---------------- */

  const decimalsOf = (str) => {
    const s = String(str);
    const i = s.indexOf('.');
    return i < 0 ? 0 : Math.min(2, s.length - i - 1);
  };

  function openWizard(preset) {
    wizard = {
      name: (preset && preset.name) || '',
      unit: (preset && preset.unit) || '',
      value: '',
      target: '',
    };
    D.modalMask.classList.toggle('modal-mask--side', !D.drawer.hidden);
    D.modalMask.hidden = false;
    renderWizard();
  }

  function renderWizard() {
    const w = wizard;
    const unitChips = UNITS.map((u) => `<button type="button" data-u="${esc(u)}" class="${w.unit === u ? 'on' : ''}">${esc(u)}</button>`).join('');
    D.modal.innerHTML = `
      <h2 class="modal-title">新增关注数</h2>
      <p class="modal-sub">记下「此刻是多少」，之后的加减都从它出发</p>

      <div class="grid-2" style="margin-top:16px">
        <div><label class="field" for="w-name">名称</label>
          <input id="w-name" type="text" maxlength="40" placeholder="例如：体重 / 余额" value="${esc(w.name)}" />
        </div>
        <div><label class="field" for="w-unit">单位（可空）</label>
          <input id="w-unit" type="text" maxlength="8" placeholder="例如 kg，可点下方快选" value="${esc(w.unit)}" />
        </div>
      </div>
      <div class="unit-chips" id="w-units" style="margin-top:8px">${unitChips}</div>

      <div class="grid-2" style="margin-top:14px">
        <div><label class="field" for="w-value">现在的值</label>
          <input id="w-value" type="number" step="any" placeholder="例如 62.4" value="${esc(w.value)}" />
        </div>
        <div><label class="field" for="w-target">目标值（可空）</label>
          <input id="w-target" type="number" step="any" placeholder="例如 58" value="${esc(w.target)}" />
        </div>
      </div>

      <div class="modal-actions">
        <button class="btn js-cancel" type="button">取消</button>
        <div class="right"><button class="btn btn-primary js-save" type="button">创建</button></div>
      </div>`;

      const nameInput = $('#w-name', D.modal);
      const unitInput = $('#w-unit', D.modal);
      // 文本框 = 单位的唯一真相源：点快选把值写进框里，再点同一个 = 清空；手输时快选自动跟亮
      const syncUnitChips = () => $$('#w-units button', D.modal).forEach((b) => b.classList.toggle('on', b.dataset.u === unitInput.value.trim()));
      $$('#w-units button', D.modal).forEach((b) => b.addEventListener('click', () => {
        unitInput.value = unitInput.value.trim() === b.dataset.u ? '' : b.dataset.u;
        syncUnitChips();
      }));
      unitInput.addEventListener('input', syncUnitChips);

    $('.js-cancel', D.modal).addEventListener('click', closeModal);
    $('.js-save', D.modal).addEventListener('click', async () => {
      const vRaw = $('#w-value', D.modal).value.trim();
      const tRaw = $('#w-target', D.modal).value.trim();
      const name = nameInput.value.trim();
      if (!name) { toast('请填名称'); nameInput.focus(); return; }
      const payload = { name, unit: unitInput.value.trim() };
      if (vRaw === '') { toast('请填现在的值'); $('#w-value', D.modal).focus(); return; }
      const v = Number(vRaw);
      if (!Number.isFinite(v)) { toast('数值不合法'); return; }
      payload.value = v;
      payload.decimals = decimalsOf(vRaw);   // 从小数点自动推断小数位，省掉一个容易填错的字段
      if (tRaw !== '') {
        const t = Number(tRaw);
        if (!Number.isFinite(t)) { toast('目标值不合法'); return; }
        payload.target = t;
      }
      try { await createMetric(payload); closeModal(); toast('已创建'); } catch (e) { fail(e); }
    });
    const onEnter = (e) => { if (e.key === 'Enter') $('.js-save', D.modal).click(); };
    nameInput.addEventListener('keydown', onEnter);
    $('#w-value', D.modal).addEventListener('keydown', onEnter);
    setTimeout(() => nameInput.focus(), 0);
  }

  /* ---------------- 设置（编辑）：单页表单 ---------------- */

  function openModal(metric) {
    if (!metric) { openWizard(null); return; }
    const m = metric;
    // 抽屉开着时弹层往左半区放，别被抽屉挡住（closeModal 里摘掉这个类）
    D.modalMask.classList.toggle('modal-mask--side', !D.drawer.hidden);
    D.modal.innerHTML = `
      <h2 class="modal-title">编辑 · ${esc(m.name)}</h2>
      <p class="modal-sub">改名字、单位、目标与快捷步进，历史记录不受影响</p>

      <div class="grid-2" style="margin-top:16px">
        <div><label class="field" for="f-name">名称</label><input id="f-name" type="text" maxlength="40" value="${esc(m.name)}" /></div>
        <div><label class="field" for="f-unit">单位</label><input id="f-unit" type="text" maxlength="8" placeholder="可空" value="${esc(m.unit)}" /></div>
      </div>

      <div class="field-block"><label class="field" for="f-target">目标值（可空）</label><input id="f-target" type="number" step="any" placeholder="不设就留空" value="${isNum(m.target) ? m.target : ''}" /></div>

      <div class="field-block"><label class="field" for="f-steps">快捷步进（逗号分隔，最多 6 个）</label>
        <input id="f-steps" type="text" placeholder="-1, -0.5, 0.5, 1" value="${esc((m.quickSteps || []).join(', '))}" />
        <p class="field-hint">显示成详情页里的一排小按钮，点一下就在当前值上加 / 减。</p>
      </div>

      <div class="modal-actions">
        <button class="btn js-cancel" type="button">取消</button>
        <div class="right"><button class="btn btn-primary js-save" type="button">保存</button></div>
      </div>`;

    D.modalMask.hidden = false;

    $('.js-cancel', D.modal).addEventListener('click', closeModal);
    $('.js-save', D.modal).addEventListener('click', async () => {
      const name = $('#f-name', D.modal).value.trim();
      if (!name) { toast('请填名称'); return; }
      const payload = { name, unit: $('#f-unit', D.modal).value.trim() };
      const tRaw = $('#f-target', D.modal).value.trim();
      if (tRaw === '') payload.target = null;
      else {
        const t = Number(tRaw);
        if (!Number.isFinite(t)) { toast('目标值不合法'); return; }
        payload.target = t;
      }
      const sRaw = $('#f-steps', D.modal).value.trim();
      if (sRaw !== '') {
        const arr = sRaw.split(/[,，\s]+/).map(Number).filter((n) => Number.isFinite(n) && n !== 0);
        if (!arr.length) { toast('快捷步进不合法'); return; }
        payload.quickSteps = arr;
      }
      try { await patchMetric(m.id, payload); closeModal(); toast('已保存'); } catch (e) { fail(e); }
    });
    setTimeout(() => $('#f-name', D.modal)?.focus(), 0);
  }

  function closeModal() {
    D.modalMask.hidden = true;
    D.modal.classList.remove('modal-mask--side');
    D.modalMask.classList.remove('modal-mask--side');
    D.modal.innerHTML = '';
    wizard = null;
  }

  /* ---------------- 添加到桌面 ---------------- */

  function menuHTML() {
    const items = WIDGETS.map((w) => `<button class="menu-item" type="button" data-widget="${w.id}"><b>${esc(w.label)}</b><span>${esc(w.desc)}</span></button>`).join('');
    const hasApi = !!(window.JSOS && typeof window.JSOS.addWidget === 'function');
    const hint = hasApi ? '' : '<div class="menu-sep"></div><div class="menu-hint">当前不在 JSOS 里。在真实 JSOS 中，桌面空白处右键 → 添加小组件，也能找到这三个。</div>';
    return items + hint;
  }

  function toggleMenu() {
    const willOpen = D.deskMenu.hidden;
    if (!willOpen) { closeMenu(); return; }
    D.deskMenu.innerHTML = menuHTML();
    D.deskMenu.hidden = false;
    D.deskBtn.setAttribute('aria-expanded', 'true');
    $$('.menu-item', D.deskMenu).forEach((b) => b.addEventListener('click', () => addWidgetToDesktop(b.dataset.widget)));
  }
  function closeMenu() { D.deskMenu.hidden = true; D.deskBtn.setAttribute('aria-expanded', 'false'); }

  async function addWidgetToDesktop(widgetId) {
    const w = WIDGETS.find((x) => x.id === widgetId);
    const label = w ? w.label : widgetId;
    const api = window.JSOS;
    closeMenu();
    if (!api || typeof api.addWidget !== 'function') {
      toast(`请在桌面空白处右键 → 添加小组件 → ${label}`);
      return;
    }
    try {
      await api.addWidget(APP_ID, widgetId, { x: 140, y: 120 });
      toast(`已把「${label}」放到桌面上`);
    } catch (e) {
      toast('添加失败：' + (e && e.message ? e.message : e));
    }
  }

  /* ---------------- 事件 ---------------- */

  D.wall.addEventListener('click', (e) => {
    const card = e.target.closest('.card');
    if (!card) return;
    const id = card.dataset.id;
    if (openId === id) closeDrawer(); else openDrawer(id);
  });

  // 卡片是 div + role="button"（不是 <button>）→ 键盘可达性自己补
  D.wall.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const card = e.target.closest('.card');
    if (!card) return;
    e.preventDefault();
    openDrawer(card.dataset.id);
  });

  D.addBtn.addEventListener('click', () => { closeMenu(); openModal(null); });
  D.deskBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleMenu(); });
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu-wrap')) closeMenu(); });
  D.drawerMask.addEventListener('click', closeDrawer);
  D.modalMask.addEventListener('click', (e) => { if (e.target === D.modalMask) closeModal(); });

  D.chips?.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const [name, unit] = chip.dataset.preset.split(':');
    openWizard({ name, unit });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!D.modalMask.hidden) closeModal();
    else if (!D.deskMenu.hidden) closeMenu();
    else if (!D.drawer.hidden) closeDrawer();
  });

  /* ---------------- 启动 ---------------- */

  (async function boot() {
    await initTheme();
    try {
      const data = await api('/api/state');
      metrics = Array.isArray(data.metrics) ? data.metrics : [];
    } catch (e) {
      metrics = [];
      toast('加载失败：' + (e.message || ''));
    }
    renderWall();
  })();

  // 供真机验证脚本读取（只读快照，不参与业务）
  window.__glance = { get metrics() { return metrics; }, get openId() { return openId; }, get wizard() { return wizard; } };
})();
