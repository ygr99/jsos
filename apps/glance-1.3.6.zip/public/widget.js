/* 关注数 · 小组件（只读）
   三种小组件共用这一个页面，靠路径区分（照 bookmarks 的做法）：
     /widget/wall      4×2  关注数墙
     /widget/wall-lg   8×4  关注数全览
     /widget/metric    2×2  单个关注数（per-instance，绑定存服务端）
   1.3.0 起只有「写绝对值」一种记法（旧版「点 +N」已移除）。
   ⚠️ 只读：不在小组件里写使用数据 —— 桌面上的误触不值得为它冒风险。
   ⚠️ 2×2 的绑定关系必须是服务端状态：JSOS 小组件 iframe origin 是 localhost:<端口>，
      容器重启/端口变化后前端存储域会整个消失（jsos-apps AGENTS.md §5.3）。 */
(() => {
  'use strict';

  const ROOT = document.getElementById('root');
  const PATH = location.pathname.replace(/\/+$/, '');
  const KIND = /\/wall-lg$/.test(PATH) ? 'wall-lg' : /\/metric$/.test(PATH) ? 'metric' : 'wall';
  const WID = new URLSearchParams(location.search).get('__jsos_wid') || '';
  const LIMIT = KIND === 'wall-lg' ? 24 : 6;

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
  const fmtNum = (v, d) => (isNum(v) ? v.toLocaleString('zh-CN', { minimumFractionDigits: d, maximumFractionDigits: d }) : '—');
  const signed = (v, d) => (!isNum(v) || v === 0 ? '0' : (v > 0 ? '+' : '−') + fmtNum(Math.abs(v), d));

  function tone(m, delta) {
    if (!delta || !m.better) return 'flat';
    const good = m.better === 'up' ? delta > 0 : delta < 0;
    return good ? 'good' : 'bad';
  }

  // 小尺寸趋势：最近 12 个值连成折线（少于 2 个点不画 —— 一条直线段不是趋势）
  function spark(m, W, H) {
    const pts = (m.logs || []).filter((l) => isNum(l.v)).slice(-12).map((l) => l.v);
    if (pts.length < 2) return '';
    const min = Math.min(...pts), max = Math.max(...pts), span = max - min || 1;
    const step = (W - 4) / (pts.length - 1);
    const d = pts.map((p, i) => `${(2 + i * step).toFixed(1)},${(H - 2 - ((p - min) / span) * (H - 5)).toFixed(1)}`).join(' ');
    return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><polyline points="${d}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  // 与主界面同一套排序：置顶在前，置顶组内「后置顶的排最前」，其余按创建顺序
  const sortedMetrics = (list) => list.slice().sort((a, b) => {
    const pa = a.pinned ? 1 : 0, pb = b.pinned ? 1 : 0;
    if (pa !== pb) return pb - pa;
    if (pa) return (b.pinnedAt ? Date.parse(b.pinnedAt) : 0) - (a.pinnedAt ? Date.parse(a.pinnedAt) : 0);
    return (a.order || 0) - (b.order || 0);
  });

  /* ---------------- 渲染 ---------------- */

  function tileHTML(m) {
    const t = tone(m, m.todayDelta);
    const noVal = !isNum(m.value);
    const val = noVal
      ? '<span class="t-value is-empty">还没有值</span>'
      : `<span class="t-value">${fmtNum(m.value, m.decimals)}${m.unit ? `<em>${esc(m.unit)}</em>` : ''}</span>`;
    const foot = noVal
      ? '<span class="t-foot tone-flat">还没记过</span>'
      : (m.todayDelta
        ? `<span class="t-foot tone-${t}">今日 ${signed(m.todayDelta, m.decimals)}</span>`
        : '<span class="t-foot tone-flat">较上次 没变</span>');
    return `<div class="tile tone-${t}">
      <span class="t-name">${esc(m.name)}</span>
      ${val}
      ${foot}
    </div>`;
  }

  function renderWall(metrics) {
    if (!metrics.length) {
      ROOT.innerHTML = `<div class="wall"><div class="tile empty-tip"><span>还没有关注任何数字<br />打开「关注数」应用添加一个</span></div></div>`;
      return;
    }
    const list = sortedMetrics(metrics);
    const overflowCount = list.length - LIMIT;
    const shown = overflowCount > 0 ? list.slice(0, LIMIT - 1) : list;
    let html = shown.map(tileHTML).join('');
    if (overflowCount > 0) {
      html += `<div class="tile more" title="还有 ${overflowCount} 个"><span>+${overflowCount}</span></div>`;
    }
    ROOT.innerHTML = `<div class="wall">${html}</div>`;
  }

  function renderSingle(metric) {
    if (!metric) {
      const t = metric === null ? '还没有绑定关注数' : '先添加一个关注数';
      ROOT.innerHTML = `<div class="picker"><p class="p-title">${esc(t)}</p><div class="p-list"><p class="p-empty">打开「关注数」应用，点右上角「新增」。</p></div></div>`;
      return;
    }
    const m = metric;
    const t = tone(m, m.todayDelta);
    const val = isNum(m.value)
      ? `<span class="s-value">${fmtNum(m.value, m.decimals)}${m.unit ? `<em>${esc(m.unit)}</em>` : ''}</span>`
      : '<span class="s-value is-empty">还没有值</span>';
    const foot = `<span class="s-foot tone-${t}">${m.logCount ? `今日 ${m.todayDelta ? signed(m.todayDelta, m.decimals) : '无变化'}` : '还没记过'}</span>`;
    ROOT.innerHTML = `<div class="single">
      <span class="s-name">${esc(m.name)}${m.unit ? ' · ' + esc(m.unit) : ''}</span>
      ${val}
      ${foot}
      <div class="s-spark tone-${t}">${spark(m, 176, 22)}</div>
    </div>`;
  }

  function renderPicker(metrics, note) {
    const list = sortedMetrics(metrics);
    const items = list.map((m) => `<button type="button" data-id="${esc(m.id)}">${esc(m.name)}</button>`).join('');
    ROOT.innerHTML = `<div class="picker">
      <p class="p-title">${esc(note)}</p>
      <div class="p-list">${items || '<p class="p-empty">还没有关注数，先去应用里加一个。</p>'}</div>
    </div>`;
    ROOT.querySelectorAll('.p-list button').forEach((b) => b.addEventListener('click', async () => {
      try {
        await fetch('/api/widget/binding', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ wid: WID, metricId: b.dataset.id }),
        });
        await load();
      } catch { /* 忽略，下一轮刷新会重试 */ }
    }));
  }

  /* ---------------- 数据 ---------------- */

  async function json(url, opts) {
    const res = await fetch(url, opts);
    if (!res.ok) throw new Error(String(res.status));
    return res.json();
  }

  async function load() {
    const state = await json('/api/state');
    const metrics = Array.isArray(state.metrics) ? state.metrics : [];
    if (KIND !== 'metric') return renderWall(metrics);

    if (!WID) {
      // 没拿到实例 id（直接开页面 / 旧缓存 iframe）→ 只展示第一个，不去写绑定
      return renderSingle(metrics.length ? sortedMetrics(metrics)[0] : null);
    }
    const b = await json('/api/widget/binding?wid=' + encodeURIComponent(WID));
    if (b.metric) return renderSingle(b.metric);
    return renderPicker(metrics, metrics.length ? '选一个关注数' : '还没有关注数');
  }

  /* ---------------- 主题 & 刷新 ---------------- */

  const applyTheme = (t) => document.documentElement.classList.toggle('dark', t === 'dark');
  async function initTheme() {
    let t = null;
    try { t = await window.JSOS?.getTheme?.(); } catch { t = null; }
    if (!t) t = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    applyTheme(t);
    try { window.JSOS?.onThemeChange?.((x) => applyTheme(x)); } catch { /* 本机直跑没有 JSOS */ }
  }

  const safeLoad = () => load().catch(() => { /* 静默：小组件不该弹错 */ });

  (async function boot() {
    await initTheme();
    await safeLoad();
    // 主界面改完数据 → BroadcastChannel 立即刷新；另加 60s 轮询 + 回到前台兜底
    try { new BroadcastChannel('glance').addEventListener('message', () => safeLoad()); } catch { /* ignore */ }
    setInterval(safeLoad, 60000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) safeLoad(); });
  })();

  window.__glanceWidget = { get kind() { return KIND; }, get wid() { return WID; } };
})();
