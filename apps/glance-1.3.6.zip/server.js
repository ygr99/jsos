// 一览（glance）—— 零依赖 node:http 服务（installCommand 为空，不装任何 npm 包）
//
// [存储规范] 使用数据一律落平台注入的 DATA_DIR（容器内 = workspace/data/glance，
//   卸载勾选「删除数据」时由平台整目录清掉）；本机直跑回退 ./data。
//   前端 localStorage 只允许放"丢了无所谓"的 UI 偏好。
//
// 1.3.0 起只有一种记法：写绝对值（体重 / 余额 / 关注数）—— 每次记"此刻是多少"，
// 新值覆盖旧值，delta（与上一条的差）由服务端算。旧版「点 +N」增量型已按用户要求移除，
// 读取时直接丢弃 mode !== 'set' 的历史指标。
//
// ⚠️ value / todayDelta 一律在服务端算：todayDelta 依赖"今天"这个**本地时区**边界，
//    交给前端算会在跨零点 / 改系统时间时错乱。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const PORT = process.env.PORT || 3000;

const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const STATE_FILE = path.join(DATA_DIR, 'state.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const NAME_MAX = 40;
const UNIT_MAX = 8;
const NOTE_MAX = 60;
const MAX_LOGS_PER_METRIC = 300; // 回传给前端的历史上限（数据量极小，但别让它无限长）
const MAX_METRICS = 200;

const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const newId = (p) => p + crypto.randomUUID().slice(0, 8);

// ---------- 状态读写 ----------

const emptyState = () => ({ version: 1, metrics: [] });

function readState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return emptyState();
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (!raw || !Array.isArray(raw.metrics)) return emptyState();
    // 1.3.0 起只认「写绝对值」：旧版「点 +N」指标直接丢弃（该功能已按用户要求移除）
    raw.metrics = raw.metrics.filter((m) => m && m.mode === 'set');
    // logs 必须按时间升序（delta 递推、图表都依赖这个不变量）
    for (const m of raw.metrics) {
      if (!Array.isArray(m.logs)) m.logs = [];
      m.logs.sort((a, b) => Date.parse(a.t) - Date.parse(b.t));
    }
    return { version: 1, metrics: raw.metrics };
  } catch {
    return emptyState();
  }
}

// 原子写：先写 .tmp 再 rename —— 否则平台的 fs.watch 快照有机会读到半个文件
function writeState(state) {
  const tmp = STATE_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state));
  fs.renameSync(tmp, STATE_FILE);
}

// ---------- 小组件绑定 ----------
// per-instance 小组件（2×2「单个关注数」）挂在哪个指标上，**必须存服务端**：
// JSOS 的小组件 iframe origin 是 localhost:<端口>，容器重启/端口变化后整个前端存储域消失，
// 只存 localStorage 会全部回退（jsos-apps AGENTS.md §5.3，virtual-pet 的教训）。
const WIDGETS_FILE = path.join(DATA_DIR, 'widgets.json');
const MAX_WIDGET_BINDINGS = 50;

function readBindings() {
  try {
    if (!fs.existsSync(WIDGETS_FILE)) return {};
    const raw = JSON.parse(fs.readFileSync(WIDGETS_FILE, 'utf8'));
    return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  } catch {
    return {};
  }
}

function writeBindings(b) {
  const tmp = WIDGETS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(b));
  fs.renameSync(tmp, WIDGETS_FILE);
}

// ---------- 派生值 ----------
function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

const rnd = (m, x) => Number(Number(x).toFixed(m.decimals));

// delta = 与上一条记录的差（第一条没有可比对象 → 0）。
// 任何对 logs 的增删改之后都要重算，否则卡片上的"今日变化"会漂。
function recalcSetDeltas(m) {
  let prev = null;
  for (const l of m.logs) {
    l.delta = prev === null ? 0 : rnd(m, l.v - prev);
    prev = l.v;
  }
}

function derive(m) {
  const logs = m.logs || [];
  const t0 = startOfToday();
  let todayDelta = 0;
  let todayCount = 0;
  for (const l of logs) {
    if (Date.parse(l.t) >= t0) {
      todayDelta += l.delta || 0;
      todayCount += 1;
    }
  }
  todayDelta = rnd(m, todayDelta);
  return {
    value: logs.length ? logs[logs.length - 1].v : null,
    todayDelta,
    todayCount,
    logCount: logs.length,
    lastLogAt: logs.length ? logs[logs.length - 1].t : null,
    // 进度条的基准 = 第一条记录的值（开始追踪时是多少）。
    // 没有它就只能拿"当前值 / 目标值"当百分比 —— 那样"还差 4.7 kg"会显示成 95% 满，是假的。
    startValue: logs.length ? logs[0].v : null,
  };
}

function publicMetric(m) {
  return {
    id: m.id,
    name: m.name,
    unit: m.unit,
    decimals: m.decimals,
    mode: m.mode,
    better: m.better,
    target: m.target,
    quickSteps: m.quickSteps,
    pinned: !!m.pinned,
    pinnedAt: m.pinnedAt || null,
    order: m.order,
    createdAt: m.createdAt,
    ...derive(m),
    logs: (m.logs || []).slice(-MAX_LOGS_PER_METRIC),
  };
}

// ---------- 入参归一化 ----------

// 注意：小数位 0 是合法值，不能写 `Number(v) || 1`（0 会被吞掉）
function normDecimals(v) {
  const n = Number(v);
  return Number.isInteger(n) && n >= 0 && n <= 2 ? n : 1;
}

function normSteps(raw) {
  const def = [-1, -0.5, 0.5, 1];
  if (!Array.isArray(raw)) return def;
  const out = raw.map(Number).filter((n) => Number.isFinite(n) && n !== 0).slice(0, 6);
  return out.length ? out : def;
}

const normBetter = (v) => (v === 'up' || v === 'down' ? v : null);
const normStr = (v, max) => String(v ?? '').trim().slice(0, max);

// ---------- 业务操作（全部同步，出错返回 { error }） ----------

function createMetric(state, body) {
  if (state.metrics.length >= MAX_METRICS) return { error: `指标数量已达上限 ${MAX_METRICS}` };
  const name = normStr(body.name, NAME_MAX);
  if (!name) return { error: 'name 不能为空' };
  const m = {
    id: newId('m_'),
    name,
    unit: normStr(body.unit, UNIT_MAX),
    decimals: normDecimals(body.decimals),
    mode: 'set', // 唯一记法；body.mode 一律忽略
    better: normBetter(body.better),
    target: isNum(body.target) ? rnd({ decimals: normDecimals(body.decimals) }, body.target) : null,
    quickSteps: normSteps(body.quickSteps),
    pinned: false,
    pinnedAt: null, // 方案 A：置顶组内按「后置顶的排最前」排序，靠这个时间戳
    order: state.metrics.reduce((mx, x) => Math.max(mx, x.order || 0), 0) + 1,
    createdAt: new Date().toISOString(),
    logs: [],
  };
  // 新建时可以直接填"起手值"：记一条 delta 0 的基准
  if (isNum(body.value) && body.value !== 0) {
    m.logs.push({
      id: newId('l_'),
      t: new Date().toISOString(),
      v: rnd(m, body.value),
      delta: 0,
      note: '起手值',
    });
    recalcSetDeltas(m);
  }
  state.metrics.push(m);
  return { metric: m };
}

function patchMetric(m, body) {
  if ('name' in body) {
    const name = normStr(body.name, NAME_MAX);
    if (!name) return { error: 'name 不能为空' };
    m.name = name;
  }
  if ('unit' in body) m.unit = normStr(body.unit, UNIT_MAX);
  if ('decimals' in body) {
    m.decimals = normDecimals(body.decimals);
    m.logs.forEach((l) => {
      if (typeof l.v === 'number') l.v = rnd(m, l.v);
      if (typeof l.delta === 'number') l.delta = rnd(m, l.delta);
    });
    recalcSetDeltas(m);
  }
  if ('better' in body) m.better = normBetter(body.better);
  if ('target' in body) m.target = isNum(body.target) ? body.target : null;
  if ('quickSteps' in body) m.quickSteps = normSteps(body.quickSteps);
  if ('pinned' in body) {
    m.pinned = !!body.pinned;
    // 每次置顶都刷新时间戳 → 置顶区内部「后置顶的排最前」；取消置顶清掉
    m.pinnedAt = m.pinned ? new Date().toISOString() : null;
  }
  if ('order' in body && isNum(body.order)) m.order = body.order;
  return { metric: m };
}

function addLog(m, body) {
  const note = normStr(body.note, NOTE_MAX);
  if (isNum(body.delta)) return { error: '不接受 delta，请传 v（新的值）' };
  if (!isNum(body.v)) return { error: '必须传 v（新的值）' };
  m.logs.push({ id: newId('l_'), t: new Date().toISOString(), v: rnd(m, body.v), delta: 0, note });
  recalcSetDeltas(m);
  return { metric: m };
}

function patchLog(m, log, body) {
  if ('note' in body) log.note = normStr(body.note, NOTE_MAX);
  if ('delta' in body && isNum(body.delta)) return { error: '不能直接改 delta，请改 v' };
  if ('v' in body) {
    if (!isNum(body.v)) return { error: 'v 必须是数字' };
    log.v = rnd(m, body.v);
    recalcSetDeltas(m);
  }
  return { metric: m };
}

// ---------- HTTP ----------

const json = (res, code, data) => {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(data));
};

function readBody(req) {
  return new Promise((resolve) => {
    let buf = '';
    req.on('data', (c) => {
      buf += c;
      if (buf.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      if (!buf) return resolve({});
      try {
        resolve(JSON.parse(buf));
      } catch {
        resolve(null); // 让调用方回 400
      }
    });
    req.on('error', () => resolve(null));
  });
}

const findMetric = (state, id) => state.metrics.find((m) => m.id === id);

async function handleApi(req, res, url) {
  const p = url.pathname;
  const seg = p.split('/').filter(Boolean); // ['api','metrics','<id>','log','<logId>']

  if (p === '/api/health') return json(res, 200, { ok: true });

  if (p === '/api/state' && req.method === 'GET') {
    const state = readState();
    return json(res, 200, { version: state.version, metrics: state.metrics.map(publicMetric) });
  }

  // 小组件实例 → 指标的绑定（只读展示用；小组件本身不写使用数据）
  if (p === '/api/widget/binding') {
    if (req.method === 'GET') {
      const wid = url.searchParams.get('wid') || '';
      if (!wid) return json(res, 400, { error: 'wid 不能为空' });
      const state = readState();
      const bound = readBindings()[wid] || null;
      const m = bound ? findMetric(state, bound) : null;
      // 指标被删掉了 → 返回 null，小组件会显示选择器（不要把脏 id 透出去）
      return json(res, 200, { wid, metricId: m ? bound : null, metric: m ? publicMetric(m) : null });
    }
    if (req.method === 'POST') {
      const body = await readBody(req);
      if (!body) return json(res, 400, { error: '请求体不是合法 JSON' });
      const wid = normStr(body.wid, 64);
      if (!wid) return json(res, 400, { error: 'wid 不能为空' });
      const metricId = normStr(body.metricId, 64);
      const bindings = readBindings();
      if (!metricId) {
        delete bindings[wid];
        writeBindings(bindings);
        return json(res, 200, { ok: true, wid, metricId: null });
      }
      if (!findMetric(readState(), metricId)) return json(res, 404, { error: '指标不存在' });
      if (!bindings[wid] && Object.keys(bindings).length >= MAX_WIDGET_BINDINGS) {
        return json(res, 400, { error: `小组件绑定数量已达上限 ${MAX_WIDGET_BINDINGS}` });
      }
      bindings[wid] = metricId;
      writeBindings(bindings);
      return json(res, 200, { ok: true, wid, metricId });
    }
    return json(res, 405, { error: 'method not allowed' });
  }

  if (p === '/api/metrics' && req.method === 'POST') {
    const body = await readBody(req);
    if (!body) return json(res, 400, { error: '请求体不是合法 JSON' });
    const state = readState();
    const r = createMetric(state, body);
    if (r.error) return json(res, 400, r);
    writeState(state);
    return json(res, 201, { ok: true, metric: publicMetric(r.metric), count: state.metrics.length });
  }

  if (seg[1] !== 'metrics' || !seg[2]) return json(res, 404, { error: 'not found' });

  const state = readState();
  const m = findMetric(state, seg[2]);
  if (!m) return json(res, 404, { error: '指标不存在' });

  // /api/metrics/:id
  if (seg.length === 3) {
    if (req.method === 'PATCH') {
      const body = await readBody(req);
      if (!body) return json(res, 400, { error: '请求体不是合法 JSON' });
      const r = patchMetric(m, body);
      if (r.error) return json(res, 400, r);
      writeState(state);
      return json(res, 200, { ok: true, metric: publicMetric(m) });
    }
    if (req.method === 'DELETE') {
      state.metrics = state.metrics.filter((x) => x.id !== m.id);
      writeState(state);
      // 顺手清掉指向它的小组件绑定，别留脏 id
      const bindings = readBindings();
      let dirty = false;
      for (const [k, v] of Object.entries(bindings)) if (v === m.id) { delete bindings[k]; dirty = true; }
      if (dirty) writeBindings(bindings);
      return json(res, 200, { ok: true, count: state.metrics.length });
    }
    return json(res, 405, { error: 'method not allowed' });
  }

  // /api/metrics/:id/log  |  /api/metrics/:id/log/:logId
  if (seg[3] !== 'log') return json(res, 404, { error: 'not found' });

  if (!seg[4]) {
    if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' });
    const body = await readBody(req);
    if (!body) return json(res, 400, { error: '请求体不是合法 JSON' });
    const r = addLog(m, body);
    if (r.error) return json(res, 400, r);
    writeState(state);
    return json(res, 201, { ok: true, metric: publicMetric(m) });
  }

  const log = m.logs.find((l) => l.id === seg[4]);
  if (!log) return json(res, 404, { error: '记录不存在' });

  if (req.method === 'PATCH') {
    const body = await readBody(req);
    if (!body) return json(res, 400, { error: '请求体不是合法 JSON' });
    const r = patchLog(m, log, body);
    if (r.error) return json(res, 400, r);
    writeState(state);
    return json(res, 200, { ok: true, metric: publicMetric(m) });
  }
  if (req.method === 'DELETE') {
    m.logs = m.logs.filter((l) => l.id !== log.id);
    if (m.mode === 'set') recalcSetDeltas(m);
    writeState(state);
    return json(res, 200, { ok: true, metric: publicMetric(m) });
  }
  return json(res, 405, { error: 'method not allowed' });
}

function serveStatic(res, pathname) {
  let rel = decodeURIComponent(pathname).replace(/^\/+/, '');
  let file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    return res.end('forbidden');
  }
  if (!rel || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    file = path.join(PUBLIC, 'index.html'); // SPA 回落
  }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {
    'content-type': MIME[ext] || 'application/octet-stream',
    'cache-control': ext === '.html' ? 'no-store' : 'public, max-age=60',
  });
  res.end(fs.readFileSync(file));
}

// 三种小组件共用一个页面，靠路径区分（照 bookmarks 的做法）
function serveWidget(res) {
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
  res.end(fs.readFileSync(path.join(PUBLIC, 'widget.html')));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (url.pathname.startsWith('/widget/')) return serveWidget(res);
    serveStatic(res, url.pathname);
  } catch (e) {
    json(res, 500, { error: e.message });
  }
});

server.listen(PORT, () => console.log(`glance running on ${PORT}`));
