/**
 * 看电视 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 一个核心接口：
 *   /api/hls?u=<encodeURIComponent(完整m3u8/分段URL)>[&ref=<Referer>]
 *
 * 为什么 HLS 必须经同源代理（meinv-video 同款理由）：
 *   - JSOS 强制 COEP require-corp，hls.js 用 fetch/XHR 拉跨域播放列表/分段，
 *     目标源绝大多数没有 ACAO 头 → 一律被 CORS 拦死；
 *   - 容器内混合内容策略连 http:// 裸 IP 目标都到不了（IPTV 源大半是这种）。
 *   解法：代理端把播放列表里的分段/子列表 URI 重写回 /api/hls?u=...，
 *   分段则原样流式转发。前端所有播放地址只写原始 URL，代理链由服务端续接。
 *
 * 出站策略（用户拍板：能不用代理就不用代理）：
 *   直连优先（outboundPreferDirect），直连不通（容器内 CORS/混合内容/防盗链
 *   403）才回退 JSOS 系统 CORS 代理。本机直跑全程直连。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outboundPreferDirect, UA } from './lib/http.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const app = express();
app.use(express.static(join(__dirname, 'public')));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'watch-tv' });
});

/* ------------------------------ HLS 同源代理 ------------------------------ */

/** 原始 URI → 绝对地址 → 包回本代理 */
function wrapHls(u, base, ref) {
  let abs;
  try {
    abs = new URL(u, base).href;
  } catch {
    return u;
  }
  if (!/^https?:/i.test(abs)) return u;
  let q = `u=${encodeURIComponent(abs)}`;
  if (ref) q += `&ref=${encodeURIComponent(ref)}`;
  return `/api/hls?${q}`;
}

/** 重写播放列表：所有非注释行 + #EXT-X-KEY/#EXT-X-MAP 的 URI 属性 */
function rewritePlaylist(text, baseUrl, ref) {
  return text
    .split(/\r?\n/)
    .map((line) => {
      const t = line.trim();
      if (!t) return line;
      if (t.startsWith('#')) {
        return t.replace(/URI="([^"]*)"/g, (_m, u) => `URI="${wrapHls(u, baseUrl, ref)}"`);
      }
      return wrapHls(t, baseUrl, ref);
    })
    .join('\n');
}

const PASS_HEADERS = ['content-type', 'content-length', 'content-range', 'accept-ranges'];

app.get('/api/hls', async (req, res) => {
  const raw = String(req.query.u || '');
  let target;
  try {
    target = new URL(raw);
  } catch {
    return res.status(400).send('bad url');
  }
  if (!/^https?:$/.test(target.protocol)) return res.status(400).send('bad protocol');

  const ref = String(req.query.ref || '');
  const headers = { 'User-Agent': UA };
  if (ref) headers['Referer'] = ref;
  if (req.headers.range) headers['Range'] = req.headers.range;

  let up, via;
  try {
    ({ res: up, via } = await outboundPreferDirect(target.href, { headers }));
  } catch (e) {
    return res.status(502).send(`upstream error: ${e.message || e}`);
  }

  const status = up.status;
  const ct = (up.headers.get('content-type') || '').toLowerCase();
  const passHeaders = {};
  for (const h of PASS_HEADERS) {
    const v = up.headers.get(h);
    if (v) passHeaders[h] = v;
  }

  // 判定是否播放列表：扩展名 / mpegurl 类 content-type
  let isPlaylist =
    ct.includes('mpegurl') || ct.includes('apple') || /\.m3u8?(\?|#|$)/i.test(target.pathname);

  // 模糊类型（octet-stream/text/plain/空）时嗅探首块：#EXTM3U 开头 → 播放列表
  if (!isPlaylist && up.body && (!ct || /^(application\/octet-stream|text\/|binary)/.test(ct))) {
    try {
      const reader = up.body.getReader();
      const first = await reader.read();
      if (first.done) {
        res.status(status).set(passHeaders).end();
        return;
      }
      const head = new TextDecoder().decode(first.value.slice(0, 16)).trimStart();
      if (head.startsWith('#EXTM3U')) {
        isPlaylist = true;
        const chunks = [Buffer.from(first.value)];
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(Buffer.from(value));
        }
        const text = Buffer.concat(chunks).toString('utf8');
        res
          .status(200)
          .type('application/vnd.apple.mpegurl')
          .send(rewritePlaylist(text, target.href, ref));
      } else {
        // 不是播放列表 → 首块 + 剩余全部流式转发
        res.status(status).set(passHeaders);
        if (!passHeaders['content-type']) res.type('video/mp2t');
        res.write(Buffer.from(first.value));
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(Buffer.from(value));
        }
        res.end();
      }
      return;
    } catch (e) {
      if (res.headersSent) res.end();
      else res.status(502).send(`stream error: ${e.message || e}`);
      return;
    }
  }

  if (isPlaylist) {
    const text = await up.text();
    if (status >= 400) {
      res.status(status).send(text || 'playlist error');
      return;
    }
    console.log(`[hls] playlist via ${via}: ${target.href.slice(0, 80)}`);
    res.status(200).type('application/vnd.apple.mpegurl').send(rewritePlaylist(text, target.href, ref));
    return;
  }

  // 媒体分段：流式转发
  console.log(`[hls] segment  via ${via}: ${target.href.slice(0, 80)}`);
  res.status(status).set(passHeaders);
  if (!passHeaders['content-type']) res.type('video/mp2t');
  if (up.body) Readable.fromWeb(up.body).pipe(res);
  else res.end();
});

app.listen(port, () => {
  console.log(`watch-tv listening on http://localhost:${port}`);
});
