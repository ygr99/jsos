import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PROXY_CONFIG_PATH = path.join(DATA_DIR, 'proxy-configs.json');

// 确保 DATA_DIR 存在
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 默认代理配置（2026-09-05 切换自建 jsos-cors-proxy）
const DEFAULT_PROXY_URL = 'https://proxy.xn--4gqta1h0zg9yuu7a.fun';
const LEGACY_PROXY_URL = 'https://cors-proxy.jsos.dev';

const DEFAULT_DATA = {
  configs: [
    {
      id: 'default',
      name: '默认代理',
      url: DEFAULT_PROXY_URL,
      key: 'hello-world',
      isDefault: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  ],
  activeId: 'default',
};

// MIME 类型映射
const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/** 云同步：统一 JSON 响应 */
function sendJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

/** 读原始请求体：云同步要按**字节**透传给 OSS，不能当字符串处理 */
function readBodyBuffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/* ---------------- 云同步（数据存阿里云 OSS） ----------------
 * 链路：前端 → 本服务（同源，无 CORS 问题）
 *              → 向 {PROXY_URL}/oss-sign 取预签名 URL（经平台代理，请求仅几百字节）
 *              → 直连 OSS 传输数据（**不经平台代理**，因此没有 4 MB 体积上限）
 *
 * 对象名固定为 jsos-sync/<同步码>.json —— 同步码既是密钥也是路径，
 * 所以不需要任何额外的元信息存储：查询就是一次 HEAD。
 *
 * 安全：AK/SK 只存在于签名服务（Vercel 环境变量）里，本服务与前端都碰不到。
 */
const CLOUD_CODE_RE = /^[A-Za-z0-9_-]{8,64}$/;
const CLOUD_PREFIX = 'jsos-sync/';

/** 当前生效的代理配置（云同步借它去要 OSS 签名） */
function activeProxy() {
  try {
    const cfg = readProxyConfig();
    const list = Array.isArray(cfg.configs) ? cfg.configs : [];
    const hit = list.find(c => c.id === cfg.activeId) || list.find(c => c.isDefault) || list[0];
    if (hit && hit.url) {
      return { url: String(hit.url).replace(/\/+$/, ''), key: String(hit.key || '') };
    }
  } catch { /* 落到默认 */ }
  return { url: DEFAULT_PROXY_URL, key: 'hello-world' };
}

/** 同步码 → 对象 key（非法字符一律拒绝，避免路径注入） */
function cloudObjectKey(code) {
  if (!CLOUD_CODE_RE.test(String(code || ''))) return null;
  return CLOUD_PREFIX + code + '.json';
}

/** 向 /oss-sign 要一条预签名 URL */
async function signedOssUrl(objectKey, op) {
  const { url, key } = activeProxy();
  const qs = new URLSearchParams({ key: objectKey, op, 'x-cors-proxy-key': key });
  const r = await fetch(`${url}/oss-sign?${qs.toString()}`);
  let j = null;
  try { j = await r.json(); } catch { j = null; }
  if (!j || !j.ok) throw new Error((j && j.message) || `签名服务返回 ${r.status}`);
  return j.url;
}

function readProxyConfig() {
  try {
    if (!fs.existsSync(PROXY_CONFIG_PATH)) {
      fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(DEFAULT_DATA, null, 2), 'utf8');
      return DEFAULT_DATA;
    }
    const raw = fs.readFileSync(PROXY_CONFIG_PATH, 'utf8');
    const data = JSON.parse(raw);
    // 兼容：确保有 default 配置
    if (!data.configs || !Array.isArray(data.configs)) {
      return DEFAULT_DATA;
    }
    // 迁移：官方旧代理地址 → 自建 jsos-cors-proxy（升级保数据的容器自动切换）
    let migrated = false;
    for (const c of data.configs) {
      if (c.url === LEGACY_PROXY_URL) {
        c.url = DEFAULT_PROXY_URL;
        c.updatedAt = Date.now();
        migrated = true;
      }
    }
    if (migrated) writeProxyConfig(data);
    const hasDefault = data.configs.some(c => c.isDefault);
    if (!hasDefault) {
      data.configs.unshift(DEFAULT_DATA.configs[0]);
    }
    if (!data.activeId) {
      data.activeId = 'default';
    }
    return data;
  } catch {
    return DEFAULT_DATA;
  }
}

function writeProxyConfig(data) {
  fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(data, null, 2), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  // CORS headers for API
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // API: proxy configs
  if (pathname === '/api/proxy-configs') {
    try {
      if (req.method === 'GET') {
        const data = readProxyConfig();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(data));
      }
      if (req.method === 'PUT') {
        const body = await readBody(req);
        const data = JSON.parse(body);
        writeProxyConfig(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: true }));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  /* ---------------- 云同步 API（数据存 OSS，预签名直传） ---------------- */

  if (pathname === '/api/cloud-sync/meta' || pathname === '/api/cloud-sync/push' || pathname === '/api/cloud-sync/pull') {
    const code = url.searchParams.get('code') || '';
    const objectKey = cloudObjectKey(code);
    if (!objectKey) {
      return sendJson(res, 400, { ok: false, error: '同步码格式无效：需 8-64 位，仅限字母、数字、下划线与连字符' });
    }

    // 查询：一次 HEAD 就能拿到「是否存在 / 体积 / 更新时间」
    if (pathname === '/api/cloud-sync/meta') {
      try {
        const signed = await signedOssUrl(objectKey, 'head');
        const r = await fetch(signed, { method: 'HEAD' });
        if (r.status === 404) return sendJson(res, 200, { ok: true, exists: false });
        if (r.status !== 200) return sendJson(res, 502, { ok: false, error: `OSS 查询失败 (${r.status})` });
        return sendJson(res, 200, {
          ok: true,
          exists: true,
          bytes: Number(r.headers.get('content-length') || 0),
          syncDate: r.headers.get('last-modified') || '',
        });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }

    // 上传：取签名 → 直连 OSS PUT（数据不经平台代理，故无体积上限）
    if (pathname === '/api/cloud-sync/push') {
      let body;
      try {
        body = await readBodyBuffer(req);
      } catch {
        return sendJson(res, 400, { ok: false, error: '读取请求体失败' });
      }
      if (!body || body.length === 0) {
        return sendJson(res, 400, { ok: false, error: '请求体为空' });
      }
      try {
        const signed = await signedOssUrl(objectKey, 'put');
        // ⚠️ 绝不要设置 Content-Type：OSS 的 URL 签名要求该头为空，否则 SignatureDoesNotMatch
        const r = await fetch(signed, { method: 'PUT', body });
        if (!r.ok) {
          const txt = await r.text().catch(() => '');
          return sendJson(res, 502, { ok: false, error: `上传到 OSS 失败 (${r.status}) ${String(txt).slice(0, 200)}` });
        }
        return sendJson(res, 200, { ok: true, bytes: body.length, syncDate: new Date().toISOString() });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }

    // 恢复：取签名 → 直连 OSS GET
    if (pathname === '/api/cloud-sync/pull') {
      try {
        const signed = await signedOssUrl(objectKey, 'get');
        const r = await fetch(signed);
        if (r.status === 404) {
          return sendJson(res, 404, { ok: false, error: '服务器上没有该同步码的备份' });
        }
        if (!r.ok) {
          return sendJson(res, 502, { ok: false, error: `从 OSS 下载失败 (${r.status})` });
        }
        const backup = await r.text();
        return sendJson(res, 200, { ok: true, backup });
      } catch (e) {
        return sendJson(res, 502, { ok: false, error: String((e && e.message) || e) });
      }
    }
  }

  // Static file serving
  let decoded = decodeURIComponent(pathname);

  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }

  let target = path.resolve(path.join(ROOT, decoded));

  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  // 目录默认 index.html
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }

  fs.readFile(target, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

server.listen(process.env.PORT, () => console.log(process.env.PORT));
