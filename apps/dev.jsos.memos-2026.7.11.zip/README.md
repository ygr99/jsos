# Memos - JSOS Application

基于 Cloudflare Worker 后端的轻量级备忘录应用，移植为 JSOS 应用。

## 功能特性

- ✅ 备忘录 CRUD（创建、读取、更新、删除）
- ✅ Markdown 支持
- ✅ 标签系统
- ✅ 附件上传/下载
- ✅ 评论功能
- ✅ 反应（Reactions）
- ✅ 分享功能
- ✅ 多语言支持（中文/英文）
- ✅ 搜索功能
- ✅ 归档功能

## 简化功能

以下功能已被移除以简化应用：

- ❌ 用户认证（默认已登录）
- ❌ 用户管理
- ❌ SSO/OAuth2 登录
- ❌ Webhooks
- ❌ AI 功能
- ❌ RSS 订阅
- ❌ SSE 实时推送

## 技术栈

### 后端
- **Node.js** + **Express** — HTTP 服务器
- **sql.js** — SQLite WASM 数据库
- **jsonwebtoken** — JWT 令牌（兼容前端）
- **bcryptjs** — 密码哈希
- **multer** — 文件上传

### 前端
- **React 18** + **TypeScript**
- **Vite** — 构建工具
- **Tailwind CSS** — 样式
- **React Query** — 数据获取
- **React Router** — 路由

## 目录结构

```
dev.jsos.memos/
├── package.json          # JSOS manifest + 依赖
├── icon.svg              # 应用图标
├── server/               # 后端模块
│   ├── index.js          # 入口文件
│   ├── db.js             # 数据库操作
│   └── routes/           # API 路由
│       ├── auth.js       # 认证路由（简化版）
│       ├── memos.js      # 备忘录路由
│       ├── attachments.js # 附件路由
│       └── instance.js   # 实例路由
├── src/                  # 前端源码
└── dist/                 # 构建产物
```

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `PORT` | 服务器端口 | `3000` |
| `DATA_DIR` | 数据目录 | `./data` |
| `JWT_SECRET` | JWT 密钥 | `memos-dev-secret-key` |

## 启动方式

### 生产模式（推荐）

```bash
# 安装依赖
npm install

# 构建前端
npm run build

# 启动服务器（仅后端，静态文件由Express服务）
npm start
```

访问 `http://localhost:3000`

### 开发模式

需要同时启动后端服务器和Vite开发服务器：

```bash
# 终端1：启动后端服务器
npm run dev:server

# 终端2：启动Vite开发服务器
npm run dev
```

或者使用启动脚本：

```bash
./dev.sh
```

前端开发服务器运行在 `http://localhost:3001`，API请求会自动代理到后端 `http://localhost:3000`。

## API 路由

| 路由 | 说明 |
|------|------|
| `POST /api/v1/auth/signin` | 登录（返回默认用户） |
| `POST /api/v1/auth/signup` | 注册（返回默认用户） |
| `GET /api/v1/auth/me` | 获取当前用户 |
| `GET /api/v1/memos` | 列表备忘录 |
| `POST /api/v1/memos` | 创建备忘录 |
| `GET /api/v1/memos/:id` | 获取备忘录 |
| `PATCH /api/v1/memos/:id` | 更新备忘录 |
| `DELETE /api/v1/memos/:id` | 删除备忘录 |
| `POST /api/v1/attachments` | 上传附件 |
| `GET /api/v1/attachments/:id` | 获取附件 |
| `GET /api/v1/instance/profile` | 实例信息 |

## 数据持久化

- 数据库文件：`$DATA_DIR/memos.db`
- 附件文件：`$DATA_DIR/attachments/`
- 每 30 秒自动保存数据库
- 进程退出时保存

## 许可证

MIT
