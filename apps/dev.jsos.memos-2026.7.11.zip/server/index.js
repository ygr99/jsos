import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { existsSync, readFileSync, readdirSync } from 'fs';
import { initDatabase, queryOne, DATA_DIR } from './db.js';
import authRoutes from './routes/auth.js';
import memoRoutes from './routes/memos.js';
import attachmentRoutes from './routes/attachments.js';
import instanceRoutes from './routes/instance.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DIST_DIR = join(__dirname, '../dist');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// CORS headers for WebContainer
app.use((req, res, next) => {
  res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  next();
});

// API routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/memos', memoRoutes);
app.use('/api/v1/attachments', attachmentRoutes);
app.use('/api/v1/instance', instanceRoutes);

// Serve attachment files from disk
app.get('/file/attachments/:uid/:filename', (req, res) => {
  try {
    const { uid } = req.params;
    const ATTACHMENTS_DIR = join(DATA_DIR, 'attachments');

    if (!existsSync(ATTACHMENTS_DIR)) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    const files = readdirSync(ATTACHMENTS_DIR);
    const match = files.find(f => f.startsWith(uid));

    if (!match) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    const filePath = join(ATTACHMENTS_DIR, match);
    res.sendFile(filePath);
  } catch (err) {
    res.status(404).json({ error: 'Attachment not found' });
  }
});

// User routes (simplified)
app.get('/api/v1/users/:username', (req, res) => {
  const user = queryOne('SELECT * FROM user WHERE id = 1');
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.json({
    name: `users/${user.username}`,
    username: user.username,
    displayName: user.nickname || user.username,
    nickname: user.nickname || '',
    role: user.role === 'ADMIN' ? 2 : 1,
    state: user.row_status === 'ARCHIVED' ? 2 : 1,
    avatarUrl: user.avatar_url || '',
    description: user.description || ''
  });
});

// Shortcut routes (empty)
app.get('/api/v1/shortcuts', (req, res) => {
  res.json({ shortcuts: [] });
});

// SSE routes (stub)
app.get('/api/v1/sse', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  // Keep connection alive
  const keepAlive = setInterval(() => {
    res.write(': keepalive\n\n');
  }, 30000);

  req.on('close', () => {
    clearInterval(keepAlive);
  });
});

// Health check
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Serve static files from dist
if (existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR));
}

// SPA fallback
app.get('*', (req, res) => {
  if (existsSync(join(DIST_DIR, 'index.html'))) {
    res.sendFile(join(DIST_DIR, 'index.html'));
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

// Initialize database and start server
async function start() {
  try {
    await initDatabase();
    console.log('[DB] Database initialized');

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`[Server] Memos server running on port ${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();
