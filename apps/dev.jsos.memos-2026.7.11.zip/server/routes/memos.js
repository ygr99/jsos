import { Router } from 'express';
import { queryOne, queryAll, run, getDb } from '../db.js';
import { v4 as uuidv4 } from 'uuid';

const router = Router();

// ============================================================================
// CEL-like Filter Parser
// ============================================================================

function parseFilter(filterStr) {
  if (!filterStr || !filterStr.trim()) {
    return { sql: '', params: [] };
  }

  const conditions = [];
  const params = [];

  // Split by && first, then by || (simple approach: treat as flat AND list)
  const orGroups = filterStr.split('||').map(s => s.trim());

  for (const orGroup of orGroups) {
    const andParts = orGroup.split('&&').map(s => s.trim());
    const andConditions = [];

    for (const part of andParts) {
      const parsed = parseSingleCondition(part);
      if (parsed) {
        andConditions.push(parsed.sql);
        params.push(...parsed.params);
      }
    }

    if (andConditions.length > 0) {
      conditions.push(`(${andConditions.join(' AND ')})`);
    }
  }

  if (conditions.length === 0) {
    return { sql: '', params: [] };
  }

  return {
    sql: conditions.join(' OR '),
    params
  };
}

function parseSingleCondition(expr) {
  expr = expr.trim();
  if (!expr) return null;

  // creator == "users/admin" or creator == "admin"
  let match = expr.match(/^creator\s*==\s*"?([^"]+)"?\s*$/);
  if (match) {
    let username = match[1].trim();
    if (!username.startsWith('users/')) {
      username = `users/${username}`;
    }
    return {
      sql: 'creator_id = (SELECT id FROM user WHERE username = ? LIMIT 1)',
      params: [username.replace('users/', '')]
    };
  }

  // content.contains("xxx")
  match = expr.match(/^content\.contains\(\s*"?([^"]+)"?\s*\)\s*$/);
  if (match) {
    return {
      sql: 'content LIKE ?',
      params: [`%${match[1]}%`]
    };
  }

  // tag in ["tag1"]
  match = expr.match(/^tag\s+in\s*\[\s*(.+?)\s*\]\s*$/);
  if (match) {
    const tags = match[1].split(',').map(t => t.trim().replace(/^"|"$/g, ''));
    const tagConditions = tags.map(() => `json_extract(payload, '$.tags') LIKE ?`);
    const tagParams = tags.map(t => `%"${t}"%`);
    return {
      sql: `(${tagConditions.join(' OR ')})`,
      params: tagParams
    };
  }

  // visibility in ["PUBLIC", "PROTECTED"]
  match = expr.match(/^visibility\s+in\s*\[\s*(.+?)\s*\]\s*$/);
  if (match) {
    const values = match[1].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    const placeholders = values.map(() => '?');
    return {
      sql: `visibility IN (${placeholders.join(', ')})`,
      params: values
    };
  }

  // pinned (boolean property)
  if (expr === 'pinned') {
    return { sql: 'pinned = 1', params: [] };
  }

  // has_link
  if (expr === 'has_link') {
    return { sql: `json_extract(payload, '$.property.hasLink') = 1`, params: [] };
  }

  // has_task_list
  if (expr === 'has_task_list') {
    return { sql: `json_extract(payload, '$.property.hasTaskList') = 1`, params: [] };
  }

  // has_code
  if (expr === 'has_code') {
    return { sql: `json_extract(payload, '$.property.hasCode') = 1`, params: [] };
  }

  // created_ts >= X
  match = expr.match(/^created_ts\s*>=\s*(\d+)\s*$/);
  if (match) {
    return { sql: 'created_ts >= ?', params: [Number(match[1])] };
  }

  // created_ts < X
  match = expr.match(/^created_ts\s*<\s*(\d+)\s*$/);
  if (match) {
    return { sql: 'created_ts < ?', params: [Number(match[1])] };
  }

  // created_ts <= X
  match = expr.match(/^created_ts\s*<=\s*(\d+)\s*$/);
  if (match) {
    return { sql: 'created_ts <= ?', params: [Number(match[1])] };
  }

  // created_ts > X
  match = expr.match(/^created_ts\s*>\s*(\d+)\s*$/);
  if (match) {
    return { sql: 'created_ts > ?', params: [Number(match[1])] };
  }

  // Unknown filter - ignore gracefully
  console.warn(`[Filter] Unknown filter expression: ${expr}`);
  return null;
}

function generateUid() {
  return uuidv4().replace(/-/g, '').slice(0, 22);
}

function parseMemoPayload(content) {
  const tags = [];
  const tagRegex = /#([a-zA-Z0-9_\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff/\-]+)/g;
  let match;
  while ((match = tagRegex.exec(content)) !== null) {
    tags.push(match[1]);
  }

  const hasLink = /https?:\/\/[^\s]+/.test(content);
  const hasTaskList = /- \[[ x]\]/.test(content);
  const hasCode = /```[\s\S]*?```/.test(content) || /`[^`]+`/.test(content);
  const hasIncompleteTask = /- \[ \]/.test(content);

  const lines = content.split('\n');
  let title = '';
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) {
      title = trimmed.replace(/^#+\s*/, '').slice(0, 100);
      break;
    }
  }

  return {
    tags,
    property: { hasLink, hasTaskList, hasCode, hasIncompleteTask, title }
  };
}

function formatMemo(memo, creatorUsername) {
  const payload = JSON.parse(memo.payload || '{}');
  return {
    name: `memos/${memo.uid}`,
    creator: `users/${creatorUsername || 'admin'}`,
    createTime: new Date(memo.created_ts * 1000).toISOString(),
    updateTime: new Date(memo.updated_ts * 1000).toISOString(),
    state: memo.row_status === 'ARCHIVED' ? 'ARCHIVED' : 'NORMAL',
    content: memo.content,
    visibility: memo.visibility,
    pinned: memo.pinned === 1,
    tags: payload.tags || [],
    property: payload.property || {},
    location: payload.location || null,
    parent: payload.parent || ''
  };
}

function getMemoAttachments(memoId, memoUid) {
  const attachments = queryAll(
    'SELECT * FROM attachment WHERE memo_id = ? ORDER BY created_ts ASC',
    [memoId]
  );
  return attachments.map(att => ({
    id: att.id,
    name: `attachments/${att.uid}`,
    uid: att.uid,
    createTime: new Date(att.created_ts * 1000).toISOString(),
    updateTime: new Date((att.updated_ts || att.created_ts) * 1000).toISOString(),
    filename: att.filename,
    type: att.type,
    size: att.size,
    memo: `memos/${memoUid}`,
    externalLink: ''
  }));
}

function getMemoRelations(memoId) {
  const relations = queryAll(
    'SELECT * FROM memo_relation WHERE memo_id = ? OR related_memo_id = ?',
    [memoId, memoId]
  );
  return relations.map(rel => {
    const memo = queryOne('SELECT id, uid, content, visibility, creator_id FROM memo WHERE id = ?', [rel.memo_id]);
    const relatedMemo = queryOne('SELECT id, uid, content, visibility, creator_id FROM memo WHERE id = ?', [rel.related_memo_id]);
    return {
      memo: memo ? { name: `memos/${memo.uid}`, snippet: memo.content.slice(0, 120) } : undefined,
      relatedMemo: relatedMemo ? { name: `memos/${relatedMemo.uid}`, snippet: relatedMemo.content.slice(0, 120) } : undefined,
      type: rel.type
    };
  }).filter(r => r.memo && r.relatedMemo);
}

function getMemoReactions(memoUid) {
  const reactions = queryAll(
    'SELECT * FROM reaction WHERE content_id = ?',
    [memoUid]
  );
  return reactions.map(r => ({
    id: r.id,
    creator: `users/admin`,
    contentId: r.content_id,
    reactionType: r.reaction_type,
    createTime: new Date(r.created_ts * 1000).toISOString()
  }));
}

function enrichMemo(memo, creatorUsername) {
  return {
    ...formatMemo(memo, creatorUsername),
    attachments: getMemoAttachments(memo.id, memo.uid),
    relations: getMemoRelations(memo.id),
    reactions: getMemoReactions(memo.uid)
  };
}

// List memos
router.get('/', (req, res) => {
  try {
    const pageSize = Math.min(Number(req.query.pageSize) || 50, 1000);
    const pageToken = req.query.pageToken;
    const filter = req.query.filter || '';
    const state = req.query.state || 'NORMAL';
    const orderBy = req.query.orderBy || 'created_ts desc';

    let offset = 0;
    if (pageToken) {
      try {
        offset = Number(atob(pageToken));
      } catch {}
    }

    const conditions = [];
    const params = [];

    if (state === 'ARCHIVED') {
      conditions.push('row_status = ?');
      params.push('ARCHIVED');
    } else {
      conditions.push('row_status = ?');
      params.push('NORMAL');
    }

    conditions.push('json_extract(payload, \'$.parent\') IS NULL');

    // Parse CEL-like filter expression
    if (filter) {
      const parsed = parseFilter(filter);
      if (parsed.sql) {
        conditions.push(`(${parsed.sql})`);
        params.push(...parsed.params);
      }
    }

    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    // Parse orderBy
    let orderClause = 'ORDER BY pinned DESC, created_ts DESC';
    if (orderBy) {
      const [field, direction] = orderBy.split(/\s+/);
      const dir = direction?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
      if (field === 'create_time' || field === 'created_ts') {
        orderClause = `ORDER BY pinned DESC, created_ts ${dir}`;
      }
    }

    const countResult = queryOne(`SELECT COUNT(*) as total FROM memo ${where}`, params);
    const total = countResult?.total || 0;

    const memos = queryAll(
      `SELECT * FROM memo ${where} ${orderClause} LIMIT ? OFFSET ?`,
      [...params, pageSize, offset]
    );

    const nextPageToken = offset + pageSize < total ? btoa(String(offset + pageSize)) : '';

    res.json({
      memos: memos.map(m => enrichMemo(m, 'admin')),
      nextPageToken,
      totalSize: total
    });
  } catch (err) {
    console.error('List memos error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo by ID
router.get('/:id', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    res.json(enrichMemo(memo, 'admin'));
  } catch (err) {
    console.error('Get memo error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Create memo
router.post('/', (req, res) => {
  try {
    const { content, visibility, createTime, updateTime, location } = req.body;

    if (content === undefined) {
      return res.status(400).json({ error: 'Content is required' });
    }

    const uid = generateUid();
    const payload = {
      ...parseMemoPayload(content || ''),
      ...(location ? { location } : {})
    };

    const createdTs = createTime ? Math.floor(new Date(createTime).getTime() / 1000) : Math.floor(Date.now() / 1000);
    const updatedTs = updateTime ? Math.floor(new Date(updateTime).getTime() / 1000) : Math.floor(Date.now() / 1000);

    run(
      `INSERT INTO memo (uid, creator_id, content, visibility, payload, created_ts, updated_ts)
       VALUES (?, 1, ?, ?, ?, ?, ?)`,
      [uid, content || '', visibility || 'PRIVATE', JSON.stringify(payload), createdTs, updatedTs]
    );

    const memo = queryOne('SELECT * FROM memo WHERE uid = ?', [uid]);
    if (!memo) {
      return res.status(500).json({ error: 'Failed to create memo' });
    }

    res.status(201).json(enrichMemo(memo, 'admin'));
  } catch (err) {
    console.error('Create memo error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update memo
router.patch('/:id', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const body = req.body;
    const updates = [];
    const params = [];

    if (body.content !== undefined) {
      updates.push('content = ?');
      params.push(body.content);

      const payload = parseMemoPayload(body.content);
      const existingPayload = JSON.parse(memo.payload || '{}');
      updates.push('payload = ?');
      params.push(JSON.stringify({ ...existingPayload, ...payload }));
    }

    if (body.visibility !== undefined) {
      updates.push('visibility = ?');
      params.push(body.visibility);
    }

    if (body.pinned !== undefined) {
      updates.push('pinned = ?');
      params.push(body.pinned ? 1 : 0);
    }

    if (body.rowStatus !== undefined) {
      updates.push('row_status = ?');
      params.push(body.rowStatus);
    }

    if (body.createTime) {
      updates.push('created_ts = ?');
      params.push(Math.floor(new Date(body.createTime).getTime() / 1000));
    }

    if (body.updateTime) {
      updates.push('updated_ts = ?');
      params.push(Math.floor(new Date(body.updateTime).getTime() / 1000));
    }

    if (updates.length === 0) {
      return res.json(enrichMemo(memo, 'admin'));
    }

    updates.push("updated_ts = strftime('%s', 'now')");
    params.push(memo.id);

    run(`UPDATE memo SET ${updates.join(', ')} WHERE id = ?`, params);

    const updated = queryOne('SELECT * FROM memo WHERE id = ?', [memo.id]);
    res.json(enrichMemo(updated, 'admin'));
  } catch (err) {
    console.error('Update memo error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Delete memo
router.delete('/:id', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    run('DELETE FROM memo WHERE id = ?', [memo.id]);
    run('DELETE FROM memo_relation WHERE memo_id = ? OR related_memo_id = ?', [memo.id, memo.id]);
    run('DELETE FROM reaction WHERE content_id = ?', [memo.uid]);

    res.json({});
  } catch (err) {
    console.error('Delete memo error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo comments
router.get('/:id/comments', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const relations = queryAll(
      'SELECT * FROM memo_relation WHERE memo_id = ? AND type = ?',
      [memo.id, 'COMMENT']
    );

    const comments = [];
    for (const rel of relations) {
      const comment = queryOne('SELECT * FROM memo WHERE id = ?', [rel.related_memo_id]);
      if (comment && comment.row_status !== 'ARCHIVED') {
        comments.push(enrichMemo(comment, 'admin'));
      }
    }

    res.json({
      memos: comments,
      nextPageToken: '',
      totalSize: comments.length
    });
  } catch (err) {
    console.error('Get comments error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Create comment
router.post('/:id/comments', (req, res) => {
  try {
    const id = req.params.id;
    let parentMemo;

    if (/^\d+$/.test(id)) {
      parentMemo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      parentMemo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!parentMemo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const { content, visibility } = req.body;
    const uid = generateUid();
    const payload = {
      ...parseMemoPayload(content || ''),
      parent: `memos/${parentMemo.uid}`
    };

    const now = Math.floor(Date.now() / 1000);
    run(
      `INSERT INTO memo (uid, creator_id, content, visibility, payload, created_ts, updated_ts)
       VALUES (?, 1, ?, ?, ?, ?, ?)`,
      [uid, content || '', visibility || parentMemo.visibility, JSON.stringify(payload), now, now]
    );

    const comment = queryOne('SELECT * FROM memo WHERE uid = ?', [uid]);
    if (!comment) {
      return res.status(500).json({ error: 'Failed to create comment' });
    }

    run(
      'INSERT INTO memo_relation (memo_id, related_memo_id, type) VALUES (?, ?, ?)',
      [parentMemo.id, comment.id, 'COMMENT']
    );

    res.status(201).json(enrichMemo(comment, 'admin'));
  } catch (err) {
    console.error('Create comment error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo reactions
router.get('/:id/reactions', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    res.json({ reactions: getMemoReactions(memo.uid) });
  } catch (err) {
    console.error('Get reactions error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Add reaction
router.post('/:id/reactions', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const { reactionType } = req.body;
    if (!reactionType) {
      return res.status(400).json({ error: 'Reaction type is required' });
    }

    // Upsert reaction
    const existing = queryOne(
      'SELECT * FROM reaction WHERE creator_id = 1 AND content_id = ? AND reaction_type = ?',
      [memo.uid, reactionType]
    );

    if (existing) {
      res.json({
        id: existing.id,
        creator: 'users/admin',
        contentId: existing.content_id,
        reactionType: existing.reaction_type,
        createTime: new Date(existing.created_ts * 1000).toISOString()
      });
    } else {
      run(
        'INSERT INTO reaction (creator_id, content_id, reaction_type) VALUES (1, ?, ?)',
        [memo.uid, reactionType]
      );

      const reaction = queryOne(
        'SELECT * FROM reaction WHERE creator_id = 1 AND content_id = ? AND reaction_type = ?',
        [memo.uid, reactionType]
      );

      res.json({
        id: reaction.id,
        creator: 'users/admin',
        contentId: reaction.content_id,
        reactionType: reaction.reaction_type,
        createTime: new Date(reaction.created_ts * 1000).toISOString()
      });
    }
  } catch (err) {
    console.error('Add reaction error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Delete reaction
router.delete('/:id/reactions/:reactionId', (req, res) => {
  try {
    const reactionId = Number(req.params.reactionId);
    run('DELETE FROM reaction WHERE id = ? AND creator_id = 1', [reactionId]);
    res.json({});
  } catch (err) {
    console.error('Delete reaction error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo relations
router.get('/:id/relations', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const relations = queryAll(
      'SELECT * FROM memo_relation WHERE memo_id = ? OR related_memo_id = ?',
      [memo.id, memo.id]
    );

    res.json({ relations });
  } catch (err) {
    console.error('Get relations error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update relations
router.patch('/:id/relations', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const { relations } = req.body;

    // Delete existing relations
    run('DELETE FROM memo_relation WHERE memo_id = ?', [memo.id]);

    // Insert new relations
    if (Array.isArray(relations)) {
      for (const rel of relations) {
        run(
          'INSERT INTO memo_relation (memo_id, related_memo_id, type) VALUES (?, ?, ?)',
          [memo.id, rel.relatedMemoId, rel.type]
        );
      }
    }

    const updatedRelations = queryAll(
      'SELECT * FROM memo_relation WHERE memo_id = ?',
      [memo.id]
    );

    res.json({ relations: updatedRelations });
  } catch (err) {
    console.error('Update relations error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo shares
router.get('/:id/shares', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const shares = queryAll(
      'SELECT * FROM memo_share WHERE memo_id = ?',
      [memo.id]
    );

    res.json({
      shares: shares.map(s => ({
        name: `memos/${memo.uid}/shares/${s.uid}`,
        uid: s.uid,
        createTime: new Date(s.created_ts * 1000).toISOString(),
        expireTime: s.expires_ts ? new Date(s.expires_ts * 1000).toISOString() : null
      }))
    });
  } catch (err) {
    console.error('Get shares error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Create share
router.post('/:id/shares', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const { expiresTs } = req.body;
    const uid = generateUid();

    run(
      'INSERT INTO memo_share (uid, memo_id, creator_id, expires_ts) VALUES (?, ?, 1, ?)',
      [uid, memo.id, expiresTs || null]
    );

    const share = queryOne('SELECT * FROM memo_share WHERE uid = ?', [uid]);

    res.json({
      name: `memos/${memo.uid}/shares/${share.uid}`,
      uid: share.uid,
      createTime: new Date(share.created_ts * 1000).toISOString(),
      expireTime: share.expires_ts ? new Date(share.expires_ts * 1000).toISOString() : null
    });
  } catch (err) {
    console.error('Create share error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Delete share
router.delete('/:id/shares/:shareId', (req, res) => {
  try {
    const { shareId } = req.params;
    run('DELETE FROM memo_share WHERE uid = ?', [shareId]);
    res.json({});
  } catch (err) {
    console.error('Delete share error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo by share token
router.get('/shares/:token', (req, res) => {
  try {
    const { token } = req.params;
    const share = queryOne('SELECT * FROM memo_share WHERE uid = ?', [token]);

    if (!share) {
      return res.status(404).json({ error: 'Share not found' });
    }

    if (share.expires_ts && share.expires_ts < Math.floor(Date.now() / 1000)) {
      return res.status(410).json({ error: 'Share expired' });
    }

    const memo = queryOne('SELECT * FROM memo WHERE id = ?', [share.memo_id]);
    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    res.json(enrichMemo(memo, 'admin'));
  } catch (err) {
    console.error('Get shared memo error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get memo attachments
router.get('/:id/attachments', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    res.json({ attachments: getMemoAttachments(memo.id, memo.uid) });
  } catch (err) {
    console.error('Get attachments error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update memo attachments
router.patch('/:id/attachments', (req, res) => {
  try {
    const id = req.params.id;
    let memo;

    if (/^\d+$/.test(id)) {
      memo = queryOne('SELECT * FROM memo WHERE id = ?', [Number(id)]);
    } else {
      memo = queryOne('SELECT * FROM memo WHERE uid = ?', [id]);
    }

    if (!memo) {
      return res.status(404).json({ error: 'Memo not found' });
    }

    const { attachments } = req.body;

    // Clear existing memo attachments
    run('UPDATE attachment SET memo_id = NULL WHERE memo_id = ?', [memo.id]);

    // Set new attachments
    if (Array.isArray(attachments)) {
      for (const att of attachments) {
        const attId = att.id || att.uid;
        if (attId) {
          const attRow = queryOne('SELECT id FROM attachment WHERE id = ? OR uid = ?', [attId, attId]);
          if (attRow) {
            run('UPDATE attachment SET memo_id = ? WHERE id = ?', [memo.id, attRow.id]);
          }
        }
      }
    }

    res.json({});
  } catch (err) {
    console.error('Update attachments error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
