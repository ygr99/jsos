import { Router } from 'express';
import { generateToken } from '../middleware/auth.js';
import { queryOne } from '../db.js';

const router = Router();

// Sign in - always returns default user
router.post('/signin', async (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(500).json({ error: 'Default user not found' });
    }

    const token = generateToken({
      id: user.id,
      username: user.username,
      role: user.role,
      status: user.row_status
    });

    const expiresAt = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60;

    res.json({
      user: formatUser(user),
      accessToken: token,
      expiresAt: new Date(expiresAt * 1000).toISOString(),
      expiresAtSeconds: expiresAt,
      accessTokenExpiresAt: new Date(expiresAt * 1000).toISOString()
    });
  } catch (err) {
    console.error('Sign in error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Sign up - same as sign in
router.post('/signup', async (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(500).json({ error: 'Default user not found' });
    }

    const token = generateToken({
      id: user.id,
      username: user.username,
      role: user.role,
      status: user.row_status
    });

    const expiresAt = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60;

    res.json({
      user: formatUser(user),
      accessToken: token,
      expiresAt: new Date(expiresAt * 1000).toISOString(),
      expiresAtSeconds: expiresAt,
      accessTokenExpiresAt: new Date(expiresAt * 1000).toISOString()
    });
  } catch (err) {
    console.error('Sign up error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Sign out
router.post('/signout', (req, res) => {
  res.json({});
});

// Refresh token
router.post('/refresh', async (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(500).json({ error: 'Default user not found' });
    }

    const token = generateToken({
      id: user.id,
      username: user.username,
      role: user.role,
      status: user.row_status
    });

    const expiresAt = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60;

    res.json({
      accessToken: token,
      expiresAt: new Date(expiresAt * 1000).toISOString(),
      expiresAtSeconds: expiresAt,
      accessTokenExpiresAt: new Date(expiresAt * 1000).toISOString()
    });
  } catch (err) {
    console.error('Refresh error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get current user
router.get('/me', async (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const formattedUser = formatUser(user, { includeEmail: true });
    res.json({
      user: formattedUser,
      ...formattedUser
    });
  } catch (err) {
    console.error('Get me error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Auth status
router.get('/status', async (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const formattedUser = formatUser(user, { includeEmail: true });
    res.json({
      ok: true,
      authenticated: true,
      user: formattedUser,
      ...formattedUser
    });
  } catch (err) {
    console.error('Auth status error:', err);
    res.status(500).json({ error: err.message });
  }
});

function formatUser(user, options = {}) {
  const result = {
    name: `users/${user.username}`,
    username: user.username,
    displayName: user.nickname || user.username,
    nickname: user.nickname || '',
    role: user.role === 'ADMIN' ? 2 : 1,
    state: user.row_status === 'ARCHIVED' ? 2 : 1,
    avatarUrl: user.avatar_url || '',
    description: user.description || ''
  };

  if (options.includeEmail) {
    result.email = user.email || '';
  }

  return result;
}

export default router;
