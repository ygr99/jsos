import { Router } from 'express';
import { queryOne, queryAll, run } from '../db.js';

const router = Router();

// Get instance profile
router.get('/profile', (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    const admin = user ? {
      name: `users/${user.username}`,
      username: user.username,
      nickname: user.nickname || user.username,
      role: 2
    } : undefined;

    res.json({
      version: '1.0.0-jsos',
      mode: 'prod',
      admin
    });
  } catch (err) {
    console.error('Get profile error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get instance stats
router.get('/stats', (req, res) => {
  try {
    const storageRow = queryOne('SELECT COALESCE(SUM(size), 0) AS total FROM attachment');
    const localStorageBytes = storageRow?.total || 0;

    let databaseSize = -1;
    try {
      const pageCountRow = queryOne('PRAGMA page_count');
      const pageSizeRow = queryOne('PRAGMA page_size');
      const pageCount = pageCountRow?.page_count || pageCountRow?.pageCount || 0;
      const pageSize = pageSizeRow?.page_size || pageSizeRow?.pageSize || 0;
      if (pageCount > 0 && pageSize > 0) {
        databaseSize = pageCount * pageSize;
      }
    } catch {}

    res.json({
      database: {
        driver: 'sqlite',
        sizeBytes: databaseSize
      },
      localStorageBytes,
      generatedTime: {
        seconds: Math.floor(Date.now() / 1000),
        nanos: 0
      }
    });
  } catch (err) {
    console.error('Get stats error:', err);
    res.status(500).json({ error: err.message });
  }
});

// List instance settings
router.get('/settings', (req, res) => {
  try {
    const settings = queryAll('SELECT * FROM system_setting');
    res.json({
      settings: settings.map(s => ({
        name: `instance/settings/${s.name}`,
        value: s.value
      }))
    });
  } catch (err) {
    console.error('List settings error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get instance setting
router.get('/settings/:key', (req, res) => {
  try {
    const { key } = req.params;
    const setting = queryOne('SELECT * FROM system_setting WHERE name = ?', [key]);

    if (!setting) {
      return res.json({ name: `instance/settings/${key}`, value: '{}' });
    }

    res.json({
      name: `instance/settings/${setting.name}`,
      value: setting.value
    });
  } catch (err) {
    console.error('Get setting error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update instance setting
router.patch('/settings/:key', (req, res) => {
  try {
    const { key } = req.params;
    const { value, description } = req.body;

    const existing = queryOne('SELECT * FROM system_setting WHERE name = ?', [key]);
    if (existing) {
      run(
        'UPDATE system_setting SET value = ?, description = COALESCE(?, description) WHERE name = ?',
        [value, description || null, key]
      );
    } else {
      run(
        'INSERT INTO system_setting (name, value, description) VALUES (?, ?, ?)',
        [key, value, description || '']
      );
    }

    res.json({ name: `instance/settings/${key}`, value });
  } catch (err) {
    console.error('Update setting error:', err);
    res.status(500).json({ error: err.message });
  }
});

// List user settings
router.get('/users/:username/settings', (req, res) => {
  try {
    const user = queryOne('SELECT * FROM user WHERE id = 1');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const settings = queryAll('SELECT * FROM user_setting WHERE user_id = ?', [user.id]);
    res.json({
      settings: settings.map(s => ({
        name: `users/${user.username}/settings/${s.key}`,
        key: s.key,
        value: s.value
      }))
    });
  } catch (err) {
    console.error('List user settings error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get user setting
router.get('/users/:username/settings/:key', (req, res) => {
  try {
    const { key } = req.params;
    const setting = queryOne('SELECT * FROM user_setting WHERE user_id = 1 AND key = ?', [key]);

    if (!setting) {
      return res.json({ key, value: '{}' });
    }

    res.json({
      key: setting.key,
      value: setting.value
    });
  } catch (err) {
    console.error('Get user setting error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update user setting
router.patch('/users/:username/settings/:key', (req, res) => {
  try {
    const { key } = req.params;
    const { value } = req.body;

    const existing = queryOne('SELECT * FROM user_setting WHERE user_id = 1 AND key = ?', [key]);
    if (existing) {
      run(
        'UPDATE user_setting SET value = ? WHERE user_id = 1 AND key = ?',
        [typeof value === 'string' ? value : JSON.stringify(value), key]
      );
    } else {
      run(
        'INSERT INTO user_setting (user_id, key, value) VALUES (1, ?, ?)',
        [key, typeof value === 'string' ? value : JSON.stringify(value)]
      );
    }

    res.json({ key, value });
  } catch (err) {
    console.error('Update user setting error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get user stats
router.get('/users/:username/stats', (req, res) => {
  try {
    const memoCount = queryOne('SELECT COUNT(*) as count FROM memo WHERE creator_id = 1 AND row_status = \'NORMAL\'');
    const archivedCount = queryOne('SELECT COUNT(*) as count FROM memo WHERE creator_id = 1 AND row_status = \'ARCHIVED\'');
    const tagQuery = queryAll('SELECT DISTINCT payload FROM memo WHERE creator_id = 1 AND row_status = \'NORMAL\'');

    const tags = new Set();
    for (const row of tagQuery) {
      try {
        const payload = JSON.parse(row.payload || '{}');
        if (payload.tags) {
          payload.tags.forEach(t => tags.add(t));
        }
      } catch {}
    }

    res.json({
      memoCount: memoCount?.count || 0,
      archivedMemoCount: archivedCount?.count || 0,
      tagCount: tags.size
    });
  } catch (err) {
    console.error('Get user stats error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
