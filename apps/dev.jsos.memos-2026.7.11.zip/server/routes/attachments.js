import { Router } from 'express';
import multer from 'multer';
import { existsSync, mkdirSync, renameSync, unlinkSync } from 'fs';
import { join, extname } from 'path';
import { queryOne, queryAll, run, DATA_DIR } from '../db.js';
import { v4 as uuidv4 } from 'uuid';

const ATTACHMENTS_DIR = join(DATA_DIR, 'attachments');

// Ensure attachments directory exists
if (!existsSync(ATTACHMENTS_DIR)) {
  mkdirSync(ATTACHMENTS_DIR, { recursive: true });
}

const upload = multer({
  dest: join(DATA_DIR, '.upload-tmp'),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

const router = Router();

function generateUid() {
  return uuidv4().replace(/-/g, '').slice(0, 22);
}

function formatAttachment(att) {
  return {
    id: att.id,
    name: `attachments/${att.uid}`,
    uid: att.uid,
    createTime: new Date(att.created_ts * 1000).toISOString(),
    updateTime: new Date((att.updated_ts || att.created_ts) * 1000).toISOString(),
    filename: att.filename,
    type: att.type,
    size: att.size,
    memo: att.memo_id ? `memos/${att.memo_id}` : '',
    externalLink: ''
  };
}

// Upload attachment
router.post('/', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    const uid = generateUid();
    const originalName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');
    const ext = extname(originalName);
    const targetPath = join(ATTACHMENTS_DIR, `${uid}${ext}`);

    // Move file to attachments directory
    renameSync(req.file.path, targetPath);

    const now = Math.floor(Date.now() / 1000);
    run(
      `INSERT INTO attachment (uid, creator_id, filename, type, size, storage_type, reference, created_ts, updated_ts)
       VALUES (?, 1, ?, ?, ?, 'LOCAL', ?, ?, ?)`,
      [uid, originalName, req.file.mimetype, req.file.size, targetPath, now, now]
    );

    const att = queryOne('SELECT * FROM attachment WHERE uid = ?', [uid]);
    if (!att) {
      return res.status(500).json({ error: 'Failed to save attachment' });
    }

    res.status(201).json(formatAttachment(att));
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// List attachments
router.get('/', (req, res) => {
  try {
    const pageSize = Math.min(Number(req.query.pageSize) || 50, 1000);
    const pageToken = req.query.pageToken;

    let offset = 0;
    if (pageToken) {
      try {
        offset = Number(atob(pageToken));
      } catch {}
    }

    const countResult = queryOne('SELECT COUNT(*) as total FROM attachment');
    const total = countResult?.total || 0;

    const attachments = queryAll(
      'SELECT * FROM attachment ORDER BY created_ts DESC LIMIT ? OFFSET ?',
      [pageSize, offset]
    );

    const nextPageToken = offset + pageSize < total ? btoa(String(offset + pageSize)) : '';

    res.json({
      attachments: attachments.map(formatAttachment),
      nextPageToken,
      totalSize: total
    });
  } catch (err) {
    console.error('List attachments error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get attachment by ID
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;
    let att;

    if (/^\d+$/.test(id)) {
      att = queryOne('SELECT * FROM attachment WHERE id = ?', [Number(id)]);
    } else {
      att = queryOne('SELECT * FROM attachment WHERE uid = ?', [id]);
    }

    if (!att) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    res.json(formatAttachment(att));
  } catch (err) {
    console.error('Get attachment error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Delete attachment
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    let att;

    if (/^\d+$/.test(id)) {
      att = queryOne('SELECT * FROM attachment WHERE id = ?', [Number(id)]);
    } else {
      att = queryOne('SELECT * FROM attachment WHERE uid = ?', [id]);
    }

    if (!att) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    // Delete file from filesystem
    if (att.reference && existsSync(att.reference)) {
      unlinkSync(att.reference);
    }

    run('DELETE FROM attachment WHERE id = ?', [att.id]);
    res.json({});
  } catch (err) {
    console.error('Delete attachment error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
