import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'memos-dev-secret-key-change-in-production';

// Default user ID = 1
const DEFAULT_USER = {
  id: 1,
  username: 'admin',
  role: 'ADMIN',
  status: 'NORMAL'
};

export function generateToken(user = DEFAULT_USER) {
  return jwt.sign(
    {
      name: user.username,
      role: user.role,
      status: user.status
    },
    JWT_SECRET,
    {
      subject: String(user.id),
      issuer: 'memos',
      audience: 'user.access-token',
      expiresIn: '30d'
    }
  );
}

export function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET, {
      issuer: 'memos',
      audience: 'user.access-token'
    });
  } catch {
    return null;
  }
}

// Auth middleware - always sets default user
export function authMiddleware(req, res, next) {
  // Always set user to default user
  req.user = DEFAULT_USER;
  next();
}

// Optional auth - same as required for this simplified version
export function authOptional(req, res, next) {
  req.user = DEFAULT_USER;
  next();
}
