/**
 * 直播视界 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 三个接口：
 *   /api/state                  直播源列表（模式 A 单文档状态，DATA_DIR 持久化，首装播种）
 *   /api/room/:platform/:roomId 单个直播间归一化信息（9001 中转优先，见 lib/rooms.js）
 *   /api/img?u=                 图片同源代理（JSOS 强制 COEP require-corp，
 *                               跨域图片无 CORP 头会被 ERR_BLOCKED_BY_RESPONSE 拦掉；
 *                               域名白名单防 SSRF）
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } from 'fs';
import { outboundFetch, setProxyConfig, getProxyConfig } from './lib/http.js';
import { PLATFORMS, fetchRoom, isRoomUsable } from './lib/rooms.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'streams.json');

// JSOS 启动时注入 CORS 代理配置（容器内自动走代理，本机直跑直连）
if (process.env.PROXY_URL) {
  setProxyConfig({ url: process.env.PROXY_URL, key: process.env.PROXY_KEY || '' });
}

/** 首装播种（照九韵笺模式：文件不存在才写，用户清空后不复活） */
const DEFAULT_STREAMS = [
  { platform: 'douyu', roomId: '9690322', customName: '', tags: ['游戏'] },
  { platform: 'bilibili', roomId: '32447141', customName: '', tags: ['编程'] },
  { platform: 'douyin', roomId: '659712903300', customName: '', tags: ['科技'] },
];

const PLATFORM_IDS = Object.keys(PLATFORMS);

/** 图片代理域名白名单（防 SSRF；按后缀匹配，覆盖三平台图片 CDN 实测域名） */
const IMG_HOST_RE = /(^|\.)(douyucdn\.cn|hdslb\.com|douyinpic\.com|douyinstatic\.com|byteimg\.com|bilivideo\.com)$/i;
/** 防盗链 Referer 映射（经代理 x-upstream-referer 透传） */
const IMG_REFERER = [
  [/hdslb\.com$/i, 'https://live.bilibili.com/'],
  [/douyucdn\.cn$/i, 'https://www.douyu.com/'],
  [/douyinpic\.com$|douyinstatic\.com$|byteimg\.com$/i, 'https://live.douyin.com/'],
];

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

function ok(res, data) {
  res.json({ ok: true, ...data });
}
function fail(res, error, status = 502) {
  res.status(status).json({ ok: false, error });
}

/* ------------------------------ 直播源列表（模式 A） ------------------------------ */

function sanitizeStream(s) {
  if (!s || typeof s !== 'object') return null;
  const platform = String(s.platform || '');
  const roomId = String(s.roomId || '').trim();
  if (!PLATFORM_IDS.includes(platform)) return null;
  if (!roomId || roomId.length > 64 || !/^[\w-]+$/.test(roomId)) return null;
  return {
    platform,
    roomId,
    customName: String(s.customName || '').slice(0, 60),
    tags: Array.isArray(s.tags)
      ? s.tags.map((t) => String(t).trim().slice(0, 20)).filter(Boolean).slice(0, 8)
      : [],
  };
}

function saveStreams(list) {
  mkdirSync(DATA_DIR, { recursive: true });
  const tmp = STATE_FILE + '.tmp';
  writeFileSync(tmp, JSON.stringify(list, null, 2));
  renameSync(tmp, STATE_FILE); // 原子写
}

function loadStreams() {
  if (!existsSync(STATE_FILE)) {
    saveStreams(DEFAULT_STREAMS); // 首装播种
    return DEFAULT_STREAMS;
  }
  try {
    const j = JSON.parse(readFileSync(STATE_FILE, 'utf8'));
    if (!Array.isArray(j)) return [];
    return j.map(sanitizeStream).filter(Boolean);
  } catch {
    return [];
  }
}

app.get('/api/health', (req, res) => {
  ok(res, {
    service: 'live-view',
    proxyConfigured: !!getProxyConfig(),
    relay: String(process.env.LIVE_RELAY || 'http://8.129.83.45:9001').replace(/\/+$/, ''),
    time: new Date().toISOString(),
  });
});

app.get('/api/state', (req, res) => {
  ok(res, { streams: loadStreams() });
});

app.post('/api/state', (req, res) => {
  const list = req.body?.streams;
  if (!Array.isArray(list)) return fail(res, 'streams 必须是数组', 400);
  if (list.length > 200) return fail(res, '直播间数量超出限制（200）', 400);
  const clean = list.map(sanitizeStream);
  if (clean.some((s) => !s)) return fail(res, '存在非法的直播间条目（platform / roomId 不合法）', 400);
  saveStreams(clean);
  ok(res, { streams: clean });
});

/* ------------------------------ 单个直播间信息 ------------------------------ */

app.get('/api/room/:platform/:roomId', async (req, res) => {
  const { platform, roomId } = req.params;
  if (!PLATFORM_IDS.includes(platform)) return fail(res, `不支持的平台: ${platform}`, 400);
  if (!/^[\w-]{1,64}$/.test(roomId)) return fail(res, 'roomId 不合法', 400);
  try {
    const room = await fetchRoom(platform, roomId);
    if (!isRoomUsable(room)) throw new Error('房间数据不完整');
    ok(res, { room });
  } catch (err) {
    fail(res, `获取直播间信息失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 图片同源代理 ------------------------------ */

app.get('/api/img', async (req, res) => {
  const raw = String(req.query.u || '');
  let u;
  try {
    u = new URL(raw);
  } catch {
    return fail(res, 'URL 无效', 400);
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return fail(res, '仅支持 http/https 地址', 400);
  if (!IMG_HOST_RE.test(u.hostname)) return fail(res, '域名不在白名单', 400);

  const refererRule = IMG_REFERER.find(([re]) => re.test(u.hostname));
  const referer = refererRule ? refererRule[1] : '';

  try {
    const { res: up } = await outboundFetch(u.href, {
      timeout: 20000,
      proxyQuery: referer ? { 'x-upstream-referer': referer } : null,
      headers: {
        ...(referer ? { Referer: referer } : {}),
        Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      },
      // 判据：必须是图片类型（CORS 代理失败可能回 200 + text/plain → 不能当图片喂给 <img>）
      isOk: (r) => (r.headers.get('content-type') || '').startsWith('image/'),
    });
    const buf = Buffer.from(await up.arrayBuffer());
    res.setHeader('Content-Type', up.headers.get('content-type') || 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.status(200).send(buf);
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `图片拉取失败：${err?.message || '未知错误'}`, 502);
    } else {
      res.destroy();
    }
  }
});

app.listen(port, () => {
  console.log(`[live-view] listening on http://localhost:${port} (proxy: ${getProxyConfig() ? 'on' : 'off'})`);
});
