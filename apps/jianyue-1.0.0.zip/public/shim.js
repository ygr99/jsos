/* 简阅 JSOS 垫片 —— 让 uTools 插件「简阅」v1.2.0 的 bundle 原样跑在 JSOS 里。
 * 本文件必须在 bundle（module 脚本）之前执行，由 index.html 注入（见 setup-plugin.cjs）。
 *
 * 三块职责：
 *  1. window.utools —— dbStorage（书架/书签/划线/设置/AI 会话元数据，键全为 reader:*）
 *     架构（数据存服务端铁律）：内存 Map 提供同步语义（bundle 直接同步读写），
 *     boot 时同步 XHR 从服务端 storage.json 整体载入；写入 600ms 防抖回存 +
 *     pagehide sendBeacon 兜底 + 30s 定时兜底；localStorage 作同源二级镜像。
 *  2. window.services —— 原 preload（Node fs）的操作全部改为同步 XHR 打到本应用
 *     服务端（DATA_DIR/jianyue/{books,covers,fonts,ai-cache}）。bundle 对这些
 *     API 全是同步调用（含 copyBookToCache 的导入上传），因此一律 sync XHR。
 *  3. 原生文件对话框（showFilePicker/showImagePicker/showFontPicker）浏览器里只能
 *     异步 → bundle 已打 await 补丁；选中的文件内容吸入内存 pick 表，
 *     pick://<字节数>/<文件名> 虚拟路径对 bundle 透明（bookId 哈希按路径算，
 *     同名同大小的文件重复导入仍能去重）。
 *
 * 虚拟路径约定（cache:// 前缀，服务端按 kind 映射到 DATA_DIR 子目录）：
 *   cache://books/<bookId>.<ext>   书籍文件（openBook 按路径取扩展名，必须带真实扩展名）
 *   cache://covers/<bookId>.<ext>  封面图
 *   字体路径特殊：copyFontToCache/getFontFiles 返回 /api/font-file?name=<enc>，
 *   它会原样进 @font-face 的 src url()（bundle 的 file:// 前缀已打补丁去掉），
 *   所以必须是可直接 GET 的同源 URL。
 */
(function () {
  'use strict';

  if (window.__jianyueShimLoaded) return;
  window.__jianyueShimLoaded = true;

  // ============ 同步 XHR 工具 ============
  function jsonSync(method, url, body) {
    try {
      const x = new XMLHttpRequest();
      x.open(method, url, false);
      if (body !== undefined) x.setRequestHeader('Content-Type', 'application/json');
      x.send(body === undefined ? null : JSON.stringify(body));
      return x.status >= 200 && x.status < 300 ? JSON.parse(x.responseText) : null;
    } catch {
      return null;
    }
  }

  function textSync(method, url, body) {
    try {
      const x = new XMLHttpRequest();
      x.open(method, url, false);
      x.send(body === undefined ? null : body);
      return x.status >= 200 && x.status < 300 ? x.responseText : null;
    } catch {
      return null;
    }
  }

  // 二进制上传（书籍/字体）：body 原样发送，绝不能走 JSON.stringify
  function rawSync(method, url, body) {
    try {
      const x = new XMLHttpRequest();
      x.open(method, url, false);
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      x.send(body === undefined ? null : body);
      return x.status >= 200 && x.status < 300 ? JSON.parse(x.responseText) : null;
    } catch {
      return null;
    }
  }

  // 同步取二进制：sync XHR 不允许设 responseType，用 x-user-defined 逐字节还原
  // （该编码下 0x80-0xFF 映射到 U+F780-0xF7FF，& 0xff 正好还原）
  function binarySync(url) {
    try {
      const x = new XMLHttpRequest();
      x.open('GET', url, false);
      x.overrideMimeType('text/plain; charset=x-user-defined');
      x.send(null);
      if (x.status < 200 || x.status >= 300) return null;
      const s = x.responseText;
      const u = new Uint8Array(s.length);
      for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 0xff;
      return u.buffer;
    } catch {
      return null;
    }
  }

  function downloadBlob(name, data, mime) {
    try {
      const blob = data instanceof Blob ? data : new Blob([data], { type: mime || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
    } catch {}
  }

  // ============ 1. utools.dbStorage（服务端 KV + 同步内存层） ============
  const KV_KEY_PREFIX = 'jianyue:kv:';
  const kv = new Map();
  let kvDirty = false;
  let kvFlushTimer = null;

  function kvSeedFromLocal() {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(KV_KEY_PREFIX)) kv.set(k.slice(KV_KEY_PREFIX.length), localStorage.getItem(k));
      }
    } catch {}
  }

  function kvMirrorLocal(key, value) {
    try {
      if (value === undefined || value === null) localStorage.removeItem(KV_KEY_PREFIX + key);
      else localStorage.setItem(KV_KEY_PREFIX + key, value);
    } catch {}
  }

  function kvFlushNow() {
    if (!kvDirty) return;
    kvDirty = false;
    const payload = JSON.stringify(Object.fromEntries(kv));
    try {
      navigator.sendBeacon('/api/storage', new Blob([payload], { type: 'application/json' }));
    } catch {
      jsonSync('POST', '/api/storage', Object.fromEntries(kv));
    }
  }

  function kvScheduleFlush() {
    kvDirty = true;
    clearTimeout(kvFlushTimer);
    kvFlushTimer = setTimeout(kvFlushNow, 600);
  }

  // boot：服务端为唯一事实源；服务端不可达才退回 localStorage 镜像
  try {
    const seeded = jsonSync('GET', '/api/storage');
    if (seeded && typeof seeded === 'object') {
      for (const [k, v] of Object.entries(seeded)) {
        kv.set(k, v);
        kvMirrorLocal(k, v);
      }
    } else {
      kvSeedFromLocal();
    }
  } catch {
    kvSeedFromLocal();
  }

  window.utools = {
    dbStorage: {
      getItem(key) {
        const v = kv.get(String(key));
        return v === undefined ? null : v;
      },
      setItem(key, value) {
        const k = String(key);
        const v = typeof value === 'string' ? value : String(value);
        kv.set(k, v);
        kvMirrorLocal(k, v);
        kvScheduleFlush();
      },
      removeItem(key) {
        const k = String(key);
        kv.delete(k);
        kvMirrorLocal(k, null);
        kvScheduleFlush();
      },
    },
    copyText(text) {
      const t = String(text == null ? '' : text);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(t).catch(() => copyViaExecCommand(t));
      } else {
        copyViaExecCommand(t);
      }
    },
  };

  function copyViaExecCommand(t) {
    try {
      const ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    } catch {}
  }

  // ============ 2. 文件选择（pick 表） ============
  const picks = new Map(); // pick://<size>/<name> -> { name, buffer }

  function pickFiles(accept, multiple) {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept;
      if (multiple) input.multiple = true;
      input.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
      input.addEventListener('change', () => {
        resolve(Array.from(input.files || []));
        setTimeout(() => input.remove(), 0);
      });
      input.addEventListener('cancel', () => {
        resolve([]);
        setTimeout(() => input.remove(), 0);
      });
      window.__jianyueLastFileInput = input; // 测试钩子
      document.body.appendChild(input);
      input.click();
    });
  }

  function pickPathFor(file) {
    return 'pick://' + file.size + '/' + file.name;
  }

  async function ingestFiles(files) {
    const paths = [];
    for (const f of files) {
      const p = pickPathFor(f);
      if (!picks.has(p)) picks.set(p, { name: f.name, buffer: await f.arrayBuffer() });
      paths.push(p);
    }
    return paths;
  }

  const BOOK_ACCEPT = '.epub,.txt,.mobi,.azw3,.cbz,.cbr';
  const IMAGE_ACCEPT = '.jpg,.jpeg,.png,.gif,.webp,.bmp';
  const FONT_ACCEPT = '.ttf,.otf,.woff,.woff2';

  // ============ 3. 虚拟路径工具 ============
  function extOf(p) {
    const m = /\.([A-Za-z0-9]+)$/.exec(p || '');
    return m ? m[1].toLowerCase() : '';
  }

  function baseName(p) {
    return String(p || '').split(/[\\/]/).pop() || '';
  }

  function fileNameOf(p) {
    return baseName(p);
  }

  function fontNameParam(p) {
    // /api/font-file?name=<enc> -> <decoded name>
    try {
      const m = /[?&]name=([^&]+)/.exec(p || '');
      return m ? decodeURIComponent(m[1]) : '';
    } catch {
      return '';
    }
  }

  // ============ 4. window.services ============
  const AI_DIR = 'cache://ai-cache';

  window.services = {
    readFileAsBuffer(p) {
      if (String(p).startsWith('pick://')) {
        const e = picks.get(String(p));
        return e && e.buffer ? e.buffer : new ArrayBuffer(0);
      }
      const buf = binarySync('/api/fs/read?path=' + encodeURIComponent(p));
      return buf || new ArrayBuffer(0);
    },

    readFileAsText(p) {
      if (String(p).startsWith('pick://')) {
        const e = picks.get(String(p));
        if (!e || !e.buffer) return '';
        try {
          return new TextDecoder('utf-8').decode(new Uint8Array(e.buffer));
        } catch {
          return '';
        }
      }
      return textSync('GET', '/api/fs/read?path=' + encodeURIComponent(p)) || '';
    },

    checkFileExists(p) {
      return !!jsonSync('GET', '/api/fs/exists?path=' + encodeURIComponent(p));
    },

    showFilePicker() {
      return pickFiles(BOOK_ACCEPT, true).then(ingestFiles);
    },

    showImagePicker() {
      return pickFiles(IMAGE_ACCEPT, false).then(ingestFiles);
    },

    showFontPicker() {
      return pickFiles(FONT_ACCEPT, true).then(ingestFiles);
    },

    // 浏览器没有「选目录写文件」；直接触发下载。返回值只需为真值
    // （bundle 拿它判断成功，随后传给 showItemInFolder）
    saveFile(defaultName, data) {
      const name = String(defaultName || ('export-' + Date.now()));
      downloadBlob(name, data, typeof data === 'string' ? 'text/markdown' : 'application/octet-stream');
      return 'download://' + name;
    },

    writeTextFile(text) {
      const name = Date.now() + '.txt';
      downloadBlob(name, String(text == null ? '' : text), 'text/plain');
      return 'download://' + name;
    },

    writeImageFile(base64Url) {
      const m = /^data:image\/([a-z]{1,20});base64,/i.exec(base64Url || '');
      if (!m) return null;
      const name = Date.now() + '.' + m[1];
      const bin = atob(base64Url.substring(m[0].length));
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      downloadBlob(name, u8, 'image/' + m[1]);
      return 'download://' + name;
    },

    getFileName(p) {
      return fileNameOf(p);
    },

    getFileSize(p) {
      if (String(p).startsWith('pick://')) {
        const m = /^pick:\/\/(\d+)\//.exec(String(p));
        return m ? Number(m[1]) : 0;
      }
      const r = jsonSync('GET', '/api/fs/exists?path=' + encodeURIComponent(p));
      return r && r.exists ? (r.size || 0) : 0;
    },

    copyBookToCache(bookId, srcPath) {
      const e = picks.get(String(srcPath));
      const ext = '.' + (extOf(srcPath) || 'epub');
      const r = rawSync('POST', '/api/fs/book/' + encodeURIComponent(bookId) + '?ext=' + encodeURIComponent(ext), e && e.buffer ? new Uint8Array(e.buffer) : new Uint8Array(0));
      if (!r || !r.ok) return null;
      return 'cache://books/' + bookId + ext;
    },

    deleteCachedBook(p) {
      if (!p || !String(p).startsWith('cache://books/')) return;
      jsonSync('DELETE', '/api/fs/delete?path=' + encodeURIComponent(p));
    },

    cachedBookExists(p) {
      if (!p || !String(p).startsWith('cache://')) return false;
      const r = jsonSync('GET', '/api/fs/exists?path=' + encodeURIComponent(p));
      return !!(r && r.exists);
    },

    saveCoverFile(bookId, base64DataUrl) {
      const r = jsonSync('POST', '/api/fs/cover/' + encodeURIComponent(bookId), { dataUrl: base64DataUrl });
      return r && r.path ? r.path : null;
    },

    deleteCoverFile(p) {
      if (!p || !String(p).startsWith('cache://covers/')) return;
      jsonSync('DELETE', '/api/fs/delete?path=' + encodeURIComponent(p));
    },

    coverFileExists(p) {
      if (!p || !String(p).startsWith('cache://covers/')) return false;
      const r = jsonSync('GET', '/api/fs/exists?path=' + encodeURIComponent(p));
      return !!(r && r.exists);
    },

    findEpubCover(bookId, p) {
      if (!p || !String(p).startsWith('cache://books/')) return null;
      const r = jsonSync('GET', '/api/fs/epub-cover?bookId=' + encodeURIComponent(bookId) + '&path=' + encodeURIComponent(p));
      return r && r.path ? r.path : null;
    },

    copyFontToCache(pickPath) {
      const e = picks.get(String(pickPath));
      const name = fileNameOf(pickPath);
      if (!name) return null;
      const r = rawSync('POST', '/api/fs/font?name=' + encodeURIComponent(name), e && e.buffer ? new Uint8Array(e.buffer) : new Uint8Array(0));
      if (!r || !r.ok) return null;
      return '/api/font-file?name=' + encodeURIComponent(name);
    },

    deleteFontFile(p) {
      const name = fontNameParam(p);
      if (!name) return;
      jsonSync('DELETE', '/api/fs/font?name=' + encodeURIComponent(name));
    },

    getFontFiles() {
      const r = jsonSync('GET', '/api/fs/fonts');
      return r && Array.isArray(r.fonts) ? r.fonts : [];
    },

    showItemInFolder() {
      // 浏览器里导出即触发下载，没有「在文件夹中显示」
    },

    // ---------- AI 缓存（对话历史） ----------
    ensureAiCacheDir() {
      return AI_DIR;
    },

    readAiCacheFile(p) {
      if (!p || !String(p).startsWith(AI_DIR + '/')) return null;
      const name = String(p).slice(AI_DIR.length + 1);
      const r = textSync('GET', '/api/fs/ai-read?name=' + encodeURIComponent(name));
      return r === null ? null : r;
    },

    writeAiCacheFile(p, data) {
      if (!p || !String(p).startsWith(AI_DIR + '/')) return;
      const name = String(p).slice(AI_DIR.length + 1);
      textSync('POST', '/api/fs/ai-write?name=' + encodeURIComponent(name), String(data == null ? '' : data));
    },

    deleteAiCacheFile(p) {
      if (!p || !String(p).startsWith(AI_DIR + '/')) return;
      const name = String(p).slice(AI_DIR.length + 1);
      jsonSync('DELETE', '/api/fs/ai-delete?name=' + encodeURIComponent(name));
    },

    listAiCacheFiles() {
      const r = jsonSync('GET', '/api/fs/ai-list');
      return r && Array.isArray(r.names) ? r.names : [];
    },

    // ---------- 浮窗阅读（uTools 独立窗口 → 浏览器弹出窗） ----------
    createFloatReader(text, chapterTitle, opacity) {
      try {
        const w = 420;
        const h = 560;
        const left = Math.max(0, (screen.availWidth || 1280) - w - 20);
        const top = Math.max(0, (screen.availHeight || 800) - h - 40);
        const win = window.open('', 'jianyue-float-reader',
          'popup=yes,width=' + w + ',height=' + h + ',left=' + left + ',top=' + top);
        if (!win) return false;
        win.document.write(floatReaderHtml());
        win.document.close();
        try {
          win.document.title = '简阅 · 浮窗阅读';
          const titleEl = win.document.getElementById('chapterTitle');
          const contentEl = win.document.getElementById('content');
          const slider = win.document.getElementById('opacitySlider');
          if (titleEl) titleEl.textContent = '简阅 · ' + (chapterTitle || '当前章节');
          if (contentEl) {
            if (text && String(text).trim()) contentEl.textContent = text;
            else contentEl.innerHTML = '<div class="empty-hint">当前章节无文字内容</div>';
          }
          if (slider && typeof opacity === 'number') slider.value = Math.round(opacity * 100);
          win.addEventListener('pagehide', () => { floatWin = null; });
        } catch {}
        floatWin = win;
        return true;
      } catch {
        return false;
      }
    },

    closeFloatReader() {
      try { if (floatWin) floatWin.close(); } catch {}
      floatWin = null;
    },

    isFloatReaderOpen() {
      try { return !!(floatWin && !floatWin.closed); } catch { return false; }
    },

    // 拖拽导入：浏览器 File 没有 .path，先吸入内存再返回虚拟路径（bundle P6 补丁）
    resolveDropFiles(files) {
      return ingestFiles(files);
    },
  };

  let floatWin = null;

  function floatReaderHtml() {
    return '<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><style>' +
      '*{margin:0;padding:0;box-sizing:border-box}html,body{background:transparent;height:100%;overflow:hidden;' +
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',system-ui,sans-serif;user-select:none}" +
      '.container{height:100%;display:flex;flex-direction:column;background:rgba(30,30,30,1);border-radius:12px;' +
      'border:1px solid rgba(255,255,255,.1);overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.4)}' +
      '.header{display:flex;align-items:center;padding:8px 12px;background:rgba(255,255,255,.05);' +
      'border-bottom:1px solid rgba(255,255,255,.08);gap:8px;flex-shrink:0}' +
      '.title{flex:1;font-size:12px;color:rgba(255,255,255,.7);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.opacity-control{display:flex;align-items:center;gap:6px}.opacity-label{font-size:10px;color:rgba(255,255,255,.5)}' +
      '.opacity-slider{width:60px;height:3px;-webkit-appearance:none;appearance:none;background:rgba(255,255,255,.2);' +
      'border-radius:2px;outline:none;cursor:pointer}' +
      '.opacity-slider::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;' +
      'background:#fff;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3)}' +
      '.close-btn{width:22px;height:22px;border-radius:50%;border:none;background:rgba(255,255,255,.1);' +
      'color:rgba(255,255,255,.7);font-size:11px;cursor:pointer;display:flex;align-items:center;justify-content:center}' +
      '.close-btn:hover{background:#e74c3c;color:#fff}' +
      '.content{flex:1;overflow-y:auto;padding:16px 20px;font-size:14px;line-height:1.8;color:rgba(255,255,255,.85);' +
      'white-space:pre-wrap;word-break:break-word;user-select:text}' +
      '.content::-webkit-scrollbar{width:4px}.content::-webkit-scrollbar-thumb{background:rgba(255,255,255,.15);border-radius:2px}' +
      '.empty-hint{display:flex;align-items:center;justify-content:center;height:100%;color:rgba(255,255,255,.3);font-size:13px}' +
      '</style></head><body><div class="container" id="app">' +
      '<div class="header"><span class="title" id="chapterTitle">简阅 · 浮窗阅读</span>' +
      '<div class="opacity-control"><span class="opacity-label">透明度</span>' +
      '<input type="range" class="opacity-slider" id="opacitySlider" min="20" max="100" value="85"></div>' +
      '<button class="close-btn" id="closeBtn" title="关闭">&#10005;</button></div>' +
      '<div class="content" id="content"><div class="empty-hint">加载中...</div></div></div>' +
      '<script>' +
      'var s=document.getElementById("opacitySlider"),c=document.getElementById("app"),b=document.getElementById("closeBtn");' +
      's.addEventListener("input",function(e){c.style.opacity=Number(e.target.value)/100});' +
      'b.addEventListener("click",function(){try{window.close()}catch(e){}});' +
      '<\/script></body></html>';
  }

  // ============ 5. 跨域 fetch → 服务端出站代理 ============
  // 容器内 iframe 直连外部 API 受 CORS 约束；AI 解读/朗读是 bundle 里裸 fetch 的
  // OpenAI 兼容接口，统一改走同源 /api/outbound（服务端直连优先、平台代理兜底）。
  const origFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    try {
      if (typeof input !== 'string' && !(input instanceof URL)) return origFetch(input, init);
      const url = new URL(String(input), location.href);
      if (url.origin === location.origin || !/^https?:$/.test(url.protocol)) return origFetch(input, init);
      return origFetch('/api/outbound?url=' + encodeURIComponent(url.href), init);
    } catch {
      return origFetch(input, init);
    }
  };

  // ============ 6. uTools 生命周期事件 ============
  // bundle 在 onMounted 里监听 plugin-enter（uTools 打开插件时触发），
  // plugin-out 时保存进度 —— 这里在页面卸载时补发并立即回存 KV。
  window.addEventListener('load', () => {
    setTimeout(() => {
      try {
        window.dispatchEvent(new CustomEvent('plugin-enter', { detail: { code: 'reader', type: '', payload: null } }));
      } catch {}
    }, 200);
  });
  window.addEventListener('pagehide', () => {
    try {
      window.dispatchEvent(new CustomEvent('plugin-out'));
    } catch {}
    clearTimeout(kvFlushTimer);
    kvFlushNow();
  });
  setInterval(kvFlushNow, 30000);
})();
