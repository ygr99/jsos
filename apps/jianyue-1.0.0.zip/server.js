/**
 * 简阅 —— JSOS 应用服务端
 *
 * 前端是 uTools 插件「简阅」的原 bundle + 垫片（public/shim.js）。
 * 原 preload（Node fs）负责的所有文件操作在这里落地到 DATA_DIR：
 *
 *   DATA_DIR/jianyue/books/<bookId>.<ext>      书籍文件（bundle 起名 book_xxx）
 *   DATA_DIR/jianyue/covers/<bookId>.<ext>     封面（bundle 存 dataURL / 服务端解 EPUB）
 *   DATA_DIR/jianyue/fonts/<显示名>.<ext>      自定义字体（保留原文件名，中文 OK）
 *   DATA_DIR/jianyue/ai-cache/<sessionId>.json AI 对话历史
 *   DATA_DIR/jianyue/storage.json              dbStorage KV 整仓（书架/书签/划线/设置）
 *
 * 前端所有 services 调用都是同步 XHR（bundle 同步语义），所以这里的路由必须
 * 「快进快出」——都是本地小文件操作，唯一出网的是 /api/outbound（AI 接口）。
 */
import express from 'express';
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync, readdirSync, renameSync, statSync } from 'fs';
import { join, dirname, resolve, sep, extname } from 'path';
import { fileURLToPath } from 'url';
import { inflateRawSync } from 'zlib';
import { Readable } from 'stream';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const BASE = join(DATA_DIR, 'jianyue');
const DIRS = {
  books: join(BASE, 'books'),
  covers: join(BASE, 'covers'),
  fonts: join(BASE, 'fonts'),
  'ai-cache': join(BASE, 'ai-cache'),
};
const STORAGE_FILE = join(BASE, 'storage.json');
for (const d of Object.values(DIRS)) mkdirSync(d, { recursive: true });

app.use(express.static(join(__dirname, 'public')));

// ---------- 虚拟路径安全解析（cache://<kind>/<name> -> DATA_DIR 子目录内文件） ----------
const VIRTUAL_RE = /^cache:\/\/(books|covers|fonts|ai-cache)\/(.+)$/;

function safeTarget(virtualPath, expectedKinds) {
  const m = VIRTUAL_RE.exec(String(virtualPath || ''));
  if (!m) return null;
  const kind = m[1];
  const name = m[2];
  if (expectedKinds && !expectedKinds.includes(kind)) return null;
  if (!name || name.includes('/') || name.includes('\\') || name.includes('..') || name.startsWith('.')) return null;
  const dir = DIRS[kind];
  const target = resolve(dir, name);
  if (!target.startsWith(resolve(dir) + sep)) return null;
  return { kind, name, target };
}

function readStorage() {
  try {
    return JSON.parse(readFileSync(STORAGE_FILE, 'utf8'));
  } catch {
    return {};
  }
}

// ---------- dbStorage KV 整仓（垫片 boot 载入 + 防抖回存 + pagehide beacon） ----------
app.get('/api/storage', (req, res) => {
  res.json(readStorage());
});

app.post('/api/storage', express.json({ limit: '80mb' }), (req, res) => {
  const data = req.body;
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return res.status(400).json({ ok: false, error: 'storage payload must be an object' });
  }
  mkdirSync(BASE, { recursive: true });
  const tmp = STORAGE_FILE + '.tmp';
  writeFileSync(tmp, JSON.stringify(data), 'utf8');
  renameSync(tmp, STORAGE_FILE);
  res.json({ ok: true });
});

// ---------- 文件读取 / 存在性（books / covers / fonts / ai-cache 通用） ----------
app.get('/api/fs/read', (req, res) => {
  const t = safeTarget(req.query.path);
  if (!t || !existsSync(t.target)) return res.status(404).json({ ok: false, error: 'not found' });
  res.set('Content-Type', 'application/octet-stream');
  res.set('Cache-Control', 'no-store');
  res.send(readFileSync(t.target));
});

app.get('/api/fs/exists', (req, res) => {
  const t = safeTarget(req.query.path);
  if (!t) return res.status(400).json({ ok: false, error: 'bad path' });
  if (!existsSync(t.target)) return res.json({ exists: false });
  let size = 0;
  try { size = statSync(t.target).size; } catch {}
  res.json({ exists: true, size });
});

// 书籍/封面删除走这一个口（字体/AI 缓存有专用路由）；限 books/covers 两类
app.delete('/api/fs/delete', (req, res) => {
  const t = safeTarget(req.query.path, ['books', 'covers']);
  if (!t) return res.status(400).json({ ok: false, error: 'bad path' });
  try { unlinkSync(t.target); } catch {}
  res.json({ ok: true });
});

// ---------- 书籍上传（copyBookToCache：导入/重定位时同步上传） ----------
app.post('/api/fs/book/:bookId', express.raw({ type: () => true, limit: '300mb' }), (req, res) => {
  const bookId = String(req.params.bookId || '');
  if (!/^[\w-]{1,80}$/.test(bookId)) return res.status(400).json({ ok: false, error: 'bad bookId' });
  const ext = String(req.query.ext || '.epub');
  if (!/^\.[A-Za-z0-9]{1,8}$/.test(ext)) return res.status(400).json({ ok: false, error: 'bad ext' });
  writeFileSync(join(DIRS.books, bookId + ext), req.body);
  res.json({ ok: true });
});

// ---------- 封面（saveCoverFile：dataURL base64 落盘） ----------
app.post('/api/fs/cover/:bookId', express.json({ limit: '20mb' }), (req, res) => {
  const bookId = String(req.params.bookId || '');
  if (!/^[\w-]{1,80}$/.test(bookId)) return res.status(400).json({ ok: false, error: 'bad bookId' });
  const m = /^data:image\/([a-z]{1,20});base64,/i.exec(String((req.body || {}).dataUrl || ''));
  if (!m) return res.json({ path: null });
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
  const target = join(DIRS.covers, bookId + '.' + ext);
  writeFileSync(target, Buffer.from(req.body.dataUrl.substring(m[0].length), 'base64'));
  res.json({ path: 'cache://covers/' + bookId + '.' + ext });
});

// ---------- EPUB 封面兜底提取（findEpubCover：直接解 zip 中央目录找 cover 图） ----------
// 算法与原 uTools preload 逐行对应：EOCD 扫描 -> 中央目录 -> 文件名含 cover/front 的
// 最大图片 -> 本地头跳过 -> method 0/8 解压
app.get('/api/fs/epub-cover', (req, res) => {
  const bookId = String(req.query.bookId || '');
  const t = safeTarget(req.query.path, ['books']);
  if (!/^[\w-]{1,80}$/.test(bookId) || !t || !existsSync(t.target)) {
    return res.json({ path: null });
  }
  try {
    const buf = readFileSync(t.target);
    let eocdOff = -1;
    for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
      if (buf[i] === 0x50 && buf[i + 1] === 0x4b && buf[i + 2] === 0x05 && buf[i + 3] === 0x06) {
        eocdOff = i;
        break;
      }
    }
    if (eocdOff === -1) return res.json({ path: null });
    const cdOff = buf.readUInt32LE(eocdOff + 16);
    const cdCount = buf.readUInt16LE(eocdOff + 10);
    const imgExts = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp']);
    const entries = [];
    let off = cdOff;
    for (let i = 0; i < cdCount; i++) {
      if (buf.readUInt32LE(off) !== 0x02014b50) break;
      const method = buf.readUInt16LE(off + 10);
      const compSize = buf.readUInt32LE(off + 20);
      const uncompSize = buf.readUInt32LE(off + 24);
      const nameLen = buf.readUInt16LE(off + 28);
      const extraLen = buf.readUInt16LE(off + 30);
      const commentLen = buf.readUInt16LE(off + 32);
      const localOff = buf.readUInt32LE(off + 42);
      const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
      entries.push({ name, method, compSize, uncompSize, localOff });
      off += 46 + nameLen + extraLen + commentLen;
    }
    const isCoverName = (n) => {
      const lower = n.toLowerCase();
      return lower.includes('cover') || lower.includes('front');
    };
    const best = entries
      .filter((e) => imgExts.has(extname(e.name).toLowerCase()) && isCoverName(e.name))
      .sort((a, b) => b.uncompSize - a.uncompSize)[0];
    if (!best) return res.json({ path: null });
    const localNameLen = buf.readUInt16LE(best.localOff + 26);
    const localExtraLen = buf.readUInt16LE(best.localOff + 28);
    const dataOff = best.localOff + 30 + localNameLen + localExtraLen;
    const compData = buf.subarray(dataOff, dataOff + best.compSize);
    let fileData;
    if (best.method === 0) fileData = compData;
    else if (best.method === 8) fileData = inflateRawSync(compData);
    else return res.json({ path: null });
    const saveExt = extname(best.name).toLowerCase() === '.jpeg' ? '.jpg' : extname(best.name).toLowerCase();
    const coverPath = join(DIRS.covers, bookId + saveExt);
    writeFileSync(coverPath, fileData);
    res.json({ path: 'cache://covers/' + bookId + saveExt });
  } catch {
    res.json({ path: null });
  }
});

// ---------- 自定义字体 ----------
// 磁盘上保留显示名（可中文）；垫片拿到的路径是 /api/font-file?name=<enc>，
// 它会原样进 @font-face 的 src url()，所以必须是可直接 GET 的同源 URL。
function fontNameFrom(req) {
  try { return decodeURIComponent(String(req.query.name || '')); } catch { return ''; }
}

app.post('/api/fs/font', express.raw({ type: () => true, limit: '50mb' }), (req, res) => {
  const name = fontNameFrom(req);
  if (!name || name.includes('/') || name.includes('\\') || name.includes('..')) {
    return res.status(400).json({ ok: false, error: 'bad font name' });
  }
  writeFileSync(join(DIRS.fonts, name), req.body);
  res.json({ ok: true });
});

const FONT_MIME = { '.ttf': 'font/ttf', '.otf': 'font/otf', '.woff': 'font/woff', '.woff2': 'font/woff2' };

app.get('/api/font-file', (req, res) => {
  const name = fontNameFrom(req);
  const target = resolve(DIRS.fonts, name);
  if (!name || name.includes('/') || name.includes('\\') || name.includes('..') ||
      !target.startsWith(resolve(DIRS.fonts) + sep) || !existsSync(target)) {
    return res.status(404).end();
  }
  res.set('Content-Type', FONT_MIME[extname(name).toLowerCase()] || 'application/octet-stream');
  res.set('Cache-Control', 'no-store');
  res.send(readFileSync(target));
});

app.get('/api/fs/fonts', (req, res) => {
  const fonts = [];
  try {
    for (const f of readdirSync(DIRS.fonts)) {
      if (!/\.(ttf|otf|woff|woff2)$/i.test(f)) continue;
      fonts.push({
        name: f.replace(/\.(ttf|otf|woff|woff2)$/i, ''),
        path: '/api/font-file?name=' + encodeURIComponent(f),
      });
    }
  } catch {}
  res.json({ fonts });
});

app.delete('/api/fs/font', (req, res) => {
  const name = fontNameFrom(req);
  const target = resolve(DIRS.fonts, name);
  if (!name || name.includes('/') || name.includes('\\') || name.includes('..') ||
      !target.startsWith(resolve(DIRS.fonts) + sep)) {
    return res.status(400).json({ ok: false, error: 'bad font name' });
  }
  try { unlinkSync(target); } catch {}
  res.json({ ok: true });
});

// ---------- AI 对话历史缓存 ----------
// 垫片传来的 name 是会话文件名（bundle 拼 ensureAiCacheDir() + '/' + id + '.json'）
function aiTarget(req) {
  let name = '';
  try { name = decodeURIComponent(String(req.query.name || '')); } catch {}
  return safeTarget('cache://ai-cache/' + name);
}

app.get('/api/fs/ai-read', (req, res) => {
  const t = aiTarget(req);
  if (!t || !existsSync(t.target)) return res.status(404).json({ ok: false });
  res.set('Content-Type', 'text/plain; charset=utf-8');
  res.send(readFileSync(t.target, 'utf8'));
});

app.post('/api/fs/ai-write', express.text({ type: () => true, limit: '30mb' }), (req, res) => {
  const t = aiTarget(req);
  if (!t || !t.name.endsWith('.json')) return res.status(400).json({ ok: false });
  writeFileSync(t.target, String(req.body || ''), 'utf8');
  res.json({ ok: true });
});

app.delete('/api/fs/ai-delete', (req, res) => {
  const t = aiTarget(req);
  if (!t) return res.status(400).json({ ok: false });
  try { unlinkSync(t.target); } catch {}
  res.json({ ok: true });
});

app.get('/api/fs/ai-list', (req, res) => {
  let names = [];
  try {
    names = readdirSync(DIRS['ai-cache']).filter((n) => n.endsWith('.json'));
  } catch {}
  res.json({ names });
});

// ---------- 出站代理（AI 解读 / AI 朗读：OpenAI 兼容接口，SSE 流式透传） ----------
// bundle 在 iframe 里裸 fetch 外部 API 会被 CORS 拦；垫片把跨域 fetch 全部改写到这里。
// 服务端直连优先，网络错误时才回退平台代理（encoded 路径 + query key 形态）。
app.all('/api/outbound', express.raw({ type: () => true, limit: '25mb' }), async (req, res) => {
  let target = '';
  try { target = decodeURIComponent(String(req.query.url || '')); } catch { target = String(req.query.url || ''); }
  if (!/^https?:\/\//i.test(target)) return res.status(400).json({ error: 'bad target url' });
  const method = String(req.query.method || req.method || 'POST').toUpperCase();

  const headers = {};
  for (const h of ['content-type', 'authorization', 'accept', 'accept-language', 'user-agent']) {
    if (req.headers[h]) headers[h] = req.headers[h];
  }
  const hasBody = method !== 'GET' && method !== 'HEAD';
  const body = hasBody ? req.body : undefined;

  const PROXY_URL = process.env.PROXY_URL || '';
  const PROXY_KEY = process.env.PROXY_KEY || '';
  // 直连优先（自建/局域网端点只有直连可达）；网络层失败才回退平台代理
  const attempts = [{ via: 'direct', url: target }];
  if (PROXY_URL && PROXY_KEY) {
    attempts.push({
      via: 'proxy',
      url: PROXY_URL.replace(/\/+$/, '') + '/' + encodeURIComponent(target) + '?x-cors-proxy-key=' + encodeURIComponent(PROXY_KEY),
    });
  }
  let lastErr = null;
  for (const attempt of attempts) {
    try {
      const up = await fetch(attempt.url, {
        method,
        headers,
        body: hasBody ? body : undefined,
        redirect: 'follow',
      });
      res.set('x-jianyue-outbound-via', attempt.via);
      const ct = up.headers.get('content-type');
      if (ct) res.set('Content-Type', ct);
      const cl = up.headers.get('content-length');
      if (cl) res.set('Content-Length', cl);
      res.status(up.status);
      if (!up.body) return res.end();
      const stream = Readable.fromWeb(up.body);
      stream.on('error', () => res.destroy());
      return stream.pipe(res);
    } catch (e) {
      lastErr = e;
    }
  }
  res.status(502).json({ error: 'outbound failed', message: lastErr && lastErr.message });
});

// ---------- 兜底：SPA 无路由，其余路径全回 index.html ----------
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'no such api' });
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`jianyue running on ${port}`));
