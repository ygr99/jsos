import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

// [存储规范] 数据存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/<appId>，
// 用户卸载勾选「同时删除应用数据」时由平台整目录清除）；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const EVENTS_FILE = join(DATA_DIR, 'events.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

app.get('/api/events', (req, res) => {
  try {
    if (!fs.existsSync(EVENTS_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(fs.readFileSync(EVENTS_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/events', (req, res) => {
  if (!Array.isArray(req.body)) return res.status(400).json({ error: 'events must be an array' });
  try {
    const tmp = EVENTS_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(req.body));
    fs.renameSync(tmp, EVENTS_FILE);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`days-matter running on ${port}`));
