/**
 * days-matter 共享核心：服务端存储（workspace/data/<appId>/events.json）+ 日期计算
 *
 * 存储：数据经 /api/events 存到服务端 DATA_DIR（JSOS 容器内 = workspace/data/<appId>，
 * 平台卸载勾选「同时删除应用数据」时整目录清除——唯一会被真正清理的存储位置）。
 * 同步：跨页面（主页面 ↔ 小组件）用 BroadcastChannel 通知 + 60s/可见性兜底轮询。
 */

export const DEFAULT_EVENTS = [
  { name: '元旦', date: '2027-01-01', type: 'countdown', icon: '🎉', isPinned: false },
  { name: '春节', date: '2027-02-06', type: 'countdown', icon: '🧧', isPinned: false },
  { name: '发工资', date: '15', type: 'monthly', icon: '💰', isPinned: false },
  { name: '来到世界', date: '2000-01-01', type: 'passed', icon: '👶', isPinned: false },
  { name: '开始工作', date: '2020-07-01', type: 'passed', icon: '💼', isPinned: false },
];

const SYNC_CHANNEL = 'days-matter-sync';

export async function loadEvents() {
  try {
    const res = await fetch('/api/events', { cache: 'no-store' });
    const data = await res.json();
    return Array.isArray(data) ? data : null;
  } catch {
    return null;
  }
}

export async function saveEvents(events) {
  try {
    await fetch('/api/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(events),
    });
  } catch (e) {
    console.error('保存日子数据失败:', e);
    return;
  }
  notifyChange();
}

/** 跨页面即时通知（同一容器内同源） */
export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage('events-updated');
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = () => cb();
  } catch {}
}

/**
 * 每月重复事件的下一次日期（date 为 1-31 的字符串/数字）
 * 该月没有对应日期（如2月30日）时取该月最后一天
 */
export function nextMonthlyDate(dayOfMonth, now = new Date()) {
  const day = parseInt(dayOfMonth);
  let d = new Date(now.getFullYear(), now.getMonth(), day);
  if (now.getDate() >= day) d = new Date(now.getFullYear(), now.getMonth() + 1, day);
  if (d.getDate() !== day) d = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  return d;
}

/**
 * 处理全部事件，附加 daysLeft（passed 类型为已过天数，取正）与 nextDate
 */
export function processEvents(events, now = new Date()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const DAY = 1000 * 60 * 60 * 24;

  return (events || []).map((event) => {
    if (event.type === 'monthly') {
      const d = nextMonthlyDate(event.date, today);
      return { ...event, daysLeft: Math.ceil((d - today) / DAY), nextDate: fmt(d) };
    }
    const d = new Date(event.date);
    d.setHours(0, 0, 0, 0);
    const diff = Math.ceil((d - today) / DAY);
    if (event.type === 'passed') return { ...event, daysLeft: Math.abs(diff), nextDate: fmt(d) };
    return { ...event, daysLeft: diff, nextDate: fmt(d) };
  });
}

function fmt(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 小组件展示对象：置顶优先，否则取剩余天数最近的 countdown/monthly（daysLeft > 0）
 */
export function pickWidgetEvent(processed) {
  const pinned = processed.filter((e) => e.isPinned);
  if (pinned.length) return pinned[0];
  const valid = processed
    .filter((e) => e.type === 'countdown' || e.type === 'monthly')
    .filter((e) => e.daysLeft > 0)
    .sort((a, b) => a.daysLeft - b.daysLeft);
  return valid.length ? valid[0] : null;
}
