/* HowToCook 前端：顶栏栏目 + 左侧目录 + 正文（marked 渲染包内 markdown） */

const LS_THEME = 'howtocook.theme';
const LS_SIDEBAR = 'howtocook.sidebar-collapsed';
const IMG_EXT_RE = /\.(jpe?g|png|webp|gif|bmp|svg)$/i;

const shell = document.getElementById('shell');
const sidebar = document.getElementById('sidebar');
const sidebarList = document.getElementById('sidebar-list');
const content = document.getElementById('content');
const tabsBar = document.getElementById('tabs');
const searchInput = document.getElementById('search-input');
const searchClear = document.getElementById('search-clear');
const themeToggle = document.getElementById('theme-toggle');
const collapseBtn = document.getElementById('collapse-btn');
const iconCollapse = collapseBtn.querySelector('.icon-collapse');
const iconExpand = collapseBtn.querySelector('.icon-expand');

const state = {
  nav: null,
  flat: [],
  tabId: 'before',
  path: '',
  query: '',
  collapsed: new Set(),
};

const readLS = (key) => {
  try { return localStorage.getItem(key); } catch { return null; }
};
const writeLS = (key, value) => {
  try { localStorage.setItem(key, value); } catch {}
};

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function notice(title, body) {
  const art = el('article', 'markdown-body status');
  art.append(el('h2', null, title));
  if (body) art.append(el('p', null, body));
  return art;
}

// 用户从 uTools 版迁来的核心诉求：只要正文换了一份，就不要停在旧的滚动位置。
// 所有正文写入都必须经过这里，滚动重置只这一处。
function setDoc(node) {
  content.replaceChildren(node);
  content.scrollTop = 0;
}

/* ---------------- 目录 ---------------- */

const groupKey = (tabId, group) => `${tabId}/${group.name}`;

function matches(item, group, tab, q) {
  return `${item.title}\n${group.name}\n${tab.name}`.toLowerCase().includes(q);
}

function renderItem(item, tab, group, showFrom) {
  const btn = el('button', 'item');
  btn.type = 'button';
  btn.dataset.path = item.path;
  btn.title = item.title;
  btn.setAttribute('aria-current', item.path === state.path ? 'true' : 'false');
  btn.append(el('span', 'name', item.title));
  if (showFrom && (group.name || tab.id !== state.tabId)) {
    btn.append(el('span', 'from', group.name ? `${tab.name}·${group.name}` : tab.name));
  }
  btn.addEventListener('click', () => selectEntry(item.path));
  const li = el('li');
  li.append(btn);
  return li;
}

function renderGroup(tab, group, items, { open, showFrom }) {
  const wrap = el('section', 'group');
  const list = el('ul', 'group-items');
  for (const item of items) list.append(renderItem(item, tab, group, showFrom));

  if (group.name) {
    const head = el('button', 'group-head');
    head.type = 'button';
    head.dataset.key = groupKey(tab.id, group);
    head.setAttribute('aria-expanded', open ? 'true' : 'false');
    head.append(el('span', 'caret', '▾'), el('span', 'group-name', group.name), el('span', 'count', String(items.length)));
    head.addEventListener('click', () => {
      const key = head.dataset.key;
      if (head.getAttribute('aria-expanded') === 'true') state.collapsed.add(key);
      else state.collapsed.delete(key);
      head.setAttribute('aria-expanded', state.collapsed.has(key) ? 'false' : 'true');
      list.toggleAttribute('hidden', state.collapsed.has(key));
    });
    wrap.append(head, list);
  } else {
    wrap.append(list);
  }
  list.toggleAttribute('hidden', Boolean(group.name) && !open);
  return wrap;
}

function renderSidebar() {
  if (!state.nav) return;
  const q = state.query.trim().toLowerCase();
  const frag = document.createDocumentFragment();

  if (q) {
    let total = 0;
    for (const tab of state.nav.tabs) {
      for (const group of tab.groups) {
        const items = group.items.filter((item) => matches(item, group, tab, q));
        if (!items.length) continue;
        total += items.length;
        frag.append(renderGroup(tab, group, items, { open: true, showFrom: true }));
      }
    }
    if (!total) {
      const empty = el('div', 'empty');
      empty.append(el('strong', null, `没有找到「${state.query.trim()}」`), el('span', null, '换个菜名试试，或清空搜索回到当前栏目。'));
      sidebarList.replaceChildren(empty);
      return;
    }
    sidebarList.replaceChildren(frag);
    return;
  }

  const tab = state.nav.tabs.find((t) => t.id === state.tabId) || state.nav.tabs[0];
  state.tabId = tab.id;
  for (const group of tab.groups) {
    if (!group.items.length) continue;
    const open = !group.name || !state.collapsed.has(groupKey(tab.id, group));
    frag.append(renderGroup(tab, group, group.items, { open, showFrom: false }));
  }
  sidebarList.replaceChildren(frag);
}

function markCurrent() {
  for (const btn of sidebarList.querySelectorAll('.item')) {
    btn.setAttribute('aria-current', btn.dataset.path === state.path ? 'true' : 'false');
  }
  const current = sidebarList.querySelector('.item[aria-current="true"]');
  if (!current) return;
  const group = current.closest('.group');
  const list = group?.querySelector('.group-items');
  if (list) list.toggleAttribute('hidden', false);
  const head = group?.querySelector('.group-head');
  if (head) head.setAttribute('aria-expanded', 'true');
  // 只能用 nearest：center 这类"容器内满足不了"的请求会把溢出量链式滚到外层视口
  current.scrollIntoView({ block: 'nearest' });
}

/* ---------------- 正文 ---------------- */

function resolveRelative(baseFile, ref) {
  let clean = String(ref || '').split('#')[0].split('?')[0];
  if (!clean) return '';
  try { clean = decodeURIComponent(clean); } catch {}
  clean = clean.replace(/^\/+/, '');
  const dir = baseFile.includes('/') ? baseFile.slice(0, baseFile.lastIndexOf('/')) : '';
  const stack = [];
  for (const seg of `${dir}/${clean}`.split('/')) {
    if (seg === '' || seg === '.') continue;
    if (seg === '..') { stack.pop(); continue; }
    stack.push(seg);
  }
  return stack.join('/');
}

function contentUrl(relPath) {
  return '/content/' + relPath.split('/').map(encodeURIComponent).join('/');
}

function degradeImage(img, reason) {
  const box = el('span', 'img-fallback', `🖼 图片未能加载${img.alt ? ` · ${img.alt}` : ''}`);
  if (reason) box.title = reason;
  img.replaceWith(box);
}

function prepareImage(img, basePath) {
  const raw = (img.getAttribute('src') || '').trim();
  img.removeAttribute('srcset');
  img.loading = 'lazy';
  img.decoding = 'async';
  if (/^https?:/i.test(raw)) {
    // 外站直链（少数几篇用了第三方图床）不改写：被 COEP 拦下时走占位降级
  } else {
    const rel = resolveRelative(basePath, raw);
    if (rel.startsWith('dishes/') && IMG_EXT_RE.test(rel)) img.src = '/api/img/' + rel.split('/').map(encodeURIComponent).join('/');
    else return degradeImage(img, '包内图片引用指向了无法定位的路径');
  }
  img.addEventListener('error', () => degradeImage(img, '上游图片源不可达'), { once: true });
}

function prepareLink(a) {
  const href = (a.getAttribute('href') || '').trim();
  if (/^https?:/i.test(href)) {
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
  }
}

function renderArticle(mdText, basePath) {
  const art = el('article', 'markdown-body');
  art.innerHTML = marked.parse(mdText);
  for (const img of art.querySelectorAll('img')) prepareImage(img, basePath);
  for (const a of art.querySelectorAll('a')) prepareLink(a);
  return art;
}

async function selectEntry(path) {
  if (!path) return;
  state.path = path;
  const hit = state.flat.find((item) => item.path === path);
  if (hit && hit.tabId !== state.tabId) {
    state.tabId = hit.tabId;
    syncTabs();
    renderSidebar();
  }
  markCurrent();
  setDoc(notice('正在载入…', hit ? hit.title : path));

  let res;
  try {
    res = await fetch(contentUrl(path), { cache: 'no-store' });
  } catch (err) {
    return setDoc(notice('加载失败', `读取 ${path} 时网络出错：${err.message}`));
  }
  if (!res.ok) return setDoc(notice('加载失败', `无法读取 ${path}（HTTP ${res.status}）`));
  const text = await res.text();
  setDoc(renderArticle(text, path));
  document.title = `${hit ? hit.title : 'HowToCook'} · HowToCook`;
}

/* ---------------- 顶栏 ---------------- */

function syncTabs() {
  for (const btn of tabsBar.querySelectorAll('.tab')) {
    btn.setAttribute('aria-selected', btn.dataset.tab === state.tabId ? 'true' : 'false');
  }
}

function switchTab(tabId) {
  state.tabId = tabId;
  syncTabs();
  renderSidebar();
  sidebar.scrollTop = 0;
  content.scrollTop = 0;
}

function setCollapsed(collapsed, persist) {
  shell.classList.toggle('collapsed', collapsed);
  iconCollapse.toggleAttribute('hidden', collapsed);
  iconExpand.toggleAttribute('hidden', !collapsed);
  const label = collapsed ? '展开侧边栏' : '折叠侧边栏';
  collapseBtn.setAttribute('aria-label', label);
  collapseBtn.title = label;
  if (persist) writeLS(LS_SIDEBAR, collapsed ? '1' : '0');
}

function applyTheme(theme) {
  document.body.classList.toggle('dark', theme === 'dark');
  themeToggle.textContent = theme === 'dark' ? '☀️' : '🌙';
}

/* ---------------- 启动 ---------------- */

async function fetchJson(url) {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function initTheme() {
  const saved = readLS(LS_THEME);
  let theme = saved === 'light' || saved === 'dark' ? saved : null;
  if (!theme) {
    theme = 'light';
    try {
      const sys = await window.JSOS?.getTheme?.();
      if (sys === 'dark') theme = 'dark';
    } catch {}
  }
  applyTheme(theme);
  try {
    window.JSOS?.onThemeChange?.((next) => {
      const own = readLS(LS_THEME);
      if (own !== 'light' && own !== 'dark') applyTheme(next === 'dark' ? 'dark' : 'light');
    });
  } catch {}
}

function bindUi() {
  tabsBar.addEventListener('click', (e) => {
    const btn = e.target.closest('.tab');
    if (btn) switchTab(btn.dataset.tab);
  });

  collapseBtn.addEventListener('click', () => setCollapsed(!shell.classList.contains('collapsed'), true));
  themeToggle.addEventListener('click', () => {
    const next = document.body.classList.contains('dark') ? 'light' : 'dark';
    applyTheme(next);
    writeLS(LS_THEME, next);
  });

  searchInput.addEventListener('input', () => {
    state.query = searchInput.value;
    searchClear.toggleAttribute('hidden', !state.query.trim());
    renderSidebar();
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const first = sidebarList.querySelector('.item');
    if (first) selectEntry(first.dataset.path);
  });
  searchClear.addEventListener('click', () => {
    searchInput.value = '';
    state.query = '';
    searchClear.toggleAttribute('hidden', true);
    renderSidebar();
    searchInput.focus();
  });

  // 正文里的相对链接一律同页跳转（跳外站才允许新标签）
  content.addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (!a) return;
    const href = (a.getAttribute('href') || '').trim();
    if (!href || href.startsWith('#') || /^https?:/i.test(href) || /^mailto:/i.test(href)) return;
    e.preventDefault();
    const target = resolveRelative(state.path, href);
    if (state.flat.some((item) => item.path === target)) selectEntry(target);
    else setDoc(notice('没找到这篇', `正文里的引用「${href}」在这份内容里对不到文件。`));
  });
}

async function init() {
  bindUi();
  setCollapsed(readLS(LS_SIDEBAR) === '1');
  try {
    state.nav = await fetchJson('/api/nav');
  } catch (err) {
    return setDoc(notice('目录加载失败', `${err.message}——应用后台可能已停止，重新打开应用即可恢复。`));
  }
  for (const tab of state.nav.tabs) {
    for (const group of tab.groups) {
      if (group.name) state.collapsed.add(groupKey(tab.id, group));
      for (const item of group.items) state.flat.push({ ...item, tabId: tab.id, tabName: tab.name });
    }
  }
  await initTheme();
  syncTabs();
  renderSidebar();
  const start = state.flat.find((item) => item.path === 'tips/厨房准备.md') || state.flat[0];
  if (start) await selectEntry(start.path);
}

init();
