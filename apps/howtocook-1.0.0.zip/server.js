import { createServer } from 'node:http';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = join(__dirname, 'public');
const CONTENT_DIR = join(PUBLIC_DIR, 'content');
const PORT = Number(process.env.PORT) || 4720;
const PROXY_URL = (process.env.PROXY_URL || '').replace(/\/+$/, '');
const PROXY_KEY = process.env.PROXY_KEY || '';

const REPO = 'Anduin2017/HowToCook';
const REF = 'master';
const IMG_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.svg']);
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
};

// ---------- 导航索引（启动时扫描一次，包内内容是固定的） ----------

const DISH_CATEGORIES = [
  ['vegetable_dish', '素菜'],
  ['meat_dish', '荤菜'],
  ['aquatic', '水产'],
  ['breakfast', '早餐'],
  ['staple', '主食'],
  ['semi-finished', '半成品加工'],
  ['soup', '汤与粥'],
  ['drink', '饮料'],
  ['condiment', '酱料和其它材料'],
  ['dessert', '甜品'],
];
const TIPS_BEFORE = ['厨房准备', '如何选择现在吃什么', '食材相克与禁忌'];
const LEARN_TOOLS = ['高压力锅', '空气炸锅', '微波炉'];
const TIPS_TECHS = ['去腥', '学习焯水', '学习炒与煎', '学习凉拌', '学习腌', '学习蒸', '学习煮', '食品安全'];
const ADVANCED = ['辅料技巧', '高级专业术语', '糖色的炒制', '油温判断技巧'];
const STARS = [0, 1, 2, 3, 4, 5, 7, 8];

const collator = new Intl.Collator('zh-Hans-CN', { numeric: true });

function baseName(file) {
  return file.replace(/\.md$/i, '');
}

function sortFixed(list, order) {
  const rank = new Map(order.map((name, i) => [name, i]));
  return [...list].sort((a, b) => {
    const ra = rank.has(a.title) ? rank.get(a.title) : order.length;
    const rb = rank.has(b.title) ? rank.get(b.title) : order.length;
    return ra !== rb ? ra - rb : collator.compare(a.title, b.title);
  });
}

function walkMd(dirRel) {
  const abs = join(CONTENT_DIR, dirRel);
  if (!existsSync(abs)) return [];
  const out = [];
  for (const entry of readdirSync(abs, { withFileTypes: true })) {
    const childRel = dirRel ? `${dirRel}/${entry.name}` : entry.name;
    if (entry.isDirectory()) out.push(...walkMd(childRel));
    else if (/\.md$/i.test(entry.name)) out.push({ title: baseName(entry.name), path: childRel });
  }
  return out;
}

function buildNav() {
  const tipsRoot = walkMd('tips').filter((it) => it.path.split('/').length === 2);
  const learn = walkMd('tips/learn');
  const advanced = walkMd('tips/advanced');
  const dishAll = walkMd('dishes');

  const dishGroups = DISH_CATEGORIES.map(([dir, name]) => ({
    name,
    items: sortFixed(
      dishAll.filter((it) => it.path.startsWith(`dishes/${dir}/`)),
      []
    ),
  }));

  return {
    tabs: [
      {
        id: 'before',
        name: '做菜之前',
        groups: [
          { name: '', items: sortFixed(tipsRoot, TIPS_BEFORE) },
          { name: '厨房工具', items: sortFixed(learn.filter((i) => LEARN_TOOLS.includes(i.title)), LEARN_TOOLS) },
          { name: '烹饪技巧', items: sortFixed(learn.filter((i) => !LEARN_TOOLS.includes(i.title)), TIPS_TECHS) },
        ],
      },
      {
        id: 'recipes',
        name: '菜谱',
        groups: [
          {
            name: '按难度索引',
            items: STARS.filter((n) => existsSync(join(CONTENT_DIR, `starsystem/${n}Star.md`))).map((n) => ({
              title: `${n} 星难度`,
              path: `starsystem/${n}Star.md`,
            })),
          },
          ...dishGroups,
        ],
      },
      { id: 'advanced', name: '进阶知识学习', groups: [{ name: '', items: sortFixed(advanced, ADVANCED) }] },
    ],
  };
}

const NAV = buildNav();
const KNOWN_PATHS = new Set();
for (const tab of NAV.tabs) for (const g of tab.groups) for (const it of g.items) KNOWN_PATHS.add(it.path);

// ---------- 工具 ----------

function resolveContentPath(rawRel) {
  const rel = String(rawRel || '').replace(/^\/+/, '');
  const abs = resolve(CONTENT_DIR, rel);
  if (abs !== CONTENT_DIR && !abs.startsWith(CONTENT_DIR + (process.platform === 'win32' ? '\\' : '/'))) return null;
  return existsSync(abs) && statSync(abs).isFile() ? abs : null;
}

function safeJoinStatic(urlPath) {
  const abs = resolve(PUBLIC_DIR, `.${urlPath}`);
  if (!abs.startsWith(PUBLIC_DIR)) return null;
  return existsSync(abs) && statSync(abs).isFile() ? abs : null;
}

function send(res, status, body, headers = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(body);
  res.writeHead(status, { 'cache-control': 'no-store', ...headers });
  res.end(buf);
}

function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), { 'content-type': 'application/json; charset=utf-8' });
}

function encodeUpstreamPath(rel) {
  return rel.split('/').map(encodeURIComponent).join('/');
}

function imageCandidates(rel) {
  const encoded = encodeUpstreamPath(rel);
  const direct = [
    ['jsdelivr-gcore', `https://gcore.jsdelivr.net/gh/${REPO}@${REF}/${encoded}`],
    ['jsdelivr-cdn', `https://cdn.jsdelivr.net/gh/${REPO}@${REF}/${encoded}`],
    ['github-raw', `https://raw.githubusercontent.com/${REPO}/${REF}/${encoded}`],
  ];
  if (!PROXY_URL || !PROXY_KEY) return direct;
  return [
    ...direct,
    ...direct.map(([label, url]) => [
      `${label}-proxy`,
      `${PROXY_URL}/${encodeURIComponent(url)}?x-cors-proxy-key=${encodeURIComponent(PROXY_KEY)}`,
    ]),
  ];
}

async function fetchImage(rel) {
  const tried = [];
  for (const [label, url] of imageCandidates(rel)) {
    try {
      const up = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(12000) });
      const type = up.headers.get('content-type') || '';
      // 状态码不能作数：代理失败常回 200 + text/html，必须确认真的是图片
      if (!up.ok || !type.startsWith('image/')) {
        tried.push(`${label}:${up.status}/${type.split(';')[0] || '-'}`);
        continue;
      }
      return { label, body: Buffer.from(await up.arrayBuffer()), type };
    } catch (err) {
      tried.push(`${label}:${err.name === 'TimeoutError' ? 'timeout' : err.cause?.code || err.message}`);
    }
  }
  return { label: null, tried };
}

// ---------- 路由 ----------

const server = createServer(async (req, res) => {
  let url;
  try {
    url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  } catch {
    return sendJson(res, 400, { error: 'bad url' });
  }
  const path = url.pathname;
  let pathname;
  try {
    pathname = decodeURIComponent(path);
  } catch {
    return send(res, 400, 'bad path');
  }

  try {
    if (pathname === '/api/nav') return sendJson(res, 200, NAV);

    if (pathname.startsWith('/api/img/')) {
      const rel = pathname.slice('/api/img/'.length);
      const ext = extname(rel).toLowerCase();
      if (rel.includes('..') || !rel.startsWith('dishes/') || !IMG_EXTS.has(ext)) return send(res, 400, 'bad image path');
      const got = await fetchImage(rel);
      if (!got.label) return send(res, 404, `上游图片不可达：${got.tried.join(' | ')}`);
      return send(res, 200, got.body, {
        'content-type': got.type,
        'cache-control': 'public, max-age=86400',
        'x-img-source': got.label,
      });
    }

    if (pathname.startsWith('/content/')) {
      const abs = resolveContentPath(pathname.slice('/content/'.length));
      if (!abs) return send(res, 404, '内容文件不存在');
      return send(res, 200, readFileSync(abs), { 'content-type': MIME[extname(abs).toLowerCase()] || 'text/plain; charset=utf-8' });
    }

    if (pathname === '/' || pathname === '/index.html') {
      return send(res, 200, readFileSync(join(PUBLIC_DIR, 'index.html')), { 'content-type': MIME['.html'] });
    }

    const staticFile = safeJoinStatic(pathname);
    if (staticFile) {
      return send(res, 200, readFileSync(staticFile), {
        'content-type': MIME[extname(staticFile).toLowerCase()] || 'application/octet-stream',
      });
    }

    return send(res, 404, 'Not found');
  } catch (err) {
    return send(res, 500, `服务器错误：${err.message}`);
  }
});

server.listen(PORT, () => {
  const total = KNOWN_PATHS.size;
  console.log(`[howtocook] listening on http://localhost:${PORT} · ${total} 篇内容 · 出口：${PROXY_URL ? '直连优先 + 代理兜底' : '仅直连'}`);
});
