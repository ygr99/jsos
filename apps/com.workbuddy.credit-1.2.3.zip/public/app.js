/* WorkBuddy 积分 — 前端 */
'use strict';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const f2 = (n) => (Math.round((Number(n) || 0) * 100) / 100).toFixed(2);
const pad = (n) => String(n).padStart(2, '0');
const fmtDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

let META = { maxSpanDays: 32, credentials: {} };
/** 当前区间：默认今天 */
let CUR = { preset: 'today', start: fmtDate(new Date()), end: fmtDate(new Date()) };

function showErr(msg) {
  const el = $('err');
  if (!msg) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  el.textContent = msg;
}

/* ---------------- 凭据设置 ---------------- */
function openCredDialog() {
  const val = prompt(
    '为 WorkBuddy 配置 cookie\n\n' +
    '获取方式：浏览器登录 workbuddy.cn 后打开\n' +
    '  https://www.workbuddy.cn/profile/plans-usage\n' +
    '按 F12 → Network → 刷新 → 点开任一 billing/meter/... 请求\n' +
    '→ Headers → Request Headers → 复制 cookie: 整行的值\n\n' +
    '它只保存在本机应用数据目录（DATA_DIR），仅发往 workbuddy.cn。\n' +
    '留空并确定 = 清除已保存的凭据。',
    '');
  if (val === null) return;
  fetch('/api/credentials', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ cookie: val.trim() }),
  }).then((r) => r.json()).then((j) => {
    if (j.error) return showErr(j.error);
    META.credentials = j.credentials;
    load();
  }).catch((e) => showErr('保存失败：' + e.message));
}

/* ---------------- 区间切换 ---------------- */
function setPreset(preset, start, end) {
  CUR.preset = preset;
  if (start) CUR.start = start;
  if (end) CUR.end = end;
  for (const b of $('ranges').querySelectorAll('button')) {
    b.setAttribute('aria-pressed', String(b.dataset.preset === preset));
  }
  $('custom').hidden = preset !== 'custom';
  if (preset === 'custom') {
    // 自选默认给最近 7 天，省得用户对着空输入框
    if (!$('dStart').value) {
      const a = new Date();
      a.setDate(a.getDate() - 6);
      $('dStart').value = fmtDate(a);
      $('dEnd').value = fmtDate(new Date());
    }
  }
  load();
}

/* ---------------- 渲染 ---------------- */
function renderStats(d) {
  const remain = (d.summary?.packages || []).reduce((a, p) => a + (p.remain || 0), 0);
  const cards = [
    { k: '积分消耗', v: f2(d.total) },
    { k: '请求条数', v: d.count },
    { k: '日均消耗', v: d.byDay.length ? f2(d.total / d.byDay.length) : '0.00' },
  ];
  if (remain > 0) cards.push({ k: '积分余额', v: f2(remain) });

  $('stats').innerHTML = cards.map((c) =>
    `<div class="stat"><div class="k">${esc(c.k)}</div><div class="v">${esc(c.v)}</div></div>`
  ).join('');

  $('rangeLabel').textContent = `· ${d.label}${d.note || ''}`;

  const bits = [];
  if (d.summary?.planName) bits.push(`订阅套餐：${d.summary.planName}`);
  for (const p of d.summary?.packages || []) {
    bits.push(`积分余额 ${f2(p.remain)} / ${f2(p.total)} ${p.unit}`);
  }
  $('planInfo').textContent = bits.join('   ·   ');
}

function renderDayChart(d) {
  if (!d.byDay.length) {
    $('dayChart').innerHTML = '<div class="empty">该区间没有消耗记录</div>';
    return;
  }
  const max = Math.max(...d.byDay.map((x) => x.credit), 0.01);
  $('dayChart').innerHTML = d.byDay.map((x) => `
    <div class="row" style="margin-bottom:6px">
      <div style="width:88px;font-size:12px;color:var(--fg2)">${esc(x.date.slice(5))}</div>
      <div class="barwrap" style="flex:1"><div class="bar" style="width:${(x.credit / max * 100).toFixed(1)}%"></div></div>
      <div class="num" style="width:64px;text-align:right;font-size:12px;font-variant-numeric:tabular-nums">${f2(x.credit)}</div>
    </div>`).join('');
}

function renderModelTable(rows, total) {
  if (!rows.length) { $('modelTable').innerHTML = '<div class="empty">无数据</div>'; return; }
  const max = rows[0].credit || 1;
  $('modelTable').innerHTML = `<table><thead><tr>
      <th>模型</th><th style="width:34%">占比</th><th class="num">消耗</th><th class="num">占比</th>
    </tr></thead><tbody>`
    + rows.map((r) => {
      const pct = total > 0 ? (r.credit / total * 100) : 0;
      return `<tr>
        <td>${esc(r.key)}</td>
        <td><div class="barwrap"><div class="bar" style="width:${(r.credit / max * 100).toFixed(1)}%"></div></div></td>
        <td class="num">${f2(r.credit)}</td>
        <td class="num">${pct.toFixed(1)}%</td>
      </tr>`;
    }).join('') + '</tbody></table>';
}

function renderDetail(rows) {
  if (!rows.length) { $('detailTable').innerHTML = '<div class="empty">无明细</div>'; return; }
  $('detailTable').innerHTML = `<table><thead><tr>
      <th style="width:132px">时间</th><th style="width:150px">模型</th>
      <th class="num" style="width:74px">消耗</th><th>输入内容</th></tr></thead><tbody>`
    + rows.map((r) => `<tr>
        <td style="font-size:12px;color:var(--fg2)">${esc(r.time)}</td>
        <td style="font-size:12px">${esc(r.model)}</td>
        <td class="num">${f2(r.credit)}</td>
        <td id="prompt" title="${esc(r.prompt)}">${esc(r.prompt.slice(0, 90))}${r.prompt.length > 90 ? '…' : ''}</td>
      </tr>`).join('') + '</tbody></table>';
}

/** 出错时把各区块置为占位，避免留下空白卡片让人以为页面坏了 */
function renderEmptyState() {
  $('stats').innerHTML = '';
  $('planInfo').textContent = '';
  $('rangeLabel').textContent = '';
  $('dayChart').innerHTML = '<div class="empty">暂无数据</div>';
  $('modelTable').innerHTML = '<div class="empty">暂无数据</div>';
  $('detailTable').innerHTML = '<div class="empty">暂无数据</div>';
}

function load() {
  showErr('');
  $('reload').disabled = true;
  $('reload').textContent = '加载中…';

  const qs = new URLSearchParams({ preset: CUR.preset });
  if (CUR.preset === 'custom') {
    qs.set('start', $('dStart').value);
    qs.set('end', $('dEnd').value);
  }

  fetch('/api/usage?' + qs)
    .then((r) => r.json().then((j) => ({ status: r.status, json: j })))
    .then(({ json }) => {
      if (json.error) {
        const extra = json.via ? `（出站路径：${json.via}）` : '';
        showErr(json.error + extra + (json.needCredential ? ' — 请点右上角「凭据设置」。' : ''));
        renderEmptyState();
        return;
      }
      renderStats(json);
      renderDayChart(json);
      renderModelTable(json.byModel || [], json.total);
      renderDetail(json.topDetail || []);
    })
    .catch((e) => {
      showErr('请求失败：' + e.message);
      renderEmptyState();
    })
    .finally(() => {
      $('reload').disabled = false;
      $('reload').textContent = '刷新';
    });
}

async function init() {
  try {
    META = await (await fetch('/api/meta')).json();
  } catch (e) {
    return showErr('初始化失败：' + e.message);
  }
  $('reload').onclick = load;
  $('cfgBtn').onclick = openCredDialog;
  $('applyCustom').onclick = () => setPreset('custom', $('dStart').value, $('dEnd').value);
  for (const b of $('ranges').querySelectorAll('button')) {
    b.onclick = () => setPreset(b.dataset.preset);
  }
  load();
}

init();
