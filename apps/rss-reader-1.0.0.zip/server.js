// RSS 阅读器 —— 零依赖静态 + API 服务（installCommand 为空，不装任何 npm 包）
// 接口：
//   GET  /api/health          就绪探测（测试轮询用）
//   GET  /api/sources         订阅列表（文件不存在时播种默认源）
//   POST /api/sources         全量保存 { feeds: {name:url}, pinned: [name] }（原子写）
//   GET  /api/feed?url=       抓取 RSS/Atom 原文（容器内经平台代理；返回 JSON 包装 + via 标签）
//   GET  /api/img?u=          正文图片同源代理（COEP require-corp 下外链图片必经此）
import http from 'node:http';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { outbound, UA, viaLabel } from './lib/http.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const SOURCES_FILE = path.join(DATA_DIR, 'sources.json');
const PORT = process.env.PORT || 3000;

const DEFAULT_SOURCES = {
  feeds: {
    科技爱好者: 'https://www.ruanyifeng.com/blog/atom.xml',
    BlogFinder: 'https://bf.zzxworld.com/feed.xml',
  },
  pinned: [],
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const MAX_BODY = 1 << 20; // 1MB：订阅列表 JSON 足够
const MAX_FEED = 8 << 20; // 8MB：feed 上限
const MAX_IMG = 10 << 20; // 10MB：图片上限

const json = (res, code, obj) => {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(obj));
};
const fail = (res, code, message) => json(res, code, { code, data: null, message });

function readBody(req, limit = MAX_BODY) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/** SSRF 基础防护：仅 http/https + 拦 localhost / 私网 / 链路本地 / 云 metadata */
export function assertSafeUrl(raw) {
  let u;
  try {
    u = new URL(raw);
  } catch {
    throw new Error('URL 格式无效');
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('仅允许 http/https');
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '');
  if (!h) throw new Error('缺少主机名');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) {
    throw new Error('不允许访问内网主机');
  }
  if (net.isIP(h)) {
    if (isPrivateIp(h)) throw new Error('不允许访问私网地址');
  } else {
    // IPv6 字面量形如 [::1] 时 hostname 已去方括号；形如 ::ffff:1.2.3.4 的映射地址也查一层
    if (h.startsWith('::ffff:')) {
      const v4 = h.slice(7);
      if (net.isIPv4(v4) && isPrivateIp(v4)) throw new Error('不允许访问私网地址');
    }
  }
  return u;
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true; // 链路本地 / 云 metadata
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT
    if (a === 198 && (b === 18 || b === 19)) return true; // 基准测试段
    return false;
  }
  const s = ip.toLowerCase();
  if (s === '::1' || s === '::') return true;
  if (/^f[cd][0-9a-f]{2}:/.test(s)) return true; // fc00::/7 唯一本地
  if (/^fe[89ab][0-9a-f]:/.test(s)) return true; // fe80::/10 链路本地
  return false;
}

function atomicWrite(file, data) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, data);
  fs.renameSync(tmp, file);
}

function loadSources() {
  if (!fs.existsSync(SOURCES_FILE)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    atomicWrite(SOURCES_FILE, JSON.stringify(DEFAULT_SOURCES, null, 2) + '\n');
    return DEFAULT_SOURCES;
  }
  try {
    const doc = JSON.parse(fs.readFileSync(SOURCES_FILE, 'utf8'));
    if (!doc || typeof doc !== 'object' || typeof doc.feeds !== 'object' || !doc.feeds) throw new Error('bad doc');
    if (!Array.isArray(doc.pinned)) doc.pinned = [];
    return doc;
  } catch {
    // 损坏则重播种默认源（数据已丢，回默认比白屏好）
    atomicWrite(SOURCES_FILE, JSON.stringify(DEFAULT_SOURCES, null, 2) + '\n');
    return DEFAULT_SOURCES;
  }
}

function saveSources(doc) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  atomicWrite(SOURCES_FILE, JSON.stringify(doc, null, 2) + '\n');
}

function validateSourcesDoc(doc) {
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) return '结构必须是对象';
  const feeds = doc.feeds;
  if (!feeds || typeof feeds !== 'object' || Array.isArray(feeds)) return 'feeds 必须是对象';
  const names = Object.keys(feeds);
  if (names.length > 200) return '订阅源数量过多';
  for (const name of names) {
    if (typeof name !== 'string' || !name.trim() || name.length > 100) return '源名称非法';
    const url = feeds[name];
    if (typeof url !== 'string') return `${name} 的 URL 非法`;
    try {
      const u = new URL(url);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error();
    } catch {
      return `${name} 的 URL 必须是 http/https`;
    }
  }
  const pinned = doc.pinned;
  if (!Array.isArray(pinned)) return 'pinned 必须是数组';
  if (pinned.some((p) => typeof p !== 'string' || !(p in feeds))) return 'pinned 含未知源';
  return null;
}

async function handleFeed(res, raw) {
  let u;
  try {
    u = assertSafeUrl(raw);
  } catch (e) {
    return fail(res, 400, e.message);
  }
  let r;
  try {
    r = await outbound(u.href, {
      headers: { 'user-agent': UA, accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*' },
      timeout: 20000,
    });
  } catch (e) {
    return fail(res, 502, e?.name === 'TimeoutError' ? '抓取超时（20s）' : `抓取失败：${e?.message || '网络错误'}`);
  }
  if (!r.ok) return fail(res, 502, `上游返回 ${r.status}`);
  const text = await r.text();
  if (text.length > MAX_FEED) return fail(res, 413, 'feed 内容过大');
  if (!/<rss[\s>]|<feed[\s>]/i.test(text.slice(0, 4000))) {
    return fail(res, 422, '该地址不是有效的 RSS/Atom 源');
  }
  return json(res, 200, { code: 200, data: { xml: text, via: viaLabel(), status: r.status, bytes: Buffer.byteLength(text) }, message: 'success' });
}

async function handleImg(res, raw) {
  let u;
  try {
    u = assertSafeUrl(raw);
  } catch (e) {
    return fail(res, 400, e.message);
  }
  let r;
  try {
    r = await outbound(u.href, { headers: { 'user-agent': UA, accept: 'image/*,*/*;q=0.8' }, timeout: 20000 });
  } catch (e) {
    return fail(res, 502, e?.name === 'TimeoutError' ? '图片抓取超时' : '图片抓取失败');
  }
  const ct = (r.headers.get('content-type') || '').toLowerCase();
  if (!r.ok || !ct.startsWith('image/')) {
    return fail(res, 502, `非图片响应（${r.status} ${ct || '无类型'}）`);
  }
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length > MAX_IMG) return fail(res, 413, '图片过大');
  res.writeHead(200, { 'content-type': ct, 'cache-control': 'public, max-age=3600', 'content-length': buf.length });
  res.end(buf);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;

  try {
    if (p === '/api/health') return json(res, 200, { ok: true, via: viaLabel() });

    if (p === '/api/sources') {
      if (req.method === 'GET') return json(res, 200, { code: 200, data: loadSources(), message: 'success' });
      if (req.method === 'POST') {
        let doc;
        try {
          doc = JSON.parse(await readBody(req));
        } catch {
          return fail(res, 400, '请求体必须是 JSON');
        }
        const err = validateSourcesDoc(doc);
        if (err) return fail(res, 400, err);
        saveSources(doc);
        return json(res, 200, { code: 200, data: { ok: true }, message: 'success' });
      }
      return fail(res, 405, 'method not allowed');
    }

    if (p === '/api/feed' && req.method === 'GET') return await handleFeed(res, url.searchParams.get('url'));
    if (p === '/api/img' && req.method === 'GET') return await handleImg(res, url.searchParams.get('url'));

    if (p.startsWith('/api/')) return fail(res, 404, 'not found');

    // 静态文件（含 SPA 回落 + 路径穿越防护）
    let rel = decodeURIComponent(p).replace(/^\/+/, '');
    let file = path.join(PUBLIC, rel);
    if (!file.startsWith(PUBLIC)) {
      res.writeHead(403);
      return res.end('forbidden');
    }
    if (!rel || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      file = path.join(PUBLIC, 'index.html');
    }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'content-type': MIME[ext] || 'application/octet-stream',
      'cache-control': ext === '.html' ? 'no-store' : 'public, max-age=60',
    });
    res.end(fs.readFileSync(file));
  } catch (e) {
    if (!res.headersSent) fail(res, 500, `服务内部错误：${e?.message || 'unknown'}`);
    else res.end();
  }
});

server.listen(PORT, () => console.log(`rss-reader running on ${PORT}`));
