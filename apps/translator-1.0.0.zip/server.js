import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { translate, getLangs } from './lib/fanyi.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(join(__dirname, 'public')));

const MAX_LEN = 500;

app.get('/api/fanyi', async (req, res) => {
  const text = String(req.query.text ?? '').trim();
  const from = String(req.query.from || 'auto');
  const to = String(req.query.to || 'auto');
  if (!text) return res.status(400).json({ error: '缺少待翻译文本' });
  if (text.length > MAX_LEN) return res.status(400).json({ error: `文本超过 ${MAX_LEN} 字` });
  try {
    const data = await translate(text.slice(0, MAX_LEN + 50), from, to);
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: e?.message || '翻译失败' });
  }
});

app.get('/api/langs', async (req, res) => {
  try {
    res.setHeader('Cache-Control', 'no-store');
    res.json(await getLangs());
  } catch (e) {
    res.status(502).json({ error: e?.message || '获取语言列表失败' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`translator running on ${port}`));
