/* ============================================================
 * 网页屏保 Web Screen — 8 款 Canvas 屏保
 * 每款屏保：create(ctx, w, h) => step(dt)，dt 为秒
 * ============================================================ */
'use strict';

const $ = (s) => document.querySelector(s);

/* ---------- 工具 ---------- */
function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
const line = (ctx, x1, y1, x2, y2) => { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };

/* ---------- 1. 矩阵字符雨 ---------- */
function matrixCreate(ctx, w, h) {
  const glyphs = 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const fs = 18;
  const cols = Math.ceil(w / fs);
  const drops = Array.from({ length: cols }, () => Math.floor(Math.random() * -h / fs));
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
  return (dt) => {
    ctx.fillStyle = 'rgba(0,0,0,0.09)'; ctx.fillRect(0, 0, w, h);
    ctx.font = fs + 'px monospace'; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
    const sp = Math.max(dt, 0.008) * 20;
    for (let i = 0; i < cols; i++) {
      const y = drops[i] * fs;
      if (y > -fs && y < h) {
        ctx.fillStyle = Math.random() < 0.06 ? '#eafff0' : '#3dff70';
        ctx.fillText(glyphs[Math.floor(Math.random() * glyphs.length)], i * fs, y);
      }
      drops[i] += sp * (0.75 + (i * 37 % 50) / 100);
      if (y > h && Math.random() > 0.982) drops[i] = Math.floor(Math.random() * -20);
    }
  };
}

/* ---------- 2. DVD 弹跳 ---------- */
function dvdCreate(ctx, w, h) {
  const lw = Math.min(180, w * 0.22), lh = lw * 0.45;
  let x = Math.random() * (w - lw), y = Math.random() * (h - lh);
  const speed = Math.min(w, h) * 0.18;
  let vx = speed * (Math.random() < 0.5 ? 1 : -1), vy = speed * (Math.random() < 0.5 ? 1 : -1);
  let hue = Math.random() * 360;
  return (dt) => {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    x += vx * dt; y += vy * dt;
    if (x <= 0 || x >= w - lw) { vx = -vx; hue = (hue + 47) % 360; x = Math.max(0, Math.min(w - lw, x)); }
    if (y <= 0 || y >= h - lh) { vy = -vy; hue = (hue + 47) % 360; y = Math.max(0, Math.min(h - lh, y)); }
    ctx.save();
    ctx.shadowColor = `hsl(${hue} 90% 55%)`; ctx.shadowBlur = 30;
    rr(ctx, x, y, lw, lh, 14);
    ctx.fillStyle = `hsl(${hue} 90% 52%)`; ctx.fill();
    ctx.restore();
    ctx.fillStyle = `hsl(${hue} 95% 80%)`;
    ctx.font = `900 ${lh * 0.52}px Arial, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('DVD', x + lw / 2, y + lh / 2 + 2);
    ctx.textAlign = 'left';
  };
}

/* ---------- 3. 星际穿越 ---------- */
function starfieldCreate(ctx, w, h) {
  const N = 420, cx = w / 2, cy = h / 2, f = Math.min(w, h) * 0.45;
  const newStar = () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * 0.9 + 0.1 });
  const stars = Array.from({ length: N }, newStar);
  return (dt) => {
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#dfe8ff';
    for (const s of stars) {
      s.z -= dt * 0.35;
      if (s.z <= 0.02) Object.assign(s, newStar());
      const px = cx + (s.x / s.z) * f, py = cy + (s.y / s.z) * f;
      if (px < 0 || px > w || py < 0 || py > h) { Object.assign(s, newStar()); continue; }
      ctx.globalAlpha = 1 - s.z;
      ctx.beginPath(); ctx.arc(px, py, (1 - s.z) * 2.6 + 0.3, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
  };
}

/* ---------- 4. 极光 ---------- */
function auroraCreate(ctx, w, h) {
  const stars = Array.from({ length: 130 }, () => ({ x: Math.random() * w, y: Math.random() * h * 0.65, r: Math.random() * 1.3 + 0.3, tw: Math.random() * 6 }));
  const bands = [
    { hue: 145, y: 0.40, amp: 60, speed: 0.25, alpha: 0.32 },
    { hue: 175, y: 0.50, amp: 80, speed: 0.18, alpha: 0.28 },
    { hue: 262, y: 0.58, amp: 70, speed: 0.12, alpha: 0.24 },
  ];
  let t = 0;
  return (dt) => {
    t += dt;
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#020308'); bg.addColorStop(0.7, '#050810'); bg.addColorStop(1, '#0a0f1e');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#cdd8ff';
    for (const s of stars) {
      ctx.globalAlpha = 0.25 + 0.6 * Math.abs(Math.sin(t * 0.8 + s.tw));
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'lighter';
    for (const b of bands) {
      ctx.beginPath(); ctx.moveTo(0, h);
      for (let x = 0; x <= w + 8; x += 8) {
        const y = h * b.y
          + Math.sin(x * 0.004 + t * b.speed * 2) * b.amp
          + Math.sin(x * 0.011 - t * b.speed * 3.1) * b.amp * 0.4;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h); ctx.closePath();
      const g = ctx.createLinearGradient(0, h * b.y - b.amp, 0, h);
      g.addColorStop(0, `hsla(${b.hue + Math.sin(t * 0.3) * 20} 90% 60% / ${b.alpha})`);
      g.addColorStop(1, 'hsla(0 0% 0% / 0)');
      ctx.fillStyle = g; ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  };
}

/* ---------- 5. 时钟 ---------- */
function clockCreate(ctx, w, h) {
  let last = -1;
  const week = '日一二三四五六';
  return (dt) => {
    const d = new Date(), s = d.getSeconds();
    if (s === last) return;
    last = s;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const fs = Math.min(w / 3.4, h / 2.4);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.save();
    ctx.shadowColor = 'rgba(120,180,255,0.75)'; ctx.shadowBlur = fs * 0.1;
    ctx.fillStyle = '#eaf2ff';
    ctx.font = `700 ${fs}px 'Segoe UI', system-ui, sans-serif`;
    ctx.fillText(`${hh}:${mm}`, w / 2, h / 2 - fs * 0.1);
    ctx.restore();
    ctx.fillStyle = 'rgba(150,195,255,0.85)';
    ctx.font = `500 ${fs * 0.18}px 'Segoe UI', system-ui, sans-serif`;
    ctx.fillText(`${d.getFullYear()} 年 ${d.getMonth() + 1} 月 ${d.getDate()} 日 · 星期${week[d.getDay()]}`, w / 2, h / 2 + fs * 0.52);
  };
}

/* ---------- 6. 3D 管道 ---------- */
function pipesCreate(ctx, w, h) {
  const cell = Math.max(36, Math.min(w, h) / 12);
  const cols = Math.ceil(w / cell), rows = Math.ceil(h / cell);
  const lw = cell * 0.42;
  const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
  let grid, walker, hue, filled;
  const freeCell = () => {
    for (let i = 0; i < 40; i++) {
      const c = Math.floor(Math.random() * cols), r = Math.floor(Math.random() * rows);
      if (!grid[c][r]) return { c, r };
    }
    return { c: 0, r: 0 };
  };
  const newWalker = () => {
    hue = (hue + 83) % 360;
    const p = freeCell();
    walker = { c: p.c, r: p.r, dir: Math.floor(Math.random() * 4), life: 18 + Math.random() * 40 };
  };
  const reset = () => {
    grid = Array.from({ length: cols }, () => new Uint8Array(rows));
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    filled = 0; hue = Math.random() * 360; newWalker();
    grid[walker.c][walker.r] = 1;
  };
  reset();
  const seg = (c1, r1, c2, r2) => {
    const x1 = c1 * cell + cell / 2, y1 = r1 * cell + cell / 2;
    const x2 = c2 * cell + cell / 2, y2 = r2 * cell + cell / 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = `hsl(${hue} 60% 20%)`; ctx.lineWidth = lw * 1.5; line(ctx, x1, y1, x2, y2);
    ctx.strokeStyle = `hsl(${hue} 85% 55%)`; ctx.lineWidth = lw; line(ctx, x1, y1, x2, y2);
    ctx.strokeStyle = `hsla(${hue} 100% 88% / .75)`; ctx.lineWidth = lw * 0.32; line(ctx, x1, y1, x2, y2);
  };
  const move = () => {
    let moved = false;
    for (let tries = 0; tries < 8 && !moved; tries++) {
      if (Math.random() < 0.35) walker.dir = (walker.dir + (Math.random() < 0.5 ? 1 : 3)) % 4;
      const c2 = walker.c + DIRS[walker.dir][0], r2 = walker.r + DIRS[walker.dir][1];
      if (c2 >= 0 && c2 < cols && r2 >= 0 && r2 < rows && !grid[c2][r2]) {
        seg(walker.c, walker.r, c2, r2);
        grid[c2][r2] = 1; filled++;
        walker.c = c2; walker.r = r2; moved = true;
      }
    }
    if (!moved || --walker.life <= 0) newWalker();
    if (filled > cols * rows * 0.55) reset();
  };
  let acc = 0;
  return (dt) => {
    acc += dt * 8;
    while (acc >= 1) { acc -= 1; move(); }
  };
}

/* ---------- 7. 智能贪吃蛇（BFS 自动寻路） ---------- */
function snakeCreate(ctx, w, h) {
  const cols = 28;
  const rows = Math.max(12, Math.round(cols * h / w));
  const cs = Math.min(w / cols, h / rows);
  const ox = (w - cs * cols) / 2, oy = (h - cs * rows) / 2;
  let snake, dir, food, acc, speed;
  const occ = (c, r, skipTail) => snake.slice(0, skipTail ? -1 : snake.length).some(s => s.c === c && s.r === r);
  const placeFood = () => {
    let c, r;
    do { c = Math.floor(Math.random() * cols); r = Math.floor(Math.random() * rows); } while (occ(c, r));
    food = { c, r };
  };
  const reset = () => {
    const mid = Math.floor(rows / 2);
    snake = [{ c: 5, r: mid }, { c: 4, r: mid }, { c: 3, r: mid }];
    dir = { c: 1, r: 0 }; acc = 0; speed = 7;
    placeFood();
    ctx.fillStyle = '#05070c'; ctx.fillRect(0, 0, w, h);
  };
  const nextDir = () => {
    const head = snake[0];
    const key = (c, r) => r * cols + c;
    const blocked = new Set(snake.slice(0, -1).map(s => key(s.c, s.r)));
    const prev = new Map(), seen = new Set([key(head.c, head.r)]), q = [head];
    while (q.length) {
      const cur = q.shift();
      if (cur.c === food.c && cur.r === food.r) {
        let n = cur;
        while (true) {
          const p = prev.get(key(n.c, n.r));
          if (!p || (p.c === head.c && p.r === head.r)) break;
          n = p;
        }
        return { c: n.c - head.c, r: n.r - head.r };
      }
      for (const [dc, dr] of [[1, 0], [0, 1], [-1, 0], [0, -1]]) {
        const c2 = cur.c + dc, r2 = cur.r + dr, k = key(c2, r2);
        if (c2 < 0 || c2 >= cols || r2 < 0 || r2 >= rows || seen.has(k) || blocked.has(k)) continue;
        seen.add(k); prev.set(k, cur); q.push({ c: c2, r: r2 });
      }
    }
    return null;
  };
  const safeMove = () => {
    const head = snake[0];
    for (const d of [dir, { c: 1, r: 0 }, { c: -1, r: 0 }, { c: 0, r: 1 }, { c: 0, r: -1 }]) {
      const c2 = head.c + d.c, r2 = head.r + d.r;
      if (c2 >= 0 && c2 < cols && r2 >= 0 && r2 < rows && !occ(c2, r2, true)) return d;
    }
    return null;
  };
  const draw = () => {
    ctx.fillStyle = '#05070c'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(139,124,255,0.06)';
    for (let c = 0; c <= cols; c += 2) ctx.fillRect(ox + c * cs, oy, 1, cs * rows);
    for (let r = 0; r <= rows; r += 2) ctx.fillRect(ox, oy + r * cs, cs * cols, 1);
    ctx.save();
    ctx.shadowColor = 'rgba(255,90,90,.8)'; ctx.shadowBlur = 14;
    ctx.fillStyle = '#ff5a5a';
    ctx.beginPath();
    ctx.arc(ox + (food.c + 0.5) * cs, oy + (food.r + 0.5) * cs, cs * 0.34, 0, 7);
    ctx.fill();
    ctx.restore();
    snake.forEach((s, i) => {
      const t = i / snake.length;
      ctx.fillStyle = `hsl(${145 - t * 40} ${80 - t * 25}% ${58 - t * 22}%)`;
      rr(ctx, ox + s.c * cs + cs * 0.08, oy + s.r * cs + cs * 0.08, cs * 0.84, cs * 0.84, cs * 0.3);
      ctx.fill();
    });
  };
  const step = () => {
    const nd = nextDir() || safeMove();
    if (!nd) { reset(); return; }
    dir = nd;
    const head = { c: snake[0].c + dir.c, r: snake[0].r + dir.r };
    if (head.c < 0 || head.c >= cols || head.r < 0 || head.r >= rows || occ(head.c, head.r, true)) { reset(); return; }
    snake.unshift(head);
    if (head.c === food.c && head.r === food.r) {
      speed = Math.min(14, speed + 0.25);
      placeFood();
    } else snake.pop();
  };
  reset();
  return (dt) => {
    acc += dt * speed;
    while (acc >= 1) { acc -= 1; step(); }
    draw();
  };
}

/* ---------- 8. 文字滚动 ---------- */
function textCreate(ctx, w, h) {
  const text = localStorage.getItem('ws-text') || 'HELLO JSOS · 屏保时间到 · 起来活动一下吧 ✨';
  let x = w, t = 0;
  return (dt) => {
    t += dt;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    const fs = Math.min(h * 0.26, 150);
    ctx.font = `800 ${fs}px 'Segoe UI', 'Microsoft YaHei', system-ui, sans-serif`;
    const tw = ctx.measureText(text).width;
    x -= dt * (w * 0.1 + 80);
    if (x < -tw) x = w;
    const hue = (t * 30) % 360;
    const g = ctx.createLinearGradient(0, h / 2 - fs / 2, 0, h / 2 + fs / 2);
    g.addColorStop(0, `hsl(${hue} 95% 72%)`);
    g.addColorStop(1, `hsl(${(hue + 60) % 360} 95% 55%)`);
    ctx.save();
    ctx.shadowColor = `hsla(${hue} 95% 60% / .8)`; ctx.shadowBlur = 26;
    ctx.fillStyle = g; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    ctx.fillText(text, x, h / 2);
    ctx.restore();
  };
}

/* ---------- 屏保注册表 ---------- */
const SAVERS = [
  { id: 'matrix',    name: '矩阵字符雨', en: 'Matrix Rain', desc: '黑客帝国绿色数字雨，头字发光', icon: '💚', tile: 'linear-gradient(135deg,#0d3320,#071a10)', create: matrixCreate },
  { id: 'dvd',       name: 'DVD 弹跳',   en: 'DVD Bounce',  desc: '经典待机动画，撞角变色',       icon: '📀', tile: 'linear-gradient(135deg,#3a2a55,#1a1430)', create: dvdCreate },
  { id: 'starfield', name: '星际穿越',   en: 'Starfield',   desc: '超空间穿梭，繁星扑面而来',     icon: '🌌', tile: 'linear-gradient(135deg,#1a2a55,#0d1430)', create: starfieldCreate },
  { id: 'aurora',    name: '极光',       en: 'Aurora',      desc: '夜空中流动的绿紫色光幕',       icon: '🌈', tile: 'linear-gradient(135deg,#1d4038,#0c1e22)', create: auroraCreate },
  { id: 'clock',     name: '时钟',       en: 'Clock',       desc: '极简大字实时时钟，适合展示',   icon: '🕐', tile: 'linear-gradient(135deg,#243a5e,#101a30)', create: clockCreate },
  { id: 'pipes',     name: '3D 管道',    en: 'Pipes',       desc: '复古屏保管道路径无限生长',     icon: '🔧', tile: 'linear-gradient(135deg,#4d3a24,#241a10)', create: pipesCreate },
  { id: 'snake',     name: '智能贪吃蛇', en: 'Snake AI',    desc: 'BFS 寻路，小蛇自己觅食',       icon: '🐍', tile: 'linear-gradient(135deg,#1d4d2a,#0c2412)', create: snakeCreate },
  { id: 'text',      name: '文字滚动',   en: 'Text Scroll', desc: '彩虹流光跑马灯，内容可自定义', icon: '💬', tile: 'linear-gradient(135deg,#4d2440,#24101e)', create: textCreate },
];

/* ---------- 启动器渲染 ---------- */
const grid = $('#grid');
for (const s of SAVERS) {
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <div class="tile" style="--tile-bg:${s.tile}">${s.icon}</div>
    <div class="go">▶</div>
    <div class="name">${s.name}</div>
    <div class="en">${s.en}</div>
    <div class="desc">${s.desc}</div>`;
  card.addEventListener('click', () => play(s));
  grid.appendChild(card);
}

/* ---------- 播放器 ---------- */
const overlay = $('#overlay'), cv = $('#cv'), hint = $('#hint'), title = $('#title'), toastEl = $('#toast');
const ctx = cv.getContext('2d');
let step = null, raf = 0, lastT = 0, playing = false, wakeLock = null, hideTimer = 0;

async function requestWakeLock() {
  try {
    wakeLock = await navigator.wakeLock?.request('screen');
    wakeLock?.addEventListener('release', () => { wakeLock = null; });
  } catch { /* 不支持或被拒绝则静默 */ }
}
function releaseWakeLock() {
  try { wakeLock?.release(); } catch { /* 忽略 */ }
  wakeLock = null;
}

function sizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  cv.width = Math.floor(innerWidth * dpr);
  cv.height = Math.floor(innerHeight * dpr);
  cv.style.width = innerWidth + 'px';
  cv.style.height = innerHeight + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { w: innerWidth, h: innerHeight };
}

function loop(ts) {
  raf = requestAnimationFrame(loop);
  const dt = Math.min((ts - lastT) / 1000, 0.05);
  lastT = ts;
  step?.(dt);
}

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 1800);
}

async function play(saver) {
  if (saver.id === 'text') {
    const t = prompt('滚动文字（取消则使用已有/默认内容）', localStorage.getItem('ws-text') || '');
    if (t && t.trim()) localStorage.setItem('ws-text', t.trim());
  }
  const { w, h } = sizeCanvas();
  overlay.classList.add('show');
  title.textContent = `${saver.icon} ${saver.name} · ${saver.en}`;
  hint.classList.remove('fade'); title.classList.remove('fade');
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { hint.classList.add('fade'); title.classList.add('fade'); }, 3000);
  playing = true;
  step = saver.create(ctx, w, h);
  lastT = performance.now();
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(loop);
  requestWakeLock();
}

function stop() {
  if (!playing) return;
  playing = false;
  cancelAnimationFrame(raf);
  step = null;
  overlay.classList.remove('show');
  releaseWakeLock();
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
}

function toggleFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(() => {});
  } else {
    const p = document.documentElement.requestFullscreen?.();
    p?.then(() => {}).catch(() => toast('当前环境不支持全屏（iframe 受限）'));
  }
}

overlay.addEventListener('click', (e) => {
  if (e.target === $('#fsBtn')) return;
  stop();
});
$('#fsBtn').addEventListener('click', (e) => { e.stopPropagation(); toggleFullscreen(); });
overlay.addEventListener('dblclick', (e) => {
  if (e.target === $('#fsBtn')) return;
  e.preventDefault();
  toggleFullscreen();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') stop();
  else if (playing && e.key.toLowerCase() === 'f') toggleFullscreen();
});
window.addEventListener('resize', () => {
  if (!playing) return;
  const { w, h } = sizeCanvas();
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && playing) requestWakeLock();
});
