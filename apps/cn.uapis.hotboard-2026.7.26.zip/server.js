import express from 'express'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { existsSync, readFileSync, writeFileSync } from 'fs'

const __dirname = dirname(fileURLToPath(import.meta.url))
const app = express()
const PORT = process.env.PORT || 3000

app.use(express.json())
app.use(express.static(join(__dirname, 'dist')))

function getDataDir() {
  return process.env.DATA_DIR || join(__dirname, 'data')
}

function getConfigPath() {
  return join(getDataDir(), 'widget-config.json')
}

function readConfig() {
  try {
    const p = getConfigPath()
    if (existsSync(p)) {
      const raw = JSON.parse(readFileSync(p, 'utf-8'))
      if (raw.widgetPlatforms) {
        return { widgetPlatforms: raw.widgetPlatforms }
      }
    }
  } catch {}
  return { widgetPlatforms: ['weibo', 'zhihu', 'bilibili'] }
}

function writeConfig(config) {
  try {
    writeFileSync(getConfigPath(), JSON.stringify(config, null, 2))
  } catch (e) {
    console.error('Failed to save config:', e.message)
  }
}

app.get('/api/config', (req, res) => {
  res.json(readConfig())
})

app.post('/api/config', (req, res) => {
  const config = readConfig()
  const { widgetPlatforms } = req.body
  if (widgetPlatforms) config.widgetPlatforms = widgetPlatforms
  writeConfig(config)
  res.json(config)
})

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'dist', 'index.html'))
})

app.listen(PORT, () => {
  console.log(`HotBoard server running on port ${PORT}`)
})
