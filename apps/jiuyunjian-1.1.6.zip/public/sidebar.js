// 侧边栏交互：片段与「当前页高亮」都由服务端注入 HTML（server.js renderSidebar），
// 折叠状态由 <head> 里的内联脚本写进 <html class="sb-collapsed">（早于首次样式计算）。
// 所以这里只负责两件事：① 用户第一次交互后放开过渡；② 点击折叠按钮时切换状态并持久化。
(function () {
  var KEY = "jiuyunjian.sidebar-collapsed";
  var root = document.documentElement;

  // 加载期禁止过渡（sidebar.css 里的 html:not(.sb-anim)）；用户第一次交互就放开。
  // pointerdown / keydown 都早于 click，所以首次点击折叠按钮照样有动画。
  function enableAnim() { root.classList.add("sb-anim"); }
  ["pointerdown", "keydown", "touchstart"].forEach(function (ev) {
    window.addEventListener(ev, enableAnim, { once: true, capture: true });
  });

  // 跨文档 View Transition（sidebar.css @view-transition）：
  // ① pagereveal 记录活动中的过渡 → window.__appVT（smoke/waitForFunction 等它清空再点）；
  // ② 过渡动画期间（~250ms）浏览器把指针命中到根文档、链接点不动 → 用户一碰就 skip，
  //    立刻交还真实页面，死区最多一次点击。
  window.__vtReady = false;
  window.__appVT = null;
  addEventListener("pagereveal", function (e) {
    window.__vtReady = true;
    if (e.viewTransition) {
      window.__appVT = e.viewTransition;
      var clear = function () { window.__appVT = null; };
      e.viewTransition.finished.then(clear, clear);
    }
  });
  ["pointerdown", "keydown", "touchstart"].forEach(function (ev) {
    window.addEventListener(ev, function () {
      if (window.__appVT) { try { window.__appVT.skipTransition(); } catch (e) {} }
    }, { capture: true });
  });

  var btn = document.querySelector("#collapse-btn");
  if (!btn) {
    console.error("侧边栏片段缺失：检查 views/*.html 的 <!--@sidebar--> 占位与服务端注入");
    return;
  }

  function syncAria() {
    var collapsed = root.classList.contains("sb-collapsed");
    btn.setAttribute("aria-label", collapsed ? "展开侧边栏" : "折叠侧边栏");
    btn.title = collapsed ? "展开侧边栏" : "折叠侧边栏";
  }
  syncAria();

  btn.addEventListener("click", function () {
    enableAnim();
    var collapsed = root.classList.toggle("sb-collapsed");
    try { localStorage.setItem(KEY, collapsed ? "1" : "0"); } catch (e) {}
    syncAria();
  });
})();
