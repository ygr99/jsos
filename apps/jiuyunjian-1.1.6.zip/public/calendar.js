document.addEventListener("DOMContentLoaded", function () {
  const loadingSpinner = document.getElementById("loading-spinner");
  loadingSpinner.style.display = "flex";

  let currentMode = "diary";

  window.currentPreviewInfo = {
    blockId: null,
    timer: null,
  };

  Promise.all([
    loadScriptIfNotExists("https://cdn.jsdelivr.net/npm/marked/marked.min.js"),
    loadScriptIfNotExists(
      "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"
    ),
    loadStyleIfNotExists(
      "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/default.min.css"
    ),
    loadStyleIfNotExists(
      "https://cdn.jsdelivr.net/npm/github-markdown-css/github-markdown.min.css"
    ),
  ])
    .then(function () {
      console.log("所有预览所需库已加载");
    })
    .catch(function (error) {
      console.error("加载预览所需库时出错:", error);
    });

  var previewPanel = document.createElement("div");
  previewPanel.className = "article-preview-panel";
  previewPanel.style.display = "none";
  document.body.appendChild(previewPanel);

  // 页面样式在 public/calendar.css 里用 <link> 静态引入（原先在这里 JS 注入 → 首帧无样式会闪）

  fetch("/data")
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      var calendarEl = document.getElementById("calendar");
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        locale: "zh-cn",
        firstDay: 1,
        events: function (fetchInfo, successCallback, failureCallback) {
          successCallback(buildEvents(currentMode, data.blocks));
        },
        eventClick: function (info) {
          info.jsEvent.preventDefault();
          location.href = info.event.url;
        },
        eventMouseEnter: function (mouseEnterInfo) {
          if (currentMode === "task") {
            showTaskPreview(mouseEnterInfo.el, mouseEnterInfo.event);
          } else if (currentMode === "sleep") {
            // 睡眠模式不显示预览
          } else {
            var blockId = mouseEnterInfo.event.extendedProps.blockId;
            if (blockId !== window.currentPreviewInfo.blockId) {
              if (window.currentPreviewInfo.timer) {
                clearTimeout(window.currentPreviewInfo.timer);
                window.currentPreviewInfo.timer = null;
              }
              showPreviewPanel(mouseEnterInfo.el, blockId, data.blocks);
            }
          }
        },
        eventMouseLeave: function () {
          hidePreviewPanel();
        },
        eventContent: function (arg) {
          var html =
            '<div class="fc-event-title" style="padding-left: 3px !important;">' +
            arg.event.title +
            "</div>";
          if (arg.view.type === "listYear") {
            html =
              '<a href="' +
              arg.event.url +
              '">' +
              html +
              "</a>";
          }
          return { html: html };
        },
        eventOrder: "classNames",
        dayHeaderContent: function (arg) {
          return { html: "<div>" + arg.text + "</div>" };
        },
        dayCellContent: function (arg) {
          if (arg.date.getDay() === 1) {
            var isoWeek = getISOWeek(arg.date);
            return {
              html:
                '<div class="fc-daygrid-day-top"><div class="fc-iso-week">第' +
                isoWeek +
                '周</div><div class="fc-daygrid-day-number">' +
                arg.dayNumberText +
                "</div></div>",
            };
          }
          return {
            html:
              '<div class="fc-daygrid-day-number">' +
              arg.dayNumberText +
              "</div>",
          };
        },
      });

      calendar.render();
      initListReversal();
      loadingSpinner.style.display = "none";

      var modeBtns = document.querySelectorAll(".mode-btn");
      for (var mi = 0; mi < modeBtns.length; mi++) {
        modeBtns[mi].addEventListener("click", function () {
          for (var mj = 0; mj < modeBtns.length; mj++) {
            modeBtns[mj].classList.remove("active");
          }
          this.classList.add("active");
          currentMode = this.getAttribute("data-mode");
          if (currentMode === "list") {
            calendar.changeView("listYear");
          } else {
            calendar.changeView("dayGridMonth");
          }
          calendar.refetchEvents();
        });
      }
    })
    .catch(function (error) {
      console.error("Error loading data:", error);
      loadingSpinner.style.display = "none";
    });
});

function buildEvents(mode, blocks) {
  if (mode === "task") {
    return buildTaskEvents(blocks);
  }
  if (mode === "sleep") {
    return buildSleepEvents(blocks);
  }
  if (mode === "list") {
    return buildListEvents(blocks);
  }
  return buildDiaryEvents(blocks);
}

function buildListEvents(blocks) {
  return buildDiaryEvents(blocks);
}

function reverseListRows() {
  var tbody = document.querySelector(".fc-list tbody");
  if (!tbody) return;
  var rows = Array.prototype.slice.call(tbody.children);
  var groups = [];
  var current = null;
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    if (r.classList.contains("fc-list-day")) {
      current = [r];
      groups.push(current);
    } else if (current) {
      current.push(r);
    } else {
      groups.push([r]);
    }
  }
  groups.reverse();
  var frag = document.createDocumentFragment();
  for (var g = 0; g < groups.length; g++) {
    for (var j = 0; j < groups[g].length; j++) {
      frag.appendChild(groups[g][j]);
    }
  }
  tbody.appendChild(frag);
}

function initListReversal() {
  var observer = new MutationObserver(function (mutations) {
    var relevant = mutations.some(function (m) {
      var t = m.target;
      if (t.nodeType !== 1) return false;
      if (t.classList && t.classList.contains("fc-list-table")) return true;
      if (t.tagName === "TBODY" || t.tagName === "TR") {
        return !!(t.closest && t.closest(".fc-list"));
      }
      return false;
    });
    if (!relevant) return;
    var tbody = document.querySelector(".fc-list tbody");
    if (!tbody || !tbody.children.length) return;
    var dayRows = tbody.querySelectorAll("tr.fc-list-day");
    if (!dayRows.length) return;
    var firstDay = dayRows[0].getAttribute("data-date");
    var lastDay = dayRows[dayRows.length - 1].getAttribute("data-date");
    if (firstDay >= lastDay) return;
    observer.disconnect();
    reverseListRows();
    observer.observe(document.body, { childList: true, subtree: true });
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function buildDiaryEvents(blocks) {
  return blocks
    .filter(function (block) {
      return (
        block.content.indexOf("# 📆") === 0 ||
        block.content.indexOf("# 📘") === 0
      );
    })
    .map(function (block) {
      var firstLine = block.content.split("\n")[0];
      var isCalendarEntry = firstLine.indexOf("# 📆") === 0;
      var title = firstLine;
      if (isCalendarEntry) {
        title = title.replace(/^#\s*📆\s*/, "");
      } else {
        title = title.replace(/^#\s*📘\s*/, "");
      }
      return {
        title: title,
        start: block.date,
        url: "/article.html?id=" + block.id,
        backgroundColor: isCalendarEntry ? "#30a5ff" : "#ffb347",
        borderColor: isCalendarEntry ? "#30a5ff" : "#ffb347",
        textColor: "#ffffff",
        display: "block",
        classNames: isCalendarEntry ? ["calendar-entry"] : ["note-entry"],
        extendedProps: {
          blockId: block.id,
          blockContent: block.content,
        },
      };
    });
}

function buildTaskEvents(blocks) {
  var events = [];
  for (var i = 0; i < blocks.length; i++) {
    var block = blocks[i];
    if (block.content.indexOf("# 📆") !== 0) continue;
    var tasks = parseTasksFromContent(block.content);
    for (var j = 0; j < tasks.length; j++) {
      var task = tasks[j];
      events.push({
        title: task.title,
        start: block.date,
        url: "/article.html?id=" + block.id,
        backgroundColor: task.checked ? "#30a5ff" : "#9e9e9e",
        borderColor: task.checked ? "#30a5ff" : "#9e9e9e",
        textColor: "#ffffff",
        display: "block",
        classNames: task.checked
          ? ["task-entry", "task-done-event"]
          : ["task-entry", "task-pending-event"],
        extendedProps: {
          blockId: block.id,
          blockContent: block.content,
          taskTitle: task.title,
          taskDetails: task.details,
          taskChecked: task.checked,
        },
      });
    }
  }
  return events;
}

function parseTasksFromContent(content) {
  var lines = content.split("\n");
  var tasks = [];
  var inTaskSection = false;
  var currentTask = null;

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];

    if (line.indexOf("## ") === 0) {
      if (line.indexOf("🚩事项") !== -1) {
        inTaskSection = true;
      } else {
        if (currentTask) {
          tasks.push(currentTask);
          currentTask = null;
        }
        inTaskSection = false;
      }
      continue;
    }

    if (!inTaskSection) continue;

    var taskMatch = line.match(/^- \[([ x])\] (.+)/);
    if (taskMatch) {
      if (currentTask) {
        tasks.push(currentTask);
      }
      currentTask = {
        checked: taskMatch[1] === "x",
        title: taskMatch[2],
        details: [],
      };
    } else if (currentTask && line.trim() && line.match(/^\s{6}/)) {
      currentTask.details.push(line.trim());
    } else if (currentTask && !line.trim()) {
      continue;
    } else if (currentTask && line.trim()) {
      tasks.push(currentTask);
      currentTask = null;
    }
  }

  if (currentTask) {
    tasks.push(currentTask);
  }

  return tasks;
}

function buildSleepEvents(blocks) {
  var events = [];
  for (var i = 0; i < blocks.length; i++) {
    var block = blocks[i];
    if (block.content.indexOf("# 📆") !== 0) continue;
    var sleeps = parseSleepFromContent(block.content);
    for (var j = 0; j < sleeps.length; j++) {
      var sleep = sleeps[j];
      for (var k = 0; k < sleep.ranges.length; k++) {
        var r = sleep.ranges[k];
        events.push({
          title: r.start + "-" + r.end,
          start: block.date,
          url: "/article.html?id=" + block.id,
          backgroundColor: "#5c6bc0",
          borderColor: "#5c6bc0",
          textColor: "#ffffff",
          display: "block",
          classNames: ["sleep-entry"],
          extendedProps: { blockId: block.id },
        });
      }
      if (sleep.totalDuration) {
        events.push({
          title: sleep.totalDuration,
          start: block.date,
          url: "/article.html?id=" + block.id,
          backgroundColor: "#3f51b5",
          borderColor: "#3f51b5",
          textColor: "#ffffff",
          display: "block",
          classNames: ["sleep-total-entry"],
          extendedProps: { blockId: block.id },
        });
      }
    }
  }
  return events;
}

function parseSleepFromContent(content) {
  var lines = content.split("\n");
  var sleeps = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    if (line.indexOf("💤") !== 0) continue;
    var rest = line.replace(/^💤\s*/, "");
    var arrowIdx = rest.indexOf("->");
    var totalDuration = "";
    if (arrowIdx !== -1) {
      totalDuration = rest.substring(arrowIdx + 2).trim();
      rest = rest.substring(0, arrowIdx).trim();
    }
    var ranges = [];
    var rangeRegex = /(\d{1,2}:\d{2})-(\d{1,2}:\d{2})/g;
    var match;
    while ((match = rangeRegex.exec(rest)) !== null) {
      ranges.push({ start: match[1], end: match[2] });
    }
    if (ranges.length > 0) {
      sleeps.push({ ranges: ranges, totalDuration: totalDuration });
    }
  }
  return sleeps;
}

function showTaskPreview(eventEl, event) {
  var blockId = event.extendedProps.blockId;
  var taskTitle = event.extendedProps.taskTitle;
  var taskDetails = event.extendedProps.taskDetails || [];
  var taskChecked = event.extendedProps.taskChecked;

  if (blockId !== window.currentPreviewInfo.blockId) {
    if (window.currentPreviewInfo.timer) {
      clearTimeout(window.currentPreviewInfo.timer);
      window.currentPreviewInfo.timer = null;
    }
  }

  window.currentPreviewInfo.blockId = blockId;

  if (window.currentPreviewInfo.timer) {
    clearTimeout(window.currentPreviewInfo.timer);
    window.currentPreviewInfo.timer = null;
  }

  var previewPanel = document.querySelector(".article-preview-panel");
  var rect = eventEl.getBoundingClientRect();

  var detailsHtml = "";
  if (taskDetails.length > 0) {
    var detailLines = [];
    for (var i = 0; i < taskDetails.length; i++) {
      detailLines.push(taskDetails[i]);
    }
    var detailText = detailLines.join("\n");
    if (window.marked) {
      try {
        detailsHtml = marked.parse(detailText, { breaks: true });
      } catch (e) {
        detailsHtml = "<p>" + detailText.replace(/\n/g, "<br>") + "</p>";
      }
    } else {
      detailsHtml = "<p>" + detailText.replace(/\n/g, "<br>") + "</p>";
    }
  }

  previewPanel.innerHTML =
    '<div class="preview-header">' +
    '<div class="preview-title">' +
    (taskChecked ? "✅" : "⬜") +
    " " +
    taskTitle +
    "</div>" +
    '<div class="preview-date">' +
    (event.startStr || event.start.toISOString().split("T")[0]) +
    "</div>" +
    "</div>" +
    '<div class="preview-content">' +
    '<div class="markdown-body">' +
    detailsHtml +
    "</div>" +
    "</div>";

  previewPanel.style.display = "block";
  previewPanel.style.position = "absolute";

  var panelHeight = 300;
  var panelWidth = 400;

  var top = rect.bottom + window.scrollY;
  var left = rect.left + window.scrollX;

  if (top + panelHeight > window.innerHeight + window.scrollY) {
    top = rect.top + window.scrollY - panelHeight;
  }

  if (left + panelWidth > window.innerWidth + window.scrollX) {
    left = window.innerWidth + window.scrollX - panelWidth - 10;
  }

  previewPanel.style.top = top + "px";
  previewPanel.style.left = left + "px";
  previewPanel.style.width = panelWidth + "px";
  previewPanel.style.maxHeight = panelHeight + "px";

  previewPanel.onmouseenter = function () {
    if (window.currentPreviewInfo.timer) {
      clearTimeout(window.currentPreviewInfo.timer);
      window.currentPreviewInfo.timer = null;
    }
  };

  previewPanel.onmouseleave = function () {
    hidePreviewPanel();
  };

  previewPanel.onclick = function () {
    location.href = "/article.html?id=" + blockId;
  };
}

function showPreviewPanel(eventEl, blockId, blocks) {
  var article = null;
  for (var i = 0; i < blocks.length; i++) {
    if (blocks[i].id == blockId) {
      article = blocks[i];
      break;
    }
  }
  if (!article) return;

  window.currentPreviewInfo.blockId = blockId;

  if (window.currentPreviewInfo.timer) {
    clearTimeout(window.currentPreviewInfo.timer);
    window.currentPreviewInfo.timer = null;
  }

  var previewPanel = document.querySelector(".article-preview-panel");
  var rect = eventEl.getBoundingClientRect();

  var content = article.content;
  var isNote = content.indexOf("# 📘") === 0;
  var isDiary = content.indexOf("# 📆") === 0;

  var title = "";
  if (isNote) {
    title = content
      .split("\n")[0]
      .replace(/^#\s*📘\s*/, "")
      .trim();
  } else if (isDiary) {
    title = content
      .split("\n")[0]
      .replace(/^#\s*📆\s*/, "")
      .trim();
  } else {
    title = "未知类型";
  }

  var contentWithoutTitle = content.split("\n").slice(1).join("\n");

  var htmlContent = contentWithoutTitle;
  if (window.marked) {
    try {
      htmlContent = marked.parse(contentWithoutTitle, {
        breaks: true,
        highlight: function (code, lang) {
          if (window.hljs) {
            var language = window.hljs.getLanguage(lang) ? lang : "plaintext";
            return window.hljs.highlight(code, { language: language }).value;
          }
          return code;
        },
      });
    } catch (e) {
      console.error("Error parsing markdown:", e);
    }
  }

  previewPanel.innerHTML =
    '<div class="preview-header">' +
    '<div class="preview-title">' +
    (isNote ? "📘" : isDiary ? "📆" : "") +
    " " +
    title +
    "</div>" +
    '<div class="preview-date">' +
    new Date(article.date).toISOString().split("T")[0] +
    "</div>" +
    "</div>" +
    '<div class="preview-content">' +
    '<div class="markdown-body">' +
    htmlContent +
    "</div>" +
    "</div>";

  if (window.hljs) {
    var codeBlocks = previewPanel.querySelectorAll("pre code");
    for (var i = 0; i < codeBlocks.length; i++) {
      window.hljs.highlightBlock(codeBlocks[i]);
    }
  }

  previewPanel.style.display = "block";
  previewPanel.style.position = "absolute";

  var panelHeight = 300;
  var panelWidth = 400;

  var top = rect.bottom + window.scrollY;
  var left = rect.left + window.scrollX;

  if (top + panelHeight > window.innerHeight + window.scrollY) {
    top = rect.top + window.scrollY - panelHeight;
  }

  if (left + panelWidth > window.innerWidth + window.scrollX) {
    left = window.innerWidth + window.scrollX - panelWidth - 10;
  }

  previewPanel.style.top = top + "px";
  previewPanel.style.left = left + "px";
  previewPanel.style.width = panelWidth + "px";
  previewPanel.style.maxHeight = panelHeight + "px";

  previewPanel.onmouseenter = function () {
    if (window.currentPreviewInfo.timer) {
      clearTimeout(window.currentPreviewInfo.timer);
      window.currentPreviewInfo.timer = null;
    }
  };

  previewPanel.onmouseleave = function () {
    hidePreviewPanel();
  };

  previewPanel.onclick = function () {
    location.href = "/article.html?id=" + blockId;
  };
}

function hidePreviewPanel() {
  window.currentPreviewInfo.timer = setTimeout(function () {
    var previewPanel = document.querySelector(".article-preview-panel");
    previewPanel.style.display = "none";
    window.currentPreviewInfo.blockId = null;
  }, 100);
}

function getISOWeek(date) {
  var target = new Date(date.valueOf());
  var dayNr = (date.getDay() + 6) % 7;
  target.setDate(target.getDate() - dayNr + 3);
  var firstThursday = target.valueOf();
  target.setMonth(0, 1);
  if (target.getDay() !== 4) {
    target.setMonth(0, 1 + ((4 - target.getDay() + 7) % 7));
  }
  return 1 + Math.ceil((firstThursday - target) / 604800000);
}

function loadScriptIfNotExists(src) {
  return new Promise(function (resolve, reject) {
    if (document.querySelector('script[src="' + src + '"]')) {
      resolve();
      return;
    }
    var script = document.createElement("script");
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

function loadStyleIfNotExists(href) {
  return new Promise(function (resolve, reject) {
    if (document.querySelector('link[href="' + href + '"]')) {
      resolve();
      return;
    }
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    link.onload = resolve;
    link.onerror = reject;
    document.head.appendChild(link);
  });
}
