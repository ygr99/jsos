// 九韵笺 —— 日记·笔记·博客（由 99-日记 移植为 JSOS 应用）
// 数据全部落服务端 DATA_DIR（jsos AGENTS.md §6 铁律）；已去掉原项目的密码登录与阿里云 OSS。
import express from "express";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const VIEWS = path.join(__dirname, "views");
const PUBLIC = path.join(__dirname, "public");
const DATA_FILE = path.join(DATA_DIR, "data.json");

// 侧栏片段：由服务端注入页面 HTML（见 renderSidebar 注释），不做运行期 fetch
const SIDEBAR_HTML = fs.readFileSync(path.join(VIEWS, "sidebar.html"), "utf8");

const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

function readBlocks() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return Array.isArray(data.blocks) ? data.blocks : [];
  } catch {
    return [];
  }
}

// 原子写：先写 .tmp 再 rename（jsos §6 模式 A）
function writeBlocks(blocks) {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify({ blocks }, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

// 首装播种：data.json 不存在时写入一篇使用指南笔记；用户删掉或已有数据后不复活
if (!fs.existsSync(DATA_FILE)) {
  writeBlocks([{
    id: crypto.randomUUID(),
    date: new Date().toISOString().split("T")[0],
    content: fs.readFileSync(path.join(__dirname, "guide.md"), "utf8"),
  }]);
}

// ===== 数据接口（保持原前端调用路径不变：/data、/data.json） =====
function sendData(req, res) {
  res.json({ blocks: readBlocks() });
}
app.get("/data", sendData);
app.get("/data.json", sendData);

app.post("/data", (req, res) => {
  try {
    const { blocks: newBlocks } = req.body;
    if (!Array.isArray(newBlocks)) return res.status(400).json({ error: "blocks 必须是数组" });

    const processedBlocks = newBlocks.map((block, index) => {
      const processedBlock = { ...block };
      const firstLine = String(block.content || "").split("\n")[0];

      // 日历条目（# 📆 开头）：从标题提取日期
      if (firstLine.startsWith("# 📆")) {
        const dateMatch = firstLine.match(/(\d{4})年(\d{1,2})月(\d{1,2})日/);
        if (dateMatch) {
          const [, year, month, day] = dateMatch;
          processedBlock.date = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
        }
      } else {
        // 文章条目：沿用上方最近的日历日期，都没有则用今天
        const lastDate = findLastCalendarDate(newBlocks, index);
        if (lastDate) processedBlock.date = lastDate;
        else processedBlock.date = new Date().toISOString().split("T")[0];
      }
      return processedBlock;
    });

    writeBlocks(processedBlocks);
    res.sendStatus(200);
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ error: "Failed to save data" });
  }
});

// 从下往上找日期
function findLastCalendarDate(blocks, currentIndex) {
  for (let i = currentIndex; i >= 0; i--) {
    const firstLine = String(blocks[i].content || "").split("\n")[0];
    if (firstLine.startsWith("# 📆")) {
      const dateMatch = firstLine.match(/(\d{4})年(\d{1,2})月(\d{1,2})日/);
      if (dateMatch) {
        const [, year, month, day] = dateMatch;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
      }
    }
  }
  return null;
}

// 从内容块里提取展示日期（日历条目用标题里的完整日期，否则用 block.date）
function displayDateOf(block) {
  const lines = String(block.content || "").split("\n");
  const firstLine = lines[0];
  if (firstLine.startsWith("# 📆")) {
    const m = firstLine.match(/# 📆 (.*?)(?:\n|$)/);
    if (m) return m[1];
  }
  return block.date;
}

// ===== 网站库（#网站库）=====
app.get("/api/website-library", (req, res) => {
  try {
    const result = {};
    for (const block of readBlocks()) {
      const websiteLines = String(block.content || "").split("\n").filter((line) => line.includes("#网站库"));
      if (!websiteLines.length) continue;
      const displayDate = displayDateOf(block);
      result[displayDate] ||= {};
      for (const line of websiteLines) {
        const cleanLine = line.replace(/#网站库/g, "").trim();
        const urlMatch = cleanLine.match(/(.+?)\s+(https?:\/\/\S+)/);
        if (urlMatch) {
          const siteName = urlMatch[1].trim().replace(/^\d+\.\s*/, "");
          result[displayDate][siteName] = urlMatch[2].trim();
        } else {
          result[displayDate][cleanLine.replace(/^\d+\.\s*/, "")] = cleanLine;
        }
      }
    }
    res.json(result);
  } catch (error) {
    console.error("Error processing website library:", error);
    res.status(500).json({ error: "Failed to process website library data" });
  }
});

// ===== 句子（#句子）=====
app.get("/api/sentences", (req, res) => {
  try {
    const result = {};
    for (const block of readBlocks()) {
      const sentenceLines = String(block.content || "").split("\n").filter((line) => line.includes("#句子"));
      if (!sentenceLines.length) continue;
      const displayDate = displayDateOf(block);
      result[displayDate] ||= {};
      for (const line of sentenceLines) {
        const cleanSentence = line.replace(/#句子(-[^#\s]+)?/g, "").trim().replace(/^\d+\.\s*/, "");
        if (!cleanSentence) continue;
        const categoryMatch = line.match(/#句子(-[^#\s]+)?/);
        const category = (categoryMatch && categoryMatch[1]) || "default";
        result[displayDate][category] ||= [];
        result[displayDate][category].push(cleanSentence);
      }
    }
    res.json(result);
  } catch (error) {
    console.error("Error processing sentences:", error);
    res.status(500).json({ error: "Failed to process sentences data" });
  }
});

// ===== 图片上传：base64 → DATA_DIR/uploads，返回同源 /media 路径 =====
const MIME_BY_EXT = {
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
  ".webp": "image/webp", ".svg": "image/svg+xml", ".bmp": "image/bmp", ".ico": "image/x-icon",
};

app.post("/api/upload-image", (req, res) => {
  try {
    const { image, filename } = req.body;
    if (!image) return res.status(400).json({ success: false, message: "没有图片数据" });

    const base64Data = String(image).replace(/^data:image\/\w+;base64,/, "");
    const buffer = Buffer.from(base64Data, "base64");
    if (!buffer.length) return res.status(400).json({ success: false, message: "图片内容为空" });

    const ext = (path.extname(filename || "") || ".png").toLowerCase();
    const safeExt = MIME_BY_EXT[ext] ? ext : ".png";
    const name = `${Date.now()}_${crypto.randomBytes(3).toString("hex")}${safeExt}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, name), buffer);

    res.json({ success: true, url: `/media/${name}`, message: "上传成功" });
  } catch (error) {
    console.error("上传图片失败:", error);
    res.status(500).json({ success: false, message: "上传失败: " + error.message });
  }
});

// 媒体文件：文件由本应用生成、扩展名已白名单校验，express.static 按扩展名给 Content-Type
app.use("/media", express.static(UPLOAD_DIR, { fallthrough: false }));

// ===== 页面与静态资源 =====
app.use(express.static(PUBLIC));

// 导航项归属：带 .html 后缀的归一到侧栏 data-path（否则从 /blog.html 进来侧栏不高亮）
function sidebarActivePath(p) {
  if (p === "/index.html") return "/";
  if (p === "/article.html") return "/blog";
  if (p === "/blog.html") return "/blog";
  if (p === "/calendar.html") return "/calendar";
  if (p === "/sentences.html") return "/sentences";
  return p;
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// 把 views/sidebar.html 塞进 <!--@sidebar--> 占位，并当场标好当前页高亮。
// 为什么不用前端 fetch 片段：那样侧栏要等一次往返才出现 —— 每切换一个页面，左边那一栏都会空一帧再"闪"出来。
// 服务端注入后侧栏跟着 HTML 一起到达，首帧就是完整页面，高亮也不用再跳一次。
function renderSidebar(urlPath) {
  const active = sidebarActivePath(urlPath);
  return SIDEBAR_HTML.replace(
    new RegExp('(<a href="[^"]*" data-path="' + escapeRe(active) + '")'),
    (_match, tag) => tag + ' class="active"'
  );
}

function sendView(res, file, urlPath) {
  try {
    const html = fs.readFileSync(path.join(VIEWS, file), "utf8");
    res.type("html").send(html.replace("<!--@sidebar-->", renderSidebar(urlPath)));
  } catch (error) {
    console.error("读取视图失败:", file, error);
    res.status(404).send("页面不存在");
  }
}

app.get("/", (req, res) => sendView(res, "index.html", "/"));
app.get(["/blog", "/calendar", "/sentences"], (req, res) =>
  sendView(res, req.path.slice(1) + ".html", req.path));
app.get(/^\/[\w.-]+\.html$/, (req, res, next) => {
  const file = path.basename(req.path);
  if (!fs.existsSync(path.join(VIEWS, file))) return next();
  sendView(res, file, req.path);
});

app.use(express.static(VIEWS)); // 兜底：views 下其余静态资源（如 sidebar.html 片段本身）

app.listen(process.env.PORT || 3000, () => {
  console.log(`九韵笺 running on http://localhost:${process.env.PORT || 3000}`);
  console.log(`DATA_DIR = ${DATA_DIR}`);
});
