// 聚合一言 · 一键上架：打包 → 拷 zip/图标到主仓库 → 更新 store.json
// 用法: node publish.mjs
// 增量发版只需：改 package.json 的 version → node publish.mjs
import { readFileSync, writeFileSync, copyFileSync, existsSync, readdirSync, unlinkSync } from 'fs';
import { execFileSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const root = path.dirname(fileURLToPath(import.meta.url));
const REPO = 'C:/Users/99/jsos';
const APPS_DIR = path.join(REPO, 'apps');
const STORE = path.join(REPO, 'store.json');

const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'));
const { id } = pkg.jsos;
const version = pkg.version;
if (!existsSync(APPS_DIR)) throw new Error('找不到主仓库 apps 目录：' + APPS_DIR);

// 1. 打包（JSZip 正向斜杠，见 build.mjs）
execFileSync(process.execPath, [path.join(root, 'build.mjs')], { cwd: root, stdio: 'inherit' });

const zipName = `${id}-${version}.zip`;
const srcZip = path.join(root, zipName);
const dstZip = path.join(APPS_DIR, zipName);
if (!existsSync(srcZip)) throw new Error('打包产物不存在：' + srcZip);

// 2. 清掉同应用的旧版本 zip（仓库里每个应用只保留当前版本），再拷 zip + 图标
const staleRe = new RegExp(`^${id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}-\\d[^/]*\\.zip$`);
for (const name of readdirSync(APPS_DIR)) {
  if (name !== zipName && staleRe.test(name)) {
    unlinkSync(path.join(APPS_DIR, name));
    console.log('清掉旧版本:', name);
  }
}
for (const name of readdirSync(root)) {
  if (name !== zipName && staleRe.test(name)) unlinkSync(path.join(root, name));
}
copyFileSync(srcZip, dstZip);
const dstIcon = path.join(APPS_DIR, `${id}-icon.svg`);
copyFileSync(path.join(root, 'icon.svg'), dstIcon);

// 3. 更新 store.json（存在则原地更新版本，不存在则追加并 appCount+1）
const iconDataUrl = 'data:image/svg+xml;base64,' + readFileSync(path.join(root, 'icon.svg')).toString('base64');
const storeRaw = readFileSync(STORE, 'utf8');
const store = JSON.parse(storeRaw);
const today = new Date().toISOString().slice(0, 10);

const entry = {
  id,
  name: pkg.jsos.name,
  description: pkg.jsos.description,
  version,
  icon: iconDataUrl,
  category: 'entertainment',
  tags: ['一言', '句子', '古诗词', '段子', '趣味'],
  author: { name: 'ygr99' },
  license: 'MIT',
  zipUrl: `/apps/${zipName}`,
  stars: 0,
  updatedAt: today,
};

const at = store.apps.findIndex(a => a.id === id);
if (at >= 0) {
  store.apps[at] = { ...store.apps[at], ...entry };
  console.log(`store.json：更新已有条目 ${id} → ${version}`);
} else {
  store.apps.push(entry);
  store.appCount = store.apps.length;
  console.log(`store.json：新增条目 ${id} ${version}，appCount → ${store.appCount}`);
}
store.updatedAt = today;

// 保持 2 空格缩进 + 末尾换行（与仓库现有格式一致）
writeFileSync(STORE, JSON.stringify(store, null, 2) + (storeRaw.endsWith('\n') ? '' : '\n'));

// 4. 自检：三处同步（源码 icon.svg / apps/<id>-icon.svg / store.json dataURL）
const check = JSON.parse(readFileSync(STORE, 'utf8')).apps.find(a => a.id === id);
console.log('\n自检');
console.log('  zip      :', dstZip, existsSync(dstZip) ? '✓' : '✗');
console.log('  icon     :', dstIcon, existsSync(dstIcon) ? '✓' : '✗');
console.log('  store 版本:', check.version, check.version === version ? '✓' : '✗ 与 package.json 不一致');
console.log('  zipUrl   :', check.zipUrl, check.zipUrl.endsWith(`${id}-${version}.zip`) ? '✓' : '✗ 与版本号不同步');
console.log('  icon 同步:', check.icon === iconDataUrl ? '✓' : '✗');
