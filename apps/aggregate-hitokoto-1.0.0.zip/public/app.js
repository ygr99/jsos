/**
 * 聚合一言 · 前端逻辑
 * 移植自 99-起始页 AggregateHitokoto 组件：左侧类型切换 + 中央句子卡 + 再来一条。
 * 句子统一由服务端 /api/quote 抓取（直连优先、容器内兜底系统代理），前端零外网请求。
 */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  const TYPE_KEY = 'aggregate-hitokoto.type';
  const COLLAPSE_KEY = 'aggregate-hitokoto.sidebar-collapsed';

  const els = {
    shell: $('#shell'),
    nav: $('#nav'),
    typeName: $('#type-name'),
    quoteText: $('#quote-text'),
    updateTime: $('#update-time'),
    refreshBtn: $('#refresh-btn'),
    toast: $('#toast'),
  };

  let currentType = 'hitokoto';
  let isLoading = false;
  let toastTimer = null;

  /* ------------------------------ 取句 ------------------------------ */

  function setButtonLoading(loading) {
    els.refreshBtn.disabled = loading;
    els.refreshBtn.classList.toggle('loading', loading);
    els.refreshBtn.lastChild.textContent = loading ? ' 加载中…' : ' 再来一条';
  }

  function updateTime() {
    const n = new Date();
    const p = (x) => String(x).padStart(2, '0');
    els.updateTime.textContent = `更新时间: ${p(n.getHours())}:${p(n.getMinutes())}:${p(n.getSeconds())}`;
  }

  function showToast(message, duration = 3000) {
    els.toast.textContent = message;
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), duration);
  }

  async function fetchQuote() {
    if (isLoading) return;
    isLoading = true;
    setButtonLoading(true);
    els.quoteText.textContent = '正在加载…';
    els.quoteText.className = 'quote-text loading';
    try {
      const res = await fetch(`/api/quote?type=${encodeURIComponent(currentType)}`);
      const data = await res.json();
      if (!res.ok || !data.ok || !data.text) throw new Error(data.error || `HTTP ${res.status}`);
      els.quoteText.textContent = data.text;
      els.quoteText.className = 'quote-text';
      updateTime();
    } catch (err) {
      console.error('获取一言数据出错:', err);
      els.quoteText.textContent = '获取数据失败，请稍后再试…';
      els.quoteText.className = 'quote-text error';
      showToast('获取数据失败，请稍后再试');
    } finally {
      isLoading = false;
      setButtonLoading(false);
    }
  }

  /* ------------------------------ 类型切换 ------------------------------ */

  function setType(type) {
    const btn = $(`.nav-item[data-type="${type}"]`, els.nav);
    if (!btn) return;
    $$('.nav-item', els.nav).forEach((b) => b.classList.toggle('active', b === btn));
    currentType = type;
    els.typeName.textContent = btn.querySelector('span:last-child').textContent;
    try { localStorage.setItem(TYPE_KEY, type); } catch { /* 忽略 */ }
    fetchQuote();
  }

  els.nav.addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item');
    if (!btn || btn.dataset.type === currentType) return;
    setType(btn.dataset.type);
  });

  els.refreshBtn.addEventListener('click', fetchQuote);

  /* ------------------------------ 侧边栏折叠（§7.6） ------------------------------ */

  function setCollapsed(collapsed) {
    els.shell.classList.toggle('collapsed', collapsed);
    // 必须用 toggleAttribute 写 content attribute：SVGElement 上 .hidden = true 只是无效 expando
    $('#ic-collapse').toggleAttribute('hidden', collapsed);
    $('#ic-expand').toggleAttribute('hidden', !collapsed);
    $('#collapse-btn').setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    $$('.nav-item', els.nav).forEach((b) => {
      b.title = collapsed ? b.querySelector('span:last-child').textContent.trim() : '';
    });
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch { /* 忽略 */ }
  }

  $('#collapse-btn').addEventListener('click', () => {
    setCollapsed(!els.shell.classList.contains('collapsed'));
  });

  /* ------------------------------ 启动 ------------------------------ */

  let savedType = 'hitokoto';
  let savedCollapsed = false;
  try {
    savedType = localStorage.getItem(TYPE_KEY) || 'hitokoto';
    savedCollapsed = localStorage.getItem(COLLAPSE_KEY) === '1';
  } catch { /* 忽略 */ }
  setCollapsed(savedCollapsed);
  setType(savedType);
})();
