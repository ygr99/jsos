/**
 * 聚合一言 打包：JSZip（正向斜杠）→ zip
 * 排除 node_modules / data / package-lock / *.zip / check-* 与 smoke- 脚本及截图
 */
import { createRequire } from 'module';
const require = createRequire('C:/Users/99/jsos/package.json');
const JSZip = require('jszip');
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const { version } = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
const OUT = path.join(__dirname, `aggregate-hitokoto-${version}.zip`);

const EXCLUDE_DIRS = new Set(['node_modules', 'data']);
const EXCLUDE_FILES = (f) =>
  f.endsWith('.zip') || f.endsWith('.log') || f === 'package-lock.json' ||
  /^(check|smoke)[.-]/.test(f);

const zip = new JSZip();
function addDir(dir, zipDir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (EXCLUDE_DIRS.has(entry.name)) continue;            // 目录/junction（node_modules 指向外部）一律按名排除
    if (entry.isFile() && EXCLUDE_FILES(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) addDir(full, zipDir.folder(entry.name));
    else if (entry.isFile()) zipDir.file(entry.name, fs.readFileSync(full));
    // symlink 等其他类型跳过（junction 的 Dirent 两者皆非，读它会 EISDIR）
  }
}
addDir(__dirname, zip);

const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
fs.writeFileSync(OUT, buf);
console.log(`打包完成: ${OUT} (${(buf.length / 1024).toFixed(1)} KB)`);
