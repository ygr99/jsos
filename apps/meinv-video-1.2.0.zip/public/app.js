/* 小姐姐视频 —— 抖音式竖屏信息流
 * 一屏一个视频：滚轮/触摸/方向键上下切换，滚动到底前自动追加（预加载后续 2 个）。
 * 直连优先：视频源带 Access-Control-Allow-Origin: *，<video crossorigin="anonymous">
 * 在 COEP require-corp 下可过 CORS-cross-origin 检查直接播放（不经 /api/video 代理，快）；
 * 直连失败（error）自动降级为 /api/video 同源代理，再失败标记跳过。
 * 缓存策略：全部在内存（不写 localStorage），pagehide/卸载时释放所有 video src。 */

const $ = (id) => document.getElementById(id);
const feed = $('feed');
const loader = $('loader');
const loaderText = $('loaderText');
const toast = $('toast');

let items = [];          // { url, via, el, video, failed }
let current = 0;         // 当前可见 slide 下标
let fetching = false;
let firstReady = false;
let toastTimer = 0;

function toastMsg(text) {
  toast.textContent = text;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.hidden = true; }, 3000);
}

function showLoader(bottom) {
  loader.className = bottom ? 'loader bottom' : 'loader center';
  loaderText.textContent = bottom ? '加载下一个…' : '加载中…';
  loader.hidden = false;
}

function hideLoader() {
  loader.hidden = true;
}

async function fetchVideoUrl() {
  const r = await fetch('/api/random');
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return { url: data.url, via: data.via || '' };
}

/** 直连地址 → 同源代理地址（降级用） */
function proxyUrl(url) {
  return `/api/video?u=${encodeURIComponent(url)}`;
}

function createSlide(item, index) {
  const el = document.createElement('section');
  el.className = 'slide';
  el.dataset.index = String(index);

  const video = document.createElement('video');
  video.crossOrigin = 'anonymous';   // 直连：CORS 模式 + 源站 ACAO * → 过 COEP 检查
  video.playsInline = true;
  video.loop = true;                 // 抖音式循环
  video.preload = 'auto';            // 预加载
  video.src = item.url;
  video.muted = false;

  video.addEventListener('canplay', () => {
    if (index === 0 && !firstReady) {
      firstReady = true;
      hideLoader();
      video.play().catch(() => {});  // 带声自动播；被手势策略拦则停在首帧，点击视频即可
    }
  });

  // 直连失败 → 降级同源代理；代理也失败 → 标记失败
  video.addEventListener('error', () => {
    if (!item.failed && video.src !== location.origin + proxyUrl(item.url) && !video.src.endsWith(proxyUrl(item.url))) {
      video.crossOrigin = null;
      video.src = proxyUrl(item.url);
      video.load();
      if (index === current) video.play().catch(() => {});
      return;
    }
    item.failed = true;
    toastMsg(`第 ${index + 1} 个视频加载失败，可继续下滑`);
  });

  // 点击视频：播放/暂停（同时是首次交互手势，解锁带声自动播）
  video.addEventListener('click', () => {
    if (video.paused) video.play().catch(() => {});
    else video.pause();
  });

  el.appendChild(video);
  feed.appendChild(el);
  item.el = el;
  item.video = video;
  io.observe(el);
}

async function appendSlides(n = 2) {
  if (fetching) return;
  fetching = true;
  showLoader(items.length > 0);
  try {
    const results = await Promise.allSettled(Array.from({ length: n }, fetchVideoUrl));
    let added = 0;
    for (const res of results) {
      if (res.status !== 'fulfilled') continue;
      const item = { url: res.value.url, via: res.value.via, failed: false };
      createSlide(item, items.length);
      items.push(item);
      added++;
    }
    if (items.length && added === 0) {
      toastMsg('获取视频失败：' + (results[0].reason?.message || '未知错误'));
    }
  } finally {
    fetching = false;
    if (firstReady || items.length) hideLoader();
  }
}

/** 可见项周围的存活窗口：前 1 + 当前 + 后 2，窗口外的释放 src 省内存（滚回来会按 URL 重载） */
function maintainWindow() {
  items.forEach((item, i) => {
    const inWindow = i >= current - 1 && i <= current + 2 && !item.failed;
    const v = item.video;
    if (!v) return;
    const isProxied = v.src.endsWith(proxyUrl(item.url));
    if (inWindow) {
      if (!v.getAttribute('src')) {
        v.crossOrigin = isProxied ? null : 'anonymous';
        v.src = isProxied ? proxyUrl(item.url) : item.url;
        v.load();
      }
    } else if (v.getAttribute('src')) {
      v.pause();
      v.removeAttribute('src');
      v.load();   // 清空媒体资源，释放内存
    }
  });
}

const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    const index = Number(e.target.dataset.index);
    const item = items[index];
    if (!item || !item.video) continue;
    if (e.isIntersecting && e.intersectionRatio >= 0.6) {
      current = index;
      item.video.play().catch(() => {});
      maintainWindow();
      // 快到底 → 预取下一批
      if (current >= items.length - 2) appendSlides(2);
    } else {
      item.video.pause();
    }
  }
}, { root: feed, threshold: 0.6 });

/* ---- 滚轮/键盘：一次一屏（触摸走原生滚动吸附） ---- */
let wheelLock = false;
function stepBy(dir) {
  const next = Math.min(items.length - 1, Math.max(0, current + dir));
  if (next === current) return;
  wheelLock = true;
  feed.scrollTo({ top: next * feed.clientHeight, behavior: 'smooth' });
  setTimeout(() => { wheelLock = false; }, 380);
}
feed.addEventListener('wheel', (e) => {
  e.preventDefault();
  if (wheelLock) return;
  stepBy(e.deltaY > 0 ? 1 : -1);
}, { passive: false });

document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown' || e.key === 'PageDown') { e.preventDefault(); if (!wheelLock) stepBy(1); }
  if (e.key === 'ArrowUp' || e.key === 'PageUp') { e.preventDefault(); if (!wheelLock) stepBy(-1); }
  if (e.key === ' ') {
    const v = items[current]?.video;
    if (v) { e.preventDefault(); v.paused ? v.play().catch(() => {}) : v.pause(); }
  }
});

/* ---- 退出应用：清缓存（媒体全部在内存，释放 video 资源即可） ---- */
function releaseAll() {
  items.forEach((item) => {
    if (item.video) {
      item.video.pause();
      item.video.removeAttribute('src');
      item.video.load();
    }
  });
  feed.innerHTML = '';
  items = [];
  current = 0;
}
window.addEventListener('pagehide', releaseAll);
window.addEventListener('beforeunload', releaseAll);

/* ---- 启动：首批 3 个，第一个自动播放 ---- */
showLoader(false);
appendSlides(3);
