/**
 * 书签 · 主界面逻辑
 * 数据：服务端 /api/state（window.BM 里的读写与解析器）
 */
(function () {
  const BM = window.BM;
  const $ = (id) => document.getElementById(id);

  const PANEL_IDS = {
    editor: 'exp-editor',
    paste: 'exp-paste',
    bulk: 'exp-bulk',
    html: 'exp-html',
    desktop: 'exp-desktop',
  };

  let S = { bookmarks: [], widgetTitle: BM.DEFAULT_WIDGET_TITLE, widgetTitleAll: BM.DEFAULT_WIDGET_TITLE_ALL };
  let q = '';
  let panel = '';              // '' | editor | paste | bulk | html | desktop
  let editingId = null;        // '__new__' = 新增，其它 = 正在编辑的书签 id
  let pendingDeleteId = null;  // 卡片上的行内删除确认
  let flashId = null;
  let bulkSortable = null;

  /* ==================== 存储（串行写入，避免竞态） ==================== */

  let saveChain = Promise.resolve();
  let saveTimer = null;

  function postState() {
    const snapshot = {
      bookmarks: S.bookmarks.map((b) => ({ id: b.id, title: b.title, url: b.url, desktop: !!b.desktop, createdAt: b.createdAt })),
      widgetTitle: S.widgetTitle,
      widgetTitleAll: S.widgetTitleAll,
    };
    saveChain = saveChain.then(async () => {
      try {
        await BM.saveState(snapshot);
      } catch (e) {
        toast('保存失败：' + (e && e.message ? e.message : e), 'err');
      }
    });
    return saveChain;
  }
  function save() {
    clearTimeout(saveTimer);
    return postState();
  }
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(postState, 350);
  }

  /* ==================== 轻提示 ==================== */

  function toast(msg, kind, action) {
    const wrap = $('toasts');
    const el = document.createElement('div');
    el.className = 'toast' + (kind === 'err' ? ' err' : '');
    const span = document.createElement('span');
    span.textContent = msg;
    el.appendChild(span);

    let done = false;
    const dismiss = () => {
      if (done) return;
      done = true;
      el.classList.add('out');
      setTimeout(() => el.remove(), 220);
    };
    if (action) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'undo';
      b.textContent = action.label;
      b.addEventListener('click', () => {
        action.run();
        dismiss();
      });
      el.appendChild(b);
    }
    wrap.appendChild(el);
    const timer = setTimeout(dismiss, action ? 6000 : 2600);
    el.addEventListener('click', () => clearTimeout(timer));
    return dismiss;
  }

  /* ==================== 小工具 ==================== */

  function fallbackColor(seed) {
    let h = 0;
    const s = String(seed || 'x');
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
    return 'hsl(' + h + ', 32%, 62%)';
  }

  function icon(name) {
    return '<svg class="i"><use href="#' + name + '"/></svg>';
  }

  function openBookmark(url) {
    const w = window.open(url, '_blank', 'noopener');
    if (!w) toast('新窗口被浏览器拦下了，请允许弹出窗口', 'err');
  }

  /* ==================== 书签列表 ==================== */

  function visibleBookmarks() {
    const kw = q.trim().toLowerCase();
    if (!kw) return S.bookmarks;
    return S.bookmarks.filter((b) =>
      (b.title + '\n' + b.url + '\n' + BM.hostOf(b.url)).toLowerCase().includes(kw)
    );
  }

  function opBtn(act, iconName, title, onClick, on) {
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.act = act;
    b.title = title;
    b.setAttribute('aria-label', title);
    if (on) b.classList.add('on');
    b.innerHTML = icon(iconName);
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      onClick();
    });
    return b;
  }

  function buildCard(b) {
    const el = document.createElement('article');
    el.className = 'bm' + (flashId === b.id ? ' flash' : '');
    el.dataset.id = b.id;

    const wrapIcon = document.createElement('div');
    wrapIcon.className = 'bm-icon';
    const img = document.createElement('img');
    img.alt = '';
    img.loading = 'lazy';
    img.decoding = 'async';
    img.src = BM.iconUrl(b.url);
    img.addEventListener('error', () => wrapIcon.classList.add('failed'));
    const fb = document.createElement('div');
    fb.className = 'fb';
    fb.textContent = (b.title || BM.hostOf(b.url)).trim().slice(0, 1).toUpperCase() || '?';
    fb.style.background = fallbackColor(b.url);
    wrapIcon.append(img, fb);

    const meta = document.createElement('div');
    meta.className = 'bm-meta';
    const t = document.createElement('div');
    t.className = 'bm-title';
    t.textContent = b.title;
    const h = document.createElement('div');
    h.className = 'bm-host';
    h.textContent = BM.hostOf(b.url);
    meta.append(t, h);

    el.append(wrapIcon, meta);

    if (pendingDeleteId === b.id) {
      const cf = document.createElement('div');
      cf.className = 'bm-confirm';
      const s = document.createElement('span');
      s.textContent = '删除？';
      const yes = document.createElement('button');
      yes.type = 'button';
      yes.className = 'danger';
      yes.textContent = '删除';
      yes.addEventListener('click', (e) => {
        e.stopPropagation();
        removeBookmark(b.id);
      });
      const no = document.createElement('button');
      no.type = 'button';
      no.textContent = '取消';
      no.addEventListener('click', (e) => {
        e.stopPropagation();
        pendingDeleteId = null;
        renderGrid();
      });
      cf.append(s, yes, no);
      el.appendChild(cf);
    } else {
      const ops = document.createElement('div');
      ops.className = 'bm-ops';
      ops.append(
        opBtn('open', 'i-open', '打开', () => openBookmark(b.url)),
        opBtn('desk', 'i-star', b.desktop ? '从桌面小组件移除' : '显示在桌面小组件', () => toggleDesktop(b.id), b.desktop),
        opBtn('edit', 'i-edit', '编辑', () => openEditor(b)),
        opBtn('del', 'i-trash', '删除', () => {
          pendingDeleteId = b.id;
          renderGrid();
        })
      );
      el.appendChild(ops);
    }

    el.addEventListener('click', (e) => {
      if (e.target && e.target.closest && e.target.closest('button')) return;
      openBookmark(b.url);
    });
    return el;
  }

  function renderGrid() {
    const list = visibleBookmarks();
    const grid = $('grid');
    grid.textContent = '';
    const empty = $('empty');

    if (!list.length) {
      empty.hidden = false;
      if (!S.bookmarks.length) {
        $('empty-title').textContent = '还没有书签';
        $('empty-sub').textContent = '点右上角「添加书签」，或试试「批量粘贴」与「HTML 导入」';
      } else {
        $('empty-title').textContent = '没有找到匹配的书签';
        $('empty-sub').textContent = '换个关键词试试，或清空搜索框';
      }
      return;
    }
    empty.hidden = true;
    for (const b of list) grid.appendChild(buildCard(b));
  }

  function flash(id) {
    if (!id) return;
    flashId = id;
    renderGrid();
    const el = document.querySelector('.bm[data-id="' + id + '"]');
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    setTimeout(() => {
      if (flashId !== id) return;
      flashId = null;
      const el2 = document.querySelector('.bm[data-id="' + id + '"]');
      if (el2) el2.classList.remove('flash');
    }, 1500);
  }

  async function toggleDesktop(id) {
    const b = S.bookmarks.find((x) => x.id === id);
    if (!b) return;
    b.desktop = !b.desktop;
    renderGrid();
    if (panel === 'desktop') renderDeskList();
    saveSoon();
    toast(b.desktop ? '「' + b.title + '」已加到桌面小组件' : '「' + b.title + '」已从桌面小组件移除');
  }

  async function removeBookmark(id) {
    const i = S.bookmarks.findIndex((b) => b.id === id);
    if (i < 0) return;
    const gone = S.bookmarks[i];
    S.bookmarks.splice(i, 1);
    pendingDeleteId = null;
    renderGrid();
    if (panel === 'bulk') renderBulkList();
    if (panel === 'desktop') renderDeskList();
    save();
    toast('已删除「' + gone.title + '」', null, {
      label: '撤销',
      run: () => {
        S.bookmarks.splice(Math.min(i, S.bookmarks.length), 0, gone);
        renderGrid();
        if (panel === 'desktop') renderDeskList();
        save();
      },
    });
  }

  /* ==================== 面板切换 ==================== */

  function setPanel(name) {
    panel = name || '';
    for (const key of Object.keys(PANEL_IDS)) $(PANEL_IDS[key]).hidden = true;
    document.querySelectorAll('.toolbar .btn[data-panel]').forEach((b) => b.classList.remove('on'));
    if (!panel) return;
    $(PANEL_IDS[panel]).hidden = false;
    const tab = document.querySelector('.toolbar .btn[data-panel="' + panel + '"]');
    if (tab) tab.classList.add('on');
  }

  function closePanel() {
    if (bulkSortable) {
      try { bulkSortable.destroy(); } catch {}
      bulkSortable = null;
    }
    editingId = null;
    setPanel('');
  }

  function openPanel(name) {
    if (panel === name) {
      closePanel();
      return;
    }
    closePanel();
    setPanel(name);
    if (name === 'editor') {
      $('ed-title').value = '';
      $('ed-title').placeholder = '标题';
      $('ed-url').value = '';
      syncEditor();
    }
    if (name === 'paste') updatePaste();
    if (name === 'html') updateHtml();
    if (name === 'bulk') renderBulkList();
    if (name === 'desktop') renderDeskList();
  }

  /* ==================== 添加 / 编辑 ==================== */

  function openEditor(b) {
    closePanel();
    setPanel('editor');
    if (b) {
      editingId = b.id;
      $('ed-title').value = b.title;
      $('ed-url').value = b.url;
    } else {
      editingId = '__new__';
      $('ed-title').value = '';
      $('ed-url').value = '';
    }
    syncEditor();
    $('ed-url').focus();
  }

  function syncEditor() {
    const raw = $('ed-url').value.trim();
    const url = BM.normalizeUrl(raw);
    $('ed-ok').disabled = !url;
    const hint = $('ed-hint');
    if (raw && !url) {
      hint.textContent = '网址无效：需要 http:// 或 https:// 开头（裸域名会自动补全），其它协议不支持。';
      hint.classList.add('warn');
    } else {
      hint.classList.remove('warn');
      hint.textContent =
        editingId === '__new__'
          ? '输入网址后点 ✓ 保存，标题留空会自动用网站域名。'
          : '改完点 ✓ 保存，点 ✕ 放弃这次修改。';
    }
  }

  async function commitEditor() {
    const url = BM.normalizeUrl($('ed-url').value);
    if (!url) {
      $('ed-url').focus();
      return;
    }
    const title = $('ed-title').value.trim() || BM.hostOf(url);
    const key = BM.urlKey(url);

    if (editingId === '__new__') {
      if (S.bookmarks.some((b) => BM.urlKey(b.url) === key)) {
        toast('这个网址已经收藏过了', 'err');
        return;
      }
      const b = { id: BM.newId(), title, url, desktop: true, createdAt: Date.now() };
      S.bookmarks.push(b);
      closePanel();
      await save();
      flash(b.id);
      toast('已添加「' + title + '」');
      return;
    }

    const i = S.bookmarks.findIndex((b) => b.id === editingId);
    if (i < 0) {
      closePanel();
      return;
    }
    if (S.bookmarks.some((b) => b.id !== editingId && BM.urlKey(b.url) === key)) {
      toast('这个网址已经被另一个书签占用了', 'err');
      return;
    }
    const id = editingId;
    S.bookmarks[i] = Object.assign({}, S.bookmarks[i], { title, url });
    closePanel();
    await save();
    flash(id);
    toast('已保存');
  }

  /* ==================== 批量粘贴 ==================== */

  function preview(text, parser) {
    const parsed = parser(text);
    const merged = BM.mergeWithExisting(S.bookmarks, parsed);
    return { parsed: parsed, list: merged.list, dup: merged.dup };
  }

  function fillStats(prefix, p) {
    $(prefix + '-found').textContent = p.parsed.length;
    $(prefix + '-new').textContent = p.list.length;
    $(prefix + '-dup-wrap').hidden = p.dup === 0;
    $(prefix + '-dup').textContent = p.dup;
    $(prefix + '-save').disabled = p.list.length === 0;
  }

  function updatePaste() {
    fillStats('paste', preview($('paste-input').value, BM.parsePasted));
  }

  async function importPaste() {
    const p = preview($('paste-input').value, BM.parsePasted);
    if (!p.list.length) return;
    const added = p.list.map((it) => BM.toBookmark(it, false));
    S.bookmarks.push.apply(S.bookmarks, added);
    $('paste-input').value = '';
    updatePaste();
    await save();
    flash(added[added.length - 1].id);
    toast('已导入 ' + added.length + ' 个书签');
  }

  /* ==================== HTML 导入 ==================== */

  function updateHtml() {
    fillStats('html', preview($('html-input').value, BM.parseHtmlBookmarks));
  }

  async function importHtml() {
    const p = preview($('html-input').value, BM.parseHtmlBookmarks);
    if (!p.list.length) return;
    const added = p.list.map((it) => BM.toBookmark(it, false));
    S.bookmarks.push.apply(S.bookmarks, added);
    $('html-input').value = '';
    $('html-file').value = '';
    $('html-name').textContent = '未选择文件';
    updateHtml();
    await save();
    flash(added[added.length - 1].id);
    toast('已导入 ' + added.length + ' 个书签');
  }

  /* ==================== 批量编辑 ==================== */

  function miniBtn(iconName, title, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'mini';
    b.title = title;
    b.setAttribute('aria-label', title);
    b.innerHTML = icon(iconName);
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      onClick();
    });
    return b;
  }

  function moveRow(row, delta) {
    const wrap = $('bulk-list');
    const kids = Array.prototype.slice.call(wrap.children);
    const i = kids.indexOf(row);
    const j = i + delta;
    if (i < 0 || j < 0 || j >= kids.length) return;
    if (delta < 0) wrap.insertBefore(row, kids[j]);
    else wrap.insertBefore(kids[j], row);
  }

  function bulkRow(b) {
    const row = document.createElement('div');
    row.className = 'bulk-row';
    row.dataset.id = b.id || '';

    const handle = document.createElement('span');
    handle.className = 'handle';
    handle.title = '拖动排序';
    handle.innerHTML = icon('i-grip');

    const ti = document.createElement('input');
    ti.type = 'text';
    ti.className = 'b-title';
    ti.placeholder = '标题';
    ti.value = b.title || '';

    const ui = document.createElement('input');
    ui.type = 'text';
    ui.className = 'b-url';
    ui.placeholder = 'https://example.com';
    ui.value = b.url || '';

    row.append(
      handle,
      ti,
      ui,
      miniBtn('i-up', '上移', () => moveRow(row, -1)),
      miniBtn('i-down', '下移', () => moveRow(row, 1)),
      miniBtn('i-x', '删除这一行', () => {
        row.remove();
        if (!$('bulk-list').children.length) renderBulkList();
        else $('bulk-count').textContent = $('bulk-list').children.length;
      })
    );
    return row;
  }

  function renderBulkList() {
    const wrap = $('bulk-list');
    if (bulkSortable) {
      try { bulkSortable.destroy(); } catch {}
      bulkSortable = null;
    }
    wrap.textContent = '';
    if (!S.bookmarks.length) {
      const e = document.createElement('div');
      e.className = 'bulk-empty';
      e.textContent = '还没有书签，先添加几个再来批量调整吧';
      wrap.appendChild(e);
      $('bulk-count').textContent = '0';
      return;
    }
    for (const b of S.bookmarks) wrap.appendChild(bulkRow(b));
    $('bulk-count').textContent = String(S.bookmarks.length);

    if (window.Sortable) {
      bulkSortable = window.Sortable.create(wrap, {
        handle: '.handle',
        animation: 150,
        ghostClass: 'dragging',
      });
    }
  }

  async function saveBulk() {
    const wrap = $('bulk-list');
    const rows = Array.prototype.slice.call(wrap.children).filter((r) => r.classList.contains('bulk-row'));
    const byId = new Map(S.bookmarks.map((b) => [b.id, b]));
    const seen = new Set();
    const next = [];
    let skipped = 0;

    for (const row of rows) {
      const url = BM.normalizeUrl(row.querySelector('.b-url').value);
      if (!url) {
        skipped++;
        continue;
      }
      const key = BM.urlKey(url);
      if (seen.has(key)) {
        skipped++;
        continue;
      }
      seen.add(key);
      const old = byId.get(row.dataset.id);
      const title = row.querySelector('.b-title').value.trim() || BM.hostOf(url);
      next.push({
        id: old ? old.id : BM.newId(),
        title: title,
        url: url,
        desktop: old ? !!old.desktop : false,
        createdAt: old ? old.createdAt : Date.now(),
      });
    }

    const removedCount = Math.max(0, S.bookmarks.length - rows.length);
    S.bookmarks = next;
    await save();
    closePanel();
    renderGrid();
    let msg = '已保存 ' + next.length + ' 个书签';
    if (skipped) msg += '，忽略 ' + skipped + ' 行无效网址';
    else if (removedCount) msg += '，删除 ' + removedCount + ' 个';
    toast(msg);
  }

  /* ==================== 桌面小组件设置 ==================== */

  function renderDeskCount() {
    $('desk-count').textContent = S.bookmarks.filter((b) => b.desktop).length;
  }

  function renderDeskList() {
    const wrap = $('desk-list');
    wrap.textContent = '';
    if (!S.bookmarks.length) {
      const e = document.createElement('div');
      e.className = 'bulk-empty';
      e.textContent = '还没有书签，先添加几个吧';
      wrap.appendChild(e);
      renderDeskCount();
      return;
    }
    for (const b of S.bookmarks) {
      const row = document.createElement('label');
      row.className = 'desk-item';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !!b.desktop;
      cb.addEventListener('change', () => {
        b.desktop = cb.checked;
        renderDeskCount();
        renderGrid();
        saveSoon();
      });
      const t = document.createElement('span');
      t.className = 'd-title';
      t.textContent = b.title;
      const h = document.createElement('span');
      h.className = 'd-host';
      h.textContent = BM.hostOf(b.url);
      row.append(cb, t, h);
      wrap.appendChild(row);
    }
    renderDeskCount();
  }

  function setAllDesktop(v) {
    for (const b of S.bookmarks) b.desktop = !!v;
    renderDeskList();
    renderGrid();
    saveSoon();
  }

  async function addWidgetToDesktop(widgetId) {
    const isAll = widgetId === 'all';
    const api = window.JSOS;
    if (!api || typeof api.addWidget !== 'function') {
      toast('请在桌面空白处右键 → 添加小组件 → ' + (isAll ? '桌面书签（8×4）' : '常用书签（4×2）'));
      return;
    }
    try {
      await api.addWidget('bookmarks', widgetId, { x: 140, y: 120 });
      toast('已把「' + (isAll ? '桌面书签' : '常用书签') + '」放到桌面上');
    } catch (e) {
      toast('添加失败：' + (e && e.message ? e.message : e), 'err');
    }
  }

  /* ==================== 初始化 ==================== */

  function bind() {
    // 工具栏
    document.querySelectorAll('.toolbar .btn[data-panel]').forEach((btn) => {
      btn.addEventListener('click', () => openPanel(btn.dataset.panel));
    });
    $('addBtn').addEventListener('click', () => {
      if (panel === 'editor' && editingId === '__new__') closePanel();
      else openEditor(null);
    });

    // 搜索
    const qi = $('q');
    qi.addEventListener('input', () => {
      q = qi.value;
      $('qClear').hidden = !q;
      renderGrid();
    });
    $('qClear').addEventListener('click', () => {
      qi.value = '';
      q = '';
      $('qClear').hidden = true;
      renderGrid();
      qi.focus();
    });

    // 添加 / 编辑
    $('ed-url').addEventListener('input', syncEditor);
    $('ed-ok').addEventListener('click', commitEditor);
    $('ed-cancel').addEventListener('click', closePanel);
    $('ed-title').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') $('ed-url').focus();
    });
    $('ed-url').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') commitEditor();
    });

    // 批量粘贴
    $('paste-input').addEventListener('input', updatePaste);
    $('paste-save').addEventListener('click', importPaste);

    // HTML 导入
    $('html-input').addEventListener('input', updateHtml);
    $('html-file').addEventListener('change', async (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      $('html-name').textContent = f.name;
      try {
        const text = typeof f.text === 'function' ? await f.text() : await new Promise((ok, no) => {
          const r = new FileReader();
          r.onload = () => ok(String(r.result || ''));
          r.onerror = () => no(r.error || new Error('读取失败'));
          r.readAsText(f);
        });
        $('html-input').value = text;
        updateHtml();
      } catch (err) {
        toast('读取文件失败：' + (err && err.message ? err.message : err), 'err');
      }
    });
    $('html-save').addEventListener('click', importHtml);

    // 批量编辑
    $('bulk-add').addEventListener('click', () => {
      const wrap = $('bulk-list');
      const empty = wrap.querySelector('.bulk-empty');
      if (empty) empty.remove();
      const row = bulkRow({ title: '', url: '' });
      wrap.appendChild(row);
      $('bulk-count').textContent = String(wrap.querySelectorAll('.bulk-row').length);
      row.querySelector('.b-url').focus();
    });
    $('bulk-reset').addEventListener('click', renderBulkList);
    $('bulk-save').addEventListener('click', saveBulk);

    // 桌面组件（小组件现在不显示标题，格子数固定：4×2 = 4 列 2 行，8×4 = 8 列 4 行）
    $('desk-all').addEventListener('click', () => setAllDesktop(true));
    $('desk-none').addEventListener('click', () => setAllDesktop(false));
    $('desk-add').addEventListener('click', () => addWidgetToDesktop('favorites'));
    $('desk-add-all').addEventListener('click', () => addWidgetToDesktop('all'));

    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if (pendingDeleteId) {
        pendingDeleteId = null;
        renderGrid();
        return;
      }
      if (panel) closePanel();
    });
  }

  async function init() {
    const loaded = await BM.loadState();
    if (loaded) {
      S = loaded;
    } else {
      // 首次启动播种示例数据（用户清空后会存 []，不会被重新播种）
      S = {
        bookmarks: BM.SEED_STATE.bookmarks.map((b) => Object.assign({}, b)),
        widgetTitle: BM.SEED_STATE.widgetTitle,
        widgetTitleAll: BM.SEED_STATE.widgetTitleAll,
      };
      await save();
    }
    renderGrid();
    bind();

    BM.onExternalChange(async () => {
      const next = await BM.loadState();
      if (!next) return;
      // 正在输入 / 删除确认时不打扰
      if (panel === 'editor' || panel === 'bulk' || pendingDeleteId) return;
      S = next;
      renderGrid();
      if (panel === 'desktop') renderDeskList();
      if (panel === 'paste') updatePaste();
    });
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) return;
      if (panel === 'editor' || panel === 'bulk' || pendingDeleteId) return;
      const next = await BM.loadState();
      if (next) {
        S = next;
        renderGrid();
      }
    });
  }

  init();
})();
