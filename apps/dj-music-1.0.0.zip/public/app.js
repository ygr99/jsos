/**
 * DJ 音乐 —— 前端
 * ---------------------------------------------------------------
 * 榜单列表 + 搜索 + 内置播放器（原生 <audio>，不使用 APlayer）。
 * 音频与封面一律走同源代理 /api/audio、/api/img（COEP 原因，见 server.js 注释）。
 *
 * 播放地址策略：服务端为每首返回按音质排序的候选数组（上游常把 64/128/320
 * 三个键填成同一个 URL）。播放失败就换下一个候选；候选耗尽才标记失败并跳下一首，
 * 且连续失败达 3 首即停止 —— 防止上游整体挂掉时无限重试刷请求（AGENTS.md §9）。
 */
(function () {
  'use strict';

  /* ---------------- 图标（lucide 原样路径） ---------------- */
  const P = {
    panelLeft: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
    panelLeftClose: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/>',
    play: '<polygon points="6 3 20 12 6 21 6 3"/>',
    pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
    prev: '<polygon points="19 20 9 12 19 4 19 20"/><line x1="5" x2="5" y1="19" y2="5"/>',
    next: '<polygon points="5 4 15 12 5 20 5 4"/><line x1="19" x2="19" y1="5" y2="19"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    repeat: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
    repeatOne: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/>',
    shuffle: '<path d="m18 14 4 4-4 4"/><path d="m18 2 4 4-4 4"/><path d="M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22"/><path d="M2 6h1.972a4 4 0 0 1 3.6 2.2"/><path d="M22 18h-6.041a4 4 0 0 1-3.3-1.8l-.359-.45"/>',
    volume: '<path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>',
    mute: '<path d="M11 5 6 9H2v6h4l5 4V5Z"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    externalLink: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    sparkles: '<path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/>',
    heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
    flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
    trendingUp: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
  };
  const svg = (d, size = 16, extra = '') =>
    `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra}>${d}</svg>`;
  const svgFill = (d, size = 16) =>
    `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;

  /* ---------------- 榜单定义（与上游 id 一致） ---------------- */
  const RANKS = [
    { id: 'newFaBu', name: '新歌排行榜', icon: P.music },
    { id: 'newTuiJuan', name: '最新推荐榜', icon: P.sparkles },
    { id: 'newFav', name: '最新收藏榜', icon: P.heart },
    { id: 'newDown', name: '最新下载榜', icon: P.download },
    { id: 'hotFav', name: '月收藏排行榜', icon: P.flame },
    { id: 'hotDown', name: '月下载排行榜', icon: P.trendingUp },
  ];

  const MODES = [
    { id: 'order', label: '列表循环', icon: P.repeat },
    { id: 'one', label: '单曲循环', icon: P.repeatOne },
    { id: 'random', label: '随机播放', icon: P.shuffle },
  ];

  const LS = { rank: 'dj-music.rank', vol: 'dj-music.volume', mode: 'dj-music.mode', collapsed: 'dj-music.sidebar-collapsed' };

  const $ = (s) => document.querySelector(s);
  const el = {
    side: $('#side'), collapseBtn: $('#collapse-btn'),
    tabs: $('#tabs'), refresh: $('#btn-refresh'), linkRef: $('#link-ref'),
    kw: $('#kw'), kwClear: $('#kw-clear'), count: $('#count'), playAll: $('#btn-playall'),
    list: $('#list'), empty: $('#empty'), loading: $('#loading'), loadingText: $('#loading-text'),
    player: $('#player'), cover: $('#pl-cover'), plTitle: $('#pl-title'), plArtist: $('#pl-artist'), plIndex: $('#pl-index'),
    btnPrev: $('#btn-prev'), btnPlay: $('#btn-play'), btnNext: $('#btn-next'),
    cur: $('#pl-cur'), dur: $('#pl-dur'), seek: $('#pl-seek'),
    btnMode: $('#btn-mode'), btnMute: $('#btn-mute'), vol: $('#pl-vol'),
    audio: $('#audio'), toast: $('#toast'),
  };

  const state = {
    rank: 'newFaBu',
    raw: [],
    view: [],
    emptyMsg: '',
    track: null,      // 当前曲目对象
    cand: 0,          // 当前使用的候选音频下标
    mode: 'order',
    failStreak: 0,
    lastVolume: 0.8,
  };

  /* ---------------- 小工具 ---------------- */
  let toastTimer = 0;
  function toast(msg) {
    el.toast.textContent = msg;
    el.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.toast.hidden = true; }, 2600);
  }

  function fmtTime(sec) {
    if (!Number.isFinite(sec) || sec < 0) return '0:00';
    const s = Math.floor(sec % 60);
    const m = Math.floor(sec / 60) % 60;
    const h = Math.floor(sec / 3600);
    const p = (n) => String(n).padStart(2, '0');
    return h ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
  }

  /** 文件名安全化（下载用） */
  const safeName = (s) => String(s || 'audio').replace(/[\\/:*?"<>|]/g, '_').slice(0, 80).trim() || 'audio';

  const proxied = (u) => `/api/audio?u=${encodeURIComponent(u)}`;
  const coverProxy = (u) => `/api/img?u=${encodeURIComponent(u)}`;

  /* ---------------- 主题 ---------------- */
  function applyTheme(t) { document.documentElement.classList.toggle('dark', t === 'dark'); }
  function initTheme() {
    const mql = matchMedia('(prefers-color-scheme: dark)');
    applyTheme(mql.matches ? 'dark' : 'light');
    mql.addEventListener('change', (e) => applyTheme(e.matches ? 'dark' : 'light'));
    if (window.JSOS && window.JSOS.getTheme) {
      Promise.resolve(window.JSOS.getTheme()).then((t) => t && applyTheme(t)).catch(() => {});
      if (window.JSOS.onThemeChange) window.JSOS.onThemeChange((t) => applyTheme(t));
    }
  }

  /* ---------------- 侧边栏折叠（AGENTS §5.1） ---------------- */
  function setCollapsed(collapsed) {
    el.side.classList.toggle('collapsed', collapsed);
    // SVGElement 没有 hidden IDL 属性 → 必须写真实 attribute（AGENTS §5.1 陷阱）
    el.collapseBtn.innerHTML = collapsed ? svg(P.panelLeft, 16) : svg(P.panelLeftClose, 16);
    el.collapseBtn.setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    el.collapseBtn.title = collapsed ? '展开侧边栏' : '折叠侧边栏';
    try { localStorage.setItem(LS.collapsed, collapsed ? '1' : '0'); } catch { /* 隐私模式 */ }
  }
  function initCollapse() {
    let collapsed = false;
    try { collapsed = localStorage.getItem(LS.collapsed) === '1'; } catch { /* noop */ }
    setCollapsed(collapsed);
    el.collapseBtn.addEventListener('click', () => setCollapsed(!el.side.classList.contains('collapsed')));
  }

  /* ---------------- 榜单 ---------------- */
  function renderTabs() {
    el.tabs.innerHTML = '';
    for (const r of RANKS) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tab-item' + (r.id === state.rank ? ' active' : '');
      b.dataset.rank = r.id;
      b.title = r.name;
      b.setAttribute('aria-current', r.id === state.rank ? 'true' : 'false');
      const ic = document.createElement('span');
      ic.className = 'ti';
      ic.innerHTML = svg(r.icon, 16);
      const lb = document.createElement('span');
      lb.className = 'tl';
      lb.textContent = r.name;
      b.append(ic, lb);
      b.addEventListener('click', () => { if (r.id !== state.rank) loadRank(r.id); });
      el.tabs.appendChild(b);
    }
  }

  function setOverlay(which, text) {
    el.loading.hidden = which !== 'loading';
    el.empty.hidden = which !== 'empty';
    if (which === 'loading' && text) el.loadingText.textContent = text;
    if (which === 'empty') el.empty.textContent = text || '暂无数据';
    if (which) el.list.innerHTML = '';
  }

  async function loadRank(rankId) {
    state.rank = rankId;
    try { localStorage.setItem(LS.rank, rankId); } catch { /* noop */ }
    renderTabs();
    setOverlay('loading', '正在获取榜单…');
    el.count.textContent = '';
    el.playAll.disabled = true;
    try {
      const res = await fetch(`/api/rank?t=${encodeURIComponent(rankId)}`);
      const json = await res.json().catch(() => null);
      if (!res.ok || !json || !json.ok) throw new Error(json && json.error ? json.error : `HTTP ${res.status}`);
      state.raw = json.list || [];
      state.emptyMsg = state.raw.length ? '' : '这个榜单暂时没有数据';
      applyFilter();
    } catch (err) {
      state.raw = [];
      state.view = [];
      state.emptyMsg = `榜单获取失败：${(err && err.message) || err}`;
      renderList();
      el.count.textContent = '';
      el.playAll.disabled = true;
    }
  }

  /* ---------------- 搜索 + 列表 ---------------- */
  function applyFilter() {
    const q = el.kw.value.trim().toLowerCase();
    state.view = q
      ? state.raw.filter((t) => t.title.toLowerCase().includes(q) || (t.dj || '').toLowerCase().includes(q))
      : state.raw.slice();
    el.kwClear.hidden = !q;
    renderList();
  }

  function renderList() {
    el.loading.hidden = true;
    const items = state.view;
    el.count.textContent = items.length ? `共 ${items.length} 首` : '';
    el.playAll.disabled = items.length === 0;

    if (!items.length) {
      setOverlay('empty', state.raw.length ? '没有找到匹配的歌曲，试着清空搜索词' : (state.emptyMsg || '暂无数据'));
      return;
    }
    el.empty.hidden = true;

    const frag = document.createDocumentFragment();
    items.forEach((t, idx) => frag.appendChild(renderRow(t, idx)));
    el.list.innerHTML = '';
    el.list.appendChild(frag);
    highlightRow();
  }

  function renderRow(t, idx) {
    const row = document.createElement('div');
    row.className = 'item';
    row.dataset.id = t.id;
    row.title = t.title;

    const box = document.createElement('div');
    box.className = 'cover-box';
    const img = document.createElement('img');
    img.className = 'cover';
    img.alt = '';
    img.loading = 'lazy';
    img.referrerPolicy = 'no-referrer';
    if (t.cover) {
      img.src = coverProxy(t.cover);
      img.addEventListener('error', () => { img.style.visibility = 'hidden'; });
    }
    const mask = document.createElement('div');
    mask.className = 'cover-mask';
    mask.innerHTML = svgFill(P.play, 18);
    box.append(img, mask);

    const meta = document.createElement('div');
    meta.className = 'meta';
    const title = document.createElement('div');
    title.className = 'item-title';
    title.appendChild(document.createTextNode(t.title || '(无标题)'));
    const eq = document.createElement('span');
    eq.className = 'eq';
    eq.innerHTML = '<i></i><i></i><i></i>';
    title.appendChild(eq);

    const sub = document.createElement('div');
    sub.className = 'sub';
    const parts = [`DJ：${t.dj || '-'}`, t.date, t.duration, t.size].filter(Boolean);
    parts.forEach((p, i) => {
      if (i) {
        const sep = document.createElement('span');
        sep.className = 'sep';
        sep.textContent = '·';
        sub.appendChild(sep);
      }
      const sp = document.createElement('span');
      sp.textContent = p;
      sub.appendChild(sp);
    });

    meta.append(title, sub);

    const ops = document.createElement('div');
    ops.className = 'ops';
    const dl = document.createElement('a');
    dl.className = 'icon-btn';
    dl.href = `${proxied(t.audio[0])}&dl=1`;
    dl.setAttribute('download', `${safeName(t.title)}.mp3`);
    dl.title = '下载音频';
    dl.setAttribute('aria-label', '下载音频');
    dl.innerHTML = svg(P.download, 17);
    dl.addEventListener('click', (e) => e.stopPropagation());
    ops.appendChild(dl);

    row.append(box, meta, ops);
    row.addEventListener('click', () => onRowClick(idx));
    return row;
  }

  const rowById = (id) => el.list.querySelector(`.item[data-id="${CSS.escape(String(id))}"]`);

  /** 封面遮罩图标：其他行恒为「播放」；当前曲目随播放态切「暂停 / 播放」 */
  function setRowMask(row, iconPath) {
    const mask = row && row.querySelector('.cover-mask');
    if (mask) mask.innerHTML = svgFill(iconPath, 18);
  }

  function highlightRow() {
    for (const n of el.list.querySelectorAll('.item.playing')) {
      n.classList.remove('playing', 'paused');
      setRowMask(n, P.play);
    }
    const t = state.track;
    if (!t) return;
    const row = rowById(t.id);
    if (!row) return;
    const paused = el.audio.paused;
    row.classList.add('playing');
    row.classList.toggle('paused', paused);
    setRowMask(row, paused ? P.play : P.pause);
  }

  function markFailed(id) {
    const row = rowById(id);
    if (row) row.classList.add('failed');
  }

  function onRowClick(idx) {
    const t = state.view[idx];
    if (!t) return;
    if (state.track && state.track.id === t.id) { togglePlay(); return; }
    state.failStreak = 0;
    playAt(idx);
  }

  /* ---------------- 播放器 ---------------- */
  function loadTrack(t, cand, autoplay) {
    state.track = t;
    state.cand = cand;
    el.audio.src = proxied(t.audio[cand]);
    el.audio.load();
    renderPlayer();
    highlightRow();
    if (autoplay) el.audio.play().catch(() => toast('浏览器阻止了自动播放，请点一下播放按钮'));
  }

  /** 切歌（不做失败计数重置 —— 自动跳歌必须能把连续失败累计起来） */
  function playAt(idx) {
    const list = state.view;
    if (!list.length) return;
    const n = ((idx % list.length) + list.length) % list.length;
    loadTrack(list[n], 0, true);
  }

  const currentIndex = () => (state.track ? state.view.findIndex((t) => t.id === state.track.id) : -1);

  function playRandomExceptCurrent() {
    const list = state.view;
    const i = currentIndex();
    let n = i;
    while (n === i) n = Math.floor(Math.random() * list.length);
    playAt(n);
  }

  function playNext() {
    if (!state.view.length) return;
    if (state.mode === 'random' && state.view.length > 1) { playRandomExceptCurrent(); return; }
    const i = currentIndex();
    playAt(i < 0 ? 0 : i + 1);
  }

  function playPrev() {
    if (!state.view.length) return;
    if (state.mode === 'random' && state.view.length > 1) { playRandomExceptCurrent(); return; }
    const i = currentIndex();
    playAt(i <= 0 ? state.view.length - 1 : i - 1);
  }

  function togglePlay() {
    if (!state.track) { playAt(0); return; }
    if (el.audio.paused) el.audio.play().catch(() => toast('播放失败'));
    else el.audio.pause();
  }

  function renderPlayer() {
    const t = state.track;
    el.player.hidden = !t;
    if (!t) return;
    el.plTitle.textContent = t.title || '(无标题)';
    el.plTitle.title = t.title || '';
    el.plArtist.textContent = t.dj ? `DJ：${t.dj}` : '';
    const i = currentIndex();
    el.plIndex.textContent = i >= 0 ? `${i + 1} / ${state.view.length}` : '';
    if (t.cover) {
      el.cover.src = coverProxy(t.cover);
      el.cover.style.visibility = '';
    } else {
      el.cover.removeAttribute('src');
      el.cover.style.visibility = 'hidden';
    }
    el.dur.textContent = '0:00';
    el.cur.textContent = '0:00';
    el.seek.value = '0';
  }

  function renderPlayIcon() {
    const playing = !el.audio.paused && !el.audio.ended;
    el.btnPlay.innerHTML = svgFill(playing ? P.pause : P.play, 16);
    el.btnPlay.setAttribute('aria-label', playing ? '暂停' : '播放');
    highlightRow();
  }

  function renderMode() {
    const m = MODES.find((x) => x.id === state.mode) || MODES[0];
    el.btnMode.innerHTML = svg(m.icon, 16);
    el.btnMode.title = m.label;
    el.btnMode.setAttribute('aria-label', `播放模式：${m.label}`);
  }

  function renderVolume() {
    const muted = el.audio.muted || el.audio.volume === 0;
    el.btnMute.innerHTML = svg(muted ? P.mute : P.volume, 16);
    el.btnMute.classList.toggle('on', muted);
    el.btnMute.title = muted ? '取消静音' : '静音';
    el.btnMute.setAttribute('aria-label', muted ? '取消静音' : '静音');
  }

  function initAudio() {
    const audio = el.audio;

    // 音量 / 模式偏好（纯 UI 偏好，丢了无所谓 → localStorage 即可，AGENTS §6）
    let vol = 0.8;
    try { vol = Number(localStorage.getItem(LS.vol)); } catch { /* noop */ }
    if (!Number.isFinite(vol) || vol < 0 || vol > 1) vol = 0.8;
    state.lastVolume = vol || 0.8;
    audio.volume = vol;
    el.vol.value = String(Math.round(vol * 100));
    try {
      const m = localStorage.getItem(LS.mode);
      if (MODES.some((x) => x.id === m)) state.mode = m;
    } catch { /* noop */ }
    renderMode();
    renderVolume();

    audio.addEventListener('play', renderPlayIcon);
    audio.addEventListener('pause', renderPlayIcon);

    const setDur = () => { if (Number.isFinite(audio.duration)) el.dur.textContent = fmtTime(audio.duration); };
    audio.addEventListener('loadedmetadata', setDur);
    audio.addEventListener('durationchange', setDur);

    audio.addEventListener('timeupdate', () => {
      const d = audio.duration;
      if (!Number.isFinite(d) || d <= 0) return;
      if (document.activeElement !== el.seek) el.seek.value = String(Math.round((audio.currentTime / d) * 1000));
      el.cur.textContent = fmtTime(audio.currentTime);
    });

    audio.addEventListener('ended', () => {
      state.failStreak = 0;
      if (state.mode === 'one') {
        audio.currentTime = 0;
        audio.play().catch(() => { /* noop */ });
        return;
      }
      playNext();
    });

    audio.addEventListener('error', () => {
      const t = state.track;
      if (!t) return;
      // 过期的 error 事件（已切到别的曲目/候选）不该被当成当前曲目的失败
      const current = audio.currentSrc || '';
      if (current && !current.endsWith(proxied(t.audio[state.cand]))) return;

      if (state.cand + 1 < t.audio.length) {
        loadTrack(t, state.cand + 1, true);
        return;
      }
      state.failStreak += 1;
      markFailed(t.id);
      if (state.failStreak >= 3) {
        state.failStreak = 0;
        audio.pause();
        toast('连续多首无法播放，请稍后重试');
        return;
      }
      toast(`「${t.title}」无法播放，已跳过`);
      playNext();
    });

    /* 控制条交互 */
    el.btnPlay.addEventListener('click', togglePlay);
    el.btnNext.addEventListener('click', () => { state.failStreak = 0; playNext(); });
    el.btnPrev.addEventListener('click', () => { state.failStreak = 0; playPrev(); });

    el.seek.addEventListener('input', () => {
      const d = audio.duration;
      if (Number.isFinite(d) && d > 0) el.cur.textContent = fmtTime((Number(el.seek.value) / 1000) * d);
    });
    el.seek.addEventListener('change', () => {
      const d = audio.duration;
      if (Number.isFinite(d) && d > 0) audio.currentTime = (Number(el.seek.value) / 1000) * d;
    });

    el.vol.addEventListener('input', () => {
      const v = Number(el.vol.value) / 100;
      audio.volume = v;
      audio.muted = v === 0;
      if (v > 0) state.lastVolume = v;
      try { localStorage.setItem(LS.vol, String(v)); } catch { /* noop */ }
      renderVolume();
    });

    el.btnMute.addEventListener('click', () => {
      if (audio.muted || audio.volume === 0) {
        audio.muted = false;
        audio.volume = state.lastVolume || 0.8;
        el.vol.value = String(Math.round(audio.volume * 100));
        try { localStorage.setItem(LS.vol, String(audio.volume)); } catch { /* noop */ }
      } else {
        state.lastVolume = audio.volume;
        audio.muted = true;
      }
      renderVolume();
    });

    el.btnMode.addEventListener('click', () => {
      const i = MODES.findIndex((m) => m.id === state.mode);
      state.mode = MODES[(i + 1) % MODES.length].id;
      try { localStorage.setItem(LS.mode, state.mode); } catch { /* noop */ }
      renderMode();
      toast(MODES.find((m) => m.id === state.mode).label);
    });
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    initTheme();
    initCollapse();
    initAudio();

    // 侧边栏底部按钮：图标 + 文字（折叠态只留图标）
    el.refresh.innerHTML = `${svg(P.refresh, 15, 'class="solo-icon"')}<span class="btn-label">刷新</span>`;
    el.linkRef.innerHTML = `${svg(P.externalLink, 15, 'class="solo-icon"')}<span class="btn-label">原站</span>`;

    el.refresh.addEventListener('click', () => loadRank(state.rank));
    el.kw.addEventListener('input', applyFilter);
    el.kwClear.addEventListener('click', () => { el.kw.value = ''; applyFilter(); el.kw.focus(); });
    el.playAll.addEventListener('click', () => { if (state.view.length) { state.failStreak = 0; playAt(0); } });

    // 空格：播放 / 暂停（输入框内不劫持）
    document.addEventListener('keydown', (e) => {
      if (e.code !== 'Space' || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (!state.track) return;
      e.preventDefault();
      togglePlay();
    });

    let rank = null;
    try { rank = localStorage.getItem(LS.rank); } catch { /* noop */ }
    if (!RANKS.some((r) => r.id === rank)) rank = RANKS[0].id;
    loadRank(rank);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
