/**
 * 酷狗音乐 MV —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 五组接口：
 *   /api/health  健康检查（测试轮询就绪用）
 *   /api/search  搜索 MV（上游 api.suol.cc；容器内必走平台 CORS 代理，
 *                实测其 ACAO 头为重复的 "*, *"，浏览器 CORS 检查必失败，直连是死路）
 *   /api/detail  取单条 MV 详情（实时拿带签名的播放地址，URL 约 2 小时时效，不缓存）
 *   /api/video   同源流式代理酷狗视频 CDN（透传 Range 支持拖动；上游是 http:// 且
 *                强制 COEP require-corp，<video> 直连会被混合内容+COEP 双杀）
 *   /api/img     同源图片代理（封面；跨域图片无 CORP 头会被 COEP 拦）
 *   /api/state   搜索历史持久化（AGENTS.md §6 铁律：使用数据存服务端 DATA_DIR）
 *
 * 出站策略见 lib/http.js；视频 CDN 的 ACAO 为 "*" 且服务端 http→http 简单请求
 * （Range 属 CORS 安全列表头，不触发预检），故 /api/video 直抓不走代理包装。
 */

import express from 'express';
import fs from 'node:fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outbound, IN_CONTAINER, ok, fail } from './lib/http.js';
import { searchMv, fetchDetail } from './lib/kugou.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');

/* ------------------------------ SSRF 防护 ------------------------------ */

/** 仅允许酷狗系域名（含子域）。后缀写法天然挡住 kugou.com.evil.com 这类欺骗。 */
function isKugouHost(hostname) {
  const h = String(hostname || '').toLowerCase();
  return h === 'kugou.com' || h.endsWith('.kugou.com');
}

/** 校验并解析媒体地址：协议受限 + 域名白名单（防 SSRF）。extra 参数（_r 重试戳）剥离。 */
function parseMediaUrl(raw, { httpsOnly }) {
  let u;
  try {
    u = new URL(String(raw || ''));
  } catch {
    return null;
  }
  if (httpsOnly && u.protocol !== 'https:') return null;
  if (!httpsOnly && u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (!isKugouHost(u.hostname)) return null;
  u.searchParams.delete('_r'); // 前端重试戳，不透传给上游
  return u;
}

/* ------------------------------ 搜索历史（模式 A） ------------------------------ */

function readState() {
  try {
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    return raw && typeof raw === 'object' ? raw : {};
  } catch {
    return {};
  }
}

function writeState(obj) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = STATE_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, STATE_FILE); // 原子写
}

/* ------------------------------ 应用 ------------------------------ */

const app = express();
app.use(express.static(join(__dirname, 'public')));

app.get('/api/health', (req, res) => {
  ok(res, { service: 'kugou-mv', proxy: IN_CONTAINER, time: new Date().toISOString() });
});

/* ------------------------------ 搜索 / 详情 ------------------------------ */

app.get('/api/search', async (req, res) => {
  try {
    const kw = String(req.query.kw || '').trim();
    if (!kw) return fail(res, '请输入歌名或歌手', 400);
    const { list, via } = await searchMv(kw);
    ok(res, { kw, list, via });
  } catch (err) {
    fail(res, `搜索失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/detail', async (req, res) => {
  try {
    const kw = String(req.query.kw || '').trim();
    const n = Number(req.query.n);
    if (!kw) return fail(res, '缺少搜索关键词', 400);
    const { mv, via } = await fetchDetail(kw, n);
    ok(res, { mv, via });
  } catch (err) {
    fail(res, `获取 MV 详情失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 视频同源代理（Range 透传） ------------------------------ */

app.get('/api/video', async (req, res) => {
  const target = parseMediaUrl(req.query.u, { httpsOnly: false });
  if (!target) {
    return fail(res, '仅允许代理 kugou.com 系域名的视频地址', 400);
  }

  const headers = {};
  if (req.headers.range) headers.Range = String(req.headers.range);

  try {
    const up = await fetch(target.href, {
      headers,
      redirect: 'follow',
      signal: AbortSignal.timeout(30000),
    });
    // isOk 按内容类型判，不能只看状态码：上游/代理层异常可能回 200 + 文本错误体，
    // 只看状态码会把错误体喂给 <video>，静默不播且不触发 error 兜底。
    const ct = up.headers.get('content-type') || '';
    const playable = /^(video\/|application\/octet-stream|binary\/)/i.test(ct);
    if (!(up.status === 200 || up.status === 206) || !playable) {
      await up.body?.cancel().catch(() => {});
      return fail(res, `视频源响应异常（HTTP ${up.status}，${ct || '无类型'}）`, 502);
    }

    res.status(up.status);
    for (const h of ['content-type', 'content-length', 'content-range']) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    // 显式告知可 Range 定位：上游 206 响应常不带 accept-ranges，缺了浏览器就不给拖动
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-store');

    if (req.query.dl === '1') {
      const name = decodeURIComponent(target.pathname.split('/').pop() || 'mv.mp4')
        .replace(/[\\/:*?"<>|]/g, '_');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${name.replace(/[^\x20-\x7e]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(name)}`,
      );
    }

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy()); // 必须挂 error handler，否则出错静默挂起
    stream.pipe(res);
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `视频拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

/* ------------------------------ 图片同源代理（封面） ------------------------------ */

app.get('/api/img', async (req, res) => {
  const target = parseMediaUrl(req.query.u, { httpsOnly: true });
  if (!target) {
    return fail(res, '仅允许代理 kugou.com 系域名的 https 图片地址', 400);
  }

  try {
    const { res: up, via } = await outbound(target.href, { timeout: 15000 });
    const ct = up.headers.get('content-type') || '';
    if (!up.ok || !ct.startsWith('image/')) {
      await up.body?.cancel().catch(() => {});
      return fail(res, `封面拉取失败（HTTP ${up.status}，via ${via}）`, 502);
    }
    res.status(200);
    res.setHeader('Content-Type', ct);
    const cl = up.headers.get('content-length');
    if (cl) res.setHeader('Content-Length', cl);
    res.setHeader('Cache-Control', 'max-age=86400'); // 封面按 URL 稳定，可缓存
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy());
    stream.pipe(res);
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `封面拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

/* ------------------------------ 搜索历史 ------------------------------ */

app.get('/api/state', (req, res) => {
  const state = readState();
  const history = Array.isArray(state.history) ? state.history : [];
  res.json({ ok: true, history });
});

app.post('/api/state', express.json({ limit: '16kb' }), (req, res) => {
  const raw = req.body?.history;
  if (!Array.isArray(raw)) return fail(res, 'history 必须是数组', 400);
  // 只收非空字符串、去重、单项限长、总量限 10（与前端历史条数上限一致）
  const seen = new Set();
  const history = [];
  for (const item of raw) {
    const s = String(item ?? '').trim().slice(0, 50);
    if (!s || seen.has(s)) continue;
    seen.add(s);
    history.push(s);
    if (history.length >= 10) break;
  }
  try {
    writeState({ history });
    ok(res, { history });
  } catch (err) {
    fail(res, `保存失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 启动 ------------------------------ */

// 全局兜底：未捕获异常打日志，不静默
process.on('unhandledRejection', (err) => {
  console.error('[kugou-mv] unhandledRejection:', err?.message || err);
});

app.listen(port, () => {
  console.log(`[kugou-mv] listening on http://localhost:${port} (proxy: ${IN_CONTAINER ? 'on' : 'off'})`);
});
