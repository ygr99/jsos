import express from 'express';
import fs from 'fs';
import { createReadStream } from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname as up, join, extname } from 'path';

const __dirname = up(fileURLToPath(import.meta.url));

// [存储规范 §7.9 模式 A] 设置存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/poster），
// 主页面与小组件同源共读；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

// 浏览默认根 = 容器内 workspace 根（DATA_DIR 上两级），本机直跑 = 应用目录
const BROWSE_ROOT = process.env.DATA_DIR ? up(up(DATA_DIR)) : __dirname;

const IMAGE_EXTS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg', '.avif', '.ico']);
const MIME = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.bmp': 'image/bmp', '.svg': 'image/svg+xml',
  '.avif': 'image/avif', '.ico': 'image/x-icon',
};

const app = express();
app.use(express.json({ limit: '256kb' }));
app.use(express.static(join(__dirname, 'public')));

// ---------- 设置（模式 A：单文档 + 原子写） ----------
const DEFAULT_STATE = {
  mode: 'single',        // url=图片链接 | single=单张图片 | folder=文件夹轮播
  imagePath: null,       // mode=single 时的图片绝对路径
  folderPath: null,      // mode=folder 时的相册文件夹绝对路径
  imageUrls: [],         // mode=url 时的图片 URL 列表（每行一个）
  autoRotate: false,     // 自动轮播
  order: 'sequential',   // sequential=顺序播放 | random=随机播放
  interval: 5,           // 轮播间隔（秒）
  index: 0,              // 当前显示第几张（应用里翻页会更新，小组件以此为起点）
};

app.get('/api/state', (req, res) => {
  try {
    if (!fs.existsSync(STATE_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  const b = req.body || {};
  const state = {
    mode: b.mode === 'folder' || b.mode === 'url' ? b.mode : 'single',
    imagePath: typeof b.imagePath === 'string' && b.imagePath ? b.imagePath : null,
    folderPath: typeof b.folderPath === 'string' && b.folderPath ? b.folderPath : null,
    imageUrls: Array.isArray(b.imageUrls)
      ? b.imageUrls
          .filter(u => typeof u === 'string' && /^https?:\/\//i.test(u) && u.length <= 2048)
          .slice(0, 100)
      : [],
    autoRotate: !!b.autoRotate,
    order: b.order === 'random' ? 'random' : 'sequential',
    interval: Math.min(86400, Math.max(1, Math.round(Number(b.interval) || 5))),
    index: Math.max(0, Math.round(Number(b.index) || 0)),
  };
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
    fs.renameSync(tmp, STATE_FILE);
    res.json({ ok: true, state });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------- 文件浏览（与「文件」应用同一容器文件系统） ----------
function entryInfo(dir, name) {
  try {
    const st = fs.statSync(join(dir, name));
    const ext = extname(name).toLowerCase();
    return { name, isDirectory: st.isDirectory(), isImage: !st.isDirectory() && IMAGE_EXTS.has(ext), size: st.size, mtime: st.mtimeMs };
  } catch {
    return null;
  }
}

app.get('/api/config', (req, res) => {
  res.json({ root: BROWSE_ROOT, dataDir: DATA_DIR });
});

// 列目录：目录 + 图片文件（选择单张图片和选择文件夹共用）
app.get('/api/browse', (req, res) => {
  const dirPath = req.query.path || BROWSE_ROOT;
  try {
    if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
      return res.status(404).json({ error: '目录不存在' });
    }
    const entries = fs.readdirSync(dirPath)
      .map(name => entryInfo(dirPath, name))
      .filter(e => e && (e.isDirectory || e.isImage))
      .sort((a, b) => (b.isDirectory - a.isDirectory) || a.name.localeCompare(b.name, 'zh-CN', { numeric: true }));
    res.json({ path: dirPath, parent: dirPath === '/' ? null : up(dirPath), entries });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 列出文件夹里的图片（相册；不递归，就是「那个文件夹里面的图片」）
app.get('/api/images', (req, res) => {
  const dirPath = req.query.path;
  if (!dirPath) return res.status(400).json({ error: '缺少 path' });
  try {
    if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
      return res.status(404).json({ error: '目录不存在' });
    }
    const images = fs.readdirSync(dirPath)
      .map(name => entryInfo(dirPath, name))
      .filter(e => e && !e.isDirectory && e.isImage)
      .sort((a, b) => a.name.localeCompare(b.name, 'zh-CN', { numeric: true }))
      .map(e => ({ name: e.name, path: join(dirPath, e.name), size: e.size, mtime: e.mtime }));
    res.json({ path: dirPath, images });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 图片字节（同源直出，绕开 COEP；ETag 按 mtime+size，改图自动失效）
app.get('/api/image', (req, res) => {
  const filePath = req.query.path;
  if (!filePath) return res.status(400).json({ error: '缺少 path' });
  const ext = extname(filePath).toLowerCase();
  if (!IMAGE_EXTS.has(ext)) return res.status(400).json({ error: '不是图片文件' });
  try {
    const st = fs.statSync(filePath);
    if (!st.isFile()) return res.status(400).json({ error: '不是文件' });
    const etag = `"${crypto.createHash('md5').update(`${filePath}:${st.mtimeMs}:${st.size}`).digest('hex')}"`;
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) return res.status(304).end();
    res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
    res.setHeader('Content-Length', st.size);
    createReadStream(filePath).pipe(res);
  } catch (e) {
    res.status(404).json({ error: '图片不存在' });
  }
});

// ---------- 远程图片同源代理（图片链接模式） ----------
// JSOS 强制 COEP require-corp：应用 iframe 直链外域图片无 CORP 头一律 ERR_BLOCKED_BY_RESPONSE，
// 必须由服务端拉取后同源直出。出站照 §7.5/music lib/http.js 策略：容器内（读到 PROXY_URL）全走
// 系统 CORS 代理（Vercel 安全形态：encoded 路径 + query key，零 preflight）；本机直跑直连。
const PROXY_URL = String(process.env.PROXY_URL || '').replace(/\/+$/, '');
const PROXY_KEY = String(process.env.PROXY_KEY || 'hello-world');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

function sniffImage(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf[0] === 0x47 && buf[1] === 0x49) return 'image/gif';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf[0] === 0x42 && buf[1] === 0x4d) return 'image/bmp';
  if (buf.subarray(4, 8).toString('latin1') === 'ftyp') return 'image/avif';
  if (buf.subarray(0, 200).toString('latin1').toLowerCase().includes('<svg')) return 'image/svg+xml';
  return null;
}

app.get('/api/remote', async (req, res) => {
  const u = String(req.query.url || '');
  if (!/^https?:\/\//i.test(u) || u.length > 2048) return res.status(400).json({ error: '无效的图片 URL' });
  try {
    const target = PROXY_URL
      ? `${PROXY_URL}/${encodeURIComponent(u)}?x-cors-proxy-key=${encodeURIComponent(PROXY_KEY)}`
      : u;
    const r = await fetch(target, {
      redirect: 'follow',
      headers: { 'user-agent': UA, accept: 'image/*,*/*;q=0.8' },
      signal: AbortSignal.timeout(20000),
    });
    if (!r.ok) return res.status(502).json({ error: `图片拉取失败（HTTP ${r.status}）` });
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length > 20 * 1024 * 1024) return res.status(413).json({ error: '图片超过 20MB' });
    const ctype = String(r.headers.get('content-type') || '').toLowerCase();
    const sniffed = sniffImage(buf);
    if (!ctype.startsWith('image/') && !sniffed) return res.status(400).json({ error: '该链接不是图片' });
    const etag = '"r-' + crypto.createHash('md5').update(buf).digest('hex').slice(0, 20) + '"';
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) return res.status(304).end();
    res.setHeader('Content-Type', ctype.startsWith('image/') ? ctype : (sniffed || 'application/octet-stream'));
    res.setHeader('Content-Length', buf.length);
    res.end(buf);
  } catch (e) {
    res.status(502).json({ error: '图片拉取失败：' + (e.name === 'TimeoutError' ? '请求超时' : e.message) });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`poster running on ${PORT} (root=${BROWSE_ROOT})`));
