/**
 * poster 共享核心：服务端存储（workspace/data/poster/state.json，§7.9 模式 A）
 * 同步：主页面 ↔ 小组件用 BroadcastChannel 通知 + 轮询/可见性兜底。
 */

export const SYNC_CHANNEL = 'poster-sync';

export async function loadState() {
  try {
    const res = await fetch('/api/state', { cache: 'no-store' });
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
}

export async function saveState(state) {
  try {
    const res = await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    });
    if (!res.ok) throw new Error(await res.text());
  } catch (e) {
    console.error('保存海报设置失败:', e);
    return;
  }
  notifyChange();
}

/** 跨页面即时通知（同一容器内同源）；带 token，过滤同页面自己发给自己的回声 */
const SELF_TOKEN = Math.random().toString(36).slice(2);

export function notifyChange() {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.postMessage({ token: SELF_TOKEN, type: 'state-updated' });
    ch.close();
  } catch {}
}

export function onExternalChange(cb) {
  try {
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    ch.onmessage = (e) => {
      if (e.data && e.data.token !== SELF_TOKEN) cb();
    };
  } catch {}
}

export function imgUrl(path) {
  return '/api/image?path=' + encodeURIComponent(path);
}

/** 外链图片必须经服务端 /api/remote 同源直出（COEP 会拦无 CORP 头的跨域图） */
export function remoteImgUrl(url) {
  return '/api/remote?url=' + encodeURIComponent(url);
}

/** 图片元素实际用的 src：本地路径走 /api/image，http(s) 外链走 /api/remote */
export function picSrc(path) {
  return /^https?:\/\//i.test(path) ? remoteImgUrl(path) : imgUrl(path);
}

/** 从 URL 提取展示名（取路径末段，去掉查询串） */
export function urlName(u) {
  try {
    const p = new URL(u).pathname.split('/').filter(Boolean).pop();
    return decodeURIComponent(p || new URL(u).hostname);
  } catch {
    return u.slice(0, 40);
  }
}

/** 图片展示名：本地路径取文件名，外链取 URL 末段 */
export function picName(path) {
  return /^https?:\/\//i.test(path) ? urlName(path) : baseName(path);
}

/** 轮播步进：随机时保证换一张 */
export function stepIndex(i, len, order) {
  if (len <= 1) return 0;
  if (order === 'random') {
    let n;
    do { n = Math.floor(Math.random() * len); } while (n === i);
    return n;
  }
  return (i + 1) % len;
}

export function baseName(p) {
  if (!p) return '';
  return p.replace(/[\\/]+$/, '').split(/[\\/]/).pop();
}
