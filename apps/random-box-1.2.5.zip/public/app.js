/**
 * 随机盒子 —— 前端
 * ---------------------------------------------------------------
 * 界面只做一件事：随机抽一条，新标签打开。
 * 站点配置写在服务端的 lib/sites.js，这里不提供增删改，只控制开关。
 *
 * 所有用户内容写进 DOM 前统一转义，不直接 innerHTML 拼接。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  let sites = [];

  /* ------------------------------ 工具 ------------------------------ */

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  async function api(path, options = {}) {
    let res;
    try {
      res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...options });
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    let data = null;
    try { data = await res.json(); } catch { /* 非 JSON 响应 */ }
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data || {};
  }

  const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body || {}) });

  /* ------------------------------ 渲染 ------------------------------ */

  function renderSites() {
    $('#site-empty').hidden = sites.length > 0;
    $('#site-list').innerHTML = sites.map((s) => `
      <div class="site-card ${s.enabled ? '' : 'disabled'}" data-id="${escapeHtml(s.id)}">
        <div class="site-top">
          <div class="site-main">
            <div class="site-name">
              <b>${escapeHtml(s.name)}</b>
              <span class="tag">${escapeHtml(s.kindLabel || s.kind || '')}</span>
              ${s.enabled ? '' : '<span class="tag">已关闭</span>'}
            </div>
            ${s.note ? `<div class="site-note">${escapeHtml(s.note)}</div>` : ''}
          </div>
          <div class="site-actions">
            <button class="switch ${s.enabled ? 'on' : ''}" data-act="toggle"
                    title="${s.enabled ? '点击关闭' : '点击开启'}" aria-label="启用状态"></button>
            <button class="btn ghost small" data-act="pick" ${s.enabled ? '' : 'disabled'}>随机</button>
          </div>
        </div>
      </div>`).join('');
  }

  async function refresh() {
    const s = await api('/api/sites');
    const kinds = Object.fromEntries((s.kinds || []).map((k) => [k.kind, k.label]));
    sites = (s.sites || []).map((x) => ({ ...x, kindLabel: kinds[x.kind] || x.kind }));
    renderSites();
  }

  /* ------------------------------ 随机抽取 ------------------------------ */

  /** 顶栏「随机全部」的 busy 状态 */
  function setTopBusy(busy) {
    const btn = $('#btn-flip');
    btn.disabled = busy;
    btn.querySelector('span').textContent = busy ? '抽取中…' : '随机全部';
  }

  /**
   * 抽取。busy 状态显示在触发本次抽取的按钮上：
   *  - 点顶栏「随机全部」→ 顶栏按钮进入抽取中
   *  - 点卡片「随机」→ 那张卡片的按钮进入抽取中
   */
  async function doFlip(siteId, btn) {
    const prevText = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = '抽取中…'; }
    else setTopBusy(true);
    try {
      const data = await post('/api/pick', { siteId: siteId || undefined });
      // 拿到结果再开新标签。抽取耗时若超过浏览器约 5 秒的用户激活窗口，
      // window.open 会被弹窗拦截器拦下（返回 null）→ toast 提示重试。
      // 注意：不能带 'noopener' 第三参——带它时 open 按规范永远返回 null，
      // "被拦"判断就失效了（会误报"被拦截"，实际新标签已打开）
      const w = window.open(data.item.url, '_blank');
      if (!w) toast('浏览器拦截了自动打开，请再点一次随机', 'error');
    } catch (e) {
      toast(e.message || '抽取失败', 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = prevText; }
      else setTopBusy(false);
    }
  }

  /* ------------------------------ 启动 ------------------------------ */

  /**
   * 把 JSOS 的 CORS 代理配置上报给服务端。
   * WebContainer 内服务端直连外站会被 CORS 拦掉，抓取层需要代理兜底；
   * 本机直跑时拿不到 window.JSOS，跳过上报（直连本来就能通）。
   */
  async function relayProxyConfig() {
    try {
      const cfg = await window.JSOS?.getProxyConfig?.();
      if (cfg && cfg.url) await post('/api/relay', { url: cfg.url, key: cfg.key });
    } catch { /* 拿不到就算了，直连优先 */ }
  }

  function bind() {
    $('#btn-flip').addEventListener('click', () => doFlip());

    // 站点列表：开关 + 单站随机（按 data-id 定位，不用数组下标）
    $('#site-list').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const id = btn.closest('.site-card')?.dataset.id;
      if (!id) return;

      if (btn.dataset.act === 'toggle') {
        try {
          const r = await post(`/api/sites/${encodeURIComponent(id)}/toggle`);
          sites = r.sites || sites;
          renderSites();
        } catch (err) { toast(err.message, 'error'); }
      } else if (btn.dataset.act === 'pick') {
        doFlip(id, btn);
      }
    });
  }

  bind();
  relayProxyConfig();
  refresh().catch((e) => toast('加载失败：' + e.message, 'error'));
})();
