/**
 * DJ 音乐 —— 服务端
 * ---------------------------------------------------------------
 * 熊猫DJ 排行榜（六榜）浏览 + 内置播放器试听 + 一键下载。
 *
 * 接口：
 *   GET /api/rank?t=<榜单id>   抓取并归一化榜单（服务端出站，见 lib/dangdj.js）
 *   GET /api/audio?u=<url>     同源流式代理 mp3（透传 Range，支持拖动定位）；&dl=1 时附下载头
 *   GET /api/img?u=<url>       同源图片代理（封面）
 *   GET /api/health
 *
 * 为什么音频/图片都必须同源代理（AGENTS.md §5.5）：
 *   JSOS 强制 COEP: require-corp，跨域资源没有 CORP 头一律 ERR_BLOCKED_BY_RESPONSE；
 *   上游 mv.dangdj.com / app.dangdj.com 都不发 CORP → iframe 里直链必被拦。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outboundFetch, setProxyConfig, getProxyConfig } from './lib/http.js';
import { fetchRank, isAllowedHost, RANK_IDS, RANK_TYPES } from './lib/dangdj.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

// 容器内自动注入（本机直跑没有 → 直连）
if (process.env.PROXY_URL) {
  setProxyConfig({ url: process.env.PROXY_URL, key: process.env.PROXY_KEY || '' });
}

const app = express();
app.use(express.static(join(__dirname, 'public')));

/** 解析并校验资源地址：仅允许 dangdj.com 域名下的 http(s)（防 SSRF） */
function parseAssetUrl(raw) {
  let u;
  try {
    u = new URL(String(raw || ''));
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (!isAllowedHost(u.hostname)) return null;
  return u;
}

const sendFail = (res, status, error) => res.status(status).json({ ok: false, error });

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    service: 'dj-music',
    proxyConfigured: !!getProxyConfig(),
    ranks: RANK_TYPES.map((t) => t.id),
    time: new Date().toISOString(),
  });
});

/* ------------------------------ 榜单 ------------------------------ */

app.get('/api/rank', async (req, res) => {
  const type = String(req.query.t || 'newFaBu');
  if (!RANK_IDS.has(type)) {
    return sendFail(res, 400, `未知榜单类型：${type}`);
  }
  try {
    const data = await fetchRank(type);
    res.json({ ok: true, ...data });
  } catch (err) {
    sendFail(res, 502, `榜单获取失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 音频流代理（Range 透传） ------------------------------ */

app.get('/api/audio', async (req, res) => {
  const target = parseAssetUrl(req.query.u);
  if (!target) return sendFail(res, 400, '仅允许代理 dangdj.com 域名下的音频地址');

  const headers = {};
  if (req.headers.range) headers.Range = String(req.headers.range);

  try {
    const { res: up } = await outboundFetch(target.href, {
      headers,
      timeout: 30000,
      // 206 时 res.ok 为 false，必须显式放行；同时排除代理层的文本错误体
      isOk: (r) => {
        if (r.status !== 200 && r.status !== 206) return false;
        const ct = (r.headers.get('content-type') || '').toLowerCase();
        return !ct.includes('text/') && !ct.includes('json');
      },
    });

    const upType = (up.headers.get('content-type') || '').toLowerCase();
    res.status(up.status);
    res.setHeader('Content-Type', upType.startsWith('audio/') ? upType : 'audio/mpeg');
    for (const h of ['content-length', 'content-range']) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    // 明确告知浏览器可 Range 定位（上游 HEAD 实测 accept-ranges: bytes）
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-store');

    if (req.query.dl === '1') {
      const name = decodeURIComponent(target.pathname.split('/').pop() || 'audio.mp3').replace(/[\\/:*?"<>|]/g, '_');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${name.replace(/[^\x20-\x7e]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(name)}`,
      );
    }

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy());
    res.on('close', () => stream.destroy());
    stream.pipe(res);
  } catch (err) {
    if (!res.headersSent) sendFail(res, 502, `音频拉取失败：${err?.message || '未知错误'}`);
    else res.destroy();
  }
});

/* ------------------------------ 图片代理 ------------------------------ */

app.get('/api/img', async (req, res) => {
  const target = parseAssetUrl(req.query.u);
  if (!target) return sendFail(res, 400, '仅允许代理 dangdj.com 域名下的图片地址');

  try {
    const { res: up } = await outboundFetch(target.href, {
      timeout: 15000,
      isOk: (r) => r.ok && (r.headers.get('content-type') || '').toLowerCase().startsWith('image/'),
    });

    res.status(200);
    res.setHeader('Content-Type', up.headers.get('content-type') || 'image/jpeg');
    const len = up.headers.get('content-length');
    if (len) res.setHeader('Content-Length', len);
    // 封面按 URL 内容寻址，可长缓存（上游 CDN 已实测可达且无防盗链）
    res.setHeader('Cache-Control', 'public, max-age=86400');

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy());
    res.on('close', () => stream.destroy());
    stream.pipe(res);
  } catch (err) {
    if (!res.headersSent) sendFail(res, 502, `图片拉取失败：${err?.message || '未知错误'}`);
    else res.destroy();
  }
});

app.listen(port, () => {
  console.log(`[dj-music] listening on http://localhost:${port} (proxy: ${getProxyConfig() ? 'on' : 'off'})`);
});
