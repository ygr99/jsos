// 音乐播放器应用
// [存储规范] music_page_*（含 musicDynamicTheme）键值经 CloudStore 存服务端
// DATA_DIR/storage.json（容器内 = workspace/data/<appId>，卸载删数据由平台整目录清除）；
// 内存镜像 + 400ms 防抖写回，调用点语义与 localStorage 一致
const CloudStore = (() => {
  const MATCH = (k) => typeof k === 'string' && (k.startsWith('music_page_') || k === 'musicDynamicTheme');
  const mem = new Map();
  let readyPromise = null;
  let flushTimer = null;

  async function flush() {
    try {
      await fetch('/api/storage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(mem)),
      });
    } catch (e) { console.error('云端存储写入失败:', e); }
  }
  function scheduleFlush() {
    clearTimeout(flushTimer);
    flushTimer = setTimeout(flush, 400);
  }

  return {
    /** 启动时调用一次：服务端有数据 → 全量进内存并清本机残留；服务端为空 → 首次迁移本机数据 */
    ready() {
      if (readyPromise) return readyPromise;
      readyPromise = (async () => {
        try {
          const res = await fetch('/api/storage', { cache: 'no-store' });
          const data = await res.json();
          if (data && typeof data === 'object' && Object.keys(data).length) {
            Object.entries(data).forEach(([k, v]) => mem.set(k, v));
            Object.keys(localStorage).filter(MATCH).forEach((k) => localStorage.removeItem(k));
          } else {
            const legacy = {};
            Object.keys(localStorage).filter(MATCH).forEach((k) => {
              legacy[k] = localStorage.getItem(k);
              localStorage.removeItem(k);
            });
            if (Object.keys(legacy).length) {
              Object.entries(legacy).forEach(([k, v]) => mem.set(k, v));
              await flush();
            }
          }
        } catch (e) {
          console.error('云端存储加载失败:', e);
        }
      })();
      return readyPromise;
    },
    get(k) { return MATCH(k) ? (mem.has(k) ? mem.get(k) : null) : localStorage.getItem(k); },
    set(k, v) { if (MATCH(k)) { mem.set(k, v); scheduleFlush(); } else localStorage.setItem(k, v); },
    remove(k) { if (MATCH(k)) { mem.delete(k); scheduleFlush(); } else localStorage.removeItem(k); },
  };
})();

const MusicApp = {
  // 状态
  state: {
    search: '',
    searching: false,
    results: [],
    source: 'netease',
    playlists: [],
    activeListId: '',
    nowPlayingListId: '',
    currentIndex: -1,
    // 当前歌曲在 nowPlayingListId 歌单里的位置：队列播放时 currentIndex 指向队列，
    // 队列播完后靠它回落到歌单继续播
    listIndex: -1,
    // 播放队列：当前播放的永远是队首（index 0），其后才是待播；歌播完自动移出
    queue: [],
    queueSeq: 0,          // 入队序号（_q），正序/倒序排序用
    playContext: 'list',  // 'list' | 'queue' —— currentIndex 属于哪个数组
    drawerView: 'queue',  // 侧边栏视图：queue | playlist
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    loopMode: 'order', // order, repeat, single, shuffle
    volume: 100,
    playbackRate: 1,
    dynamicTheme: false,
    eqGains: new Array(10).fill(0),
    eqPreset: 'Default',
    eqConnected: false,
    loadingSongId: null,
    isRetrying: false,
    editContext: null
  },

  // 常量
  constants: {
    PLAYLISTS_STORAGE_KEY: 'music_page_playlists_v1',
    QUEUE_STORAGE_KEY: 'music_page_queue_v1',
    DRAWER_VIEW_STORAGE_KEY: 'music_page_drawer_view_v1',
    LAST_STATE_STORAGE_KEY: 'music_page_last_state_v1',
    THEME_STORAGE_KEY: 'musicDynamicTheme',
    AI_ANALYSIS_STORAGE_KEY: 'music_page_ai_analysis_v1',
    EQ_BANDS: [80, 100, 125, 250, 500, 1000, 2000, 4000, 8000, 16000],
    EQ_PRESETS: {
      'Default': [0,0,0,0,0,0,0,0,0,0],
      'Pop': [4,3,2,1,0,0,1,2,3,2],
      'Dance': [6,5,4,2,0,-1,0,1,2,1],
      'Blues': [2,2,2,3,2,1,2,1,0,-1],
      'Classical': [0,0,0,0,0,0,0,1,2,3],
      'Jazz': [2,2,1,1,0,0,1,2,1,0],
      'Ballad': [1,1,0,0,2,3,2,1,0,-1],
      'Electronic': [5,4,3,0,-1,-2,0,2,4,5],
      'Rock': [3,2,1,0,-1,0,2,3,2,1],
      'Country': [0,0,0,1,2,2,3,2,1,0],
      'Vocal': [-2,-1,0,1,3,4,3,1,-1,-2]
    },
    EQ_PRESET_TEXT: {
      'Default': '默认',
      'Pop': '流行',
      'Dance': '舞曲',
      'Blues': '蓝调',
      'Classical': '古典',
      'Jazz': '爵士',
      'Ballad': '慢歌',
      'Electronic': '电子乐',
      'Rock': '摇滚',
      'Country': '乡村',
      'Vocal': '人声'
    },
    MUSIC_SOURCES: [
      { key: 'netease', name: '网易云', icon: '🎵' },
      { key: 'qq', name: 'QQ音乐', icon: '🎶' },
      { key: 'bilibili', name: '哔哩哔哩', icon: '📺' },
      { key: 'douyin', name: '抖音', icon: '🎬' }
    ],
    LOOP_MODES: [
      { key: 'order', icon: 'fa-repeat', title: '顺序播放' },
      { key: 'repeat', icon: 'fa-rotate', title: '列表循环' },
      { key: 'single', icon: 'fa-rotate', title: '单曲循环', badge: '1' },
      { key: 'shuffle', icon: 'fa-shuffle', title: '随机播放' }
    ],
    PLAN_ITEMS: [
      { id: 1, text: '音乐解析：抖音视频解析，QQ音乐，酷狗，酷我等等等', completed: false },
      { id: 2, text: '音乐推荐：不知道咋推荐', completed: false },
      { id: 3, text: '导入功能：导入在线歌单，音乐数据导出本地和导入本地', completed: false },
      { id: 4, text: '播放功能：缓存歌曲播放失败重试机制，刷新音频链接', completed: true },
      { id: 5, text: '播放功能：音量控制，速度控制，全局的', completed: true },
      { id: 6, text: '搜索歌词：支持搜索歌词（有些歌曲没有歌词，搜索添加歌词）', completed: true },
      { id: 7, text: '歌词效果：逐字歌词，模糊歌词，等等等', completed: false },
      { id: 8, text: '外观设置：音乐可视化动效，页面背景，毛玻璃效果，等等等', completed: false },
      { id: 9, text: '其他设置：一些音乐平台推荐', completed: false },
      { id: 10, text: '（更多想法，敬请期待…）', completed: false }
    ]
  },

  // DOM 元素
  elements: {},

  // 音频上下文
  audioContext: null,
  mediaSource: null,
  eqFilters: null,

  // 初始化
  init() {
    this.cacheElements();
    this.bindEvents();
    this.initQueue();       // 队列要先恢复，restoreLastState 才能定位队列里的歌
    this.initPlaylists();
    this.initEQ();
    this.loadTheme();
    this.renderPlanList();
    this.renderEQPresets();
    this.renderEQSliders();
    this.updatePlaceholder();
    this.initLyricsInteraction();
    this.switchDrawerView(this.state.drawerView); // 恢复上次停留的侧边栏视图
  },

  // 缓存 DOM 元素
  cacheElements() {
    this.elements = {
      musicPage: document.getElementById('musicPage'),
      settingsBtn: document.getElementById('settingsBtn'),
      sourceSelect: document.getElementById('sourceSelect'),
      searchInput: document.getElementById('searchInput'),
      searchBtn: document.getElementById('searchBtn'),
      clearSearch: document.getElementById('clearSearch'),
      albumCover: document.getElementById('albumCover'),
      albumPlaceholder: document.getElementById('albumPlaceholder'),
      randomSongBtn: document.getElementById('randomSongBtn'),
      randomSongBtnMobile: document.getElementById('randomSongBtnMobile'),
      songTitle: document.getElementById('songTitle'),
      songArtist: document.getElementById('songArtist'),
      lyricsList: document.getElementById('lyricsList'),
      lyricsEmpty: document.getElementById('lyricsEmpty'),
      lyricsContainer: document.getElementById('lyricsContainer'),
      timeLeft: document.getElementById('timeLeft'),
      timeRight: document.getElementById('timeRight'),
      progressBar: document.getElementById('progressBar'),
      volumeBtn: document.getElementById('volumeBtn'),
      volumeSlider: document.getElementById('volumeSlider'),
      volumeSliderContainer: document.getElementById('volumeSliderContainer'),
      speedBtn: document.getElementById('speedBtn'),
      speedSlider: document.getElementById('speedSlider'),
      speedSliderContainer: document.getElementById('speedSliderContainer'),
      loopBtn: document.getElementById('loopBtn'),
      prevBtn: document.getElementById('prevBtn'),
      playBtn: document.getElementById('playBtn'),
      nextBtn: document.getElementById('nextBtn'),
      playlistBtn: document.getElementById('playlistBtn'),
      searchModal: document.getElementById('searchModal'),
      closeSearchModal: document.getElementById('closeSearchModal'),
      searchLoading: document.getElementById('searchLoading'),
      searchEmpty: document.getElementById('searchEmpty'),
      resultList: document.getElementById('resultList'),
      settingsModal: document.getElementById('settingsModal'),
      closeSettingsModal: document.getElementById('closeSettingsModal'),
      dynamicTheme: document.getElementById('dynamicTheme'),
      settingsItems: document.querySelectorAll('.settings-item'),
      basicTab: document.getElementById('basicTab'),
      planTab: document.getElementById('planTab'),
      changelogTab: document.getElementById('changelogTab'),
      planList: document.getElementById('planList'),
      eqModal: document.getElementById('eqModal'),
      closeEqModal: document.getElementById('closeEqModal'),
      eqWarning: document.getElementById('eqWarning'),
      eqPresets: document.getElementById('eqPresets'),
      eqSliders: document.getElementById('eqSliders'),
      playlistDrawer: document.getElementById('playlistDrawer'),
      closeDrawer: document.getElementById('closeDrawer'),
      playlistCount: document.getElementById('playlistCount'),
      newPlaylistBtn: document.getElementById('newPlaylistBtn'),
      playlistTabs: document.getElementById('playlistTabs'),
      playlistFilter: document.getElementById('playlistFilter'),
      clearFilter: document.getElementById('clearFilter'),
      playlistItems: document.getElementById('playlistItems'),
      drawerTitle: document.getElementById('drawerTitle'),
      drawerTabs: document.getElementById('drawerTabs'),
      playlistView: document.getElementById('playlistView'),
      queueView: document.getElementById('queueView'),
      queueTabBadge: document.getElementById('queueTabBadge'),
      enqueueAllBtn: document.getElementById('enqueueAllBtn'),
      queueItems: document.getElementById('queueItems'),
      queueCount: document.getElementById('queueCount'),
      playQueueBtn: document.getElementById('playQueueBtn'),
      sortAscBtn: document.getElementById('sortAscBtn'),
      sortDescBtn: document.getElementById('sortDescBtn'),
      sortShuffleBtn: document.getElementById('sortShuffleBtn'),
      clearQueueBtn: document.getElementById('clearQueueBtn'),
      editModal: document.getElementById('editModal'),
      closeEditModal: document.getElementById('closeEditModal'),
      editName: document.getElementById('editName'),
      editArtist: document.getElementById('editArtist'),
      editLrc: document.getElementById('editLrc'),
      lrcGroup: document.getElementById('lrcGroup'),
      searchLrcBtn: document.getElementById('searchLrcBtn'),
      clearLrcBtn: document.getElementById('clearLrcBtn'),
      saveEditBtn: document.getElementById('saveEditBtn'),
      cancelEditBtn: document.getElementById('cancelEditBtn'),
      lyricSearchModal: document.getElementById('lyricSearchModal'),
      closeLyricSearchModal: document.getElementById('closeLyricSearchModal'),
      lyricSource: document.getElementById('lyricSource'),
      lyricSearchInput: document.getElementById('lyricSearchInput'),
      searchLyricBtn: document.getElementById('searchLyricBtn'),
      lyricSearchLoading: document.getElementById('lyricSearchLoading'),
      lyricSearchEmpty: document.getElementById('lyricSearchEmpty'),
      lyricResultList: document.getElementById('lyricResultList'),
      analyzeBtn: document.getElementById('analyzeBtn'),
      analyzeBtnMobile: document.getElementById('analyzeBtnMobile'),
      analyzeModal: document.getElementById('analyzeModal'),
      closeAnalyzeModal: document.getElementById('closeAnalyzeModal'),
      analyzeSongName: document.getElementById('analyzeSongName'),
      analyzeSongArtist: document.getElementById('analyzeSongArtist'),
      analyzeLoading: document.getElementById('analyzeLoading'),
      analyzeActions: document.getElementById('analyzeActions'),
      analyzeRetryBtn: document.getElementById('analyzeRetryBtn'),
      analyzeContent: document.getElementById('analyzeContent'),
      audioPlayer: document.getElementById('audioPlayer'),
      loadingOverlay: document.getElementById('loadingOverlay')
    };
  },

  // 显示加载动画
  showLoading() {
    if (this.elements.loadingOverlay) {
      this.elements.loadingOverlay.style.display = 'block';
    }
  },

  // 隐藏加载动画
  hideLoading() {
    if (this.elements.loadingOverlay) {
      this.elements.loadingOverlay.style.display = 'none';
    }
  },

  // 绑定事件
  bindEvents() {
    const { elements, state } = this;

    // 搜索
    elements.sourceSelect.addEventListener('change', (e) => {
      state.source = e.target.value;
      this.updatePlaceholder();
    });

    elements.searchInput.addEventListener('input', (e) => {
      state.search = e.target.value;
      elements.clearSearch.classList.toggle('visible', state.search.length > 0);
    });

    elements.searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.performSearch();
    });

    elements.searchBtn.addEventListener('click', () => this.performSearch());
    elements.clearSearch.addEventListener('click', () => {
      state.search = '';
      elements.searchInput.value = '';
      elements.clearSearch.classList.remove('visible');
    });

    // 设置
    elements.settingsBtn.addEventListener('click', () => {
      elements.settingsModal.classList.add('active');
    });

    elements.closeSettingsModal.addEventListener('click', () => {
      elements.settingsModal.classList.remove('active');
    });

    elements.dynamicTheme.addEventListener('change', (e) => {
      state.dynamicTheme = e.target.checked;
      CloudStore.set(this.constants.THEME_STORAGE_KEY, state.dynamicTheme ? '1' : '0');
      if (state.dynamicTheme) {
        this.applyThemeFromCurrentSong();
      } else {
        this.resetTheme();
      }
    });

    elements.settingsItems.forEach(item => {
      item.addEventListener('click', () => {
        elements.settingsItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        const tab = item.dataset.tab;
        elements.basicTab.style.display = tab === 'basic' ? 'block' : 'none';
        elements.planTab.style.display = tab === 'plan' ? 'block' : 'none';
        elements.changelogTab.style.display = tab === 'changelog' ? 'block' : 'none';
      });
    });

    // 搜索结果弹窗
    elements.closeSearchModal.addEventListener('click', () => {
      elements.searchModal.classList.remove('active');
    });

    // 播放控制
    elements.playBtn.addEventListener('click', () => this.togglePlay());
    elements.prevBtn.addEventListener('click', () => this.handlePrev());
    elements.nextBtn.addEventListener('click', () => this.handleNext());
    elements.loopBtn.addEventListener('click', () => this.toggleLoopMode());

    // 进度条
    elements.progressBar.addEventListener('input', (e) => {
      const time = (e.target.value / 100) * state.duration;
      elements.audioPlayer.currentTime = time;
      state.currentTime = time;
    });

    // 音量
    elements.volumeBtn.addEventListener('click', () => {
      const visible = elements.volumeSliderContainer.style.display === 'block';
      elements.volumeSliderContainer.style.display = visible ? 'none' : 'block';
      elements.speedSliderContainer.style.display = 'none';
    });

    elements.volumeSlider.addEventListener('input', (e) => {
      state.volume = parseInt(e.target.value);
      elements.audioPlayer.volume = state.volume / 100;
      this.updateVolumeIcon();
      // 更新音量数值显示
      const volumeValue = document.getElementById('volumeValue');
      if (volumeValue) {
        volumeValue.textContent = state.volume + '%';
      }
    });

    // 速度
    elements.speedBtn.addEventListener('click', () => {
      const visible = elements.speedSliderContainer.style.display === 'block';
      elements.speedSliderContainer.style.display = visible ? 'none' : 'block';
      elements.volumeSliderContainer.style.display = 'none';
    });

    elements.speedSlider.addEventListener('input', (e) => {
      state.playbackRate = parseFloat(e.target.value);
      elements.audioPlayer.playbackRate = state.playbackRate;
      // 更新速度数值显示
      const speedValue = document.getElementById('speedValue');
      if (speedValue) {
        speedValue.textContent = state.playbackRate.toFixed(1) + 'x';
      }
    });

    // 歌单 / 播放队列侧边栏
    elements.playlistBtn.addEventListener('click', () => {
      elements.playlistDrawer.classList.add('active');
      this.switchDrawerView(this.state.drawerView);
    });

    elements.closeDrawer.addEventListener('click', () => {
      elements.playlistDrawer.classList.remove('active');
    });

    elements.drawerTabs.querySelectorAll('.drawer-tab').forEach(tab => {
      tab.addEventListener('click', () => this.switchDrawerView(tab.dataset.view));
    });

    elements.newPlaylistBtn.addEventListener('click', () => this.createPlaylist());

    elements.enqueueAllBtn.addEventListener('click', () => this.enqueuePlaylist());
    elements.playQueueBtn.addEventListener('click', () => this.playQueueFromStart());
    elements.sortAscBtn.addEventListener('click', () => this.sortQueue('asc'));
    elements.sortDescBtn.addEventListener('click', () => this.sortQueue('desc'));
    elements.sortShuffleBtn.addEventListener('click', () => this.sortQueue('shuffle'));
    elements.clearQueueBtn.addEventListener('click', () => this.clearQueue());

    elements.playlistFilter.addEventListener('input', () => {
      this.renderPlaylistItems();
    });

    elements.clearFilter.addEventListener('click', () => {
      elements.playlistFilter.value = '';
      this.renderPlaylistItems();
    });

    // 编辑弹窗
    elements.closeEditModal.addEventListener('click', () => {
      elements.editModal.classList.remove('active');
    });

    elements.cancelEditBtn.addEventListener('click', () => {
      elements.editModal.classList.remove('active');
    });

    elements.saveEditBtn.addEventListener('click', () => this.saveEdit());

    elements.searchLrcBtn.addEventListener('click', () => {
      elements.lyricSearchModal.classList.add('active');
      elements.lyricSearchInput.value = `${elements.editName.value} ${elements.editArtist.value}`;
    });

    elements.clearLrcBtn.addEventListener('click', () => {
      elements.editLrc.value = '';
    });

    // 歌词搜索
    elements.closeLyricSearchModal.addEventListener('click', () => {
      elements.lyricSearchModal.classList.remove('active');
    });

    elements.searchLyricBtn.addEventListener('click', () => this.searchLyrics());

    elements.lyricSearchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.searchLyrics();
    });

    // AI歌词解读
    elements.analyzeBtn.addEventListener('click', () => this.openAnalyzeModal());
    if (elements.analyzeBtnMobile) {
      elements.analyzeBtnMobile.addEventListener('click', () => this.openAnalyzeModal());
    }
    elements.closeAnalyzeModal.addEventListener('click', () => {
      elements.analyzeModal.classList.remove('active');
    });

    // 随机一首歌按钮
    if (elements.randomSongBtn) {
      elements.randomSongBtn.addEventListener('click', () => this.openRandomSong());
    }
    if (elements.randomSongBtnMobile) {
      elements.randomSongBtnMobile.addEventListener('click', () => this.openRandomSong());
    }

    // 重新解析按钮
    if (elements.analyzeRetryBtn) {
      elements.analyzeRetryBtn.addEventListener('click', () => this.reanalyzeLyrics());
    }

    // 音频事件
    elements.audioPlayer.addEventListener('timeupdate', () => {
      state.currentTime = elements.audioPlayer.currentTime;
      state.duration = elements.audioPlayer.duration || 0;
      this.updateProgress();
      this.updateLyrics();
    });

    elements.audioPlayer.addEventListener('loadedmetadata', () => {
      state.duration = elements.audioPlayer.duration;
      this.updateProgress();
    });

    elements.audioPlayer.addEventListener('ended', () => {
      this.handleEnded();
    });

    elements.audioPlayer.addEventListener('playing', () => {
      // 播放成功即清零连续失败计数；音频真正开始播出才关闭加载动画
      this.state.playFailCount = 0;
      this.clearLoadingTimeout();
      this.hideLoading();
    });

    elements.audioPlayer.addEventListener('error', (e) => {
      const error = e.target.error;
      console.log('音频播放错误:', error?.code, error?.message);
      this.clearLoadingTimeout();
      this.hideLoading();

      // 只在特定错误码时触发重试
      // 2 = NETWORK_ERROR, 4 = MEDIA_ERR_SRC_NOT_SUPPORTED
      if (!state.isRetrying && state.currentIndex >= 0) {
        // 走助手：currentIndex 可能指向歌单，也可能指向播放队列
        const currentSong = this.getNowPlayingSong();

        // 如果当前歌曲标记为解析失败，则不重试
        if (currentSong?.parseFailed) {
          console.log('歌曲已标记为解析失败，跳过重试');
          return;
        }

        // 防无限循环：同一首歌连续 3 次播放失败（刷新链接也没用）→ 停止重试
        this.state.playFailCount = (this.state.playFailCount || 0) + 1;
        if (this.state.playFailCount >= 3) {
          console.error('连续 3 次播放失败，标记解析失败并停止重试');
          if (currentSong) {
            this.setNowPlayingSong({ ...currentSong, parseFailed: true });
            this.persistNowPlaying();
          }
          this.showToast('多次播放失败，已停止重试，请切换歌曲');
          return;
        }

        if (!error || error.code === 2 || error.code === 4) {
          console.log('音频链接可能已过期，触发重试机制...');
          this.retryCurrentSong();
        }
      }
    });

    // 点击外部关闭弹窗和下拉菜单
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
      }
      // 关闭下拉菜单
      if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');
      }
    });
  },

  // 更新搜索框占位符
  updatePlaceholder() {
    const { source } = this.state;
    const placeholders = {
      netease: '搜索歌曲/歌手',
      qq: '搜索歌曲/歌手',
      bilibili: '请输入哔哩哔哩视频链接',
      douyin: '请输入抖音视频链接',
      soda: '搜索汽水音乐歌曲/歌手'
    };
    this.elements.searchInput.placeholder = placeholders[source] || '搜索歌曲/歌手';
  },

  // 初始化歌单
  initPlaylists() {
    const stored = CloudStore.get(this.constants.PLAYLISTS_STORAGE_KEY);
    if (stored) {
      try {
        this.state.playlists = JSON.parse(stored);
      } catch (e) {
        this.createDefaultPlaylists();
      }
    } else {
      this.createDefaultPlaylists();
    }

    // 存量数据迁移：早期版本存过被反引号包裹的脏 URL（封面 404 / 音频失效），加载时统一清洗
    let migrated = false;
    this.state.playlists.forEach((p) => {
      (p.songs || []).forEach((s) => {
        ['url', 'cover', 'lrc', 'name', 'artist', 'album'].forEach((k) => {
          if (typeof s[k] === 'string' && s[k].includes('`')) {
            s[k] = this.stripBackticks(s[k]);
            migrated = true;
          }
        });
      });
    });
    if (migrated) this.savePlaylists();

    // 设置默认活动歌单
    if (this.state.playlists.length > 0) {
      this.state.activeListId = this.state.playlists[0].id;
      this.state.nowPlayingListId = this.state.playlists[0].id;
    }

    // 恢复最后状态
    this.restoreLastState();
  },

  // 创建默认歌单
  createDefaultPlaylists() {
    const generateId = () => `pl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.state.playlists = [
      { id: generateId(), title: '播放历史', songs: [], system: 'history' },
      { id: generateId(), title: '默认收藏', songs: [], system: 'default' }
    ];
    this.savePlaylists();
  },

  // 保存歌单
  savePlaylists() {
    CloudStore.set(this.constants.PLAYLISTS_STORAGE_KEY, JSON.stringify(this.state.playlists));
  },

  // 恢复最后状态
  restoreLastState() {
    const stored = CloudStore.get(this.constants.LAST_STATE_STORAGE_KEY);
    if (stored) {
      try {
        const { nowPlayingListId, currentIndex, listIndex, playContext } = JSON.parse(stored);
        if (typeof listIndex === 'number') this.state.listIndex = listIndex;

        // 上次是在队列里播放 → 恢复队列上下文（不自动播放）
        if (playContext === 'queue') {
          const song = this.state.queue[currentIndex];
          if (song) {
            this.state.playContext = 'queue';
            this.state.currentIndex = currentIndex;
            this.loadSong(song, false);
            return;
          }
        }

        const list = this.state.playlists.find(p => p.id === nowPlayingListId);
        if (list && currentIndex >= 0 && currentIndex < list.songs.length) {
          this.state.nowPlayingListId = nowPlayingListId;
          this.state.currentIndex = currentIndex;
          this.state.listIndex = currentIndex;
          this.loadSong(list.songs[currentIndex], false);
        }
      } catch (e) {}
    }
  },

  // 保存最后状态（currentIndex 的含义由 playContext 决定）
  saveLastState() {
    const { nowPlayingListId, currentIndex, listIndex, playContext } = this.state;
    CloudStore.set(this.constants.LAST_STATE_STORAGE_KEY, JSON.stringify({
      nowPlayingListId,
      currentIndex,
      listIndex,
      playContext
    }));
  },

  // 初始化播放队列
  initQueue() {
    const stored = CloudStore.get(this.constants.QUEUE_STORAGE_KEY);
    if (stored) {
      try {
        const data = JSON.parse(stored);
        this.state.queue = Array.isArray(data.queue) ? data.queue : [];
        this.state.queueSeq = data.queueSeq || this.state.queue.length;
      } catch (e) {}
    }
    // 默认停在播放队列页（当前播放的歌就在队首）
    const view = CloudStore.get(this.constants.DRAWER_VIEW_STORAGE_KEY);
    this.state.drawerView = view === 'playlist' ? 'playlist' : 'queue';
  },

  // 保存播放队列
  saveQueue() {
    CloudStore.set(this.constants.QUEUE_STORAGE_KEY, JSON.stringify({
      queue: this.state.queue,
      queueSeq: this.state.queueSeq
    }));
  },

  // 下一个入队序号（正序/倒序排序的依据）
  nextQueueSeq() {
    return ++this.state.queueSeq;
  },

  // 初始化均衡器
  initEQ() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.audioContext = new AudioContext();
      }
    } catch (e) {}
  },

  // 加载主题
  loadTheme() {
    const stored = CloudStore.get(this.constants.THEME_STORAGE_KEY);
    this.state.dynamicTheme = stored === '1';
    this.elements.dynamicTheme.checked = this.state.dynamicTheme;
  },

  // 渲染计划列表
  renderPlanList() {
    const html = this.constants.PLAN_ITEMS.map(item => `
      <div class="plan-item">
        <input type="checkbox" class="plan-checkbox" ${item.completed ? 'checked' : ''} disabled>
        <span class="plan-text ${item.completed ? 'completed' : ''}">${item.text}</span>
      </div>
    `).join('');
    this.elements.planList.innerHTML = html;
  },

  // 渲染均衡器预设
  renderEQPresets() {
    const presets = Object.keys(this.constants.EQ_PRESETS);
    const html = presets.map(preset => `
      <button class="eq-preset ${preset === this.state.eqPreset ? 'active' : ''}" data-preset="${preset}">
        ${this.constants.EQ_PRESET_TEXT[preset] || preset}
      </button>
    `).join('');
    this.elements.eqPresets.innerHTML = html;

    this.elements.eqPresets.querySelectorAll('.eq-preset').forEach(btn => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;
        this.applyEQPreset(preset);
      });
    });
  },

  // 渲染均衡器滑块
  renderEQSliders() {
    const html = this.constants.EQ_BANDS.map((freq, i) => `
      <div class="eq-slider-group">
        <input type="range" class="eq-slider" min="-12" max="12" step="0.5" value="0" data-index="${i}" orient="vertical">
        <span class="eq-label">${freq >= 1000 ? Math.round(freq/1000) + 'k' : freq}Hz</span>
      </div>
    `).join('');
    this.elements.eqSliders.innerHTML = html;

    this.elements.eqSliders.querySelectorAll('.eq-slider').forEach(slider => {
      slider.addEventListener('input', (e) => {
        const index = parseInt(e.target.dataset.index);
        const value = parseFloat(e.target.value);
        this.state.eqGains[index] = value;
        this.updateEQ();
      });
    });
  },

  // 应用均衡器预设
  applyEQPreset(preset) {
    this.state.eqPreset = preset;
    this.state.eqGains = [...this.constants.EQ_PRESETS[preset]];

    this.elements.eqPresets.querySelectorAll('.eq-preset').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.preset === preset);
    });

    this.elements.eqSliders.querySelectorAll('.eq-slider').forEach((slider, i) => {
      slider.value = this.state.eqGains[i];
    });

    this.updateEQ();
  },

  // 更新均衡器
  updateEQ() {
    if (this.eqFilters && this.state.eqConnected) {
      this.eqFilters.forEach((filter, i) => {
        filter.gain.value = Math.max(-12, Math.min(12, this.state.eqGains[i]));
      });
    }
  },

  // 连接均衡器
  connectEQ() {
    if (!this.audioContext || this.state.eqConnected) return;

    const audio = this.elements.audioPlayer;
    if (!this.mediaSource) {
      this.mediaSource = this.audioContext.createMediaElementSource(audio);
    }

    if (!this.eqFilters) {
      this.eqFilters = this.constants.EQ_BANDS.map(freq => {
        const filter = this.audioContext.createBiquadFilter();
        filter.type = 'peaking';
        filter.frequency.value = freq;
        filter.Q.value = 1.0;
        filter.gain.value = 0;
        return filter;
      });
    }

    let node = this.mediaSource;
    this.eqFilters.forEach(filter => {
      node.connect(filter);
      node = filter;
    });
    node.connect(this.audioContext.destination);

    this.state.eqConnected = true;
  },

  // 执行搜索
  async performSearch() {
    const { search, source } = this.state;
    if (!search.trim()) return;

    this.state.searching = true;
    this.elements.searchModal.classList.add('active');
    this.elements.searchLoading.style.display = 'block';
    this.elements.searchEmpty.style.display = 'none';
    this.elements.resultList.innerHTML = '';

    try {
      let results = [];

      if (source === 'netease') {
        results = await this.searchNetease(search);
      } else if (source === 'qq') {
        results = await this.searchQQ(search);
      } else if (source === 'bilibili') {
        results = await this.parseBilibili(search);
      } else if (source === 'douyin') {
        results = await this.parseDouyin(search);
      } else if (source === 'soda') {
        results = await this.searchSoda(search);
      }

      this.state.results = results;
      this.renderSearchResults();
    } catch (e) {
      console.error('搜索失败:', e);
      this.elements.searchEmpty.style.display = 'block';
    } finally {
      this.state.searching = false;
      this.elements.searchLoading.style.display = 'none';
    }
  },

  // 搜索网易云 - 使用后端接口
  async searchNetease(keyword) {
    const response = await fetch(`/api/netease/search?q=${encodeURIComponent(keyword)}&limit=30&offset=0`);
    const data = await response.json();

    if (data.code === 200 && data.data?.result?.songs) {
      return data.data.result.songs.map(s => ({
        id: s.id,
        name: s.name,
        artist: s.ar?.map(a => a.name).join(', ') || s.artists?.map(a => a.name).join(', '),
        album: s.al?.name || s.album?.name,
        cover: s.al?.picUrl || s.album?.picUrl,
        duration: s.dt ? Math.round(s.dt / 1000) : undefined,
        source: 'netease'
      }));
    }
    return [];
  },

  // 搜索QQ音乐
  async searchQQ(keyword) {
    const response = await fetch(`/api/qq/search?q=${encodeURIComponent(keyword)}&p=1&n=30`);
    const data = await response.json();

    if (data.code === 200 && data.data?.songs) {
      return data.data.songs.map(s => ({
        id: s.songmid,
        name: s.songname,
        artist: s.singers,
        album: s.album,
        cover: s.cover,
        duration: s.interval,
        source: 'qq',
        albumMid: s.albummid
      }));
    }
    return [];
  },

  // 搜索汽水音乐（暂时休眠：搜索源下拉已移除汽水选项——api.qishui.com 对现有出口全面风控，
  // 恢复选项即恢复搜索；歌单内已有汽水歌曲的播放/歌词走分享页，不受影响）
  async searchSoda(keyword) {
    const response = await fetch(`/api/soda/search?q=${encodeURIComponent(keyword)}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.result_groups?.[0]?.data) {
      return data.data.result_groups[0].data.map(item => {
        const track = item.entity?.track || {};
        const album = track.album || {};
        const artists = track.artists || [];
        // 使用图片代理解决跨域问题
        let coverUrl = null;
        if (album.url_cover?.urls?.[0]) {
          const originalCoverUrl = `${album.url_cover.urls[0]}${album.url_cover.uri}~c5_375x375.jpg`;
          coverUrl = `/api/proxy/image?url=${encodeURIComponent(originalCoverUrl)}`;
        }
        return {
          id: track.id,
          name: track.name,
          artist: artists.map(a => a.name).join(', '),
          album: album.name,
          cover: coverUrl,
          duration: track.duration ? Math.round(track.duration / 1000) : undefined,
          source: 'soda'
        };
      });
    }
    return [];
  },

  // 解析B站
  async parseBilibili(url) {
    const response = await fetch(`/api/bilibili/audio?url=${encodeURIComponent(url)}`);
    const data = await response.json();

    if (data.code === 200 && data.data) {
      const payload = data.data;
      if (payload.isMultiPart && payload.pages) {
        return payload.pages.map(p => ({
          id: `${payload.videoId}#${p.page}`,
          name: p.part || payload.title,
          artist: payload.owner?.name || 'UP主',
          cover: payload.cover,
          source: 'bilibili'
        }));
      }
      return [{
        id: payload.videoId || url,
        name: payload.title,
        artist: payload.owner?.name || 'UP主',
        cover: payload.cover,
        url: payload.audioUrl,
        source: 'bilibili'
      }];
    }
    return [];
  },

  // 解析抖音
  async parseDouyin(url) {
    const response = await fetch('/api/douyin/parse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await response.json();

    if (data.code === 200 && data.data) {
      return [{
        id: url,
        name: data.data.title || '未命名',
        artist: '抖音',
        cover: data.data.cover,
        url: data.data.audioUrl,
        source: 'douyin'
      }];
    }
    return [];
  },

  // 渲染搜索结果
  renderSearchResults() {
    const { results } = this.state;

    if (results.length === 0) {
      this.elements.searchEmpty.style.display = 'block';
      this.elements.resultList.innerHTML = '';
      return;
    }

    this.elements.searchEmpty.style.display = 'none';
    this.elements.resultList.innerHTML = results.map((item, index) => `
      <li class="result-item" data-index="${index}">
        <span class="result-title">${this.escapeHtml(item.name)}</span>
        <span class="result-sub">${this.escapeHtml(item.artist)} ${item.album ? '- ' + this.escapeHtml(item.album) : ''}</span>
      </li>
    `).join('');

    this.elements.resultList.querySelectorAll('.result-item').forEach(item => {
      item.addEventListener('click', () => {
        const index = parseInt(item.dataset.index);
        // 搜索结果直接播放 → 脱离队列上下文，回到歌单（currentIndex 交给 addToPlaylist 定）
        this.state.playContext = 'list';
        this.state.currentIndex = -1;
        this.playSong(this.state.results[index]);
        this.elements.searchModal.classList.remove('active');
      });
    });
  },

  // 播放歌曲
  // queueIndex：这首歌在播放队列里的下标（-1 表示队列外的新歌，会自动入队并置顶）
  async playSong(song, queueIndex = -1) {
    const { source } = song;
    this.state.loadingSongId = song.id;

    // 显示加载动画
    this.showLoading();

    try {
      let targetSong = { ...song };

      // 获取播放链接
      if (!targetSong.url) {
        if (source === 'netease') {
          targetSong = await this.getNeteaseUrl(targetSong);
        } else if (source === 'qq') {
          targetSong = await this.getQQUrl(targetSong);
        } else if (source === 'bilibili' && song.id.includes('#')) {
          const [vid, page] = song.id.split('#');
          targetSong = await this.getBilibiliPageUrl(vid, page);
        } else if (source === 'soda') {
          targetSong = await this.getSodaUrl(targetSong);
        }
      }

      // 如果解析失败且标记为不可重试，显示友好提示
      if (targetSong.parseFailed) {
        this.hideLoading();
        this.showToast('网易云音乐解析失败，请尝试其他平台');
        return;
      }

      if (!targetSong.url) {
        this.hideLoading();
        this.showToast('无法获取播放链接');
        return;
      }

      // 播放即入队：当前播放的这首歌成为队首（先于 addToPlaylist，
      // 这样 addToPlaylist 不会用歌单下标覆盖掉队列下标）
      this.syncQueueOnPlay(targetSong, queueIndex);

      // 添加到对应歌单
      this.addToPlaylist(targetSong);

      // 加载并播放：音频要经多层代理，加载耗时不可控，不能在这里关加载动画，
      // 要等音频真正播出（playing 事件）/ error 事件 / 20s 兜底超时再关
      this.loadSong(targetSong, true);

    } finally {
      this.state.loadingSongId = null;
    }
  },

  // 获取网易云链接 - 使用多个备用接口
  // 部分第三方解析接口返回的字符串被反引号包裹（封面 404 / 音频失效），统一剥离
  stripBackticks(v) {
    return typeof v === 'string' ? v.replace(/^\s*`+|`+\s*$/g, '').trim() : v;
  },

  // 加载动画超时兜底：音频要经多层代理加载，转圈持续到真正播出（playing 事件），
  // 但若上游卡死则 20s 后强制关闭，避免永远转圈
  clearLoadingTimeout() {
    if (this._loadingTimeout) {
      clearTimeout(this._loadingTimeout);
      this._loadingTimeout = null;
    }
  },
  armLoadingTimeout() {
    this.clearLoadingTimeout();
    this._loadingTimeout = setTimeout(() => {
      console.warn('音频加载超过 20s，强制关闭加载动画');
      this.hideLoading();
    }, 20000);
  },

  // 封面统一走同源图片代理：JSOS 强制 COEP require-corp，跨域图片（无 CORP 头）
  // 一律被 ERR_BLOCKED_BY_RESPONSE 拦截，直链永远加载不出来（网易云/QQ/抖音均如此）
  coverSrc(v) {
    const u = this.stripBackticks(v);
    if (!u || !/^https?:\/\//i.test(u)) return u || '';
    const referer = /hdslb\.com|bilivideo/i.test(u) ? 'https://www.bilibili.com/'
      : /(126\.net|music\.163\.com)/i.test(u) ? 'https://music.163.com/'
        : 'https://www.douyin.com/';
    return `/api/proxy/image?url=${encodeURIComponent(u)}&referer=${encodeURIComponent(referer)}`;
  },

  async getNeteaseUrl(song) {
    const level = 'exhigh';

    // 先尝试后端API，后端会处理多个解析接口
    try {
      const response = await fetch(`/api/netease/play?id=${song.id}&level=${level}`);
      const data = await response.json();

      if (data.code === 200 && data.data?.audioUrl) {
        console.log('网易云解析成功:', data.data.source);
        return {
          ...song,
          url: this.stripBackticks(data.data.audioUrl),
          cover: this.stripBackticks(data.data.cover) || song.cover,
          lrc: this.stripBackticks(data.data.lyric) || song.lrc
        };
      }
      
      // 如果后端明确返回不重试标志，直接返回，不再尝试其他接口
      if (data.retry === false) {
        console.log('后端返回不重试标志，跳过其他解析接口');
        return { ...song, parseFailed: true };
      }
    } catch (err) {
      console.log('后端API失败:', err.message);
    }

    // 如果后端失败，尝试备用的前端直连接口
    const parsers = [
      // 1. cenguigui API (更新版)
      async () => {
        const response = await fetch(`https://music-api2.cenguigui.cn/?wy=&id=${song.id}&type=song&format=json&level=${level}`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.url) {
          return {
            ...song,
            url: data.data.url,
            cover: data.data.pic || song.cover,
            lrc: data.data.lyric || song.lrc
          };
        }
        return null;
      },
      // 2. haitangw API
      async () => {
        const response = await fetch(`https://musicapi.haitangw.net/music/wy.php?id=${song.id}&level=${level}&type=json`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.url) {
          return {
            ...song,
            url: data.data.url,
            cover: data.data.pic || song.cover
          };
        }
        return null;
      },
      // 3. cunyuapi
      async () => {
        const response = await fetch(`https://www.cunyuapi.top/163music_play?id=${song.id}&quality=${level}`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.song_file_url) {
          return {
            ...song,
            url: data.song_file_url,
            cover: data.img || song.cover,
            lrc: data.lyric || song.lrc
          };
        }
        return null;
      },
      // 4. xcvts API
      async () => {
        const response = await fetch(`https://api.xcvts.cn/api/music/163music?id=${song.id}&br=999000`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.music) {
          return {
            ...song,
            url: data.data.music,
            cover: data.data.cover || song.cover,
            lrc: data.data.lyric || song.lrc
          };
        }
        return null;
      },
      // 5. ceseeet API
      async () => {
        const response = await fetch(`https://m-api.ceseet.me/url/wy/${song.id}/hires`, {
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'lx-music-request/2.6.0',
            'X-Request-Key': ''
          },
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data) {
          return {
            ...song,
            url: data.data
          };
        }
        return null;
      }
    ];

    let failedCount = 0;
    const maxFailures = 2;

    for (const parser of parsers) {
      try {
        const result = await parser();
        if (result && result.url) {
          result.url = this.stripBackticks(result.url);
          if (result.cover) result.cover = this.stripBackticks(result.cover);
          if (result.lrc) result.lrc = this.stripBackticks(result.lrc);
        }
        if (result && result.url && result.url.startsWith('http')) {
          console.log('网易云备用解析成功');
          return result;
        }
      } catch (err) {
        failedCount++;
        console.log(`备用解析接口失败 (${failedCount}/${maxFailures}):`, err.message);
        
        if (failedCount >= maxFailures) {
          console.log('达到最大失败次数，停止解析');
          break;
        }
        continue;
      }
    }

    console.error('所有网易云解析接口均失败');
    return { ...song, parseFailed: true };
  },

  // MD5 辅助函数
  async md5(string) {
    const encoder = new TextEncoder();
    const data = encoder.encode(string);
    const hashBuffer = await crypto.subtle.digest('MD5', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  // 获取QQ音乐链接
  async getQQUrl(song) {
    const response = await fetch(`/api/qq/play?songmid=${song.id}&albumMid=${song.albumMid || ''}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.audioUrl) {
      // 获取歌词
      try {
        const lrcResp = await fetch(`/api/qq/lyric?songmid=${song.id}`);
        const lrcData = await lrcResp.json();
        if (lrcData.code === 200 && lrcData.data?.lyric) {
          song.lrc = lrcData.data.lyric;
        }
      } catch (e) {}

      return {
        ...song,
        url: data.data.audioUrl,
        cover: data.data.cover || song.cover
      };
    }

    return song;
  },

  // 获取汽水音乐链接
  async getSodaUrl(song) {
    const response = await fetch(`/api/soda/play?id=${song.id}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.audioUrl) {
      // 获取歌词
      try {
        const lrcResp = await fetch(`/api/soda/lyric?id=${song.id}`);
        const lrcData = await lrcResp.json();
        if (lrcData.code === 200 && lrcData.data?.lyric) {
          song.lrc = lrcData.data.lyric;
        }
      } catch (e) {}

      return {
        ...song,
        url: data.data.audioUrl,
        cover: data.data.cover || song.cover
      };
    }

    return song;
  },

  // 获取B站分P链接
  async getBilibiliPageUrl(bvid, page) {
    const response = await fetch(`/api/bilibili/audio?url=https://www.bilibili.com/video/${bvid}?p=${page}`);
    const data = await response.json();

    if (data.code === 200 && data.data) {
      return {
        id: `${bvid}#${page}`,
        name: data.data.title,
        artist: data.data.owner?.name || 'UP主',
        cover: data.data.cover,
        url: data.data.audioUrl,
        source: 'bilibili'
      };
    }

    return null;
  },

  // 添加歌曲到歌单
  addToPlaylist(song) {
    const { source } = song;
    let targetList;

    if (source === 'bilibili') {
      targetList = this.state.playlists.find(p => p.title === '哔哩哔哩');
      if (!targetList) {
        targetList = { id: this.generateId(), title: '哔哩哔哩', songs: [] };
        this.state.playlists.push(targetList);
      }
    } else if (source === 'douyin') {
      targetList = this.state.playlists.find(p => p.title === '抖音');
      if (!targetList) {
        targetList = { id: this.generateId(), title: '抖音', songs: [] };
        this.state.playlists.push(targetList);
      }
    } else {
      targetList = this.state.playlists.find(p => p.system === 'history');
    }

    if (!targetList) return;

    const existingIndex = targetList.songs.findIndex(s => s.id === song.id);
    let songIndex;
    if (existingIndex >= 0) {
      targetList.songs[existingIndex] = song;
      songIndex = existingIndex;
    } else {
      targetList.songs.push(song);
      songIndex = targetList.songs.length - 1;
    }

    this.state.nowPlayingListId = targetList.id;
    this.state.listIndex = songIndex;
    // 队列播放中 currentIndex 是队列下标，不能被歌单下标覆盖
    if (this.state.playContext !== 'queue') this.state.currentIndex = songIndex;
    this.savePlaylists();
    this.saveLastState();
  },

  // 加载歌曲
  loadSong(song, autoPlay = false) {
    const audio = this.elements.audioPlayer;
    this.state.playFailCount = 0;
    let url = this.stripBackticks(song.url);

    // 使用代理
    if (song.source === 'bilibili') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://www.bilibili.com/`;
    } else if (song.source === 'douyin') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://www.douyin.com/`;
    } else if (song.source === 'netease') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://music.163.com/`;
    }

    audio.src = url;
    audio.volume = this.state.volume / 100;
    audio.playbackRate = this.state.playbackRate;

    // 更新UI
    this.elements.songTitle.textContent = song.name || '未知歌曲';
    this.elements.songArtist.textContent = song.artist || '--';

    if (song.cover) {
      const coverUrl = this.coverSrc(song.cover);
      this.elements.albumCover.src = coverUrl;
      this.elements.albumCover.style.display = 'block';
      this.elements.albumPlaceholder.style.display = 'none';

      if (this.state.dynamicTheme) {
        this.applyThemeFromCover(coverUrl);
      }
    } else {
      this.elements.albumCover.style.display = 'none';
      this.elements.albumPlaceholder.style.display = 'flex';
    }

    // 解析歌词
    this.parseLyrics(song.lrc);

    if (autoPlay) {
      this.armLoadingTimeout();
      audio.play().then(() => {
        this.state.isPlaying = true;
        this.updatePlayButton();
      }).catch(() => {});
    }

    // 侧边栏开着就同步一下当前播放高亮（队列/歌单都可能正在播）
    this.refreshDrawerIfOpen();
  },

  // 侧边栏打开时同步当前播放高亮
  refreshDrawerIfOpen() {
    if (!this.elements.playlistDrawer) return;
    if (!this.elements.playlistDrawer.classList.contains('active')) return;
    if (this.state.drawerView === 'queue') this.renderQueue();
    else this.renderPlaylistItems();
  },

  // 解析歌词
  parseLyrics(lrc) {
    this.state.lyrics = [];
    this.elements.lyricsList.innerHTML = '';

    if (!lrc) {
      this.elements.lyricsEmpty.style.display = 'block';
      this.elements.lyricsContainer.style.display = 'none';
      return;
    }

    const lines = lrc.split(/\r?\n/);
    const timeRegex = /\[(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?]/g;
    const lyrics = [];

    lines.forEach(line => {
      let match;
      const times = [];
      while ((match = timeRegex.exec(line)) !== null) {
        const mm = parseInt(match[1]);
        const ss = parseInt(match[2]);
        const ms = match[3] ? parseInt(match[3].padEnd(3, '0')) : 0;
        times.push(mm * 60 + ss + ms / 1000);
      }

      const text = line.replace(timeRegex, '').trim();
      times.forEach(time => {
        lyrics.push({ time, text });
      });
    });

    this.state.lyrics = lyrics.filter(l => l.text).sort((a, b) => a.time - b.time);

    if (this.state.lyrics.length === 0) {
      this.elements.lyricsEmpty.style.display = 'block';
      this.elements.lyricsContainer.style.display = 'none';
    } else {
      this.elements.lyricsEmpty.style.display = 'none';
      this.elements.lyricsContainer.style.display = 'block';
      this.elements.lyricsList.innerHTML = this.state.lyrics.map((l, i) =>
        `<li data-index="${i}">${this.escapeHtml(l.text)}</li>`
      ).join('');
    }
  },

  // 初始化歌词交互
  initLyricsInteraction() {
    const container = this.elements.lyricsContainer;
    let scrollTimeout = null;

    // 鼠标进入 - 暂停自动滚动
    container.addEventListener('mouseenter', () => {
      this.state.lyricsAutoScroll = false;
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
        scrollTimeout = null;
      }
    });

    // 鼠标离开 - 1秒后恢复自动滚动
    container.addEventListener('mouseleave', () => {
      scrollTimeout = setTimeout(() => {
        this.state.lyricsAutoScroll = true;
        this.scrollToActiveLyrics(true); // 带动画回到当前歌词
      }, 1000);
    });

    // 触摸设备支持
    container.addEventListener('touchstart', () => {
      this.state.lyricsAutoScroll = false;
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
        scrollTimeout = null;
      }
    }, { passive: true });

    container.addEventListener('touchend', () => {
      scrollTimeout = setTimeout(() => {
        this.state.lyricsAutoScroll = true;
        this.scrollToActiveLyrics(true);
      }, 2000);
    });
  },

  // 滚动到当前歌词 - 使用 requestAnimationFrame 实现丝滑动画
  scrollToActiveLyrics(animate = false) {
    const activeItem = this.elements.lyricsList.querySelector('li.active');

    if (activeItem) {
      const container = this.elements.lyricsContainer;
      const targetScrollTop = activeItem.offsetTop - container.clientHeight / 2 + activeItem.clientHeight / 2;

      if (!animate) {
        container.scrollTop = targetScrollTop;
        return;
      }

      // 使用自定义动画实现更丝滑的效果
      const startScrollTop = container.scrollTop;
      const distance = targetScrollTop - startScrollTop;
      const duration = 600; // 动画持续时间
      const startTime = performance.now();

      const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

      const animateScroll = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easedProgress = easeOutCubic(progress);

        container.scrollTop = startScrollTop + distance * easedProgress;

        if (progress < 1) {
          requestAnimationFrame(animateScroll);
        }
      };

      requestAnimationFrame(animateScroll);
    }
  },

  // 更新歌词显示
  updateLyrics() {
    const { currentTime, lyrics } = this.state;
    if (!lyrics || lyrics.length === 0) return;

    let activeIndex = -1;
    for (let i = lyrics.length - 1; i >= 0; i--) {
      if (currentTime >= lyrics[i].time) {
        activeIndex = i;
        break;
      }
    }

    if (activeIndex < 0) activeIndex = 0;

    // 只在高亮行变化时才更新
    const items = this.elements.lyricsList.querySelectorAll('li');
    const currentActive = this.elements.lyricsList.querySelector('li.active');
    const currentActiveIndex = currentActive ? parseInt(currentActive.dataset.index) : -1;

    if (currentActiveIndex !== activeIndex) {
      items.forEach((item, i) => {
        item.classList.toggle('active', i === activeIndex);
      });

      // 只有在自动滚动模式下才滚动到当前歌词
      if (this.state.lyricsAutoScroll !== false && items[activeIndex]) {
        this.scrollToActiveLyrics(true); // 使用动画滚动
      }
    }
  },

  // 切换播放/暂停
  togglePlay() {
    const audio = this.elements.audioPlayer;
    if (this.state.isPlaying) {
      audio.pause();
      this.state.isPlaying = false;
    } else {
      if (!audio.src && this.state.currentIndex >= 0) {
        const song = this.getNowPlayingSong();
        if (song) {
          this.loadSong(song, true);
          return;
        }
      }
      audio.play().then(() => {
        this.state.isPlaying = true;
        this.updatePlayButton();
      }).catch(() => {});
    }
    this.updatePlayButton();
  },

  // 更新播放按钮
  updatePlayButton() {
    const icon = this.elements.playBtn.querySelector('i');
    icon.className = this.state.isPlaying ? 'fas fa-pause-circle' : 'fas fa-play-circle';
  },

  // 更新进度
  updateProgress() {
    const { currentTime, duration } = this.state;
    this.elements.timeLeft.textContent = this.formatTime(currentTime);
    this.elements.timeRight.textContent = this.formatTime(duration);

    if (duration > 0) {
      const percent = (currentTime / duration) * 100;
      this.elements.progressBar.value = percent;
    }
  },

  // 更新音量图标
  updateVolumeIcon() {
    const { volume } = this.state;
    const icon = this.elements.volumeBtn.querySelector('i');
    if (volume === 0) {
      icon.className = 'fas fa-volume-mute';
    } else if (volume < 50) {
      icon.className = 'fas fa-volume-down';
    } else {
      icon.className = 'fas fa-volume-up';
    }
  },

  // 切换循环模式
  toggleLoopMode() {
    const modes = ['order', 'repeat', 'single', 'shuffle'];
    const currentIndex = modes.indexOf(this.state.loopMode);
    this.state.loopMode = modes[(currentIndex + 1) % modes.length];

    const mode = this.constants.LOOP_MODES.find(m => m.key === this.state.loopMode);
    this.elements.loopBtn.innerHTML = mode.badge
      ? `<i class="fas ${mode.icon}"></i><span style="font-size:10px;position:absolute;">${mode.badge}</span>`
      : `<i class="fas ${mode.icon}"></i>`;
    this.elements.loopBtn.title = mode.title;
  },

  // 当前播放上下文的歌曲数组（播放队列 或 歌单）
  nowPlayingSongs() {
    if (this.state.playContext === 'queue') return this.state.queue;
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    return list ? list.songs : [];
  },

  // 当前播放的歌曲对象
  getNowPlayingSong() {
    const songs = this.nowPlayingSongs();
    if (this.state.currentIndex < 0) return null;
    return songs[this.state.currentIndex] || null;
  },

  // 写回当前播放的歌曲（解析失败标记、刷新后的链接等）
  setNowPlayingSong(song) {
    const idx = this.state.currentIndex;
    if (idx < 0) return;
    if (this.state.playContext === 'queue') {
      if (this.state.queue[idx]) this.state.queue[idx] = song;
    } else {
      const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
      if (list && list.songs[idx]) list.songs[idx] = song;
    }
  },

  // 落盘：按当前上下文保存队列或歌单
  persistNowPlaying() {
    if (this.state.playContext === 'queue') this.saveQueue();
    else this.savePlaylists();
    this.saveLastState();
  },

  // 队列里第一首「待播」的下标：当前播放的占着队首，它之后才是待播
  pendingStart() {
    return this.state.playContext === 'queue' ? this.state.currentIndex + 1 : 0;
  },

  // 待播数量
  pendingCount() {
    return Math.max(0, this.state.queue.length - this.pendingStart());
  },

  // 播放同步队列：正在播的这首永远排在队首
  // queueIndex >= 0：这首本来就在队列里 → 清掉它之前的（更旧的），它升为队首
  // queueIndex < 0：新歌（搜索/歌单点播）→ 清掉当前及之前的，新歌插到队首
  syncQueueOnPlay(song, queueIndex = -1) {
    const queue = this.state.queue;

    if (queueIndex >= 0) {
      if (queueIndex > 0) queue.splice(0, queueIndex);
    } else {
      // 清掉当前及之前的：被新歌顶掉的旧当前不留在待播区，
      // 队列语义始终保持「队首=正在播放，其后=待播」
      if (this.state.playContext === 'queue' && this.state.currentIndex >= 0) {
        queue.splice(0, this.state.currentIndex + 1);
      }
      // 已经在待播区里排队了 → 先摘掉旧位置，避免重复
      const dup = queue.findIndex(s => s.id === song.id);
      if (dup >= 0) queue.splice(dup, 1);
      queue.unshift({ ...song, _q: this.nextQueueSeq() });
    }

    this.state.playContext = 'queue';
    this.state.currentIndex = 0;
    this.saveQueue();
  },

  // 上一首：队首前面还有（被拖上来的）歌 → 退回它；否则重播当前这首
  handlePrev() {
    const queue = this.state.queue;
    if (this.state.playContext === 'queue' && this.state.currentIndex > 0) {
      const idx = this.state.currentIndex - 1;
      this.playSong(queue[idx], idx);
      this.renderQueue();
      return;
    }
    const idx = Math.max(this.state.currentIndex, 0);
    if (queue[idx]) {
      this.playSong(queue[idx], idx);
      this.renderQueue();
    }
  },

  // 下一首：一切以播放队列为本（不管歌单）
  // 顺序/随机：队列播完 → 自动暂停；列表循环：从头再来
  handleNext() {
    const queue = this.state.queue;
    const start = this.pendingStart();

    if (start < queue.length) {
      this.playSong(queue[start], start);
      this.renderQueue();
      return;
    }

    if (this.state.loopMode === 'repeat' && queue.length > 0) {
      // 列表循环：队列播完从队首重来
      this.playSong(queue[0], 0);
      this.renderQueue();
      return;
    }

    // 队列播完 → 自动暂停，保留队列
    this.state.isPlaying = false;
    this.elements.audioPlayer.pause();
    this.updatePlayButton();
    this.saveLastState();
    this.renderQueue();
    this.showToast('队列播完了');
  },

  // 播放结束
  handleEnded() {
    if (this.state.loopMode === 'single') {
      this.elements.audioPlayer.play();
      return;
    }
    this.handleNext();
  },

  // 重试当前歌曲 - 带多次重试机制
  async retryCurrentSong(maxRetries = 3) {
    if (this.state.isRetrying) return;

    this.state.isRetrying = true;
    const song = this.getNowPlayingSong();
    if (!song) {
      this.state.isRetrying = false;
      return;
    }

    // 如果歌曲已经标记为解析失败，不再重试
    if (song.parseFailed) {
      console.log('歌曲已标记为解析失败，不再重试');
      this.state.isRetrying = false;
      return;
    }

    // 显示重试提示
    this.showLoading();

    let lastError = null;
    let parseFailedCount = 0;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`第 ${attempt}/${maxRetries} 次尝试重新获取音频...`);

        let newSong;
        if (song.source === 'netease') {
          newSong = await this.getNeteaseUrl(song);
          
          // 如果网易云解析失败且标记为不可重试，直接退出
          if (newSong?.parseFailed) {
            parseFailedCount++;
            console.log('网易云解析接口返回失败，标记不可重试');
            
            if (parseFailedCount >= 2) {
              console.log('多次解析失败，停止重试');
              break;
            }
            continue;
          }
        } else if (song.source === 'qq') {
          newSong = await this.getQQUrl(song);
        } else if (song.source === 'bilibili') {
          const [vid, page] = song.id.split('#');
          newSong = await this.getBilibiliPageUrl(vid, page || 1);
        } else if (song.source === 'douyin') {
          const response = await fetch('/api/douyin/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: song.id })
          });
          const data = await response.json();
          if (data.code === 200 && data.data) {
            newSong = { ...song, url: data.data.audioUrl };
          }
        } else if (song.source === 'soda') {
          newSong = await this.getSodaUrl(song);
        }

        if (newSong && newSong.url) {
          // 防死循环：重试拿到的仍是同一个失败 URL → 解析源没有恢复，标记失败停止循环
          if (newSong.url === song.url) {
            console.error('重试返回同一 URL，标记解析失败并停止重试');
            this.setNowPlayingSong({ ...song, parseFailed: true });
            this.persistNowPlaying();
            this.hideLoading();
            this.state.isRetrying = false;
            this.showToast('音频源暂不可用，请稍后重试或切换歌曲');
            return;
          }
          // 更新歌曲信息，清除失败标记
          const refreshed = { ...song, ...newSong, parseFailed: false };
          this.setNowPlayingSong(refreshed);
          this.persistNowPlaying();

          // 重新加载并播放（加载动画持续到音频真正播出）
          this.loadSong(refreshed, true);
          this.showToast('音频已刷新，继续播放');
          this.state.isRetrying = false;
          return;
        }
      } catch (e) {
        lastError = e;
        console.error(`第 ${attempt} 次重试失败:`, e.message);

        if (attempt < maxRetries) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
    }

    // 所有重试都失败了，标记歌曲为解析失败
    this.setNowPlayingSong({ ...song, parseFailed: true });
    this.persistNowPlaying();
    
    this.hideLoading();
    this.state.isRetrying = false;
    this.showToast('音频获取失败，请尝试切换歌曲');
    console.error('音频重试机制最终失败:', lastError);
  },

  // 渲染歌单标签
  renderPlaylistTabs() {
    const html = this.state.playlists.map(p => `
      <div class="playlist-tab ${p.id === this.state.activeListId ? 'active' : ''}" data-id="${p.id}">
        ${this.escapeHtml(p.title)}
        ${!p.system ? `<span class="more-btn" data-id="${p.id}"><i class="fas fa-ellipsis-v"></i></span>` : ''}
      </div>
    `).join('');

    this.elements.playlistTabs.innerHTML = html;

    this.elements.playlistTabs.querySelectorAll('.playlist-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        if (e.target.closest('.more-btn')) {
          e.stopPropagation();
          this.showPlaylistMenu(e.target.closest('.more-btn').dataset.id);
        } else {
          this.state.activeListId = tab.dataset.id;
          this.renderPlaylistTabs();
          this.renderPlaylistItems();
        }
      });
    });

    this.updateDrawerBadges();
  },

  // 渲染歌单列表
  renderPlaylistItems() {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list) return;

    this.updateDrawerBadges();

    const filter = this.elements.playlistFilter.value.toLowerCase();
    const songs = filter
      ? list.songs.filter(s =>
          (s.name || '').toLowerCase().includes(filter) ||
          (s.artist || '').toLowerCase().includes(filter)
        )
      : list.songs;

    this.elements.playlistCount.textContent = `歌曲 ${songs.length}${filter ? ` / 共 ${list.songs.length}` : ''} 首`;

    if (songs.length === 0) {
      this.elements.playlistItems.innerHTML = '<div class="empty">暂无歌曲</div>';
      return;
    }

    // 队列播放时 currentIndex 是队列下标，直接比下标会高亮错行 → 按当前歌曲 id 判
    const currentSong = this.getNowPlayingSong();

    this.elements.playlistItems.innerHTML = songs.map((song, index) => {
      const realIndex = list.songs.findIndex(s => s.id === song.id);
      const isPlaying = !!currentSong && currentSong.id === song.id;
      
      // 构建"移动到"下拉菜单选项
      const isBilibiliOrDouyin = list.title === '哔哩哔哩' || list.title === '抖音';
      const moveMenuItems = isBilibiliOrDouyin
        ? (this.state.playlists.find(p => p.title === '抖音')
            ? [{ key: 'douyin', label: '抖音' }]
            : [])
        : [
            { key: 'create', label: '＋ 新建歌单' },
            ...this.state.playlists
              .filter(p => p.id !== this.state.activeListId && p.title !== '哔哩哔哩' && p.title !== '抖音')
              .map(p => ({ key: p.id, label: p.title }))
          ];
      
      const moveDropdown = moveMenuItems.length > 0 ? `
        <div class="dropdown">
          <button class="dropdown-toggle" onclick="MusicApp.toggleMoveMenu(${realIndex})">移动到 <i class="fas fa-chevron-down"></i></button>
          <div class="dropdown-menu" id="moveMenu-${realIndex}">
            ${moveMenuItems.map(item => `
              <div class="dropdown-item" onclick="MusicApp.handleMoveClick(${realIndex}, '${item.key}')">${this.escapeHtml(item.label)}</div>
            `).join('')}
          </div>
        </div>
      ` : '';
      
      return `
        <li class="playlist-item ${isPlaying ? 'active' : ''}" data-index="${realIndex}">
          <div class="playlist-item-info">
            <div class="playlist-item-title">${this.escapeHtml(song.name)}</div>
            <div class="playlist-item-artist">${this.escapeHtml(song.artist)}</div>
          </div>
          <div class="playlist-item-actions">
            <button class="icon-act" title="加入播放队列（队尾）" onclick="MusicApp.addSongToQueue(${realIndex})"><i class="fas fa-list-ol"></i></button>
            <button class="icon-act" title="下一首播放（插到待播最前）" onclick="MusicApp.addSongToQueue(${realIndex}, true)"><i class="fas fa-forward"></i></button>
            <button onclick="MusicApp.playFromPlaylist(${realIndex})">播放</button>
            <button onclick="MusicApp.removeFromPlaylist(${realIndex})">删除</button>
            ${isBilibiliOrDouyin ? `<button onclick="MusicApp.openEditModal(${realIndex})">修改</button>` : ''}
            ${moveDropdown}
          </div>
        </li>
      `;
    }).join('');
  },

  // ===== 播放队列 =====

  // 侧边栏视图切换：歌单 / 播放队列
  switchDrawerView(view) {
    this.state.drawerView = view === 'queue' ? 'queue' : 'playlist';
    CloudStore.set(this.constants.DRAWER_VIEW_STORAGE_KEY, this.state.drawerView);

    const isQueue = this.state.drawerView === 'queue';
    this.elements.drawerTabs.querySelectorAll('.drawer-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.view === this.state.drawerView);
    });
    // hidden 是 HTMLElement 的 IDL 属性，div 上可直接用
    this.elements.playlistView.hidden = isQueue;
    this.elements.queueView.hidden = !isQueue;
    this.elements.drawerTitle.textContent = isQueue ? '播放队列' : '歌单';

    if (isQueue) {
      this.renderQueue();
    } else {
      this.renderPlaylistTabs();
      this.renderPlaylistItems();
    }
    this.updateDrawerBadges();
  },

  // 侧边栏队列 tab 的角标：正在播放 + 待播（即整个队列）；歌单 tab 无角标
  updateDrawerBadges() {
    const total = this.state.queue.length;
    if (this.elements.queueTabBadge) {
      this.elements.queueTabBadge.textContent = total;
      this.elements.queueTabBadge.style.display = total > 0 ? 'inline-block' : 'none';
    }
  },

  // 渲染播放队列
  renderQueue() {
    if (!this.elements.queueItems) return;
    const { queue, playContext, currentIndex } = this.state;
    const pending = this.pendingCount();

    this.updateDrawerBadges();
    this.elements.queueCount.textContent = queue.length
      ? `队列 ${queue.length} 首 · 待播 ${pending} 首`
      : '队列为空';

    if (queue.length === 0) {
      this.elements.queueItems.innerHTML =
        '<div class="empty">队列还是空的<br>去歌单页点 <i class="fas fa-list-ol"></i> 加入歌曲</div>';
      return;
    }

    this.elements.queueItems.innerHTML = queue.map((song, i) => {
      const isCurrent = playContext === 'queue' && i === currentIndex;
      const played = playContext === 'queue' && i < currentIndex;
      return `
        <li class="queue-item ${isCurrent ? 'active' : ''} ${played ? 'played' : ''}" data-index="${i}" draggable="true">
          <span class="queue-drag" title="拖动调整顺序"><i class="fas fa-grip-lines"></i></span>
          <span class="queue-index">${isCurrent ? '<i class="fas fa-volume-up"></i>' : i + 1}</span>
          <div class="queue-item-info">
            <div class="queue-item-title">${this.escapeHtml(song.name)}</div>
            <div class="queue-item-artist">${this.escapeHtml(song.artist)}</div>
          </div>
          <div class="queue-item-actions">
            <button class="icon-act" title="播放" onclick="MusicApp.playFromQueue(${i})"><i class="fas fa-play"></i></button>
            <button class="icon-act" title="移出队列" onclick="MusicApp.removeFromQueue(${i})"><i class="fas fa-times"></i></button>
          </div>
        </li>
      `;
    }).join('');

    this.bindQueueDrag();
  },

  // 队列拖拽排序
  bindQueueDrag() {
    let from = -1;
    this.elements.queueItems.querySelectorAll('.queue-item').forEach(item => {
      item.addEventListener('dragstart', (e) => {
        from = parseInt(item.dataset.index, 10);
        item.classList.add('dragging');
        if (e.dataTransfer) {
          e.dataTransfer.effectAllowed = 'move';
          try { e.dataTransfer.setData('text/plain', String(from)); } catch (err) {}
        }
      });
      item.addEventListener('dragend', () => item.classList.remove('dragging'));
      item.addEventListener('dragover', (e) => {
        e.preventDefault();
        if (from >= 0) item.classList.add('drag-over');
      });
      item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
      item.addEventListener('drop', (e) => {
        e.preventDefault();
        item.classList.remove('drag-over');
        if (from < 0) return;
        const to = parseInt(item.dataset.index, 10);
        this.moveQueueItem(from, to);
        from = -1;
      });
    });
  },

  // 移动队列中的歌曲
  moveQueueItem(from, to) {
    const queue = this.state.queue;
    if (from === to || from < 0 || to < 0 || from >= queue.length || to >= queue.length) return;

    const [song] = queue.splice(from, 1);
    queue.splice(to, 0, song);

    // 正在播的那首跟着走（它前面剩下的就是"更早播过的"）
    if (this.state.playContext === 'queue') {
      if (from === this.state.currentIndex) {
        this.state.currentIndex = to;
      } else if (from < this.state.currentIndex && to >= this.state.currentIndex) {
        this.state.currentIndex--;
      } else if (from > this.state.currentIndex && to <= this.state.currentIndex) {
        this.state.currentIndex++;
      }
    }

    this.saveQueue();
    this.saveLastState();
    this.renderQueue();
  },

  // 歌单里的歌加入队列（next=true 插到待播最前）
  addSongToQueue(index, next = false) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs[index]) return;
    this.enqueueSongs([{ ...list.songs[index] }], next);
  },

  // 当前歌单整单入队
  enqueuePlaylist() {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs.length) {
      this.showToast('当前歌单没有歌曲');
      return;
    }
    this.enqueueSongs(list.songs.map(s => ({ ...s })), false);
  },

  // 入队（next=true 插到待播最前；已在队列里的歌自动去重）
  enqueueSongs(songs, next = false) {
    if (!songs.length) return;

    const fresh = songs
      .filter(s => !this.state.queue.some(q => q.id === s.id))
      .map(s => ({ ...s, _q: this.nextQueueSeq() }));
    if (!fresh.length) {
      this.showToast('歌曲已在队列中');
      return;
    }

    if (next) {
      const at = Math.min(this.pendingStart(), this.state.queue.length);
      this.state.queue.splice(at, 0, ...fresh);
    } else {
      this.state.queue.push(...fresh);
    }

    this.saveQueue();
    this.renderQueue();
    this.showToast(next
      ? `已插队 ${fresh.length} 首，下一首播放`
      : `已加入队列 ${fresh.length} 首`);
  },

  // 从队列指定位置播放（syncQueueOnPlay 会把它收进队首）
  playFromQueue(index) {
    const song = this.state.queue[index];
    if (!song) return;

    this.playSong(song, index);
    this.saveQueue();
    this.saveLastState();
    this.renderQueue();
  },

  // 从第一首待播开始播放；无待播则重播当前
  playQueueFromStart() {
    if (!this.state.queue.length) {
      this.showToast('队列还是空的');
      return;
    }
    const start = Math.min(this.pendingStart(), this.state.queue.length - 1);
    this.playFromQueue(start);
  },

  // 从队列移除
  removeFromQueue(index) {
    const queue = this.state.queue;
    if (index < 0 || index >= queue.length) return;

    queue.splice(index, 1);

    if (this.state.playContext === 'queue') {
      if (index === this.state.currentIndex) {
        // 删掉的是正在播的：停播，剩下的队列全是待播（currentIndex=-1 → pendingStart=0）
        this.elements.audioPlayer.pause();
        this.elements.audioPlayer.src = '';
        this.state.isPlaying = false;
        this.updatePlayButton();
        this.state.currentIndex = -1;
      } else if (index < this.state.currentIndex) {
        this.state.currentIndex--;
      }
    }

    this.saveQueue();
    this.saveLastState();
    this.renderQueue();
    this.renderPlaylistItems();
  },

  // 清空队列
  clearQueue() {
    if (!this.state.queue.length) return;

    this.state.queue = [];
    if (this.state.playContext === 'queue') {
      this.state.currentIndex = -1;
    }
    this.saveQueue();
    this.saveLastState();
    this.renderQueue();
    this.renderPlaylistItems();
    this.showToast('队列已清空');
  },

  // 队列排序（只排待播区，正在播放的固定在队首）
  // mode: asc 按加入顺序正序 / desc 按加入顺序倒序 / shuffle 随机打乱
  sortQueue(mode) {
    const start = this.pendingStart();
    if (this.state.queue.length - start < 2) {
      this.showToast('待播歌曲不足两首');
      return;
    }

    const head = this.state.queue.slice(0, start);
    const rest = this.state.queue.slice(start);

    if (mode === 'asc') {
      rest.sort((a, b) => (a._q || 0) - (b._q || 0));
    } else if (mode === 'desc') {
      rest.sort((a, b) => (b._q || 0) - (a._q || 0));
    } else {
      for (let i = rest.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [rest[i], rest[j]] = [rest[j], rest[i]];
      }
    }

    this.state.queue = head.concat(rest);
    this.saveQueue();
    this.renderQueue();
    this.showToast(mode === 'asc' ? '已按加入顺序正序排列'
      : mode === 'desc' ? '已按加入顺序倒序排列' : '已随机打乱待播顺序');
  },

  // 切换移动菜单显示
  toggleMoveMenu(index) {
    const menu = document.getElementById(`moveMenu-${index}`);
    if (menu) {
      const isVisible = menu.style.display === 'block';
      // 关闭所有其他菜单
      document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');
      menu.style.display = isVisible ? 'none' : 'block';
    }
  },

  // 处理移动点击
  handleMoveClick(index, key) {
    // 关闭菜单
    document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');

    if (key === 'create') {
      this.createPlaylist();
      return;
    }

    const sourceList = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!sourceList || !sourceList.songs[index]) return;

    const song = sourceList.songs[index];

    // 找到目标歌单
    let targetList;
    if (key === 'douyin') {
      targetList = this.state.playlists.find(p => p.title === '抖音');
    } else {
      targetList = this.state.playlists.find(p => p.id === key);
    }

    if (!targetList || targetList.id === this.state.activeListId) return;

    // 检查是否已存在
    const exists = targetList.songs.find(s => s.id === song.id);
    if (exists) {
      alert('该歌曲已在目标歌单中');
      return;
    }

    // 添加到目标歌单
    targetList.songs.push({ ...song });

    // 判断是否为复制模式（播放历史不删除原歌曲）
    const isCopyMode = sourceList.system === 'history';

    if (!isCopyMode) {
      // 从当前歌单删除
      sourceList.songs.splice(index, 1);

      // 更新当前播放索引
      if (this.state.activeListId === this.state.nowPlayingListId) {
        if (index === this.state.currentIndex) {
          this.state.currentIndex = -1;
          this.state.isPlaying = false;
          this.elements.audioPlayer.pause();
          this.elements.audioPlayer.src = '';
          CloudStore.remove(this.constants.LAST_STATE_STORAGE_KEY);
        } else if (index < this.state.currentIndex) {
          this.state.currentIndex--;
        }
      }
    }

    this.savePlaylists();
    this.saveLastState();
    this.renderPlaylistItems();

    // 显示提示
    const actionText = isCopyMode ? '已添加到' : '已移动到';
    this.showToast(`${actionText}「${targetList.title}」`);
  },

  // 显示提示
  showToast(message) {
    const existingToast = document.querySelector('.toast-message');
    if (existingToast) {
      existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  },

  // 从歌单播放
  playFromPlaylist(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs[index]) return;

    this.state.nowPlayingListId = this.state.activeListId;
    this.state.playContext = 'list';
    this.state.currentIndex = index;
    this.state.listIndex = index;
    this.playSong(list.songs[index]);
    this.saveLastState();
  },

  // 从歌单删除
  removeFromPlaylist(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list) return;

    list.songs.splice(index, 1);

    if (this.state.activeListId === this.state.nowPlayingListId) {
      if (index === this.state.currentIndex) {
        this.state.isPlaying = false;
        this.state.currentTime = 0;
        this.state.duration = 0;
        this.state.currentIndex = -1;
        this.elements.audioPlayer.pause();
        this.elements.audioPlayer.src = '';
        CloudStore.remove(this.constants.LAST_STATE_STORAGE_KEY);
      } else if (index < this.state.currentIndex) {
        this.state.currentIndex--;
      }
    }

    this.savePlaylists();
    this.renderPlaylistItems();
  },

  // 创建歌单
  createPlaylist() {
    const name = prompt('新建歌单名称', '新建歌单');
    if (!name || !name.trim()) return;

    const newPlaylist = {
      id: this.generateId(),
      title: name.trim(),
      songs: []
    };

    this.state.playlists.push(newPlaylist);
    this.savePlaylists();
    this.renderPlaylistTabs();
  },

  // 显示歌单菜单
  showPlaylistMenu(id) {
    const action = confirm('删除此歌单？') ? 'delete' : null;
    if (action === 'delete') {
      const index = this.state.playlists.findIndex(p => p.id === id);
      if (index >= 0 && !this.state.playlists[index].system) {
        this.state.playlists.splice(index, 1);
        if (this.state.activeListId === id) {
          this.state.activeListId = this.state.playlists[0]?.id || '';
        }
        this.savePlaylists();
        this.renderPlaylistTabs();
        this.renderPlaylistItems();
      }
    }
  },

  // 打开编辑弹窗
  openEditModal(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs[index]) return;

    const song = list.songs[index];
    this.state.editContext = { listId: this.state.activeListId, index };

    this.elements.editName.value = song.name || '';
    this.elements.editArtist.value = song.artist || '';
    this.elements.editLrc.value = song.lrc || '';

    this.elements.editModal.classList.add('active');
  },

  // 保存编辑
  saveEdit() {
    if (!this.state.editContext) return;

    const { listId, index } = this.state.editContext;
    const list = this.state.playlists.find(p => p.id === listId);
    if (!list || !list.songs[index]) return;

    list.songs[index].name = this.elements.editName.value.trim();
    list.songs[index].artist = this.elements.editArtist.value.trim();
    list.songs[index].lrc = this.elements.editLrc.value;

    this.savePlaylists();
    this.renderPlaylistItems();
    this.elements.editModal.classList.remove('active');
    this.state.editContext = null;
  },

  // 搜索歌词
  async searchLyrics() {
    const keyword = this.elements.lyricSearchInput.value.trim();
    if (!keyword) return;

    const source = this.elements.lyricSource.value;
    this.elements.lyricSearchLoading.style.display = 'block';
    this.elements.lyricSearchEmpty.style.display = 'none';
    this.elements.lyricResultList.innerHTML = '';

    try {
      let results = [];

      if (source === 'netease') {
        results = await this.searchNetease(keyword);
      } else if (source === 'qq') {
        results = await this.searchQQ(keyword);
      }

      this.renderLyricSearchResults(results, source);
    } catch (e) {
      this.elements.lyricSearchEmpty.style.display = 'block';
    } finally {
      this.elements.lyricSearchLoading.style.display = 'none';
    }
  },

  // 渲染歌词搜索结果
  renderLyricSearchResults(results, source) {
    if (results.length === 0) {
      this.elements.lyricSearchEmpty.style.display = 'block';
      return;
    }

    this.elements.lyricResultList.innerHTML = results.map((song, index) => `
      <li class="result-item" data-index="${index}" data-id="${song.id}" data-source="${source}">
        <span class="result-title">${this.escapeHtml(song.name)}</span>
        <span class="result-sub">${this.escapeHtml(song.artist)}</span>
      </li>
    `).join('');

    this.elements.lyricResultList.querySelectorAll('.result-item').forEach(item => {
      item.addEventListener('click', async () => {
        const id = item.dataset.id;
        const src = item.dataset.source;
        let lrc = '';

        if (src === 'netease') {
          const response = await fetch('https://api.kxzjoker.cn/api/163_music', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `url=${encodeURIComponent(id)}&level=exhigh&type=json`
          });
          const data = await response.json();
          lrc = data.lyric || '';
        } else if (src === 'qq') {
          const response = await fetch(`/api/qq/lyric?songmid=${id}`);
          const data = await response.json();
          lrc = data.data?.lyric || '';
        }

        this.elements.editLrc.value = lrc;
        this.elements.lyricSearchModal.classList.remove('active');
      });
    });
  },

  // 应用主题
  applyThemeFromCover(coverUrl) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 100;
      canvas.height = 100;
      ctx.drawImage(img, 0, 0, 100, 100);

      const { data } = ctx.getImageData(0, 0, 100, 100);
      let r = 0, g = 0, b = 0;
      for (let i = 0; i < data.length; i += 4) {
        r += data[i];
        g += data[i + 1];
        b += data[i + 2];
      }
      r = Math.round(r / (data.length / 4));
      g = Math.round(g / (data.length / 4));
      b = Math.round(b / (data.length / 4));

      const root = document.documentElement;
      root.style.setProperty('--music-bg-start', `rgb(${r + 100}, ${g + 100}, ${b + 100})`);
      root.style.setProperty('--music-bg-end', `rgb(${r + 80}, ${g + 80}, ${b + 80})`);
      root.style.setProperty('--music-accent', `rgb(${r}, ${g}, ${b})`);
      root.style.setProperty('--music-panel-bg', `rgb(${r + 120}, ${g + 120}, ${b + 120})`);
      // 同时更新 primary-color，让搜索按钮等组件也能跟随主题
      root.style.setProperty('--primary-color', `rgb(${r}, ${g}, ${b})`);
      root.style.setProperty('--primary-hover', `rgb(${Math.max(0, r - 20)}, ${Math.max(0, g - 20)}, ${Math.max(0, b - 20)})`);
      // 动态主题激活时，移除 content 区域的背景色让其继承主题色
      document.querySelector('.content')?.classList.add('theme-active');
    };
    img.src = coverUrl;
  },

  // 应用当前歌曲主题
  applyThemeFromCurrentSong() {
    const song = this.getNowPlayingSong();
    if (song && song.cover) {
      this.applyThemeFromCover(this.coverSrc(song.cover));
    }
  },

  // 重置主题
  resetTheme() {
    const root = document.documentElement;
    root.style.setProperty('--music-bg-start', '#f6fafc');
    root.style.setProperty('--music-bg-end', '#eef4f8');
    root.style.setProperty('--music-accent', '#2563eb');
    root.style.setProperty('--music-panel-bg', '#F4F8FB');
    root.style.setProperty('--music-text-secondary', '#65708a');
    root.style.setProperty('--primary-color', '#1890ff');
    root.style.setProperty('--primary-hover', '#40a9ff');
    // 重置时移除 content 区域的 theme-active 类，恢复默认背景色
    document.querySelector('.content')?.classList.remove('theme-active');
  },

  // 随机打开一首歌
  async openRandomSong() {
    // 显示加载动画
    this.showLoading();

    try {
      const response = await fetch('/api/random-song');
      const data = await response.json();

      if (data.code === 200 && data.data && data.data.playUrl) {
        window.open(data.data.playUrl, '_blank');
      }
    } catch (e) {
      console.error('获取随机歌曲失败:', e);
    } finally {
      this.hideLoading();
    }
  },

  // 生成ID
  generateId() {
    return `pl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  },

  // 格式化时间
  formatTime(sec) {
    if (!isFinite(sec) || sec < 0) return '00:00';
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  },

  // HTML转义
  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  // 获取缓存的AI分析结果
  getCachedAnalysis(songId) {
    try {
      const stored = CloudStore.get(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        const cache = JSON.parse(stored);
        return cache[songId] || null;
      }
    } catch (e) {}
    return null;
  },

  // 保存AI分析结果到缓存
  saveAnalysisToCache(songId, content) {
    try {
      let cache = {};
      const stored = CloudStore.get(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        cache = JSON.parse(stored);
      }
      cache[songId] = {
        content,
        timestamp: Date.now()
      };
      CloudStore.set(this.constants.AI_ANALYSIS_STORAGE_KEY, JSON.stringify(cache));
    } catch (e) {
      console.error('保存AI分析缓存失败:', e);
    }
  },

  // 当前正在分析的歌曲ID
  currentAnalyzingSongId: null,

  // 打开AI解读弹窗
  openAnalyzeModal() {
    const song = this.getNowPlayingSong();
    if (!song) {
      this.showToast('请先播放一首歌曲');
      return;
    }

    if (!song.lrc) {
      this.showToast('当前歌曲暂无歌词');
      return;
    }

    // 更新歌曲信息
    this.elements.analyzeSongName.textContent = song.name || '未知歌曲';
    this.elements.analyzeSongArtist.textContent = song.artist || '--';

    // 显示弹窗
    this.elements.analyzeModal.classList.add('active');

    // 保存当前歌曲ID
    this.currentAnalyzingSongId = song.id;

    // 检查是否有缓存
    const cached = this.getCachedAnalysis(song.id);
    if (cached && cached.content) {
      // 显示缓存内容
      this.elements.analyzeLoading.style.display = 'none';
      this.elements.analyzeActions.style.display = 'flex';
      this.elements.analyzeContent.innerHTML = this.renderAnalyzeContent(cached.content);
    } else {
      // 开始新的分析
      this.analyzeLyrics(song, false);
    }
  },

  // 重新解析
  reanalyzeLyrics() {
    const song = this.getNowPlayingSong();
    if (!song) return;

    // 清除缓存
    try {
      const stored = CloudStore.get(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        const cache = JSON.parse(stored);
        delete cache[song.id];
        CloudStore.set(this.constants.AI_ANALYSIS_STORAGE_KEY, JSON.stringify(cache));
      }
    } catch (e) {}

    // 重新分析
    this.analyzeLyrics(song, true);
  },

  // AI分析歌词
  async analyzeLyrics(song, isRetry = false) {
    const { analyzeLoading, analyzeActions, analyzeContent } = this.elements;

    analyzeLoading.style.display = 'flex';
    analyzeActions.style.display = 'none';
    analyzeContent.innerHTML = '';

    // 提取纯歌词文本（去掉时间戳）
    const pureLyrics = this.extractPureLyrics(song.lrc);

    try {
      const response = await fetch('/api/ai/analyze-lyrics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          lyrics: pureLyrics,
          songName: song.name,
          artist: song.artist
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullContent = '';
      // SSE 按 \n 分帧，但网络 chunk 可能把一行 data: JSON 切成两半 → 缓冲到凑齐整行再解析
      let sseBuffer = '';
      const handleLine = (line) => {
        if (!line.startsWith('data: ')) return;
        const data = line.slice(6);
        if (data === '[DONE]') return;

        try {
          const parsed = JSON.parse(data);
          const delta = parsed.choices?.[0]?.delta?.content;
          if (delta) {
            fullContent += delta;
            // R1 类推理模型把思考过程以 <think>...</think> 内嵌在 content 开头
            // （该端点 reasoning_content 恒为空）→ 思考期间保持 loading，正文到达才展示
            const visible = this.analyzeVisibleContent(fullContent);
            if (visible) {
              analyzeLoading.style.display = 'none';
              analyzeActions.style.display = 'flex';
              analyzeContent.innerHTML = this.renderAnalyzeContent(visible);
            }
          }
        } catch (e) {}
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        sseBuffer += decoder.decode(value, { stream: true });
        const lines = sseBuffer.split('\n');
        sseBuffer = lines.pop();
        for (const line of lines) handleLine(line);
      }
      sseBuffer += decoder.decode();
      handleLine(sseBuffer);

      // 兜底：流结束但只有思考段没有正文（如被 max_tokens 截断在思考中）
      if (fullContent && !this.analyzeVisibleContent(fullContent)) {
        analyzeLoading.style.display = 'none';
        analyzeContent.innerHTML = `
          <div class="analyze-placeholder">
            <i class="fas fa-exclamation-circle" style="color: #f85149;"></i>
            <p>模型思考后未输出正文，请重试</p>
          </div>
        `;
      }

      // 保存到缓存（只存剥离思考段后的正文）
      const visibleContent = this.analyzeVisibleContent(fullContent);
      if (visibleContent && this.currentAnalyzingSongId) {
        this.saveAnalysisToCache(this.currentAnalyzingSongId, visibleContent);
      }
    } catch (error) {
      analyzeLoading.style.display = 'none';
      analyzeContent.innerHTML = `
        <div class="analyze-placeholder">
          <i class="fas fa-exclamation-circle" style="color: #f85149;"></i>
          <p>分析失败: ${error.message}</p>
          <p style="font-size: 12px; margin-top: 8px;">请检查网络连接或稍后重试</p>
        </div>
      `;
      console.error('AI分析失败:', error);
    }
  },

  // 剥离推理模型内嵌在 content 开头的 <think>…</think> 思考段，返回应展示的正文。
  // 思考未结束（含跨 chunk 的半截 <think 标签）时返回空串
  analyzeVisibleContent(text) {
    const end = text.indexOf('</think>');
    if (end >= 0) return text.slice(end + 8).trim();
    if (/<think>/.test(text) || /<[a-z/]*$/i.test(text)) return '';
    return text;
  },

  // 提取纯歌词文本（去掉时间戳）
  extractPureLyrics(lrc) {
    if (!lrc) return '';
    const lines = lrc.split(/\r?\n/);
    const timeRegex = /\[\d{1,2}:\d{1,2}(?:\.\d{1,3})?]/g;

    return lines
      .map(line => line.replace(timeRegex, '').trim())
      .filter(text => text.length > 0)
      .join('\n');
  },

  // 渲染分析内容（支持Markdown）
  renderAnalyzeContent(text) {
    if (!text) return '';

    // 转义HTML
    let html = this.escapeHtml(text);

    // 处理标题 # ## ### #### ##### ######
    html = html.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
    html = html.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
    html = html.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');

    // 处理加粗 **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // 处理斜体 *text*
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // 处理引用 >
    html = html.replace(/^&gt;\s*(.+)$/gm, '<blockquote>$1</blockquote>');

    // 处理列表项 * 或 -
    html = html.replace(/^[\*\-]\s+(.+)$/gm, '<li>$1</li>');

    // 将连续的li包裹在ul中
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

    // 处理换行 - 将单个换行转为 <br>，但避免连续的 <br><br>
    html = html.replace(/\n/g, '<br>');

    // 移除连续的多个 <br>，只保留一个
    html = html.replace(/(<br>\s*){2,}/g, '<br>');

    // 移除标题标签后的 <br>
    html = html.replace(/(<\/?h[1-6][^>]*>)<br>/g, '$1');

    // 移除列表项前的 <br>
    html = html.replace(/<br>(<li>)/g, '$1');

    // 移除列表后的 <br>
    html = html.replace(/(<\/ul>)<br>/g, '$1');

    // 移除引用块后的 <br>
    html = html.replace(/(<\/blockquote>)<br>/g, '$1');

    return `<div class="analyze-result">${html}</div>`;
  }
};

// 启动应用
document.addEventListener('DOMContentLoaded', async () => {
  await CloudStore.ready(); // 先加载云端键值镜像，init 里的同步读取才有数据
  MusicApp.init();
});
