// 提取 appmanager 语言包里的对象字面量并对比 addWidget 相关 key
const fs = require('fs');
function loadObj(p) {
  const src = fs.readFileSync(p, 'utf8');
  const start = src.indexOf('const t={');
  let i = src.indexOf('{', start), depth = 0, inStr = null, esc = false;
  for (; i < src.length; i++) {
    const c = src[i];
    if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === inStr) inStr = null; continue; }
    if (c === '"' || c === "'" || c === '`') inStr = c;
    else if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) { i++; break; } }
  }
  return eval('(' + src.slice(src.indexOf('{', start), i) + ')');
}
const ours = loadObj(process.argv[2]);
const off = loadObj(process.argv[3]);
const filter = process.argv[4] || 'addWidget';
console.log('=== 官方:'); Object.keys(off).filter(k => k.includes(filter)).forEach(k => console.log(k, '=', off[k]));
console.log('=== 我们的:'); Object.keys(ours).filter(k => k.includes(filter)).forEach(k => console.log(k, '=', ours[k]));
