/* 小姐姐图片 —— 抖音式横滑图片信息流
 * 一屏一张图：滚轮/触摸/方向键左右切换，滚动到末尾前自动追加。
 * 图片走同源代理 /api/img（源站无 CORS 头，COEP require-corp 下跨域直连必被拦）。
 *
 * 加载反馈只有一种：每张图自己的占位（.pic-loading），从 slide 创建起就显示，
 * 覆盖「取地址 + 下载图片」两个阶段，完成后图片淡入、占位收起。
 * 失败（含地址获取失败）→ 占位变「点击重试」，点击重新走链路。 */

const $ = (id) => document.getElementById(id);
const feed = $('feed');
const hint = $('hint');

let items = [];          // { url, el, img, loading, failed, retries }
let current = 0;         // 当前可见 slide 下标
let fetching = false;

setTimeout(() => hint.classList.add('gone'), 3500);
setTimeout(() => hint.hidden = true, 4500);

/** 源图地址 → 同源代理地址 */
function imgSrc(url) {
  return `/api/img?u=${encodeURIComponent(url)}`;
}

function setLoading(loading, text) {
  loading.className = 'pic-loading';
  loading.innerHTML = `<div class="spinner"></div><span>${text}</span>`;
}

function setFailed(loading, text) {
  loading.className = 'pic-loading failed';
  loading.innerHTML = `<span>${text}</span>`;
}

async function fetchPic() {
  const r = await fetch('/api/random');
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data.url;
}

function createSlide(item, index) {
  const el = document.createElement('section');
  el.className = 'slide';
  el.dataset.index = String(index);

  const img = new Image();
  img.decoding = 'async';
  img.alt = '随机小姐姐图片';

  // 该图唯一的加载指示：取地址 + 下载图片全程显示，完成后图片淡入
  const loading = document.createElement('div');
  loading.className = 'pic-loading';
  loading.innerHTML = '<div class="spinner"></div><span>加载中</span>';

  // 失败态点击占位重试
  loading.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!item.failed) return;
    item.failed = false;
    item.retries = 0;
    setLoading(loading, '加载中');
    fillSlide(item);
  });

  img.addEventListener('load', () => {
    img.classList.add('loaded');
    loading.classList.add('done');
  });
  // 图片下载失败 → 换一张重试
  img.addEventListener('error', () => retry(item));

  // 点击图片：左半边 = 上一张，右半边 = 下一张（与滑动方向同构）
  el.addEventListener('click', (e) => {
    const half = el.getBoundingClientRect().left + el.clientWidth / 2;
    if (e.clientX < half) stepBy(-1);
    else next();
  });

  el.appendChild(img);
  el.appendChild(loading);
  feed.appendChild(el);
  item.el = el;
  item.img = img;
  item.loading = loading;
  io.observe(el);
}

/** 取地址并填图；地址获取失败也走统一重试 */
async function fillSlide(item) {
  try {
    const url = await fetchPic();
    item.url = url;
    item.img.src = imgSrc(url);   // load → 淡入；error → retry
  } catch {
    retry(item);
  }
}

/** 重试：换一张新图（同 URL 可能已失效），上限 2 次，超限显示可点击重试态 */
function retry(item) {
  if (item.retries >= 2) {
    item.failed = true;
    setFailed(item.loading, '加载失败，点击重试');
    return;
  }
  item.retries++;
  fillSlide(item);
}

async function appendSlides(n = 2) {
  if (fetching) return;
  fetching = true;
  try {
    // 先建 slide：占位立即可见（首屏第 0ms 就有反馈；追加的滚到底可见）
    const start = items.length;
    for (let i = 0; i < n; i++) {
      const item = { url: null, failed: false, retries: 0 };
      createSlide(item, items.length);
      items.push(item);
    }
    // 再并行取地址填图
    for (const item of items.slice(start)) fillSlide(item);
  } finally {
    fetching = false;
  }
}

const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    if (!e.isIntersecting || e.intersectionRatio < 0.6) continue;
    current = Number(e.target.dataset.index);
    // 快到底 → 预取下一批
    if (current >= items.length - 2) appendSlides(2);
  }
}, { root: feed, threshold: 0.6 });

/* ---- 滚轮/键盘：一次一屏（触摸走原生横向吸附） ---- */
let wheelLock = false;
function stepBy(dir) {
  const next = Math.min(items.length - 1, Math.max(0, current + dir));
  if (next === current) return;
  wheelLock = true;
  feed.scrollTo({ left: next * feed.clientWidth, behavior: 'smooth' });
  setTimeout(() => { wheelLock = false; }, 380);
}
function next() {
  if (current < items.length - 1) stepBy(1);
  else appendSlides(1).then(() => { if (items.length > current + 1) stepBy(1); });
}
feed.addEventListener('wheel', (e) => {
  e.preventDefault();
  if (wheelLock) return;
  stepBy(e.deltaY > 0 || e.deltaX > 0 ? 1 : -1);   // 滚轮上下/左右都映射为换图
}, { passive: false });

/* ---- 鼠标左键拖动换图（桌面端）：按住左右拖，松手吸附最近一屏 ---- */
let drag = null; // { startX, startLeft, active }
feed.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  drag = { startX: e.clientX, startLeft: feed.scrollLeft, active: false };
});
window.addEventListener('mousemove', (e) => {
  if (!drag) return;
  const dx = e.clientX - drag.startX;
  if (!drag.active) {
    if (Math.abs(dx) < 6) return;   // 超过阈值才算拖动，避免误触
    drag.active = true;
    feed.style.scrollSnapType = 'none';   // 拖动期间关闭吸附，跟手
  }
  feed.scrollLeft = drag.startLeft - dx;    // 往左拖 → 下一个，往右拖 → 上一个
});
window.addEventListener('mouseup', () => {
  if (!drag) return;
  const wasActive = drag.active;
  drag = null;
  if (!wasActive) return;
  feed.style.scrollSnapType = '';
  // 松手吸附最近一屏
  const idx = Math.max(0, Math.min(items.length - 1, Math.round(feed.scrollLeft / feed.clientWidth)));
  feed.scrollTo({ left: idx * feed.clientWidth, behavior: 'smooth' });
});
feed.addEventListener('dragstart', (e) => e.preventDefault());

document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === 'ArrowDown') { e.preventDefault(); if (!wheelLock) stepBy(1); }
  if (e.key === 'ArrowLeft' || e.key === 'PageUp' || e.key === 'ArrowUp') { e.preventDefault(); if (!wheelLock) stepBy(-1); }
  if (e.key === ' ') { e.preventDefault(); next(); }
});

/* ---- 退出应用：释放图片引用 ---- */
function releaseAll() {
  items.forEach((item) => { if (item.img) item.img.src = ''; });
  feed.innerHTML = '';
  items = [];
  current = 0;
}
window.addEventListener('pagehide', releaseAll);
window.addEventListener('beforeunload', releaseAll);

/* ---- 启动：先建 1 张（占位立即显示）再后台补 2 张，左右滑动浏览 ---- */
appendSlides(1).then(() => {
  if (items.length) appendSlides(2);
});
