/**
 * 小姐姐图片 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 两个接口：
 *   /api/random  调 xxapi「手机端小姐姐图片」接口取随机图片地址
 *   /api/img     同源代理图片（JSOS 强制 COEP require-corp，图片响应无
 *                ACAO/CORP 头，跨域直连会被 ERR_BLOCKED_BY_RESPONSE 拦掉，
 *                必须经同源代理；同 heisi-pic 的道理）
 *
 * 出站路由见 lib/http.js：容器内走 JSOS CORS 代理（自动适配官方/Vercel 两种
 * 协议形态），本机直跑直连。
 * 图片域实测为 images.xxapi.cn（文档示例的 cdn.xxhzm.cn 为旧域），白名单两者
 * 都放行，防文档回滚时挂掉。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outboundFetch, setProxyConfig, getProxyConfig } from './lib/http.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const API_URL = 'https://v2.xxapi.cn/api/wapmeinvpic?return=json';
const IMG_HOSTS = new Set(['images.xxapi.cn', 'cdn.xxhzm.cn']);

// JSOS 启动时注入 CORS 代理配置（容器内自动走代理，本机直跑直连）
if (process.env.PROXY_URL) {
  setProxyConfig({ url: process.env.PROXY_URL, key: process.env.PROXY_KEY || '' });
}

const app = express();
app.use(express.static(join(__dirname, 'public')));

function ok(res, data) {
  res.json({ ok: true, ...data });
}
function fail(res, error, status = 502) {
  res.status(status).json({ ok: false, error });
}

/** 校验并解析图片地址：仅允许白名单域的 https 地址（防 SSRF） */
function parseImgUrl(raw) {
  let u;
  try {
    u = new URL(String(raw || ''));
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' || !IMG_HOSTS.has(u.hostname)) return null;
  return u;
}

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  ok(res, {
    service: 'meinv-pic',
    proxyConfigured: !!getProxyConfig(),
    time: new Date().toISOString(),
  });
});

/* ------------------------------ 随机图片地址 ------------------------------ */

app.get('/api/random', async (req, res) => {
  try {
    const { res: up, via } = await outboundFetch(API_URL, {
      timeout: 15000,
      // 判据：响应是 JSON（代理层 401/400 是纯文本 → 自动换下一个候选）
      isOk: (r) => (r.headers.get('content-type') || '').includes('json'),
    });
    const data = await up.json();
    if (data.code !== 200 || !data.data) {
      throw new Error(data.msg || `接口返回 code=${data.code}`);
    }
    const imgUrl = parseImgUrl(data.data);
    if (!imgUrl) throw new Error('接口返回了非预期的图片地址');
    ok(res, { url: imgUrl.href, via });
  } catch (err) {
    fail(res, `获取图片失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 图片同源代理 ------------------------------ */

app.get('/api/img', async (req, res) => {
  const imgUrl = parseImgUrl(req.query.u);
  if (!imgUrl) {
    return fail(res, '仅允许代理白名单域的 https 图片地址', 400);
  }

  try {
    const { res: up } = await outboundFetch(imgUrl.href, {
      timeout: 30000,
      isOk: (r) => r.status === 200 && (r.headers.get('content-type') || '').startsWith('image/'),
    });

    res.status(up.status);
    for (const h of ['content-type', 'content-length']) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    // 图片是静态资源，允许浏览器缓存（同源代理地址稳定）
    const etag = up.headers.get('etag');
    if (etag) res.setHeader('etag', etag);
    res.setHeader('cache-control', 'public, max-age=86400');

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.pipe(res);
    stream.on('error', () => res.destroy());
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `图片拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

app.listen(port, () => {
  console.log(`[meinv-pic] listening on http://localhost:${port} (proxy: ${getProxyConfig() ? 'on' : 'off'})`);
});
