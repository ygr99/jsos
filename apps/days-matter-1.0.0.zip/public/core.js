/**
 * days-matter 共享核心：数据读写 + 日期计算
 * 主页面与 widget.html 同源共享 localStorage，storage 事件实时同步
 */

export const STORE_KEY = 'days-matter.events';

export const DEFAULT_EVENTS = [
  { name: '元旦', date: '2026-01-01', type: 'countdown', icon: '🎉', isPinned: false },
  { name: '春节', date: '2026-02-16', type: 'countdown', icon: '🧧', isPinned: false },
  { name: '发工资', date: '15', type: 'monthly', icon: '💰', isPinned: false },
  { name: '开始工作', date: '2020-07-01', type: 'passed', icon: '💼', isPinned: false },
];

export function loadEvents() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : null;
  } catch {
    return null;
  }
}

export function saveEvents(events) {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(events));
  } catch (e) {
    console.error('保存日子数据失败:', e);
  }
}

/**
 * 每月重复事件的下一次日期（date 为 1-31 的字符串/数字）
 * 该月没有对应日期（如2月30日）时取该月最后一天
 */
export function nextMonthlyDate(dayOfMonth, now = new Date()) {
  const day = parseInt(dayOfMonth);
  let d = new Date(now.getFullYear(), now.getMonth(), day);
  if (now.getDate() >= day) d = new Date(now.getFullYear(), now.getMonth() + 1, day);
  if (d.getDate() !== day) d = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  return d;
}

/**
 * 处理全部事件，附加 daysLeft（passed 类型为已过天数，取正）与 nextDate
 */
export function processEvents(events, now = new Date()) {
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const DAY = 1000 * 60 * 60 * 24;

  return (events || []).map((event) => {
    if (event.type === 'monthly') {
      const d = nextMonthlyDate(event.date, today);
      return { ...event, daysLeft: Math.ceil((d - today) / DAY), nextDate: fmt(d) };
    }
    const d = new Date(event.date);
    d.setHours(0, 0, 0, 0);
    const diff = Math.ceil((d - today) / DAY);
    if (event.type === 'passed') return { ...event, daysLeft: Math.abs(diff), nextDate: fmt(d) };
    return { ...event, daysLeft: diff, nextDate: fmt(d) };
  });
}

function fmt(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 小组件展示对象：置顶优先，否则取剩余天数最近的 countdown/monthly（daysLeft > 0）
 */
export function pickWidgetEvent(processed) {
  const pinned = processed.filter((e) => e.isPinned);
  if (pinned.length) return pinned[0];
  const valid = processed
    .filter((e) => e.type === 'countdown' || e.type === 'monthly')
    .filter((e) => e.daysLeft > 0)
    .sort((a, b) => a.daysLeft - b.daysLeft);
  return valid.length ? valid[0] : null;
}
