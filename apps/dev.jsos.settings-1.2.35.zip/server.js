import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PROXY_CONFIG_PATH = path.join(DATA_DIR, 'proxy-configs.json');

// 确保 DATA_DIR 存在
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 默认代理配置（2026-09-05 切换自建 jsos-cors-proxy）
const DEFAULT_PROXY_URL = 'https://proxy.xn--4gqta1h0zg9yuu7a.fun';
const LEGACY_PROXY_URL = 'https://cors-proxy.jsos.dev';

const DEFAULT_DATA = {
  configs: [
    {
      id: 'default',
      name: '默认代理',
      url: DEFAULT_PROXY_URL,
      key: 'hello-world',
      isDefault: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  ],
  activeId: 'default',
};

// MIME 类型映射
const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function readProxyConfig() {
  try {
    if (!fs.existsSync(PROXY_CONFIG_PATH)) {
      fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(DEFAULT_DATA, null, 2), 'utf8');
      return DEFAULT_DATA;
    }
    const raw = fs.readFileSync(PROXY_CONFIG_PATH, 'utf8');
    const data = JSON.parse(raw);
    // 兼容：确保有 default 配置
    if (!data.configs || !Array.isArray(data.configs)) {
      return DEFAULT_DATA;
    }
    // 迁移：官方旧代理地址 → 自建 jsos-cors-proxy（升级保数据的容器自动切换）
    let migrated = false;
    for (const c of data.configs) {
      if (c.url === LEGACY_PROXY_URL) {
        c.url = DEFAULT_PROXY_URL;
        c.updatedAt = Date.now();
        migrated = true;
      }
    }
    if (migrated) writeProxyConfig(data);
    const hasDefault = data.configs.some(c => c.isDefault);
    if (!hasDefault) {
      data.configs.unshift(DEFAULT_DATA.configs[0]);
    }
    if (!data.activeId) {
      data.activeId = 'default';
    }
    return data;
  } catch {
    return DEFAULT_DATA;
  }
}

function writeProxyConfig(data) {
  fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(data, null, 2), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  // CORS headers for API
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // API: proxy configs
  if (pathname === '/api/proxy-configs') {
    try {
      if (req.method === 'GET') {
        const data = readProxyConfig();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(data));
      }
      if (req.method === 'PUT') {
        const body = await readBody(req);
        const data = JSON.parse(body);
        writeProxyConfig(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ ok: true }));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // Static file serving
  let decoded = decodeURIComponent(pathname);

  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }

  let target = path.resolve(path.join(ROOT, decoded));

  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  // 目录默认 index.html
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }

  fs.readFile(target, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

server.listen(process.env.PORT, () => console.log(process.env.PORT));
