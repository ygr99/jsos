/**
 * 1Panel 面板 —— 应用服务端
 * ---------------------------------------------------------------
 * 零依赖（纯 node:http + node:crypto），installCommand 为空 → WebContainer 里秒起。
 *
 * 出站策略（对齐 jsos-apps/AGENTS.md §5.5 / §8）：
 *   - 读到 PROXY_URL（JSOS 容器自动注入）→ 面板请求全走系统 CORS 代理
 *     （容器内 Node fetch 走浏览器网络栈，面板多为 http + 非标端口 → 混合内容 + CORS 双重拦截）
 *     代理形态优先 encoded 路径，遇 "Invalid target URL" 回退裸路径（老部署只认裸形态）
 *   - 未读到（本机直跑）→ 直连，方便本机调试
 *
 * 签名：1Panel 两种 Token 都实现。实测该面板只认 MD5，故 auto 模式先 MD5 后 HMAC，
 *       成功后把命中的方式回写配置（下次直连命中，不做无用重试）。
 *
 * 数据：配置存 DATA_DIR/config.json（平台快照持久化）；实时速率与趋势是过程数据，只放内存。
 */

import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');

const PROXY_URL = String(process.env.PROXY_URL || '').replace(/\/+$/, '');
const PROXY_KEY = String(process.env.PROXY_KEY || 'hello-world');
const IN_CONTAINER = Boolean(PROXY_URL);

const HISTORY_MAX = 240;

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/* ------------------------------ 配置 ------------------------------ */

const DEFAULT_CONFIG = {
  baseUrl: '',
  apiKey: '',
  signMode: 'auto', // auto | md5 | hmac
  refreshInterval: 5000,
  apiBase: '', // 解析后的接口根（去掉安全入口路径），由 /api/test 或首次调用写入
};

function getConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) return { ...DEFAULT_CONFIG };
    const raw = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    return { ...DEFAULT_CONFIG, ...raw };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}

function saveConfig(patch) {
  const next = { ...getConfig(), ...patch };
  const tmp = CONFIG_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(next, null, 2), 'utf8');
  fs.renameSync(tmp, CONFIG_PATH); // 原子写
  return next;
}

function maskKey(key) {
  if (!key) return '';
  if (key.length <= 10) return key.slice(0, 2) + '****';
  return key.slice(0, 6) + '****' + key.slice(-4);
}

/* --------------------------- 请求与签名 --------------------------- */

function sign(apiKey, timestamp, mode) {
  if (mode === 'hmac') {
    return crypto.createHmac('sha256', apiKey).update('1panel:' + timestamp).digest('hex');
  }
  return crypto.createHash('md5').update('1panel' + apiKey + timestamp).digest('hex');
}

/** 面板请求：容器内走系统代理（encoded → 裸路径回退），本机直连 */
async function rawFetch(target, { method = 'GET', headers = {}, timeout = 20000 } = {}) {
  if (!IN_CONTAINER) {
    return fetch(target, { method, headers, redirect: 'follow', signal: AbortSignal.timeout(timeout) });
  }
  const qs = 'x-cors-proxy-key=' + encodeURIComponent(PROXY_KEY);
  const attempts = [
    `${PROXY_URL}/${encodeURIComponent(target)}?${qs}`,
    `${PROXY_URL}/${target}?${qs}`,
  ];
  const h = { ...headers, 'x-cors-proxy-key': PROXY_KEY };
  let res = null;
  for (const url of attempts) {
    res = await fetch(url, { method, headers: h, redirect: 'follow', signal: AbortSignal.timeout(timeout) });
    if (res.status !== 400) return res;
    const body = await res.clone().text().catch(() => '');
    if (!/invalid target url/i.test(body)) return res;
  }
  return res;
}

function joinUrl(base, apiPath) {
  return base.replace(/\/+$/, '') + apiPath;
}

const API_PATH = '/api/v2';

/**
 * 调用 1Panel 接口。返回 { ok, code, data, message, error }
 * 注意：1Panel 鉴权失败也返回 HTTP 200 + code 401 → 必须看 body.code。
 */
async function panelRequest(cfg, apiPath, { method = 'GET', signMode } = {}) {
  if (!cfg.baseUrl || !cfg.apiKey) {
    return { ok: false, error: 'not-configured', message: '请先配置面板地址与接口密钥' };
  }
  const base = cfg.apiBase || cfg.baseUrl;
  const modes = signMode ? [signMode] : (cfg.signMode === 'auto' ? ['md5', 'hmac'] : [cfg.signMode]);

  let lastResult = null;
  for (const mode of modes) {
    const ts = Math.floor(Date.now() / 1000).toString();
    const token = sign(cfg.apiKey, ts, mode);
    let res;
    try {
      res = await rawFetch(joinUrl(base, API_PATH + apiPath), {
        method,
        headers: { '1Panel-Token': token, '1Panel-Timestamp': ts, Accept: 'application/json' },
      });
    } catch (e) {
      return {
        ok: false,
        error: e?.name === 'TimeoutError' ? 'timeout' : 'network',
        message: e?.name === 'TimeoutError' ? '请求超时，面板未响应' : '无法连接面板：' + (e?.message || '网络错误'),
      };
    }
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* 非 JSON（面板反代/入口校验页） */ }

    if (res.status !== 200 || !json) {
      const isEntrance = /<(html|!doctype)/i.test(text);
      return {
        ok: false,
        error: isEntrance ? 'bad-base' : 'http-' + res.status,
        message: isEntrance
          ? `返回的是网页而不是接口（HTTP ${res.status}），面板地址可能填错，或带了安全入口路径`
          : `面板返回 HTTP ${res.status}`,
      };
    }
    if (json.code === 200) {
      return { ok: true, code: 200, data: json.data, message: json.message || '', mode };
    }
    lastResult = { ok: false, error: 'api-' + json.code, message: json.message || `接口返回 code ${json.code}`, code: json.code };
    // 鉴权类错误才继续尝试另一种签名；其他业务错误直接返回
    if (json.code !== 401) return lastResult;
  }
  return lastResult || { ok: false, error: 'unknown', message: '请求失败' };
}

/** 解析接口根：允许用户误填安全入口路径，回退到 origin 再试一次 */
async function resolveApiBase(baseUrl, apiKey, signMode) {
  const trimmed = String(baseUrl || '').trim().replace(/\/+$/, '');
  if (!trimmed) return { ok: false, error: 'bad-url', message: '面板地址不能为空' };
  let origin = '';
  try { origin = new URL(trimmed).origin; } catch { return { ok: false, error: 'bad-url', message: '面板地址不是合法 URL' }; }

  const candidates = origin && origin !== trimmed ? [trimmed, origin] : [trimmed];
  let last = null;
  for (const cand of candidates) {
    const r = await panelRequest(
      { baseUrl: cand, apiKey, signMode: signMode || 'auto', apiBase: '' },
      '/dashboard/base/os',
    );
    if (r.ok) return { ok: true, apiBase: cand, data: r.data, mode: r.mode };
    last = r;
  }
  return last;
}

/* --------------------------- 速率与趋势 --------------------------- */

let lastSample = null; // 累计计数器 → 速率需要两次采样
const history = [];    // { t, cpu, mem, load }

function computeRates(cur) {
  const now = Date.now();
  const rates = { netRecvRate: 0, netSentRate: 0, ioReadRate: 0, ioWriteRate: 0, interval: 0 };
  if (lastSample) {
    const dt = (now - lastSample.t) / 1000;
    if (dt >= 0.5) {
      // 计数器在面板重启/网卡变化时会回绕 → 负数一律按 0 处理
      const d = (a, b) => (a >= b ? (a - b) / dt : 0);
      rates.netRecvRate = d(cur.netBytesRecv, lastSample.netBytesRecv);
      rates.netSentRate = d(cur.netBytesSent, lastSample.netBytesSent);
      rates.ioReadRate = d(cur.ioReadBytes, lastSample.ioReadBytes);
      rates.ioWriteRate = d(cur.ioWriteBytes, lastSample.ioWriteBytes);
      rates.interval = dt;
    }
  }
  lastSample = {
    t: now,
    netBytesRecv: cur.netBytesRecv || 0,
    netBytesSent: cur.netBytesSent || 0,
    ioReadBytes: cur.ioReadBytes || 0,
    ioWriteBytes: cur.ioWriteBytes || 0,
  };
  return rates;
}

function pushHistory(cur) {
  history.push({
    t: Date.now(),
    cpu: round2(cur.cpuUsedPercent),
    mem: round2(cur.memoryUsedPercent),
    load: round2(cur.loadUsagePercent),
  });
  while (history.length > HISTORY_MAX) history.shift();
}

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function loadStatusText(pct) {
  const p = Number(pct) || 0;
  if (p < 30) return '运行流畅';
  if (p < 70) return '运行正常';
  if (p < 80) return '运行缓慢';
  return '运行堵塞';
}

/** 归一化：前端与小组件只认这一份结构 */
function normalize(base) {
  const cur = base.currentInfo || {};
  const disk = Array.isArray(cur.diskData) && cur.diskData.length ? cur.diskData[0] : null;
  return {
    host: {
      hostname: base.hostname || '',
      prettyDistro: base.prettyDistro || base.platform || '',
      platformVersion: base.platformVersion || '',
      kernelVersion: base.kernelVersion || '',
      kernelArch: base.kernelArch || '',
      ipV4Addr: base.ipV4Addr || '',
      systemProxy: base.systemProxy || '',
      cpuModelName: base.cpuModelName || '',
      cpuCores: base.cpuCores || 0,
      cpuLogicalCores: base.cpuLogicalCores || 0,
      cpuMhz: base.cpuMhz || 0,
    },
    counts: {
      website: base.websiteNumber || 0,
      database: base.databaseNumber || 0,
      cronjob: base.cronjobNumber || 0,
      appInstalled: base.appInstalledNumber || 0,
      agent: base.agentNumber || 0,
    },
    current: {
      uptime: cur.uptime || 0,
      bootTime: cur.timeSinceUptime || '',
      procs: cur.procs || 0,
      load1: round2(cur.load1),
      load5: round2(cur.load5),
      load15: round2(cur.load15),
      loadUsagePercent: round2(cur.loadUsagePercent),
      loadStatus: loadStatusText(cur.loadUsagePercent),
      cpuUsedPercent: round2(cur.cpuUsedPercent),
      cpuUsed: round2(cur.cpuUsed),
      cpuTotal: cur.cpuTotal || 0,
      cpuPercent: cur.cpuPercent || [],
      cpuDetailedPercent: cur.cpuDetailedPercent || [],
      memoryTotal: cur.memoryTotal || 0,
      memoryUsed: cur.memoryUsed || 0,
      memoryAvailable: cur.memoryAvailable || 0,
      memoryCache: cur.memoryCache || 0,
      memoryUsedPercent: round2(cur.memoryUsedPercent),
      swapMemoryTotal: cur.swapMemoryTotal || 0,
      swapMemoryUsed: cur.swapMemoryUsed || 0,
      swapMemoryUsedPercent: round2(cur.swapMemoryUsedPercent),
      disk: disk && {
        path: disk.path,
        type: disk.type,
        device: disk.device,
        total: disk.total,
        used: disk.used,
        free: disk.free,
        usedPercent: round2(disk.usedPercent),
        inodesUsedPercent: round2(disk.inodesUsedPercent),
      },
      disks: (cur.diskData || []).map((d) => ({
        path: d.path, type: d.type, device: d.device,
        total: d.total, used: d.used, free: d.free, usedPercent: round2(d.usedPercent),
      })),
      netBytesSent: cur.netBytesSent || 0,
      netBytesRecv: cur.netBytesRecv || 0,
      ioReadBytes: cur.ioReadBytes || 0,
      ioWriteBytes: cur.ioWriteBytes || 0,
      gpuData: cur.gpuData || null,
      xpuData: cur.xpuData || null,
      shotTime: cur.shotTime || '',
    },
  };
}

/* ------------------------------ 工具 ------------------------------ */

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

/* ------------------------------ 路由 ------------------------------ */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  try {
    // 就绪探针（测试脚本轮询用）
    if (p === '/api/ping') return sendJson(res, 200, { ok: true, inContainer: IN_CONTAINER });

    // 配置读取
    if (p === '/api/config' && req.method === 'GET') {
      const cfg = getConfig();
      return sendJson(res, 200, {
        baseUrl: cfg.baseUrl,
        hasKey: Boolean(cfg.apiKey),
        maskedKey: maskKey(cfg.apiKey),
        signMode: cfg.signMode,
        refreshInterval: cfg.refreshInterval,
        apiBase: cfg.apiBase,
        inContainer: IN_CONTAINER,
        configured: Boolean(cfg.baseUrl && cfg.apiKey),
      });
    }

    // 配置保存（apiKey 省略/空字符串 = 不改动已有密钥）
    if (p === '/api/config' && req.method === 'POST') {
      const body = JSON.parse((await readBody(req)) || '{}');
      const patch = {};
      if (typeof body.baseUrl === 'string') patch.baseUrl = body.baseUrl.trim();
      if (typeof body.apiKey === 'string' && body.apiKey.trim()) patch.apiKey = body.apiKey.trim();
      if (['auto', 'md5', 'hmac'].includes(body.signMode)) patch.signMode = body.signMode;
      const ri = Number(body.refreshInterval);
      if (Number.isFinite(ri) && ri >= 2000 && ri <= 60000) patch.refreshInterval = Math.round(ri);

      const baseChanged = patch.baseUrl !== undefined && patch.baseUrl !== getConfig().baseUrl;
      if (baseChanged) patch.apiBase = '';
      const saved = saveConfig(patch);

      let test = null;
      if (saved.baseUrl && saved.apiKey) {
        const r = await resolveApiBase(saved.baseUrl, saved.apiKey, saved.signMode);
        test = r.ok
          ? { ok: true, message: '连接成功', apiBase: r.apiBase, os: r.data }
          : { ok: false, message: r.message, error: r.error };
        if (r.ok && r.apiBase !== saved.apiBase) {
          saveConfig({ apiBase: r.apiBase });
        }
      }
      const cfg2 = getConfig();
      return sendJson(res, 200, {
        ok: true,
        test,
        config: {
          baseUrl: cfg2.baseUrl, hasKey: Boolean(cfg2.apiKey), maskedKey: maskKey(cfg2.apiKey),
          signMode: cfg2.signMode, refreshInterval: cfg2.refreshInterval, apiBase: cfg2.apiBase,
          inContainer: IN_CONTAINER, configured: Boolean(cfg2.baseUrl && cfg2.apiKey),
        },
      });
    }

    // 连接测试（用传入值试，不落盘）
    if (p === '/api/test' && req.method === 'POST') {
      const body = JSON.parse((await readBody(req)) || '{}');
      const cfg = getConfig();
      const baseUrl = (body.baseUrl || cfg.baseUrl || '').trim();
      const apiKey = (body.apiKey || '').trim() || cfg.apiKey;
      const signMode = ['auto', 'md5', 'hmac'].includes(body.signMode) ? body.signMode : cfg.signMode;
      if (!baseUrl || !apiKey) return sendJson(res, 200, { ok: false, message: '请先填写面板地址与接口密钥' });
      const r = await resolveApiBase(baseUrl, apiKey, signMode);
      if (!r.ok) return sendJson(res, 200, { ok: false, message: r.message || '连接失败', error: r.error });
      return sendJson(res, 200, { ok: true, message: '连接成功', apiBase: r.apiBase, mode: r.mode, os: r.data });
    }

    // 概览：一次拿全部（base/all/all 已含 currentInfo）
    if (p === '/api/overview' && req.method === 'GET') {
      const cfg = getConfig();
      if (!cfg.baseUrl || !cfg.apiKey) {
        return sendJson(res, 200, { ok: false, error: 'not-configured', message: '请先在「设置」里填写面板地址与接口密钥' });
      }
      const r = await panelRequest(cfg, '/dashboard/base/all/all');
      if (!r.ok) return sendJson(res, 200, { ok: false, error: r.error, message: r.message });
      const norm = normalize(r.data || {});
      const rates = computeRates(norm.current);
      pushHistory(norm.current);
      return sendJson(res, 200, {
        ok: true,
        ...norm,
        rates,
        history: history.slice(),
        refreshInterval: cfg.refreshInterval,
        fetchedAt: Date.now(),
      });
    }

    // 进程排行
    if (p === '/api/processes' && req.method === 'GET') {
      const type = url.searchParams.get('type') === 'mem' ? 'mem' : 'cpu';
      const cfg = getConfig();
      if (!cfg.baseUrl || !cfg.apiKey) {
        return sendJson(res, 200, { ok: false, error: 'not-configured', message: '请先在「设置」里填写面板地址与接口密钥' });
      }
      const r = await panelRequest(cfg, `/dashboard/current/top/${type}`);
      if (!r.ok) return sendJson(res, 200, { ok: false, error: r.error, message: r.message });
      return sendJson(res, 200, { ok: true, type, items: r.data || [] });
    }

    // 静态文件 + SPA 回退（/widget/status 这类路由要落到 index.html）
    let decoded;
    try { decoded = decodeURIComponent(p); } catch { res.writeHead(400); return res.end('Bad Request'); }
    if (decoded.includes('\0')) { res.writeHead(400); return res.end('Bad Request'); }

    const target = path.resolve(path.join(ROOT, decoded));
    if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
      res.writeHead(403); return res.end('Forbidden');
    }
    const isDir = fs.existsSync(target) && fs.statSync(target).isDirectory();
    const file = isDir ? path.join(target, 'index.html') : target;

    if (fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
      return res.end(fs.readFileSync(file));
    }
    const index = path.join(ROOT, 'index.html');
    if (fs.existsSync(index)) {
      res.writeHead(200, { 'Content-Type': MIME['.html'] });
      return res.end(fs.readFileSync(index));
    }
    res.writeHead(404); res.end('Not Found');
  } catch (e) {
    sendJson(res, 500, { ok: false, error: 'server', message: e?.message || '服务端异常' });
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`1Panel 面板服务已启动：http://localhost:${PORT}${IN_CONTAINER ? '（容器内，出站走 CORS 代理）' : '（本机直连）'}`));

process.on('SIGTERM', () => server.close());
process.on('SIGINT', () => server.close());
