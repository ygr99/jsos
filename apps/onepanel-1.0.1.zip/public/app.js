'use strict';

/* =============================== 工具 =============================== */

const $ = (id) => document.getElementById(id);
const ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ESC_MAP[c]);
const clamp = (n) => Math.max(0, Math.min(100, Number(n) || 0));

/** 主界面百分比：<100 保留 1 位小数 */
const fmtPct = (n) => (clamp(n) >= 100 ? '100' : clamp(n).toFixed(1));

/** 字节 → 人类可读（1Panel 风格：<10 两位小数，<100 一位，其余整数） */
function fmtBytes(n) {
  let v = Number(n) || 0;
  if (v < 1024) return Math.round(v) + ' B';
  const units = ['KB', 'MB', 'GB', 'TB', 'PB'];
  let i = -1;
  do { v /= 1024; i += 1; } while (v >= 1024 && i < units.length - 1);
  const d = v >= 100 ? 0 : v >= 10 ? 1 : 2;
  return v.toFixed(d) + ' ' + units[i];
}

/** 成对数值（已用 / 总量）按总量决定小数位，避免出现 15.7 GB / 39.0 GB 这种不齐 */
function fmtRatio(used, total) {
  const t = Number(total) || 0;
  if (!t) return '—';
  const d = t >= 100 * 1024 ** 3 ? 0 : 2;
  const cut = (n) => {
    let v = Number(n) || 0;
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    let i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
    if (i === 0) return Math.round(v) + ' B';
    const dd = v >= 100 ? 0 : i >= 3 ? d : 2;
    return v.toFixed(dd) + ' ' + units[i];
  };
  return cut(used) + ' / ' + cut(t);
}

/** 小组件用的紧凑字节：1.14G / 295M */
function fmtBytesShort(n) {
  let v = Number(n) || 0;
  if (v < 1024) return Math.round(v) + 'B';
  const units = ['K', 'M', 'G', 'T', 'P'];
  let i = -1;
  do { v /= 1024; i += 1; } while (v >= 1024 && i < units.length - 1);
  return (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)) + units[i];
}

const fmtRate = (v) => fmtBytes(v) + '/s';

function fmtUptime(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return `${d} 天 ${h} 小时 ${m} 分`;
  if (h > 0) return `${h} 小时 ${m} 分`;
  return `${m} 分`;
}

const fmtNum = (n, d = 2) => (Number(n) || 0).toFixed(d);

/* =============================== 状态环 =============================== */

function ringColor(p) {
  if (p >= 85) return '#dc2626';
  if (p >= 70) return '#d97706';
  return '#0f9488';
}

function ringSvg(pct, size, stroke, color) {
  const p = clamp(pct);
  const c = size / 2;
  const r = (size - stroke) / 2;
  const len = 2 * Math.PI * r;
  const dash = (p / 100) * len;
  return `<svg class="ring-svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="#eceff3" stroke-width="${stroke}" />
    <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${color || ringColor(p)}" stroke-width="${stroke}"
      stroke-linecap="round" stroke-dasharray="${dash.toFixed(2)} ${(len - dash).toFixed(2)}"
      transform="rotate(-90 ${c} ${c})" />
  </svg>`;
}

/* =============================== 趋势 =============================== */

/** 百分比系列画在固定 0~100 刻度上，纵向可比 */
function sparkline(values, color) {
  const n = values.length;
  if (!n) return '<div class="loading">等待采样…</div>';
  const W = 240, H = 38, pad = 3;
  const x = (i) => (n === 1 ? W / 2 : (i / (n - 1)) * W);
  const y = (v) => H - pad - (clamp(v) / 100) * (H - pad * 2);
  const pts = values.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${x(0).toFixed(1)},${H} ${pts} ${x(n - 1).toFixed(1)},${H}`;
  return `<svg class="trend-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
    <polygon points="${area}" fill="${color}" opacity="0.1" />
    <polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.6"
      stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" />
  </svg>`;
}

/* =============================== 主界面 =============================== */

const state = {
  config: null,
  overview: null,
  procType: 'cpu',
  processes: null,
  view: 'overview',
  timer: null,
};

function initApp() {
  initCollapse();
  initNav();
  initProcessSeg();
  initSettings();
  $('refresh-btn').addEventListener('click', () => { tick(true); });
  $('notice-btn').addEventListener('click', () => setView('settings'));

  document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); });

  loadConfig().then(() => {
    startPolling();
  });
}

/* ----- 侧边栏折叠（AGENTS.md §5.1） ----- */

const COLLAPSE_KEY = 'onepanel.sidebar-collapsed';

function initCollapse() {
  const shell = $('shell');
  const btn = $('collapse-btn');
  const apply = (collapsed) => {
    shell.classList.toggle('collapsed', collapsed);
    // 可见性真相看 computed display；SVG 的 .hidden 属性不可靠 → 写 content attribute
    btn.querySelector('.ico-open').toggleAttribute('hidden', collapsed);
    btn.querySelector('.ico-close').toggleAttribute('hidden', !collapsed);
    btn.setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    btn.setAttribute('title', collapsed ? '展开侧边栏' : '折叠侧边栏');
  };
  let collapsed = false;
  try { collapsed = localStorage.getItem(COLLAPSE_KEY) === '1'; } catch { /* 隐私模式 */ }
  apply(collapsed);
  btn.addEventListener('click', () => {
    collapsed = !shell.classList.contains('collapsed');
    apply(collapsed);
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch { /* ignore */ }
  });
}

/* ----- 视图切换 ----- */

const VIEW_TITLE = { overview: '概览', process: '进程', settings: '设置' };

function setView(view) {
  state.view = view;
  document.querySelectorAll('.nav-item').forEach((el) => {
    const on = el.dataset.view === view;
    el.classList.toggle('is-active', on);
  });
  document.querySelectorAll('.view').forEach((el) => {
    el.classList.toggle('is-active', el.id === 'view-' + view);
  });
  $('view-title').textContent = VIEW_TITLE[view] || view;
  if (view === 'settings') renderConfigForm(state.config);
  if (view === 'process') refreshProcesses();
  if (view === 'overview') refreshOverview();
}

function initNav() {
  document.querySelectorAll('.nav-item').forEach((el) => {
    el.addEventListener('click', () => setView(el.dataset.view));
  });
}

/* ----- 提示 ----- */

function showNotice(on) { $('notice').hidden = !on; }
function showError(msg) {
  const bar = $('error-bar');
  bar.hidden = !msg;
  bar.textContent = msg || '';
}

/* ----- 轮询 ----- */

function startPolling() {
  stopPolling();
  const iv = (state.config && state.config.refreshInterval) || 5000;
  state.timer = setInterval(tick, iv);
  tick();
}

function stopPolling() {
  if (state.timer) { clearInterval(state.timer); state.timer = null; }
}

async function tick(force) {
  if (state.view === 'overview') await refreshOverview();
  else if (state.view === 'process') await Promise.all([refreshOverview(), refreshProcesses(force)]);
}

async function loadConfig() {
  try {
    state.config = await fetch('/api/config').then((r) => r.json());
  } catch {
    state.config = null;
  }
  return state.config;
}

/* ----- 概览 ----- */

async function refreshOverview() {
  let r;
  try {
    r = await fetch('/api/overview').then((x) => x.json());
  } catch (e) {
    showError('请求失败：' + (e.message || '网络错误'));
    return;
  }
  if (!r || !r.ok) {
    const notConfigured = r && r.error === 'not-configured';
    showNotice(notConfigured);
    showError(notConfigured ? '' : (r && r.message) || '读取失败');
    return;
  }
  showNotice(false);
  showError('');
  state.overview = r;
  renderOverview(r);
  const t = new Date(r.fetchedAt || Date.now());
  $('updated').textContent = '更新于 ' + t.toLocaleTimeString('zh-CN', { hour12: false });
}

function renderOverview(r) {
  const c = r.current || {};
  const h = r.host || {};

  $('host-line').textContent = [h.hostname, h.prettyDistro].filter(Boolean).join(' · ');

  const disk = c.disk || null;
  const ring = (pct, label, sub, title) => `
    <div class="ring-item" title="${esc(title || '')}">
      <div class="ring-wrap">
        ${ringSvg(pct, 132, 9)}
        <div class="ring-center">
          <div class="ring-value">${fmtPct(pct)}<em>%</em></div>
          <div class="ring-label">${esc(label)}</div>
        </div>
      </div>
      <div class="ring-sub">${esc(sub)}</div>
    </div>`;

  $('rings').innerHTML = [
    ring(c.loadUsagePercent, '负载', c.loadStatus || '—',
      `1 分钟 ${fmtNum(c.load1, 2)} · 5 分钟 ${fmtNum(c.load5, 2)} · 15 分钟 ${fmtNum(c.load15, 2)}`),
    ring(c.cpuUsedPercent, 'CPU', `( ${fmtNum(c.cpuUsed, 2)} / ${c.cpuTotal || 0} ) 核`,
      (h.cpuModelName || '') + (h.cpuMhz ? ` @ ${fmtNum(h.cpuMhz, 0)} MHz` : '')),
    ring(c.memoryUsedPercent, '内存', fmtRatio(c.memoryUsed, c.memoryTotal),
      `可用 ${fmtBytes(c.memoryAvailable)} · 缓存 ${fmtBytes(c.memoryCache)}`),
    ring(disk ? disk.usedPercent : 0, disk ? disk.path : '磁盘',
      disk ? fmtRatio(disk.used, disk.total) : '—',
      disk ? `${disk.device || ''} ${disk.type || ''}`.trim() : '无磁盘数据'),
  ].join('');

  const kv = (rows) => rows.map(([k, v, mono]) =>
    `<dt>${esc(k)}</dt><dd class="${mono ? 'mono' : ''}">${esc(v)}</dd>`).join('');

  $('sysinfo').innerHTML = kv([
    ['主机名', h.hostname || '—'],
    ['操作系统', h.prettyDistro || '—'],
    ['内核版本', h.kernelVersion || '—', true],
    ['系统架构', h.kernelArch || '—', true],
    ['CPU 型号', h.cpuModelName || '—'],
    ['核心数', `${h.cpuCores || 0} 核 / ${h.cpuLogicalCores || 0} 逻辑核`],
    ['内网地址', h.ipV4Addr || '—', true],
    ['运行时长', fmtUptime(c.uptime)],
    ['启动时间', c.bootTime || '—'],
    ['进程数', String(c.procs || 0)],
  ]);

  const rt = r.rates || {};
  $('transfers').innerHTML = kv([
    ['下行速率', fmtRate(rt.netRecvRate)],
    ['上行速率', fmtRate(rt.netSentRate)],
    ['磁盘读取', fmtRate(rt.ioReadRate)],
    ['磁盘写入', fmtRate(rt.ioWriteRate)],
    ['累计下行', fmtBytes(c.netBytesRecv)],
    ['累计上行', fmtBytes(c.netBytesSent)],
    ['累计读取', fmtBytes(c.ioReadBytes)],
    ['累计写入', fmtBytes(c.ioWriteBytes)],
    ['Swap 使用', fmtRatio(c.swapMemoryUsed, c.swapMemoryTotal)],
    ['Swap 占用', fmtPct(c.swapMemoryUsedPercent) + ' %'],
  ]);

  const hist = r.history || [];
  const series = (key) => hist.map((p) => p[key]);
  const trend = (name, key, color) => `
    <div class="trend">
      <div class="trend-head">
        <span class="trend-name">${name}</span>
        <span class="trend-now">${fmtPct(series(key).slice(-1)[0] || 0)}<em>%</em></span>
      </div>
      ${sparkline(series(key), color)}
    </div>`;
  $('trends').innerHTML =
    trend('CPU', 'cpu', '#0f9488') +
    trend('内存', 'mem', '#6366f1') +
    trend('负载', 'load', '#d97706');

  if (r.rates && r.rates.interval) {
    $('trend-note').textContent = `共 ${hist.length} 个采样点 · 间隔 ${r.rates.interval.toFixed(1)}s`;
  } else {
    $('trend-note').textContent = hist.length > 1 ? `共 ${hist.length} 个采样点` : '正在采样…';
  }

  const cnt = r.counts || {};
  const counts = [
    ['网站', cnt.website], ['数据库', cnt.database], ['已装应用', cnt.appInstalled],
    ['计划任务', cnt.cronjob], ['智能体', cnt.agent],
  ].filter(([n, v]) => !(n === '智能体' && !v));
  $('counts').innerHTML = counts.map(([name, value]) =>
    `<div class="count"><div class="count-value">${Number(value) || 0}</div><div class="count-name">${esc(name)}</div></div>`).join('');
}

/* ----- 进程 ----- */

function initProcessSeg() {
  document.querySelectorAll('#proc-seg .seg-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.procType = btn.dataset.type;
      document.querySelectorAll('#proc-seg .seg-btn').forEach((b) => b.classList.toggle('is-active', b === btn));
      refreshProcesses();
    });
  });
}

async function refreshProcesses() {
  const type = state.procType;
  let r;
  try {
    r = await fetch('/api/processes?type=' + type).then((x) => x.json());
  } catch (e) {
    showError('进程读取失败：' + (e.message || '网络错误'));
    return;
  }
  if (!r || !r.ok) {
    showError(r && r.message ? r.message : '进程读取失败');
    return;
  }
  showError('');
  state.processes = r.items || [];
  renderProcesses(state.processes, type);
}

function renderProcesses(items, type) {
  $('proc-metric-head').textContent = type === 'cpu' ? 'CPU 占用' : '内存占用';
  const body = $('proc-body');
  const empty = $('proc-empty');
  empty.hidden = items.length > 0;
  if (!items.length) { body.innerHTML = ''; return; }

  body.innerHTML = items.map((p) => {
    const pct = Number(p.percent) || 0;
    const mem = Number(p.memory) || 0;
    const sub = type === 'mem' && mem ? `<span class="cell-sub">${fmtBytes(mem)}</span>` : '';
    const user = !p.user || p.user === 'undefined' ? '—' : p.user;
    return `<tr>
      <td class="cell-name">${esc(p.name || '—')}</td>
      <td class="num">${esc(p.pid == null ? '—' : p.pid)}</td>
      <td class="cell-user">${esc(user)}</td>
      <td class="num">${pct.toFixed(2)} %${sub}</td>
      <td><div class="cell-cmd" title="${esc(p.cmd || '')}">${esc(p.cmd || '—')}</div></td>
    </tr>`;
  }).join('');
}

/* ----- 设置 ----- */

function initSettings() {
  $('cfg-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = $('cfg-msg');
    msg.className = 'form-msg';
    msg.textContent = '保存中…';
    const body = {
      baseUrl: $('cfg-baseurl').value.trim(),
      signMode: $('cfg-signmode').value,
      refreshInterval: Number($('cfg-interval').value),
    };
    const key = $('cfg-apikey').value.trim();
    if (key) body.apiKey = key;
    try {
      const r = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }).then((x) => x.json());
      state.config = r.config;
      $('cfg-apikey').value = '';
      renderConfigForm(state.config);
      if (r.test && r.test.ok) {
        msg.className = 'form-msg ok';
        msg.textContent = '已保存，连接成功';
      } else if (r.test) {
        msg.className = 'form-msg err';
        msg.textContent = '已保存，但连接失败：' + (r.test.message || '');
      } else {
        msg.className = 'form-msg ok';
        msg.textContent = '已保存';
      }
      startPolling();
    } catch (err) {
      msg.className = 'form-msg err';
      msg.textContent = '保存失败：' + (err.message || '网络错误');
    }
  });

  $('test-btn').addEventListener('click', async () => {
    const msg = $('cfg-msg');
    const btn = $('test-btn');
    msg.className = 'form-msg';
    msg.textContent = '测试中…';
    btn.disabled = true;
    try {
      const r = await fetch('/api/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          baseUrl: $('cfg-baseurl').value.trim(),
          apiKey: $('cfg-apikey').value.trim(),
          signMode: $('cfg-signmode').value,
        }),
      }).then((x) => x.json());
      if (r.ok) {
        msg.className = 'form-msg ok';
        const os = r.os || {};
        msg.textContent = `连接成功：${os.prettyDistro || os.platform || 'OK'}（${r.mode === 'hmac' ? 'HMAC-SHA256' : 'MD5'} 签名）`;
      } else {
        msg.className = 'form-msg err';
        msg.textContent = r.message || '连接失败';
      }
    } catch (err) {
      msg.className = 'form-msg err';
      msg.textContent = '测试失败：' + (err.message || '网络错误');
    } finally {
      btn.disabled = false;
    }
  });
}

function renderConfigForm(cfg) {
  if (!cfg) return;
  $('cfg-baseurl').value = cfg.baseUrl || '';
  $('cfg-apikey').value = '';
  $('cfg-apikey').placeholder = cfg.hasKey ? `已保存 ${cfg.maskedKey}，留空表示不修改` : '在 1Panel 里创建 API Key';
  $('cfg-signmode').value = cfg.signMode || 'auto';

  const sel = $('cfg-interval');
  const want = String(cfg.refreshInterval || 5000);
  if (![...sel.options].some((o) => o.value === want)) {
    sel.appendChild(new Option(`${Number(want) / 1000} 秒`, want));
  }
  sel.value = want;

  const rows = [
    ['连接状态', cfg.configured ? '已配置' : '未配置'],
    ['面板地址', cfg.baseUrl || '—'],
    ['接口密钥', cfg.hasKey ? cfg.maskedKey : '未设置'],
    ['签名方式', cfg.signMode === 'hmac' ? 'HMAC-SHA256' : cfg.signMode === 'md5' ? 'MD5' : '自动'],
    ['接口根', cfg.apiBase || (cfg.baseUrl || '—')],
    ['出站方式', cfg.inContainer ? 'JSOS 容器（经系统 CORS 代理）' : '本机直连'],
    ['刷新间隔', `${((cfg.refreshInterval || 5000) / 1000).toFixed(0)} 秒`],
  ];
  $('cfg-info').innerHTML = rows.map(([k, v]) =>
    `<dt>${esc(k)}</dt><dd class="mono">${esc(v)}</dd>`).join('');
}

/* =============================== 小组件 =============================== */

function initWidget(id) {
  document.body.dataset.widget = 'panel-' + id;
  const app = $('app');
  app.innerHTML = '<div class="widget" id="w-root"></div>';
  const root = $('w-root');

  const render = (r) => {
    if (!r || !r.ok) {
      root.innerHTML = `<div class="w-head"><span class="w-host">1Panel</span>
        <span class="w-status">${esc((r && r.message) || '未连接')}</span></div>`;
      return;
    }
    if (id === 'lite') renderWidgetLite(root, r);
    else renderWidgetStatus(root, r);
  };

  const poll = async () => {
    try {
      render(await fetch('/api/overview').then((x) => x.json()));
    } catch {
      render(null);
    }
  };

  poll();
  setInterval(poll, 10000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
}

function renderWidgetStatus(root, r) {
  const c = r.current || {};
  const h = r.host || {};
  const disk = c.disk;
  const one = (pct, name, sub) => `
    <div class="w-ring">
      <div class="w-ring-wrap">
        ${ringSvg(pct, 62, 6)}
        <div class="w-ring-val">${fmtPct(pct)}<em>%</em></div>
      </div>
      <div class="w-ring-name">${esc(name)}</div>
      <div class="w-ring-sub" title="${esc(sub)}">${esc(sub)}</div>
    </div>`;

  root.innerHTML = `
    <div class="w-head">
      <span class="w-host">${esc(h.hostname || '服务器')}</span>
      <span class="w-status"><i class="dot"></i>${esc(c.loadStatus || '')}</span>
    </div>
    <div class="w-rings">
      ${one(c.loadUsagePercent, '负载', fmtNum(c.load1, 2))}
      ${one(c.cpuUsedPercent, 'CPU', `${fmtNum(c.cpuUsed, 2)}/${c.cpuTotal || 0} 核`)}
      ${one(c.memoryUsedPercent, '内存', `${fmtBytesShort(c.memoryUsed)}/${fmtBytesShort(c.memoryTotal)}`)}
      ${one(disk ? disk.usedPercent : 0, '磁盘', disk ? `${fmtBytesShort(disk.used)}/${fmtBytesShort(disk.total)}` : '—')}
    </div>`;
}

function renderWidgetLite(root, r) {
  const c = r.current || {};
  const one = (name, value, unit, color) => `
    <div class="w-metric">
      <div class="w-metric-val"${color ? ` style="color:${color}"` : ''}>${value}<em>${unit}</em></div>
      <div class="w-metric-name">${esc(name)}</div>
    </div>`;
  root.innerHTML = `<div class="w-lite">
    ${one('CPU', fmtPct(c.cpuUsedPercent), '%', ringColor(clamp(c.cpuUsedPercent)))}
    ${one('内存', fmtPct(c.memoryUsedPercent), '%', ringColor(clamp(c.memoryUsedPercent)))}
    ${one('负载', fmtNum(c.load1, 2), '', ringColor(clamp(c.loadUsagePercent)))}
  </div>`;
}

/* =============================== 入口分流 =============================== */
/* 必须放在文件末尾：initApp/initWidget 会同步触达 state、COLLAPSE_KEY 等
   const 绑定，提前调用会命中 TDZ（且被 initCollapse 的裸 catch 静默吞掉）。 */

const widgetId = (location.pathname.match(/^\/widget\/([a-z0-9-]+)/i) || [])[1];
if (widgetId) initWidget(widgetId);
else initApp();

