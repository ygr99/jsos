/**
 * 日历 —— 服务端
 * express 托管静态页 + 60秒读懂世界数据接口（按天缓存）。
 *
 * 网络策略（2026-09-07 实测）：60s-api.viki.moe 是 https + 域名且返回
 * `Access-Control-Allow-Origin: *`，所以在 JSOS 容器里也能直连成功，
 * 不需要走 CORS 代理（代理会明显变慢）。
 * 只有当直连失败、且运行在容器内（存在 PROXY_URL）时，才兜底走一次代理。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const NEWS_URL = 'https://60s-api.viki.moe/v2/60s';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

// JSOS 在容器内启动时注入的 CORS 代理配置，仅作兜底用
const PROXY = process.env.PROXY_URL
  ? { url: String(process.env.PROXY_URL).replace(/\/+$/, ''), key: process.env.PROXY_KEY || '' }
  : null;

// Vercel 形态：encoded 路径避免 308，key 走 query 避免 preflight（见 AGENTS.md 7.5）
function proxiedUrl(target) {
  const q = PROXY.key ? `?x-cors-proxy-key=${encodeURIComponent(PROXY.key)}` : '';
  return `${PROXY.url}/${encodeURIComponent(target)}${q}`;
}

async function get(url, timeout = 10000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: ac.signal,
      headers: { 'User-Agent': UA, Accept: 'application/json' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchNews() {
  try {
    return await get(NEWS_URL);
  } catch (err) {
    if (!PROXY) throw err;
    // 直连失败 + 容器内 -> 兜底走代理
    return await get(proxiedUrl(NEWS_URL), 15000);
  }
}

// 按天缓存：同一天重复请求直接回缓存，跨天自动刷新
let cacheDate = '';
let cacheData = null;

async function getNews(force = false) {
  const today = new Date().toISOString().slice(0, 10);
  if (!force && cacheData && cacheDate === today) return cacheData;
  const data = await fetchNews();
  if (data && data.code === 200 && data.data) {
    cacheData = data;
    cacheDate = today;
  }
  return data;
}

const app = express();

app.get('/api/news', async (req, res) => {
  try {
    const data = await getNews(req.query.refresh === '1');
    if (!data || data.code !== 200 || !data.data) {
      return res.status(502).json({ ok: false, error: '数据格式错误' });
    }
    res.json({ ok: true, data: data.data });
  } catch (err) {
    const msg = err && err.name === 'AbortError' ? '请求超时' : (err && err.message) || '网络错误';
    res.status(502).json({ ok: false, error: msg });
  }
});

app.use(express.static(join(__dirname, 'public')));

// SPA 兜底：小组件 /widget/calendar 也走同一份页面，由前端按路径判断视图
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`calendar running on ${port}`));
