/**
 * 小姐姐视频 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 两个接口：
 *   /api/random  调 xxapi「小姐姐视频」接口（Authorization: Bearer key）取随机视频地址
 *   /api/video   同源流式代理 videos.xxapi.cn 的 mp4（透传 Range，支持拖动）
 *
 * 为什么视频要走 /api/video：JSOS 强制 COEP require-corp，跨域视频无 CORP 头
 * 会被 ERR_BLOCKED_BY_RESPONSE 拦掉（同 music 封面走 /api/proxy/image 的道理）。
 *
 * 出站路由见 lib/http.js（§7.5）：容器内走 JSOS CORS 代理（自动适配官方/Vercel
 * 两种协议形态），本机直跑直连。xxapi 的 API 与视频 CDN 自身 CORS 头规范
 * （实测 OPTIONS/ACAO 均正常），直连兜底在容器内也能通。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outboundFetch, setProxyConfig, getProxyConfig } from './lib/http.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

// xxapi key（用户 2026-09-07 提供）。支持环境变量覆盖，便于日后换 key 不改代码。
const XXAPI_KEY = process.env.XXAPI_KEY || '979f0d4ba967c9c3';
const API_URL = 'https://v2.xxapi.cn/api/meinv';
const VIDEO_HOST = 'videos.xxapi.cn';

// JSOS 启动时注入 CORS 代理配置（容器内自动走代理，本机直跑直连）
if (process.env.PROXY_URL) {
  setProxyConfig({ url: process.env.PROXY_URL, key: process.env.PROXY_KEY || '' });
}

const app = express();
app.use(express.static(join(__dirname, 'public')));

function ok(res, data) {
  res.json({ ok: true, ...data });
}
function fail(res, error, status = 502) {
  res.status(status).json({ ok: false, error });
}

/** 校验并解析视频地址：仅允许 https + videos.xxapi.cn（防 SSRF） */
function parseVideoUrl(raw) {
  let u;
  try {
    u = new URL(String(raw || ''));
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' || u.hostname !== VIDEO_HOST) return null;
  return u;
}

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  ok(res, {
    service: 'meinv-video',
    proxyConfigured: !!getProxyConfig(),
    time: new Date().toISOString(),
  });
});

/* ------------------------------ 随机视频地址 ------------------------------ */

app.get('/api/random', async (req, res) => {
  try {
    const { res: up, via } = await outboundFetch(API_URL, {
      headers: { Authorization: `Bearer ${XXAPI_KEY}` },
      timeout: 15000,
      // 判据：响应是 JSON（代理层 401/400 是纯文本 → 自动换下一个候选）
      isOk: (r) => (r.headers.get('content-type') || '').includes('json'),
    });
    const data = await up.json();
    if (data.code !== 200 || !data.data) {
      throw new Error(data.msg || `接口返回 code=${data.code}`);
    }
    const videoUrl = parseVideoUrl(data.data);
    if (!videoUrl) throw new Error('接口返回了非预期的视频地址');
    ok(res, { url: videoUrl.href, via });
  } catch (err) {
    fail(res, `获取视频失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 视频同源代理（Range 透传） ------------------------------ */

app.get('/api/video', async (req, res) => {
  const videoUrl = parseVideoUrl(req.query.u);
  if (!videoUrl) {
    return fail(res, '仅允许代理 videos.xxapi.cn 的 https 视频地址', 400);
  }

  const headers = {};
  if (req.headers.range) headers.Range = String(req.headers.range);

  try {
    const { res: up, via } = await outboundFetch(videoUrl.href, {
      headers,
      timeout: 30000,
      isOk: (r) => r.status === 200 || r.status === 206,
    });

    res.status(up.status);
    for (const h of ['content-type', 'content-length', 'content-range', 'accept-ranges']) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    res.setHeader('cache-control', 'no-store');

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.pipe(res);
    stream.on('error', () => res.destroy());
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `视频拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

app.listen(port, () => {
  console.log(`[meinv-video] listening on http://localhost:${port} (proxy: ${getProxyConfig() ? 'on' : 'off'})`);
});
