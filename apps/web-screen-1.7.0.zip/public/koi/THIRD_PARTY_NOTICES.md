# Third-party notices — 锦鲤河景（koi/）

The koi screensaver is adapted from **Desktop Habitats · 锦鲤版**
(https://github.com/zlbigger/desktop-koi-habitats), itself a fork of
chaseleantj/desktop-habitats.

## Desktop Habitats — MIT License

Copyright (c) 2026 Chase Lean

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Three.js — MIT License

Bundled under `koi/vendor/` (see `vendor/THREE-LICENSE.txt` in the upstream
repository). Copyright © 2010-2025 three.js authors.

## Textures — CC0 (Poly Haven)

Rock Boulder Dry, Rough Wood and Sand 01 textures come from Poly Haven under
CC0: https://polyhaven.com/license
