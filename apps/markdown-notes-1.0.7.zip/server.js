import express from 'express';
import { readFile, writeFile, readdir, unlink, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const NOTES_DIR = join(DATA_DIR, 'notes');

app.use(express.json());
app.use(express.static(join(__dirname, 'public')));

// 确保笔记目录存在
async function ensureNotesDir() {
  try { await mkdir(NOTES_DIR, { recursive: true }); } catch {}
}

// 获取笔记列表
app.get('/api/notes', async (req, res) => {
  try {
    await ensureNotesDir();
    const files = await readdir(NOTES_DIR);
    const notes = await Promise.all(
      files.filter(f => f.endsWith('.json')).map(async (f) => {
        const data = JSON.parse(await readFile(join(NOTES_DIR, f), 'utf-8'));
        return { id: f.replace('.json', ''), title: data.title, updatedAt: data.updatedAt };
      })
    );
    notes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    res.json(notes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取单篇笔记
app.get('/api/notes/:id', async (req, res) => {
  try {
    const data = await readFile(join(NOTES_DIR, `${req.params.id}.json`), 'utf-8');
    res.json(JSON.parse(data));
  } catch {
    res.status(404).json({ error: 'not found' });
  }
});

// 创建笔记
app.post('/api/notes', async (req, res) => {
  try {
    await ensureNotesDir();
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const now = new Date().toISOString();
    const note = { id, title: req.body.title || '未命名笔记', content: '', createdAt: now, updatedAt: now };
    await writeFile(join(NOTES_DIR, `${id}.json`), JSON.stringify(note, null, 2));
    res.json(note);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 更新笔记
app.put('/api/notes/:id', async (req, res) => {
  try {
    const filePath = join(NOTES_DIR, `${req.params.id}.json`);
    const existing = JSON.parse(await readFile(filePath, 'utf-8'));
    const updated = { ...existing, ...req.body, id: req.params.id, updatedAt: new Date().toISOString() };
    await writeFile(filePath, JSON.stringify(updated, null, 2));
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 删除笔记
app.delete('/api/notes/:id', async (req, res) => {
  try {
    await unlink(join(NOTES_DIR, `${req.params.id}.json`));
    res.json({ ok: true });
  } catch {
    res.status(404).json({ error: 'not found' });
  }
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`running on ${port}`));
