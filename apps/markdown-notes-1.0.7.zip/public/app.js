let notes = [];
let currentId = null;
let saveTimer = null;
let isPreview = false;
let cm = null;

const $ = id => document.getElementById(id);
const noteList = $('note-list');
const preview = $('preview');
const noteTitle = $('note-title');
const emptyState = $('empty-state');
const editorArea = $('editor-area');
const saveStatus = $('save-status');

// 初始化 CodeMirror
function initEditor() {
  cm = CodeMirror($('editor-wrap'), {
    mode: 'gfm',
    theme: 'material-darker',
    lineWrapping: true,
    lineNumbers: false,
    indentUnit: 2,
    tabSize: 2,
    extraKeys: { 'Enter': 'newlineAndIndentContinueMarkdownList' },
    placeholder: '开始写点什么...\n\n支持 Markdown 语法：\n# 标题\n**粗体** *斜体*\n- 列表项\n`代码`'
  });
  cm.on('change', () => {
    updatePreview();
    autoSave();
  });
}

// 加载笔记列表
async function loadNotes() {
  const res = await fetch('/api/notes');
  notes = await res.json();
  renderList();
}

function renderList() {
  const query = $('search').value.toLowerCase();
  const filtered = query
    ? notes.filter(n => n.title.toLowerCase().includes(query))
    : notes;
  noteList.innerHTML = filtered.map(n => `
    <div class="note-item ${n.id === currentId ? 'active' : ''}" data-id="${n.id}">
      <div class="note-title">${escapeHtml(n.title)}</div>
      <div class="note-date">${formatDate(n.updatedAt)}</div>
    </div>
  `).join('');
  noteList.querySelectorAll('.note-item').forEach(el => {
    el.addEventListener('click', () => openNote(el.dataset.id));
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

async function openNote(id) {
  if (currentId) await saveNote();
  const res = await fetch(`/api/notes/${id}`);
  const note = await res.json();
  currentId = note.id;
  noteTitle.value = note.title;
  cm.setValue(note.content);
  cm.clearHistory();
  updatePreview();
  emptyState.classList.add('hidden');
  editorArea.classList.remove('hidden');
  setTimeout(() => cm.refresh(), 10);
  renderList();
  saveStatus.textContent = '';
}

async function newNote() {
  if (currentId) await saveNote();
  const res = await fetch('/api/notes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: '未命名笔记' })
  });
  const note = await res.json();
  notes.unshift({ id: note.id, title: note.title, updatedAt: note.updatedAt });
  await openNote(note.id);
}

async function saveNote() {
  if (!currentId) return;
  const body = { title: noteTitle.value || '未命名笔记', content: cm.getValue() };
  const res = await fetch(`/api/notes/${currentId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const updated = await res.json();
  const idx = notes.findIndex(n => n.id === currentId);
  if (idx !== -1) {
    notes[idx].title = updated.title;
    notes[idx].updatedAt = updated.updatedAt;
  }
  renderList();
  saveStatus.textContent = '已保存';
  setTimeout(() => { if (saveStatus.textContent === '已保存') saveStatus.textContent = ''; }, 2000);
}

function autoSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNote, 800);
}

function updatePreview() {
  const raw = cm ? cm.getValue() : '';
  if (typeof marked !== 'undefined' && typeof marked.parse === 'function') {
    preview.innerHTML = marked.parse(raw, { breaks: true, gfm: true });
  } else {
    preview.textContent = raw;
  }
}

async function deleteNote() {
  if (!currentId) return;
  if (!confirm('确定删除这篇笔记？')) return;
  await fetch(`/api/notes/${currentId}`, { method: 'DELETE' });
  notes = notes.filter(n => n.id !== currentId);
  currentId = null;
  editorArea.classList.add('hidden');
  emptyState.classList.remove('hidden');
  noteTitle.value = '';
  cm.setValue('');
  renderList();
}

function togglePreview() {
  isPreview = !isPreview;
  $('editor-wrap').classList.toggle('hidden', isPreview);
  preview.classList.toggle('hidden', !isPreview);
  $('btn-toggle-preview').textContent = isPreview ? '编辑' : '预览';
  if (!isPreview) setTimeout(() => cm.refresh(), 10);
}

$('btn-new').addEventListener('click', newNote);
$('btn-delete').addEventListener('click', deleteNote);
$('btn-toggle-preview').addEventListener('click', togglePreview);
$('search').addEventListener('input', renderList);
noteTitle.addEventListener('input', autoSave);

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    saveNote();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
    e.preventDefault();
    newNote();
  }
});

// JSOS 主题适配
function applyTheme(theme) {
  if (cm) {
    cm.setOption('theme', theme === 'light' ? 'default' : 'material-darker');
  }
  document.documentElement.setAttribute('data-theme', theme);
}
async function initTheme() {
  if (window.JSOS) {
    const theme = await window.JSOS.getTheme();
    applyTheme(theme);
    window.JSOS.onThemeChange(applyTheme);
  }
}

function init() {
  if (typeof CodeMirror === 'undefined' || typeof marked === 'undefined') {
    setTimeout(init, 100);
    return;
  }
  initEditor();
  loadNotes();
  initTheme();
}
init();
