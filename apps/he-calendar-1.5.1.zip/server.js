// 合社日历 —— 零依赖服务（installCommand 为空，容器内不装任何 npm 包）
// 1) 静态服务 public/（vite 构建产物）
// 2) /api/weather/* 同源反代 → https://weatherapi.market.xiaomi.com/wtr-v3/*
//    小米天气 API 无 CORS 头（上游网页版因此挂了 EdgeOne 边缘函数），而容器内
//    Node fetch 走浏览器网络栈、受 CORS 约束 —— 所以按 music/lib/http.js 的
//    outbound 拍板策略：读到 PROXY_URL（容器内）→ 全走平台 CORS 代理
//    （encoded 路径 + query key 形态，避免 308 + preflight 死路）；未读到
//    （本机直跑）→ 直连。两种环境行为各自统一可预测。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const PORT = process.env.PORT || 3000;

const UPSTREAM = 'https://weatherapi.market.xiaomi.com/wtr-v3';
const PROXY_URL = String(process.env.PROXY_URL || '').replace(/\/+$/, '');
const PROXY_KEY = String(process.env.PROXY_KEY || 'hello-world');
const IN_CONTAINER = Boolean(PROXY_URL);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

async function weatherProxy(req, res, url) {
  const rest = url.pathname.replace(/^\/api\/weather/, '') || '/';
  const target = `${UPSTREAM}${rest}${url.search}`;
  let fetchUrl = target;
  let via = 'direct';
  if (IN_CONTAINER) {
    fetchUrl = `${PROXY_URL}/${encodeURIComponent(target)}?x-cors-proxy-key=${encodeURIComponent(PROXY_KEY)}`;
    via = 'proxy';
  }
  try {
    const upstream = await fetch(fetchUrl, { redirect: 'follow', signal: AbortSignal.timeout(15000) });
    const body = Buffer.from(await upstream.arrayBuffer());
    res.writeHead(upstream.status, {
      'content-type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-weather-via': via,
    });
    res.end(body);
    console.log(`[weather] ${rest} -> ${upstream.status} via ${via}`);
  } catch (err) {
    const message = err?.name === 'TimeoutError' ? '天气源请求超时' : (err?.message || '天气源网络错误');
    console.error(`[weather] ${rest} FAILED via ${via}: ${message}`);
    res.writeHead(502, { 'content-type': 'application/json; charset=utf-8', 'x-weather-via': via });
    res.end(JSON.stringify({ error: message }));
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');

  if (url.pathname.startsWith('/api/weather/')) {
    weatherProxy(req, res, url);
    return;
  }

  let rel = decodeURIComponent(url.pathname).replace(/^\/+/, '');
  let file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC)) {
    res.writeHead(403);
    return res.end('forbidden');
  }
  if (!rel || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    file = path.join(PUBLIC, 'index.html'); // SPA 回落
  }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {
    'content-type': MIME[ext] || 'application/octet-stream',
    'cache-control': ext === '.html' ? 'no-store' : 'public, max-age=60',
  });
  res.end(fs.readFileSync(file));
});

server.listen(PORT, () =>
  console.log(`he-calendar running on ${PORT} (weather ${IN_CONTAINER ? 'via PROXY_URL' : 'direct'})`)
);
