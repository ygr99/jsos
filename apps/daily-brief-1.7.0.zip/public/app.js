/**
 * 每日速览 —— 前端
 * 侧边栏切换「每日电影」/「每日英语」，内容按天由服务端缓存。
 * 所有用户内容写进 DOM 前统一转义。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 4000);
  }

  async function api(path) {
    let res;
    try {
      res = await fetch(path);
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data;
  }

  /* ------------------------------ 侧边栏切换 ------------------------------ */

  function switchView(view) {
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    $('#view-news60s').hidden = view !== 'news60s';
    $('#view-aibot').hidden = view !== 'aibot';
    $('#view-ainews').hidden = view !== 'ainews';
    $('#view-movie').hidden = view !== 'movie';
    $('#view-english').hidden = view !== 'english';
    $('#view-jsoslog').hidden = view !== 'jsoslog';
  }

  /* ------------------------------ 侧边栏折叠 ------------------------------ */

  const COLLAPSE_KEY = 'daily-brief.sidebar-collapsed';

  function setCollapsed(collapsed) {
    $('.shell').classList.toggle('collapsed', collapsed);
    // ⚠️ 必须用 toggleAttribute 写 content attribute：hidden 是 HTMLElement 的 IDL 属性，
    // SVGElement 上 svg.hidden = true 只是 JS expando，不写 DOM attribute、CSS [hidden] 也不匹配
    $('#ic-collapse').toggleAttribute('hidden', collapsed);
    $('#ic-expand').toggleAttribute('hidden', !collapsed);
    $('#collapse-btn').setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    // 折叠时导航只显示图标 → 悬浮提示补全语义（对齐 appmanager 官方模式）
    $$('.nav-item').forEach((b) => { b.title = collapsed ? b.querySelector('span').textContent : ''; });
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch { /* 忽略 */ }
  }

  function initCollapse() {
    let collapsed = false;
    try { collapsed = localStorage.getItem(COLLAPSE_KEY) === '1'; } catch { /* 忽略 */ }
    setCollapsed(collapsed);
    $('#collapse-btn').addEventListener('click', () => {
      setCollapsed(!$('.shell').classList.contains('collapsed'));
    });
  }

  /* ------------------------------ 每天60秒读懂世界 ------------------------------ */

  // 本地日期（与上游 date 字段同格式 yyyy-mm-dd，用本地时区而非 toISOString 的 UTC）
  function todayKey() {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`;
  }

  function renderNews60s(d) {
    $('#s60s-date').textContent = d.date || '';
    $('#s60s-count').textContent = d.count ? `${d.count} 条` : '';

    // 上游还没更新到今天时提示展示的是哪天的简讯（同 calendar 的处理）
    const stale = $('#s60s-stale');
    if (d.date && d.date !== todayKey()) {
      stale.textContent = `今天的简讯未更新，下面是 ${d.date} 的简讯`;
      stale.hidden = false;
    } else {
      stale.hidden = true;
    }

    const tip = $('#s60s-tip');
    tip.textContent = d.tip || '';
    tip.hidden = !d.tip;

    const list = $('#s60s-list');
    list.innerHTML = '';
    for (const [i, text] of (d.items || []).entries()) {
      const row = document.createElement('div');
      row.className = 's60s-item';
      const n = document.createElement('span');
      n.className = 'n';
      n.textContent = (i + 1) + '.';
      const body = document.createElement('span');
      body.textContent = text;   // 纯文本安全注入
      row.append(n, body);
      list.appendChild(row);
    }
    $('#s60s-card').hidden = false;
  }

  /* ------------------------------ AI 快讯 ------------------------------ */

  function renderAiNews(d) {
    const list = $('#ainews-list');
    list.innerHTML = '';
    for (const [i, item] of (d.items || []).entries()) {
      const row = document.createElement('a');
      row.className = 'news-row';
      row.href = item.url;
      row.target = '_blank';
      row.rel = 'noopener noreferrer';
      row.innerHTML = `
        <span class="news-idx">${i + 1}</span>
        <span class="news-body">
          <span class="news-row-title">${escapeHtml(item.title)}</span>
          ${item.summary ? `<span class="news-row-summary">${escapeHtml(item.summary)}</span>` : ''}
        </span>
        ${item.time ? `<span class="news-time">${escapeHtml(item.time)}</span>` : ''}`;
      list.appendChild(row);
    }
    list.hidden = false;
  }

  /* ------------------------------ AI 工具集快讯 ------------------------------ */

  function renderAibotNews(d) {
    const list = $('#aibot-list');
    list.innerHTML = '';
    for (const item of d.items || []) {
      const row = document.createElement('a');
      row.className = 'news-row';
      row.href = item.url;
      row.target = '_blank';
      row.rel = 'noopener noreferrer';
      row.innerHTML = `
        <span class="news-body">
          <span class="news-row-title">${escapeHtml(item.title)}</span>
          ${item.summary ? `<span class="news-row-summary">${escapeHtml(item.summary)}</span>` : ''}
        </span>
        ${item.source ? `<span class="news-time">来源：${escapeHtml(item.source)}</span>` : ''}`;
      list.appendChild(row);
    }
    list.hidden = false;
  }

  /* ------------------------------ 每日电影 ------------------------------ */

  // 海报经 weserv 图片代理：解决 cikeee 防盗链，且其有缓存（源站失联时海报仍可显示）
  const posterUrl = (poster) =>
    poster ? `https://images.weserv.nl/?url=www.cikeee.com${poster.startsWith('http') ? new URL(poster).pathname : poster}` : '';

  // 观影搜索按钮（复用起始页 DailyMovie 的平台清单）
  const WATCH_PLATFORMS = [
    { name: '摸鱼TV', url: (t) => `https://tv.yucoder.cn/search?q=${encodeURIComponent(t)}`, alt: false },
    { name: '腾讯视频', url: (t) => `https://v.qq.com/x/search/?q=${encodeURIComponent(t)}`, alt: true },
    { name: '爱奇艺', url: (t) => `https://so.iqiyi.com/so/q_${encodeURIComponent(t)}`, alt: true },
    { name: '优酷', url: (t) => `https://so.youku.com/search_video/q_${encodeURIComponent(t)}`, alt: true },
    { name: '抖音', url: (t) => `https://www.douyin.com/search/${encodeURIComponent(t)}`, alt: true },
  ];

  function renderMovie(m) {
    const img = $('#m-poster');
    img.onerror = () => { img.style.visibility = 'hidden'; };
    img.onload = () => { img.style.visibility = 'visible'; };
    img.src = posterUrl(m.poster);

    $('#m-title').textContent = m.title || '未知影片';
    const score = $('#m-score');
    score.textContent = m.score ? `${m.score}分` : '';
    score.hidden = !m.score;

    $('#m-meta').innerHTML = [
      escapeHtml([m.category, m.year, m.region].filter(Boolean).join(' | ')),
      m.director ? `导演：${escapeHtml(m.director)}` : '',
      m.actors ? `主演：${escapeHtml(m.actors)}` : '',
    ].filter(Boolean).join('<br>');

    $('#m-quote').textContent = m.quote || '';
    $('#m-quote').hidden = !m.quote;
    $('#m-intro').textContent = m.introduction || '';
    $('#m-intro').hidden = !m.introduction;

    const actions = $('#m-actions');
    actions.innerHTML = '<span class="actions-label">在线观看：</span>';
    if (m.title) {
      for (const p of WATCH_PLATFORMS) {
        const a = document.createElement('a');
        a.className = 'action-btn' + (p.alt ? ' alt' : '');
        a.href = p.url(m.title);
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = p.name;
        actions.appendChild(a);
      }
      actions.hidden = false;
    } else {
      actions.hidden = true;
    }

    $('#movie-card').hidden = false;
  }

  /* ------------------------------ 每日英语 ------------------------------ */

  let audioEl = null;

  function renderEnglish(e) {
    $('#e-english').textContent = e.english || '';
    $('#e-chinese').textContent = e.chinese || '';

    // 发音：经服务端代理播放（frdic 有 Referer/CORP 校验，容器 iframe 直连会被拦）
    const proxied = (u) => (u ? `/api/audio?url=${encodeURIComponent(u)}` : '');
    const hasAudio = !!(e.normalAudioUrl || e.slowAudioUrl);
    $('#e-audio').hidden = !hasAudio;
    $('#e-normal').hidden = !e.normalAudioUrl;
    $('#e-slow').hidden = !e.slowAudioUrl;
    $('#e-normal').dataset.url = proxied(e.normalAudioUrl);
    $('#e-slow').dataset.url = proxied(e.slowAudioUrl);

    // 详细解析（服务端给的是 HTML 片段，来自固定站点，直接注入）
    $('#e-explain').innerHTML = e.explanation || '';

    $('#english-card').hidden = false;
  }

  function playAudio(url) {
    if (!url) return;
    if (!audioEl) audioEl = new Audio();
    audioEl.src = url;
    audioEl.play().catch(() => toast('发音播放失败', 'error'));
  }

  /* ------------------------------ 每日 jsos 更新 ------------------------------ */

  const CHEVRON = '<svg class="log-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>';

  // 每个日期分组内的排序偏好（'desc' 新的在前 / 'asc' 早的在前），存浏览器缓存
  const LOG_ORDER_KEY = 'daily-brief.jsoslog-order';
  let logOrder = 'desc';
  let logData = null;                 // 最近一次渲染的数据（切换排序时重渲染用）
  const expanded = new Set();         // 已展开的提交 sha（重渲染后保持展开状态）

  function setLogOrder(next, { persist = true } = {}) {
    logOrder = next === 'asc' ? 'asc' : 'desc';
    $('#log-order-text').textContent = logOrder === 'asc' ? '早的在前' : '新的在前';
    $('#log-order-btn').setAttribute('aria-label', `提交排序：${logOrder === 'asc' ? '早的在前' : '新的在前'}`);
    $('#log-order-btn').title = `切换为「${logOrder === 'asc' ? '新的在前' : '早的在前'}」`;
    if (persist) {
      try { localStorage.setItem(LOG_ORDER_KEY, logOrder); } catch { /* 忽略 */ }
    }
    if (logData) renderJsosLog(logData);
  }

  function renderJsosLog(d) {
    logData = d;
    $('#jsoslog-count').textContent = d.count ? `最近 ${d.count} 个提交` : '';
    $('#jsoslog-fetched').textContent = d.fetchedTime ? `抓取时间 ${d.fetchedTime}` : '';

    const wrap = $('#jsoslog-days');
    wrap.innerHTML = '';
    for (const day of d.days || []) {
      const sec = document.createElement('section');
      sec.className = 'log-day';

      const head = document.createElement('div');
      head.className = 'log-day-head';
      head.innerHTML = `
        <span class="log-day-date">${escapeHtml(day.date)}</span>
        <span class="log-day-week">${escapeHtml(day.weekday || '')}</span>
        ${day.label ? `<span class="log-day-label">${escapeHtml(day.label)}</span>` : ''}
        <span class="log-day-count">${day.count} 个提交</span>`;
      sec.appendChild(head);

      for (const c of (logOrder === 'asc' ? [...(day.commits || [])].reverse() : day.commits || [])) {
        const row = document.createElement('div');
        row.className = 'log-row';
        // 两类行共用同一套骨架：时间 + 主题 + 右轨（箭头位 + 短 SHA），
        // 差别只在「箭头位」有没有箭头 —— 右轨末端恒为短 SHA，整列右边缘对齐，
        // 不再出现「箭头/哈希」形状交替的锯齿感。
        // 含正文 = <button> 点击展开详情（默认折叠）；无正文 = <a> 整行跳 GitHub。
        const line = document.createElement(c.hasBody ? 'button' : 'a');
        line.className = 'log-head' + (c.hasBody ? ' expandable' : ' link');
        line.dataset.sha = c.sha;
        const isOpen = c.hasBody && expanded.has(c.sha);
        if (c.hasBody) {
          line.type = 'button';
          line.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
          line.title = '展开提交详情';
        } else {
          line.href = c.url;
          line.target = '_blank';
          line.rel = 'noopener noreferrer';
          line.title = '在 GitHub 查看该提交';
        }
        // 主题 = 中文类型标签 + 可选 scope 标签 + 去掉前缀的描述
        // （类型/scope 由服务端解析好；typeKey 是 ASCII，用于上色类名）
        const tags = `<span class="log-tag t-${escapeHtml(c.typeKey || 'none')}">${escapeHtml(c.type || '更新')}</span>`
          + (c.scope ? `<span class="log-scope">${escapeHtml(c.scope)}</span>` : '');
        line.innerHTML = `
          <span class="log-time">${escapeHtml(c.time)}</span>
          <span class="log-subject">${tags}${escapeHtml(c.title || c.subject)}</span>
          <span class="log-rail">${c.hasBody ? CHEVRON : '<span class="log-chev-slot"></span>'}<span class="log-sha">${escapeHtml(c.short)}</span></span>`;
        row.appendChild(line);

        if (c.hasBody) {
          const detail = document.createElement('div');
          detail.className = 'log-detail';
          detail.hidden = !isOpen;
          const pre = document.createElement('pre');
          pre.className = 'log-body';
          pre.textContent = c.body;          // 纯文本安全注入（保留换行与缩进）
          const foot = document.createElement('a');
          foot.className = 'log-link';
          foot.href = c.url;
          foot.target = '_blank';
          foot.rel = 'noopener noreferrer';
          foot.textContent = `查看提交 ${c.short}`;
          detail.append(pre, foot);
          row.appendChild(detail);
        }
        sec.appendChild(row);
      }
      wrap.appendChild(sec);
    }
    $('#jsoslog-card').hidden = false;
  }

  /* ------------------------------ 启动 ------------------------------ */

  async function init() {
    $('#today-date').textContent = new Date().toLocaleDateString('zh-CN');

    // 六个视图并行加载，先到先显示
    const loadNews60s = api('/api/news-60s')
      .then((d) => { renderNews60s(d); $('#news60s-state').hidden = true; })
      .catch((e) => { $('#news60s-state').textContent = '加载失败：' + e.message; });
    const loadAibot = api('/api/aibot-news')
      .then((d) => { renderAibotNews(d); $('#aibot-state').hidden = true; })
      .catch((e) => { $('#aibot-state').textContent = '加载失败：' + e.message; });
    const loadNews = api('/api/ai-news')
      .then((d) => { renderAiNews(d); $('#ainews-state').hidden = true; })
      .catch((e) => { $('#ainews-state').textContent = '加载失败：' + e.message; });
    const loadMovie = api('/api/daily-movie')
      .then((d) => { renderMovie(d); $('#movie-state').hidden = true; })
      .catch((e) => { $('#movie-state').textContent = '加载失败：' + e.message; });
    const loadEnglish = api('/api/daily-english')
      .then((d) => { renderEnglish(d); $('#english-state').hidden = true; })
      .catch((e) => { $('#english-state').textContent = '加载失败：' + e.message; });
    const loadJsosLog = api('/api/jsos-log')
      .then((d) => { renderJsosLog(d); $('#jsoslog-state').hidden = true; })
      .catch((e) => { $('#jsoslog-state').textContent = '加载失败：' + e.message; });
    await Promise.allSettled([loadNews60s, loadAibot, loadNews, loadMovie, loadEnglish, loadJsosLog]);
  }

  $$('.nav-item').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));
  $('#e-normal').addEventListener('click', () => playAudio($('#e-normal').dataset.url || ''));
  $('#e-slow').addEventListener('click', () => playAudio($('#e-slow').dataset.url || ''));

  // 提交详情：点击标题行展开/收起（默认折叠）；展开状态记在 expanded 里，
  // 切换排序重渲染后不会把已展开的详情收回去
  $('#jsoslog-days').addEventListener('click', (ev) => {
    const head = ev.target.closest && ev.target.closest('.log-head.expandable');
    if (!head) return;
    const detail = head.nextElementSibling;
    const open = head.getAttribute('aria-expanded') === 'true';
    head.setAttribute('aria-expanded', open ? 'false' : 'true');
    if (detail) detail.hidden = open;
    if (open) expanded.delete(head.dataset.sha);
    else expanded.add(head.dataset.sha);
  });

  // 排序切换（组内 新的在前 / 早的在前），偏好存 localStorage，下次打开沿用
  $('#log-order-btn').addEventListener('click', () => {
    setLogOrder(logOrder === 'desc' ? 'asc' : 'desc');
  });
  try { logOrder = localStorage.getItem(LOG_ORDER_KEY) === 'asc' ? 'asc' : 'desc'; } catch { /* 忽略 */ }
  setLogOrder(logOrder, { persist: false });

  initCollapse();
  init().catch((e) => toast(e.message, 'error'));
})();
