// 侧边栏注入：fetch 片段 → 高亮当前页 → 折叠开关（状态存 localStorage，纯 UI 偏好）
(function () {
  var STORAGE_KEY = "jiuyunjian.sidebar-collapsed";
  var EXPANDED_W = "200px";
  var COLLAPSED_W = "56px";

  fetch("/sidebar.html")
    .then(function (r) { return r.text(); })
    .then(function (html) {
      var container = document.getElementById("sidebar-container");
      if (!container) return;
      container.innerHTML = html;
      document.body.classList.add("has-sidebar");

      // 当前路由高亮：/index.html 归一到 /；文章详情归属博客
      var path = location.pathname;
      if (path === "/index.html") path = "/";
      if (path === "/article.html") path = "/blog";
      var links = container.querySelectorAll(".sidebar-nav a[data-path]");
      for (var i = 0; i < links.length; i++) {
        if (links[i].getAttribute("data-path") === path) links[i].classList.add("active");
      }

      var sidebar = container.querySelector(".app-sidebar");
      var btn = container.querySelector("#collapse-btn");
      var iconClose = btn && btn.querySelector(".icon-close");
      var iconOpen = btn && btn.querySelector(".icon-open");

      function apply(collapsed) {
        sidebar.classList.toggle("collapsed", collapsed);
        document.documentElement.style.setProperty("--sidebar-w", collapsed ? COLLAPSED_W : EXPANDED_W);
        btn.setAttribute("aria-label", collapsed ? "展开侧边栏" : "折叠侧边栏");
        btn.title = collapsed ? "展开侧边栏" : "折叠侧边栏";
        // SVGElement 没有 .hidden 这个 IDL 属性，必须写真实 attribute（jsos AGENTS §5.1）
        if (iconClose) iconClose.toggleAttribute("hidden", collapsed);
        if (iconOpen) iconOpen.toggleAttribute("hidden", !collapsed);
      }

      var collapsed0 = false;
      try { collapsed0 = localStorage.getItem(STORAGE_KEY) === "1"; } catch (e) {}
      apply(collapsed0);

      btn.addEventListener("click", function () {
        var next = !sidebar.classList.contains("collapsed");
        apply(next);
        try { localStorage.setItem(STORAGE_KEY, next ? "1" : "0"); } catch (e) {}
      });
    })
    .catch(function (e) { console.error("加载侧边栏失败:", e); });
})();
