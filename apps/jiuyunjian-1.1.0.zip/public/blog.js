// 定义全局变量 posts
let posts = [];
// 定义全局变量 allBlocks 用于存储所有数据块
let allBlocks = [];

// 字符串转换为时间格式
function parseDate(str) {
  try {
    // 处理 "2024-02-13" 格式的日期
    if (str.includes("-")) {
      return new Date(str);
    }
    // 处理 "2024年02月13日" 格式的日期
    if (str.includes("年")) {
      const [year, month, day] = str
        .match(/(\d{4})年(\d{2})月(\d{2})日/)
        .slice(1);
      return new Date(year, month - 1, day);
    }
    // 如果都不匹配，尝试直接创建日期对象
    return new Date(str);
  } catch (error) {
    console.error("日期解析错误:", str, error);
    throw error;
  }
}

// 获取本周的星期天作为开始时间
function getThisSunday(date) {
  const cstDate = new Date(
    date.toLocaleString("en-US", { timeZone: "Asia/Shanghai" })
  );
  const dayOfWeek = cstDate.getDay();
  const daysToSunday = dayOfWeek === 0 ? 0 : 7 - dayOfWeek;
  const thisSunday = new Date(cstDate);
  thisSunday.setDate(cstDate.getDate() + daysToSunday);
  return thisSunday;
}

// 获取当前年份
const currentYear = new Date().getFullYear();

// 获取年份选择框
const yearSelect = document.getElementById("year-select");

// 获取任意年份的第一周的起始日期
function getFirstWeekStartDate(selectedYear) {
  const firstDayOfYear = new Date(selectedYear, 0, 1);
  const dayOfWeek = firstDayOfYear.getDay();
  const firstWeekStartDate = new Date(firstDayOfYear);
  firstWeekStartDate.setDate(
    firstDayOfYear.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1)
  );
  return firstWeekStartDate;
}

// 获取任意年份的最后一周的结束日期
function getLastWeekEndDate(selectedYear) {
  const lastDayOfYear = new Date(selectedYear, 11, 31);
  const dayOfWeek = lastDayOfYear.getDay();
  const lastWeekEndDate = new Date(lastDayOfYear);
  lastWeekEndDate.setDate(
    lastDayOfYear.getDate() + (dayOfWeek === 0 ? 0 : 7 - dayOfWeek + 1)
  );
  return lastWeekEndDate;
}

// 根据选择的年份计算周数和日期范围
function getStartDate(selectedYear) {
  const today = new Date(
    new Date().toLocaleString("en-US", { timeZone: "Asia/Shanghai" })
  );
  const startOfYear = new Date(
    new Date(selectedYear, 0, 1).toLocaleString("en-US", {
      timeZone: "Asia/Shanghai",
    })
  );

  const dayOfYear = Math.ceil((today - startOfYear) / (1000 * 60 * 60 * 24));
  const weekNumber = Math.floor((dayOfYear - 1) / 7) + 1;

  let weeks;
  if (selectedYear === 2024) {
    weeks = weekNumber - 35 + 1;
  } else if (selectedYear === 2025) {
    const firstDayOf2025 = new Date(2025, 0, 1);
    const dayOfWeek = firstDayOf2025.getDay();
    const firstWeekStartDate = new Date(firstDayOf2025);
    firstWeekStartDate.setDate(
      firstDayOf2025.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1)
    );
    weeks = weekNumber;
    const days = weeks * 7 - 1;
    return firstWeekStartDate;
  } else if (selectedYear === 2026) {
    const firstDayOf2026 = new Date(2026, 0, 1);
    const dayOfWeek = firstDayOf2026.getDay();
    const firstWeekStartDate = new Date(firstDayOf2026);
    firstWeekStartDate.setDate(
      firstDayOf2026.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1)
    );
    weeks = weekNumber;
    const days = weeks * 7 - 1;
    return firstWeekStartDate;
  } else {
    weeks = weekNumber;
  }
  const days = weeks * 7 - 1;

  const sunday = getThisSunday(today);
  const startDate = new Date(sunday);
  startDate.setDate(sunday.getDate() - days);

  return startDate;
}

// 添加精确的字数统计函数
function countWords(content) {
  // 去除第一行（标题行）
  const lines = content.split("\n");
  const contentWithoutTitle = lines.slice(1).join("\n");

  // 去除多余的空格和换行符
  const trimmedContent = contentWithoutTitle.replace(/\s+/g, " ").trim();

  // 统计中文字符（包括中文标点）
  const chineseChars = (
    trimmedContent.match(
      /[\u4e00-\u9fa5\u3000-\u303f\uff00-\uff0f\uff1a-\uff20\uff3b-\uff40\uff5b-\uff65]/g
    ) || []
  ).length;

  // 统计数字
  const numbers = (trimmedContent.match(/\d+/g) || []).length;

  // 统计英文单词（去除标点符号和数字）
  const englishWords = trimmedContent
    .replace(/[^\w\s]/g, "") // 去除标点符号
    .replace(/\d+/g, " ") // 将数字替换为空格
    .split(/\s+/) // 按空格分割
    .filter((word) => word.length > 0 && /^[a-zA-Z]+$/.test(word)).length; // 只保留纯英文单词

  return {
    chinese: chineseChars,
    english: englishWords,
    numbers: numbers,
    total: chineseChars + englishWords + numbers,
  };
}

// 构建基础数据
function dateBuild(data, startDate) {
  const dateCounts = {};
  // 标准化json中的时间格式
  data.forEach((item) => {
    if (!item.date) return; // 跳过没有日期的项
    try {
      const date = parseDate(item.date);
      const dateStr = date.toISOString().split("T")[0];
      // 只统计日记和笔记
      const firstLine = item.content.split("\n")[0];
      if (
        firstLine &&
        (firstLine.includes("# 📘") || firstLine.includes("# 📆"))
      ) {
        dateCounts[dateStr] = (dateCounts[dateStr] || 0) + 1;
      }
    } catch (e) {
      console.warn("Invalid date:", item.date);
    }
  });

  const result = [];
  const sunday = getThisSunday(new Date());

  // 生成从 startDate 到 sunday 的数据数组
  for (
    let currentDate = new Date(
      sunday.toLocaleString("en-US", { timeZone: "Asia/Shanghai" })
    );
    currentDate >=
    new Date(startDate.toLocaleString("en-US", { timeZone: "Asia/Shanghai" }));
    currentDate.setDate(currentDate.getDate() - 1)
  ) {
    const dateStr = currentDate.toISOString().split("T")[0];
    const count = dateCounts[dateStr] || 0;
    const dataContent = data.filter(
      (item) => parseDate(item.date).toISOString().split("T")[0] === dateStr
    );

    // 使用新的字数统计方法，只统计日记和笔记
    let totalWordCount = 0;
    dataContent.forEach((item) => {
      const firstLine = item.content.split("\n")[0];
      if (
        firstLine &&
        (firstLine.includes("# 📘") || firstLine.includes("# 📆"))
      ) {
        const wordCount = countWords(item.content);
        totalWordCount += wordCount.total;
      }
    });

    // 为每个内容项添加标题和处理后的字数
    const contentWithTitles = dataContent
      .filter((item) => {
        const firstLine = item.content.split("\n")[0];
        return (
          firstLine &&
          (firstLine.includes("# 📘") || firstLine.includes("# 📆"))
        );
      })
      .map((item) => {
        const contentLines = item.content.split("\n");
        const firstLine = contentLines[0];
        const contentWithoutFirstLine = contentLines.slice(1).join("\n");
        let title = firstLine;
        if (firstLine.includes("# 📘")) {
          title = firstLine.replace(/^#\s*📘\s*/, "").trim();
        } else if (firstLine.includes("# 📆")) {
          title = firstLine.replace(/^#\s*📆\s*/, "").trim();
        }
        const wordCount = countWords(item.content);
        return {
          ...item,
          title: title,
          href: `#${encodeURIComponent(title)}`,
          word_count: wordCount.total,
          word_count_detail: wordCount,
        };
      });

    result.push({
      date: dateStr,
      count: count,
      data: contentWithTitles,
      wordcount: totalWordCount,
    });
  }

  return result;
}

// 判断日期是否为今天
function isToday(date) {
  const today = new Date();
  return (
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  );
}

// 动态生成星期标签
function generateWeekLabels() {
  const weekLabels = ["一", "三", "五", "日"];
  const weekLabelsContainer = document.querySelector(".week-labels");
  weekLabelsContainer.innerHTML = ""; // 清空现有内容

  // 生成新的星期标签
  weekLabels.forEach((labelText) => {
    const label = document.createElement("div");
    label.className = "week-label";
    label.innerText = labelText;
    weekLabelsContainer.appendChild(label);
  });
}

// 填充热力图
function fillHeatmap(data, startDate) {
  let articles = dateBuild(data, startDate);
  const gridContainer = document.getElementById("relitu-container");
  gridContainer.innerHTML = "";

  // 获取选择的年份
  const selectedYear = parseInt(yearSelect.value);

  // 动态计算第一周的起始日期和最后一周的结束日期
  const firstWeekStartDate = getFirstWeekStartDate(selectedYear);
  const lastWeekEndDate = getLastWeekEndDate(selectedYear);

  let lastMonth = null; // 用于跟踪上一个月份
  let currentColumn = null; // 当前列
  let currentColumnIndex = 0; // 当前列的索引
  let currentRowIndex = 0; // 当前列中的行索引（0-6）

  // 倒序遍历文章数据
  articles
    .slice()
    .reverse()
    .forEach((article) => {
      // 获取当前格子的日期
      const currentDate = new Date(article.date);
      const currentMonth = currentDate.getMonth(); // 获取当前月份

      // 过滤数据：只显示在动态计算的日期范围内的数据
      if (currentDate < firstWeekStartDate || currentDate > lastWeekEndDate) {
        return; // 跳过不在范围内的数据
      }

      // 检查是否是新的月份的开始
      if (lastMonth !== null && currentMonth !== lastMonth) {
        // 插入7个隐形格子
        for (let i = 0; i < 7; i++) {
          if (currentRowIndex >= 7) {
            currentColumn = document.createElement("div");
            currentColumn.className = "grid-column";
            gridContainer.appendChild(currentColumn);
            currentColumnIndex++;
            currentRowIndex = 0;
          }

          const gridItem = document.createElement("div");
          gridItem.className = "grid-item invisible";
          gridItem.innerHTML = `<div class="item-info"></div>`;
          currentColumn.appendChild(gridItem);
          currentRowIndex++;
        }
      }

      lastMonth = currentMonth;

      if (currentRowIndex >= 7) {
        currentColumn = document.createElement("div");
        currentColumn.className = "grid-column";
        gridContainer.appendChild(currentColumn);
        currentColumnIndex++;
        currentRowIndex = 0;
      }

      const gridItem = document.createElement("div");
      gridItem.className = "grid-item";

      // 构建提示字符串，使用双引号并正确转义HTML
      const tooltipStr = article.data
        .map((item) => {
          const firstLine = item.content.split("\n")[0];
          // 只显示笔记和日记的内容
          if (!firstLine.includes("# 📘") && !firstLine.includes("# 📆")) {
            return null;
          }
          let content = firstLine;
          if (firstLine.includes("# 📘")) {
            content = firstLine.replace(/^#\s*📘\s*/, "").trim();
          } else if (firstLine.includes("# 📆")) {
            content = firstLine.replace(/^#\s*📆\s*/, "").trim();
          }
          content = content.replace(/"/g, "&quot;").replace(/'/g, "&apos;");
          return `- <a href=article.html?id=${item.id} target="_blank" style="color: inherit; text-decoration: none">${content}</a>`;
        })
        .filter(Boolean) // 过滤掉 null 值
        .join("<br>");

      // 构建格子内容
      const backgroundColor =
        article.wordcount != 0
          ? `rgba(30,129,248,${article.wordcount / 5000 + 0.2})`
          : "#E9ECEF";

      const tippyContent =
        `${article.date}，共 ${article.count} 篇，共 ${article.wordcount} 字<br />${tooltipStr}`
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&apos;");

      // 使用 createElement 和 setAttribute 来避免 HTML 转义问题
      const itemInfo = document.createElement("div");
      itemInfo.className = "item-info item-tippy";
      itemInfo.setAttribute("data-date", article.date);
      itemInfo.setAttribute("data-tippy-content", tippyContent);
      itemInfo.style.backgroundColor = backgroundColor;

      // 如果是月初，在格子内部显示月份标签
      if (currentDate.getDate() === 1) {
        const monthLabel = document.createElement("span");
        monthLabel.className = "month-label";
        monthLabel.textContent = currentMonth + 1;
        itemInfo.appendChild(monthLabel);
      }

      // 如果是今天，在格子内部显示今日标签
      if (isToday(currentDate)) {
        const todayLabel = document.createElement("span");
        todayLabel.className = "today-label";
        todayLabel.textContent = "今";
        itemInfo.appendChild(todayLabel);
      }

      const link = document.createElement("a");
      link.href = article.data[0]
        ? `article.html?id=${article.data[0].id}`
        : "#";
      link.target = "_blank";
      link.style.display = "block";
      link.style.width = "100%";
      link.style.height = "100%";

      itemInfo.appendChild(link);
      gridItem.appendChild(itemInfo);

      if (!currentColumn) {
        currentColumn = document.createElement("div");
        currentColumn.className = "grid-column";
        gridContainer.appendChild(currentColumn);
      }
      currentColumn.appendChild(gridItem);
      currentRowIndex++;
    });

  // 生成星期标签
  generateWeekLabels();

  // 初始化提示框
  tippy(".item-tippy", {
    allowHTML: true,
    interactive: true,
    maxWidth: "none",
    theme: "custom",
    appendTo: document.body,
    placement: "top",
    delay: [0, 0],
    duration: [0, 0],
  });

  // 页面加载或重绘后，将热力图滚动到最右侧
  requestAnimationFrame(() => {
    gridContainer.scrollLeft = gridContainer.scrollWidth;
  });
}

// 生成笔记列表
function generateNoteList(data) {
  const noteListContainer = document.getElementById("note-list");
  if (!noteListContainer) return;
  noteListContainer.innerHTML = "";

  const noteListTemplate = document.createElement("div");
  noteListTemplate.className = "note-item";

  const groupedNotes = {};
  data.forEach((note) => {
    if (!note || !note.date || !note.title) return;

    try {
      const date = parseDate(note.date);
      if (!date || isNaN(date.getTime())) return;

      const year = date.getFullYear();
      const month = date.getMonth() + 1;

      if (!groupedNotes[year]) groupedNotes[year] = {};
      if (!groupedNotes[year][month]) groupedNotes[year][month] = [];

      groupedNotes[year][month].push(note);
    } catch (e) {}
  });

  // 按年和月排序并生成笔记列表
  Object.keys(groupedNotes)
    .sort((a, b) => b - a) // 按年降序
    .forEach((year) => {
      const yearData = groupedNotes[year];
      const yearNoteCount = Object.keys(yearData).reduce(
        (sum, m) => sum + yearData[m].length,
        0
      );

      const yearDiv = document.createElement("div");
      yearDiv.className = "note-year";
      yearDiv.innerText = year;
      const yearCountSpan = document.createElement("span");
      yearCountSpan.className = "note-year-count";
      yearCountSpan.textContent = yearNoteCount;
      yearDiv.appendChild(yearCountSpan);
      noteListContainer.appendChild(yearDiv);

      Object.keys(yearData)
        .sort((a, b) => b - a) // 按月降序
        .forEach((month) => {
          const monthNotes = yearData[month];
          const monthDiv = document.createElement("div");
          monthDiv.className = "note-month";
          monthDiv.innerText = `${month}月`;
          const monthCountSpan = document.createElement("span");
          monthCountSpan.className = "note-month-count";
          monthCountSpan.textContent = monthNotes.length;
          monthDiv.appendChild(monthCountSpan);
          noteListContainer.appendChild(monthDiv);

          monthNotes.forEach((note) => {
            try {
              const noteItem = noteListTemplate.cloneNode(false);
              const date = parseDate(note.date);
              const formattedDate = `${String(date.getMonth() + 1).padStart(
                2,
                "0"
              )}-${String(date.getDate()).padStart(2, "0")}`;
              noteItem.innerHTML = `<a href="article.html?id=${note.id}" target="_blank">
                      ${formattedDate} &nbsp;&nbsp;&nbsp; ${note.title}
                    </a>`;
              noteListContainer.appendChild(noteItem);
            } catch (e) {
              console.warn("渲染笔记项时出错：", e);
            }
          });
        });
    });
}

// 填充所有数据
function fillGrid(data, startDate) {
  // 填充热力图 - 使用原始的完整数据
  fillHeatmap(data.blocks, startDate);

  // 生成笔记列表 - 只使用笔记数据
  generateNoteList(data);

  // 计算日记和笔记数量及总字数
  let noteCount = 0;
  let diaryCount = 0;
  let totalWordCount = 0;

  data.forEach((item) => {
    if (!item.content) return;

    const firstLine = item.content.split("\n")[0];
    const wordCount = countWords(item.content);

    if (firstLine && firstLine.includes("# 📘")) {
      noteCount++;
      totalWordCount += wordCount.total;
    } else if (firstLine && firstLine.includes("# 📆")) {
      diaryCount++;
      totalWordCount += wordCount.total;
    }
  });

  // 更新显示统计信息的元素
  const noteCountElement = document.getElementById("note-count");
  if (noteCountElement) {
    noteCountElement.innerHTML = `
      <span class="stat-number">${diaryCount}</span> 篇日记 &nbsp;
      <span class="stat-number">${noteCount}</span> 篇笔记 &nbsp;
      <span class="stat-number">${totalWordCount}</span> 字
    `;
  }
}

// 修改初始加载时的代码
document.addEventListener("DOMContentLoaded", function () {
  const loadingSpinner = document.getElementById("loading-spinner");
  loadingSpinner.style.display = "flex";

  // 设置默认年份为当前年份
  yearSelect.value = currentYear;

  fetch("/data")
    .then((response) => response.json())
    .then((data) => {
      console.log("获取到原始数据：", data);

      // 分别处理笔记和所有内容
      allBlocks = data.blocks; // 保存到全局变量

      // 过滤出笔记内容
      const noteBlocks = allBlocks.filter((block) => {
        // 确保 block 和 block.content 存在
        if (!block || !block.content) {
          console.log("跳过无效块：", block);
          return false;
        }

        // 获取第一行
        const firstLine = block.content.split("\n")[0];
        // 只保留第一行包含 # 📘 的笔记
        const isNote = firstLine && firstLine.includes("# 📘");
        console.log("检查是否为笔记：", firstLine, isNote);
        return isNote;
      });

      console.log("过滤后的笔记块：", noteBlocks);

      // 处理笔记数据
      posts = noteBlocks.map((block) => {
        const firstLine = block.content.split("\n")[0];
        const title =
          firstLine.replace(/^#\s*📘\s*/, "").trim() || "无标题笔记";
        return {
          ...block,
          title: title,
          href: `#${encodeURIComponent(title)}`,
          word_count: block.content.length,
        };
      });

      console.log("处理后的posts数组：", posts);

      const selectedYear = parseInt(yearSelect.value);
      const startDate = getStartDate(selectedYear);

      // 填充热力图 - 使用所有内容
      fillHeatmap(allBlocks, startDate);

      // 生成笔记列表 - 只使用笔记内容
      generateNoteList(posts);

      // 计算日记和笔记数量及总字数
      let noteCount = 0;
      let diaryCount = 0;
      let totalWordCount = 0;

      allBlocks.forEach((item) => {
        if (!item.content) return;

        const firstLine = item.content.split("\n")[0];
        const wordCount = countWords(item.content);

        if (firstLine && firstLine.includes("# 📘")) {
          noteCount++;
          totalWordCount += wordCount.total;
        } else if (firstLine && firstLine.includes("# 📆")) {
          diaryCount++;
          totalWordCount += wordCount.total;
        }
      });

      // 更新显示统计信息的元素
      const noteCountElement = document.getElementById("note-count");
      if (noteCountElement) {
        noteCountElement.innerHTML = `
          <span class="stat-number">${diaryCount}</span> 篇日记 &nbsp;
          <span class="stat-number">${noteCount}</span> 篇笔记 &nbsp;
          <span class="stat-number">${totalWordCount}</span> 字
        `;
      }

      // 添加随机笔记跳转功能
      const randomNoteButton = document.getElementById("random-note");
      randomNoteButton.addEventListener("click", function (event) {
        event.preventDefault();
        // 过滤出笔记内容
        const noteBlocks = allBlocks.filter((block) => {
          if (!block || !block.content) return false;
          const firstLine = block.content.split("\n")[0];
          return firstLine && firstLine.includes("# 📘");
        });

        if (noteBlocks.length > 0) {
          const randomIndex = Math.floor(Math.random() * noteBlocks.length);
          const randomNote = noteBlocks[randomIndex];
          window.open(`article.html?id=${randomNote.id}`, "_blank");
        }
      });

      // 添加随机日记跳转功能
      const randomDiaryButton = document.getElementById("random-diary");
      randomDiaryButton.addEventListener("click", function (event) {
        event.preventDefault();
        // 过滤出日记内容
        const diaryBlocks = allBlocks.filter((block) => {
          if (!block || !block.content) return false;
          const firstLine = block.content.split("\n")[0];
          return firstLine && firstLine.includes("# 📆");
        });

        if (diaryBlocks.length > 0) {
          const randomIndex = Math.floor(Math.random() * diaryBlocks.length);
          const randomDiary = diaryBlocks[randomIndex];
          window.open(`article.html?id=${randomDiary.id}`, "_blank");
        }
      });

      // 获取随机句子
      fetch("/api/sentences")
        .then((response) => response.json())
        .then((sentencesData) => {
          const sentences = [];
          Object.values(sentencesData).forEach((dateData) => {
            Object.values(dateData).forEach((sentenceList) => {
              sentences.push(...sentenceList);
            });
          });
          if (sentences.length > 0) {
            const randomIndex = Math.floor(Math.random() * sentences.length);
            const randomSentence = sentences[randomIndex];
            const randomSentenceDiv = document.getElementById(
              "random-sentence"
            );
            randomSentenceDiv.innerHTML = `<span>「 ${randomSentence} 」</span>`;
          }
        });
    })
    .catch((error) => {
      console.error("Error loading data:", error);
      loadingSpinner.style.display = "none";
    })
    .finally(() => {
      loadingSpinner.style.display = "none";
    });
});

// 修改年份选择框的监听器
yearSelect.addEventListener("change", function () {
  const selectedYear = parseInt(this.value);
  if (allBlocks.length > 0) {
    const startDate = getStartDate(selectedYear);
    // 填充热力图 - 使用所有内容
    fillHeatmap(allBlocks, startDate);
    
    // 生成笔记列表 - 只使用笔记内容
    generateNoteList(posts);
    
    // 计算日记和笔记数量及总字数
    let noteCount = 0;
    let diaryCount = 0;
    let totalWordCount = 0;

    allBlocks.forEach((item) => {
      if (!item.content) return;

      const firstLine = item.content.split("\n")[0];
      const wordCount = countWords(item.content);

      if (firstLine && firstLine.includes("# 📘")) {
        noteCount++;
        totalWordCount += wordCount.total;
      } else if (firstLine && firstLine.includes("# 📆")) {
        diaryCount++;
        totalWordCount += wordCount.total;
      }
    });

    // 更新显示统计信息的元素
    const noteCountElement = document.getElementById("note-count");
    if (noteCountElement) {
      noteCountElement.innerHTML = `
        <span class="stat-number">${diaryCount}</span> 篇日记 &nbsp;
        <span class="stat-number">${noteCount}</span> 篇笔记 &nbsp;
        <span class="stat-number">${totalWordCount}</span> 字
      `;
    }
  }
});
