/**
 * 每日速览 —— 前端
 * 侧边栏切换「每日电影」/「每日英语」，内容按天由服务端缓存。
 * 所有用户内容写进 DOM 前统一转义。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 4000);
  }

  async function api(path) {
    let res;
    try {
      res = await fetch(path);
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data;
  }

  /* ------------------------------ 侧边栏切换 ------------------------------ */

  function switchView(view) {
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    $('#view-movie').hidden = view !== 'movie';
    $('#view-english').hidden = view !== 'english';
  }

  /* ------------------------------ 每日电影 ------------------------------ */

  function renderMovie(m) {
    $('#m-title').textContent = m.title || '未知影片';
    const img = $('#m-poster');
    img.style.display = '';
    img.onerror = () => { img.style.display = 'none'; }; // 数据站失联时海报加载失败 → 隐藏占位
    img.src = m.poster || '';
    img.hidden = !m.poster;

    const meta = $('#m-meta');
    meta.innerHTML = '';
    const addTag = (text, cls = '') => {
      if (!text) return;
      const s = document.createElement('span');
      s.className = 'tag ' + cls;
      s.textContent = text;
      meta.appendChild(s);
    };
    if (m.score) addTag(`${m.score} 分`, 'score');
    addTag(m.category);
    addTag(m.year);
    addTag(m.region);

    $('#m-quote').textContent = m.quote ? `「${m.quote}」` : '';
    $('#m-quote').hidden = !m.quote;

    const extra = $('#m-extra');
    extra.innerHTML = '';
    const addLine = (label, value) => {
      if (!value) return;
      const p = document.createElement('div');
      p.innerHTML = `<b>${label}：</b>${escapeHtml(value)}`;
      extra.appendChild(p);
    };
    addLine('导演', m.director);
    addLine('主演', m.actors);
    addLine('简介', m.introduction);

    const detail = $('#m-detail');
    detail.hidden = !m.detailUrl;
    if (m.detailUrl) detail.href = m.detailUrl;

    $('#movie-card').hidden = false;
  }

  /* ------------------------------ 每日英语 ------------------------------ */

  let audioEl = null;

  function renderEnglish(e) {
    $('#e-english').textContent = e.english || '';
    $('#e-chinese').textContent = e.chinese || '';

    // 发音：有链接才显示播放按钮（URL 存到 dataset，点击时播放）
    const hasAudio = !!(e.normalAudioUrl || e.slowAudioUrl);
    $('#e-audio').hidden = !hasAudio;
    $('#e-normal').hidden = !e.normalAudioUrl;
    $('#e-slow').hidden = !e.slowAudioUrl;
    $('#e-normal').dataset.url = e.normalAudioUrl || '';
    $('#e-slow').dataset.url = e.slowAudioUrl || '';

    // 详细解析（服务端给的是 HTML 片段，来自固定站点，直接注入）
    $('#e-explain').innerHTML = e.explanation || '';

    $('#english-card').hidden = false;
  }

  function playAudio(url) {
    if (!url) return;
    if (!audioEl) audioEl = new Audio();
    audioEl.src = url;
    audioEl.play().catch(() => toast('发音播放失败', 'error'));
  }

  /* ------------------------------ 启动 ------------------------------ */

  async function init() {
    $('#today-date').textContent = new Date().toLocaleDateString('zh-CN');

    // 两个视图并行加载，先到先显示
    const loadMovie = api('/api/daily-movie')
      .then((d) => { renderMovie(d); $('#movie-state').hidden = true; })
      .catch((e) => { $('#movie-state').textContent = '加载失败：' + e.message; });
    const loadEnglish = api('/api/daily-english')
      .then((d) => { renderEnglish(d); $('#english-state').hidden = true; })
      .catch((e) => { $('#english-state').textContent = '加载失败：' + e.message; });
    await Promise.allSettled([loadMovie, loadEnglish]);
  }

  $$('.nav-item').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));
  $('#e-normal').addEventListener('click', () => playAudio($('#e-normal').dataset.url || ''));
  $('#e-slow').addEventListener('click', () => playAudio($('#e-slow').dataset.url || ''));

  init().catch((e) => toast(e.message, 'error'));
})();
