import express from 'express';
import { readFile, writeFile, rename, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');

app.use(express.json({ limit: '8mb' }));
app.use(express.static(join(__dirname, 'public')));

const DAY = 86400000;

function emptyState() {
  return { version: 1, items: [], settings: { idleDays: 30, focusItemId: null }, updatedAt: Date.now() };
}

async function ensureDir() {
  try { await mkdir(DATA_DIR, { recursive: true }); } catch {}
}

/** 读取状态；文件不存在/损坏时回退空状态，绝不抛错 */
async function readState() {
  await ensureDir();
  try {
    const raw = await readFile(STATE_FILE, 'utf-8');
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.items)) return emptyState();
    data.settings = { idleDays: 30, focusItemId: null, ...(data.settings || {}) };
    data.version = 1;
    return data;
  } catch {
    return emptyState();
  }
}

/** 原子写入：先写临时文件再 rename，避免写到一半被快照同步成坏数据 */
async function writeState(state) {
  await ensureDir();
  state.updatedAt = Date.now();
  const tmp = STATE_FILE + '.tmp';
  await writeFile(tmp, JSON.stringify(state, null, 2), 'utf-8');
  await rename(tmp, STATE_FILE);
  return state;
}

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/** 规范化并补全物品字段，防止脏数据污染前端计算 */
function normalizeItem(input, existing) {
  const now = Date.now();
  const base = existing || {};
  const price = Number(input.price);
  const goalValue = Number(input.goalValue);
  return {
    id: base.id || newId(),
    name: String(input.name ?? base.name ?? '').trim() || '未命名物品',
    emoji: String(input.emoji ?? base.emoji ?? '📦').trim() || '📦',
    price: Number.isFinite(price) && price >= 0 ? price : (base.price ?? 0),
    purchasedAt: Number.isFinite(Number(input.purchasedAt)) && Number(input.purchasedAt) > 0
      ? Number(input.purchasedAt)
      : (base.purchasedAt ?? now),
    category: String(input.category ?? base.category ?? '其他').trim() || '其他',
    tags: Array.isArray(input.tags) ? input.tags.filter(Boolean).slice(0, 12) : (base.tags ?? []),
    note: String(input.note ?? base.note ?? '').slice(0, 2000),
    goalType: ['days', 'uses', 'none'].includes(input.goalType) ? input.goalType : (base.goalType ?? 'days'),
    goalValue: Number.isFinite(goalValue) && goalValue > 0
      ? goalValue
      : (base.goalValue ?? (input.goalType === 'uses' ? 100 : 365)),
    usageCount: Number.isFinite(Number(input.usageCount)) && Number(input.usageCount) >= 0
      ? Math.floor(Number(input.usageCount))
      : (base.usageCount ?? 0),
    lastUsedAt: input.lastUsedAt === null
      ? null
      : (Number.isFinite(Number(input.lastUsedAt)) ? Number(input.lastUsedAt) : (base.lastUsedAt ?? null)),
    archived: Boolean(input.archived ?? base.archived ?? false),
    createdAt: base.createdAt ?? now,
    updatedAt: now,
  };
}

// ---------- API ----------

app.get('/api/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

app.get('/api/state', async (req, res) => {
  try {
    res.json(await readState());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/items', async (req, res) => {
  try {
    const state = await readState();
    const item = normalizeItem(req.body || {}, null);
    state.items.unshift(item);
    await writeState(state);
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/items/:id', async (req, res) => {
  try {
    const state = await readState();
    const idx = state.items.findIndex(i => i.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'not found' });
    const updated = normalizeItem(req.body || {}, state.items[idx]);
    state.items[idx] = updated;
    await writeState(state);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/items/:id', async (req, res) => {
  try {
    const state = await readState();
    const before = state.items.length;
    state.items = state.items.filter(i => i.id !== req.params.id);
    if (state.items.length === before) return res.status(404).json({ error: 'not found' });
    if (state.settings.focusItemId === req.params.id) state.settings.focusItemId = null;
    await writeState(state);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** 记一次使用：次数 +1 并更新最后使用时间 */
app.post('/api/items/:id/use', async (req, res) => {
  try {
    const state = await readState();
    const item = state.items.find(i => i.id === req.params.id);
    if (!item) return res.status(404).json({ error: 'not found' });
    const delta = Number(req.body?.delta);
    const step = Number.isFinite(delta) && delta !== 0 ? Math.trunc(delta) : 1;
    item.usageCount = Math.max(0, (item.usageCount || 0) + step);
    if (step > 0) item.lastUsedAt = Date.now();
    item.updatedAt = Date.now();
    await writeState(state);
    res.json(item);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/settings', async (req, res) => {
  try {
    const state = await readState();
    state.settings = { ...state.settings, ...(req.body || {}) };
    if (state.settings.focusItemId && !state.items.some(i => i.id === state.settings.focusItemId)) {
      state.settings.focusItemId = null;
    }
    await writeState(state);
    res.json(state.settings);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** 整体导入（前端「导入备份」用），会覆盖现有数据 */
app.post('/api/import', async (req, res) => {
  try {
    const payload = req.body || {};
    if (!Array.isArray(payload.items)) return res.status(400).json({ error: 'invalid payload' });
    const state = emptyState();
    state.items = payload.items.map(i => normalizeItem(i, { id: i.id }));
    state.settings = { idleDays: 30, focusItemId: null, ...(payload.settings || {}) };
    await writeState(state);
    res.json({ ok: true, count: state.items.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/** 一键载入示例数据，便于快速体验（仅在为空时写入） */
app.post('/api/seed', async (req, res) => {
  try {
    const state = await readState();
    if (state.items.length && !req.body?.force) {
      return res.status(409).json({ error: '已有数据，未覆盖' });
    }
    const now = Date.now();
    const ago = d => now - d * DAY;
    const samples = [
      { name: '笔记本电脑', emoji: '💻', price: 8999, purchasedAt: ago(420), category: '数码', tags: ['工作'], goalType: 'days', goalValue: 365, usageCount: 812, lastUsedAt: ago(0) },
      { name: '降噪耳机', emoji: '🎧', price: 1299, purchasedAt: ago(260), category: '数码', tags: ['通勤'], goalType: 'days', goalValue: 730, usageCount: 430, lastUsedAt: ago(1) },
      { name: '人体工学椅', emoji: '🪑', price: 2380, purchasedAt: ago(180), category: '家居', tags: ['健康'], goalType: 'days', goalValue: 1095, usageCount: 300, lastUsedAt: ago(0) },
      { name: '胶囊咖啡机', emoji: '☕', price: 699, purchasedAt: ago(95), category: '厨房', tags: [], goalType: 'uses', goalValue: 200, usageCount: 46, lastUsedAt: ago(46) },
      { name: '折叠单车', emoji: '🚲', price: 2180, purchasedAt: ago(300), category: '出行', tags: ['运动'], goalType: 'uses', goalValue: 300, usageCount: 62, lastUsedAt: ago(38) },
      { name: '单反相机', emoji: '📷', price: 6400, purchasedAt: ago(520), category: '数码', tags: ['兴趣'], goalType: 'uses', goalValue: 150, usageCount: 28, lastUsedAt: ago(120) },
      { name: '空气炸锅', emoji: '🍳', price: 459, purchasedAt: ago(150), category: '厨房', tags: [], goalType: 'uses', goalValue: 80, usageCount: 88, lastUsedAt: ago(3) },
      { name: '跑步鞋', emoji: '👟', price: 799, purchasedAt: ago(70), category: '运动', tags: ['健康'], goalType: 'uses', goalValue: 100, usageCount: 34, lastUsedAt: ago(2) },
      { name: 'Kindle 阅读器', emoji: '📖', price: 998, purchasedAt: ago(600), category: '学习', tags: [], goalType: 'days', goalValue: 730, usageCount: 120, lastUsedAt: ago(200) },
      { name: '智能手表', emoji: '⌚', price: 1799, purchasedAt: ago(210), category: '数码', tags: ['健康'], goalType: 'days', goalValue: 180, usageCount: 640, lastUsedAt: ago(0) },
    ];
    state.items = samples.map(s => normalizeItem(s, null));
    state.settings.focusItemId = state.items[0].id;
    await writeState(state);
    res.json({ ok: true, count: state.items.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`daily-cost running on ${port}`));
