// 每日成本 Daily Cost —— JSOS 应用
// hash 路由：#/ 主界面；#/widget/overview | ranking | focus 桌面组件

const DAY = 86400000;

const CATS = [
  { key: '数码', color: '#6366F1', emojis: ['💻', '📱', '🎧', '⌨️', '🖱️', '📷', '🎮', '⌚', '🔋', '🖨️', '📺', '🕹️'] },
  { key: '家居', color: '#14B8A6', emojis: ['🛋️', '🛏️', '🪑', '💡', '🪴', '🧹', '🚪', '🪞', '🧺', '❄️', '🔥', '🛁'] },
  { key: '服饰', color: '#EC4899', emojis: ['👕', '👖', '👟', '🧥', '🎒', '🧢', '👗', '🧦', '👔', '🕶️', '💼', '🧣'] },
  { key: '出行', color: '#0EA5E9', emojis: ['🚲', '🛵', '🚗', '🛴', '🎫', '🧳', '⛽', '🗺️', '🚁', '⛵', '🛶', '🚕'] },
  { key: '娱乐', color: '#A855F7', emojis: ['🎸', '🎹', '🎬', '📚', '🎨', '🎲', '🧩', '🎤', '📖', '✏️', '🖌️', '🎧'] },
  { key: '运动', color: '#22C55E', emojis: ['🏀', '⚽', '🏸', '🎾', '🧘', '🏋️', '🚴', '🏊', '⛰️', '🎿', '🥊', '🧗'] },
  { key: '厨房', color: '#F97316', emojis: ['🍳', '☕', '🍚', '🥘', '🍞', '🧊', '🍽️', '🔪', '🥤', '🍲', '🧁', '🍺'] },
  { key: '美妆', color: '#F43F5E', emojis: ['💄', '🧴', '🧼', '💅', '🪥', '🧖', '🌸', '💧', '🪞', '🧪', '🫧', '👃'] },
  { key: '宠物', color: '#EAB308', emojis: ['🐱', '🐶', '🐹', '🐰', '🐟', '🦜', '🐢', '🦎', '🧸', '🦴', '🏠', '🐾'] },
  { key: '学习', color: '#3B82F6', emojis: ['📚', '📝', '🎓', '🖊️', '📐', '🧮', '💡', '🗂️', '📎', '🖍️', '📏', '🔬'] },
  { key: '其他', color: '#64748B', emojis: ['📦', '🎁', '🔑', '🧰', '⚙️', '🧲', '🔧', '🪛', '📌', '🗝️', '⭐', '🪄'] },
];
const catColor = k => (CATS.find(c => c.key === k) || CATS[CATS.length - 1]).color;

// ---------- 工具 ----------
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));

function money(n, dec) {
  const v = Number.isFinite(n) ? n : 0;
  const d = dec ?? (Math.abs(v) >= 1000 ? 0 : Math.abs(v) >= 10 ? 1 : 2);
  return '¥' + v.toLocaleString('zh-CN', { minimumFractionDigits: d, maximumFractionDigits: d });
}
function dateStr(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function fromDateStr(s) {
  const p = String(s || '').split('-').map(Number);
  if (p.length !== 3 || p.some(n => !Number.isFinite(n))) return Date.now();
  return new Date(p[0], p[1] - 1, p[2], 12, 0, 0).getTime();
}
function humanAgo(ts) {
  const d = Math.floor((Date.now() - ts) / DAY);
  if (d <= 0) return '今天';
  if (d === 1) return '昨天';
  if (d < 30) return `${d} 天前`;
  if (d < 365) return `${Math.floor(d / 30)} 个月前`;
  return `${(d / 365).toFixed(1)} 年前`;
}

// ---------- 核心计算 ----------
function calc(item, idleDays = 30) {
  const now = Date.now();
  const days = Math.max(1, Math.floor((now - item.purchasedAt) / DAY) + 1);
  const daily = item.price / days;
  const uses = item.usageCount || 0;
  const perUse = uses > 0 ? item.price / uses : null;

  let progress = null, remaining = null, goalText = '';
  if (item.goalType === 'days' && item.goalValue > 0) {
    progress = days / item.goalValue;
    remaining = Math.max(0, Math.ceil(item.goalValue - days));
    goalText = `目标用满 ${item.goalValue} 天`;
  } else if (item.goalType === 'uses' && item.goalValue > 0) {
    progress = uses / item.goalValue;
    remaining = Math.max(0, item.goalValue - uses);
    goalText = `目标用满 ${item.goalValue} 次`;
  }

  const lastUse = item.lastUsedAt || item.purchasedAt;
  const idleFor = Math.floor((now - lastUse) / DAY);
  let status = 'active';
  if (progress !== null && progress >= 1) status = 'achieved';
  else if (idleFor >= idleDays) status = 'idle';

  return { days, daily, uses, perUse, progress, remaining, goalText, idleFor, status };
}

function ratingOf(daily) {
  if (daily < 0.3) return { label: '超值', emoji: '🏆', color: '#10B981' };
  if (daily < 1) return { label: '划算', emoji: '👍', color: '#22C55E' };
  if (daily < 3) return { label: '一般', emoji: '🙂', color: '#F59E0B' };
  if (daily < 10) return { label: '偏贵', emoji: '🤔', color: '#F97316' };
  return { label: '奢侈', emoji: '💸', color: '#EF4444' };
}
const STATUS_TEXT = { achieved: '已回本', idle: '吃灰中', active: '使用中' };
const statusColor = s => (s === 'achieved' ? 'var(--good)' : s === 'idle' ? 'var(--warn)' : 'var(--brand)');

function stats(items) {
  const idleDays = state.settings?.idleDays || 30;
  const list = items.filter(i => !i.archived).map(item => ({ item, c: calc(item, idleDays) }));
  const total = list.reduce((s, x) => s + x.item.price, 0);
  const perDay = list.reduce((s, x) => s + x.c.daily, 0);
  const achieved = list.filter(x => x.c.status === 'achieved');
  const idle = list.filter(x => x.c.status === 'idle');
  const byCat = {};
  for (const x of list) {
    const k = x.item.category || '其他';
    byCat[k] = byCat[k] || { key: k, count: 0, price: 0, daily: 0 };
    byCat[k].count++; byCat[k].price += x.item.price; byCat[k].daily += x.c.daily;
  }
  const cats = Object.values(byCat).sort((a, b) => b.price - a.price);
  const sorted = [...list].sort((a, b) => b.c.daily - a.c.daily);
  return {
    list, total, perDay, cats,
    count: list.length,
    achieved: achieved.length,
    idleCount: idle.length,
    idleValue: idle.reduce((s, x) => s + x.item.price, 0),
    best: sorted.length ? sorted[sorted.length - 1] : null,
    worst: sorted.length ? sorted[0] : null,
  };
}

// ---------- 状态 ----------
let state = { items: [], settings: { idleDays: 30, focusItemId: null }, updatedAt: 0 };
let lastRendered = -1;
const ui = { view: 'grid', cat: 'all', status: 'all', sort: 'daily-desc', q: '' };

async function api(path, opts) {
  const res = await fetch(path, {
    headers: opts?.body ? { 'Content-Type': 'application/json' } : undefined,
    ...opts,
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.statusText);
  return res.json();
}

async function loadState() {
  try { state = await api('/api/state'); } catch { /* 服务未就绪时保持旧状态 */ }
}

function toast(title, type = 'default') {
  if (window.JSOS?.toast) { window.JSOS.toast({ title, type }).catch(() => {}); return; }
  const el = document.createElement('div');
  el.textContent = title;
  el.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);background:rgba(15,23,42,.92);color:#fff;padding:9px 16px;border-radius:10px;font-size:13px;z-index:99;box-shadow:0 6px 20px rgba(0,0,0,.25)';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2200);
}

// ---------- 路由与渲染 ----------
function routeOf() {
  const m = (location.hash || '').match(/^#\/widget\/([a-z]+)/);
  return m ? m[1] : null;
}

function render() {
  const w = routeOf();
  // 重渲染会重建 DOM，先记下搜索框的光标位置，渲染后还原，避免打字被打断
  const ae = document.activeElement;
  const keep = ae?.dataset?.act === 'search' ? { pos: ae.selectionStart } : null;

  document.body.classList.toggle('widget', !!w);
  const root = $('#app');
  if (w === 'overview') root.innerHTML = viewOverview();
  else if (w === 'ranking') root.innerHTML = viewRanking();
  else if (w === 'focus') root.innerHTML = viewFocus();
  else root.innerHTML = viewMain();
  lastRendered = state.updatedAt;

  if (keep) {
    const el = $('[data-act="search"]');
    if (el) { el.focus(); try { el.setSelectionRange(keep.pos, keep.pos); } catch { /* 浏览器不支持时忽略 */ } }
  }
}

// ---------- 主界面 ----------
function viewMain() {
  const s = stats(state.items);
  if (!s.count) return emptyView();

  const catBtns = [['all', '全部分类'], ...CATS.map(c => [c.key, c.key])]
    .map(([v, t]) => `<button data-act="filter-cat" data-v="${esc(v)}" class="${ui.cat === v ? 'on' : ''}">${esc(t)}</button>`).join('');
  const stBtns = [['all', '全部'], ['active', '使用中'], ['achieved', '已回本'], ['idle', '吃灰中']]
    .map(([v, t]) => `<button data-act="filter-status" data-v="${v}" class="${ui.status === v ? 'on' : ''}">${t}</button>`).join('');

  const list = filtered(s);
  const maxCat = Math.max(1, ...s.cats.map(c => c.price));

  return `
  <div class="main">
    <div class="topbar">
      <div class="brand">
        <div class="brand-mark">¥</div>
        <div>
          <div class="brand-title">每日成本</div>
          <div class="brand-sub">买过的东西，每天到底花你多少钱</div>
        </div>
      </div>
      <button class="btn" data-act="export">导出备份</button>
      <button class="btn" data-act="import">导入备份</button>
      <button class="btn btn-primary" data-act="add">＋ 添加物品</button>
    </div>

    <div class="kpis">
      <div class="kpi">
        <div class="kpi-label">总投入</div>
        <div class="kpi-value num">${money(s.total)}</div>
        <div class="kpi-hint">共 ${s.count} 件物品</div>
      </div>
      <div class="kpi accent">
        <div class="kpi-label">今日摊薄</div>
        <div class="kpi-value num">${money(s.perDay)}<small>/天</small></div>
        <div class="kpi-hint">约 ${money(s.perDay * 30)} / 月</div>
      </div>
      <div class="kpi good">
        <div class="kpi-label">已回本</div>
        <div class="kpi-value num">${s.achieved}<small> / ${s.count}</small></div>
        <div class="kpi-hint">达成目标的物品</div>
      </div>
      <div class="kpi danger">
        <div class="kpi-label">吃灰占用</div>
        <div class="kpi-value num">${money(s.idleValue)}</div>
        <div class="kpi-hint">${s.idleCount} 件长期未用</div>
      </div>
    </div>

    <div class="toolbar">
      <div class="seg">${catBtns}</div>
      <div class="seg">${stBtns}</div>
      <select class="field" data-act="sort">
        <option value="daily-desc"${ui.sort === 'daily-desc' ? ' selected' : ''}>日均成本 高→低</option>
        <option value="daily-asc"${ui.sort === 'daily-asc' ? ' selected' : ''}>日均成本 低→高</option>
        <option value="price-desc"${ui.sort === 'price-desc' ? ' selected' : ''}>价格 高→低</option>
        <option value="date-desc"${ui.sort === 'date-desc' ? ' selected' : ''}>购买时间 新→旧</option>
        <option value="date-asc"${ui.sort === 'date-asc' ? ' selected' : ''}>购买时间 旧→新</option>
        <option value="progress-desc"${ui.sort === 'progress-desc' ? ' selected' : ''}>回本进度 高→低</option>
      </select>
      <input class="field search" data-act="search" placeholder="搜索名称 / 标签…" value="${esc(ui.q)}">
      <div class="seg">
        <button data-act="view" data-v="grid" class="${ui.view === 'grid' ? 'on' : ''}">卡片</button>
        <button data-act="view" data-v="list" class="${ui.view === 'list' ? 'on' : ''}">列表</button>
      </div>
    </div>

    ${list.length ? (ui.view === 'grid'
      ? `<div class="grid">${list.map(x => cardHtml(x)).join('')}</div>`
      : `<div class="rows">${list.map(x => rowHtml(x)).join('')}</div>`)
      : `<div class="empty"><div class="empty-emoji">🔍</div><div class="empty-title">没有符合条件的物品</div><div class="empty-sub">换个筛选条件试试。</div></div>`}

    <div class="section-title">分类统计</div>
    <div class="cats">
      ${s.cats.map(c => `
        <div class="cat-row">
          <div class="cat-name"><i style="width:8px;height:8px;border-radius:3px;background:${catColor(c.key)};display:inline-block"></i>${esc(c.key)}</div>
          <div class="cat-bar"><i style="width:${(c.price / maxCat * 100).toFixed(1)}%;background:${catColor(c.key)}"></i></div>
          <div class="cat-val num">${money(c.price)}<span>${c.count} 件 · ${money(c.daily)}/天</span></div>
        </div>`).join('')}
    </div>

    <div class="section-title">洞察</div>
    <div class="kpis" style="grid-template-columns:repeat(auto-fit,minmax(210px,1fr))">
      ${s.best ? `<div class="kpi good"><div class="kpi-label">🏆 最值的一件</div><div class="kpi-value" style="font-size:17px">${esc(s.best.item.emoji)} ${esc(s.best.item.name)}</div><div class="kpi-hint num">日均 ${money(s.best.c.daily)} · ${s.best.c.uses} 次使用</div></div>` : ''}
      ${s.worst ? `<div class="kpi danger"><div class="kpi-label">💸 最烧钱的一件</div><div class="kpi-value" style="font-size:17px">${esc(s.worst.item.emoji)} ${esc(s.worst.item.name)}</div><div class="kpi-hint num">日均 ${money(s.worst.c.daily)} · 持有 ${s.worst.c.days} 天</div></div>` : ''}
      ${s.idleCount ? `<div class="kpi"><div class="kpi-label">😴 吃灰提醒</div><div class="kpi-value" style="font-size:17px">${s.idleCount} 件在睡大觉</div><div class="kpi-hint num">占用 ${money(s.idleValue)}，日均蒸发 ${money(s.idleValue / Math.max(1, s.idleCount))}</div></div>` : ''}
    </div>
  </div>`;
}

function filtered(s) {
  let list = s.list;
  if (ui.cat !== 'all') list = list.filter(x => (x.item.category || '其他') === ui.cat);
  if (ui.status !== 'all') list = list.filter(x => x.c.status === ui.status);
  const q = ui.q.trim().toLowerCase();
  if (q) list = list.filter(x =>
    x.item.name.toLowerCase().includes(q) ||
    (x.item.tags || []).some(t => String(t).toLowerCase().includes(q)) ||
    (x.item.category || '').toLowerCase().includes(q));
  const by = {
    'daily-desc': (a, b) => b.c.daily - a.c.daily,
    'daily-asc': (a, b) => a.c.daily - b.c.daily,
    'price-desc': (a, b) => b.item.price - a.item.price,
    'date-desc': (a, b) => b.item.purchasedAt - a.item.purchasedAt,
    'date-asc': (a, b) => a.item.purchasedAt - b.item.purchasedAt,
    'progress-desc': (a, b) => (b.c.progress ?? -1) - (a.c.progress ?? -1),
  }[ui.sort] || (() => 0);
  return [...list].sort(by);
}

function cardHtml(x) {
  const { item: it, c } = x;
  const r = ratingOf(c.daily);
  const pct = c.progress === null ? null : clamp(c.progress * 100, 0, 100);
  return `
  <div class="card ${c.status === 'idle' ? 'idle' : ''}" data-act="edit" data-id="${it.id}">
    <div class="card-head">
      <div class="card-emoji" style="background:${catColor(it.category)}22">${esc(it.emoji)}</div>
      <div style="min-width:0;flex:1">
        <div class="card-title">${esc(it.name)}</div>
        <div class="card-meta">
          <span>${esc(it.category)}</span>·<span>持有 ${c.days} 天</span>
        </div>
      </div>
    </div>
    <div class="card-price">买入 <b class="num">${money(it.price)}</b> · ${esc(humanAgo(it.purchasedAt))}</div>
    <div class="daily-line">
      <span class="daily-num num" style="color:${r.color}">${money(c.daily)}</span>
      <span class="daily-unit">/ 天</span>
      <span class="daily-tag" style="background:${r.color}1f;color:${r.color}">${r.emoji} ${r.label}</span>
    </div>
    ${pct === null ? `<div class="bar-label"><span>未设目标</span><span>${c.uses} 次使用</span></div>`
      : `<div class="bar"><i style="width:${pct.toFixed(1)}%;background:${statusColor(c.status)}"></i></div>
         <div class="bar-label"><span>${esc(c.goalText)}</span><span class="num">${pct.toFixed(0)}%</span></div>`}
    <div class="card-foot">
      <span class="badge ${c.status}">${STATUS_TEXT[c.status]}</span>
      ${c.perUse !== null ? `<span class="badge">单次 ${money(c.perUse)}</span>` : ''}
      <div class="card-actions">
        <button class="btn btn-sm btn-icon" data-act="use" data-id="${it.id}" title="记一次使用">＋1</button>
        <button class="btn btn-sm btn-icon" data-act="focus" data-id="${it.id}" title="设为组件聚焦">◎</button>
      </div>
    </div>
  </div>`;
}

function rowHtml(x) {
  const { item: it, c } = x;
  const r = ratingOf(c.daily);
  const pct = c.progress === null ? null : clamp(c.progress * 100, 0, 100);
  return `
  <div class="row" data-act="edit" data-id="${it.id}">
    <div class="row-emoji" style="background:${catColor(it.category)}22">${esc(it.emoji)}</div>
    <div style="min-width:0;flex:1">
      <div class="row-name">${esc(it.name)}</div>
      <div class="row-sub">${esc(it.category)} · 持有 ${c.days} 天 · ${money(it.price)}</div>
    </div>
    <div class="row-prog">
      ${pct === null ? `<div class="row-sub">未设目标</div>`
        : `<div class="bar"><i style="width:${pct.toFixed(1)}%;background:${statusColor(c.status)}"></i></div>
           <div class="row-sub num" style="margin-top:3px">${esc(c.goalText)} · ${pct.toFixed(0)}%</div>`}
    </div>
    <div class="row-daily num" style="color:${r.color}">${money(c.daily)}<span>/天</span></div>
    <span class="badge ${c.status}">${STATUS_TEXT[c.status]}</span>
    <button class="btn btn-sm btn-icon" data-act="use" data-id="${it.id}" title="记一次使用">＋1</button>
  </div>`;
}

function emptyView() {
  return `
  <div class="main">
    <div class="topbar">
      <div class="brand">
        <div class="brand-mark">¥</div>
        <div>
          <div class="brand-title">每日成本</div>
          <div class="brand-sub">买过的东西，每天到底花你多少钱</div>
        </div>
      </div>
    </div>
    <div class="empty">
      <div class="empty-emoji">🧾</div>
      <div class="empty-title">还没有记录任何物品</div>
      <div class="empty-sub">记下买过的东西和价格，它会自动算出日均成本、回本进度和单次使用成本 —— 一眼看出哪些东西真的值回票价。</div>
      <div class="empty-actions">
        <button class="btn btn-primary" data-act="add">＋ 添加第一件</button>
        <button class="btn" data-act="seed">载入示例数据</button>
      </div>
    </div>
  </div>`;
}

// ---------- 组件：成本总览 ----------
function viewOverview() {
  const s = stats(state.items);
  if (!s.count) return `<div class="w"><div class="w-empty"><span class="e">🧾</span>还没有物品<br>打开「每日成本」添加</div></div>`;
  const pct = s.count ? clamp(s.achieved / s.count * 100, 0, 100) : 0;
  return `
  <div class="w">
    <div class="w-head">📊 成本总览</div>
    <div style="margin-top:6px">
      <div class="w-sub">总投入</div>
      <div class="w-big num">${money(s.total)}</div>
    </div>
    <div style="margin-top:10px">
      <div class="w-sub">今日摊薄</div>
      <div class="w-big num" style="color:var(--brand-deep)">${money(s.perDay)}<small>/天</small></div>
    </div>
    <div class="w-grid2" style="margin-top:auto">
      <div class="w-box"><div class="k">已回本</div><div class="v num" style="color:var(--good)">${s.achieved}<span style="font-size:11px;color:var(--text-3)"> / ${s.count}</span></div></div>
      <div class="w-box"><div class="k">吃灰占用</div><div class="v num" style="color:var(--bad)">${money(s.idleValue)}</div></div>
    </div>
    <div class="bar" style="margin-top:8px"><i style="width:${pct.toFixed(1)}%;background:var(--good)"></i></div>
    <div class="w-sub num" style="margin-top:4px">整体回本 ${pct.toFixed(0)}%${s.worst ? ` · 最烧钱 ${esc(s.worst.item.emoji)}${esc(s.worst.item.name)} ${money(s.worst.c.daily)}/天` : ''}</div>
  </div>`;
}

// ---------- 组件：日均账单 ----------
function viewRanking() {
  const s = stats(state.items);
  if (!s.count) return `<div class="w"><div class="w-empty"><span class="e">🧾</span>还没有物品<br>打开「每日成本」添加</div></div>`;
  const top = [...s.list].sort((a, b) => b.c.daily - a.c.daily).slice(0, 5);
  return `
  <div class="w">
    <div class="w-head" data-act="open" style="cursor:pointer">📋 日均账单 <span style="margin-left:auto">共 ${s.count} 件 →</span></div>
    <div style="margin-top:4px;flex:1;overflow:auto">
      ${top.map(x => {
        const { item: it, c } = x;
        const r = ratingOf(c.daily);
        const pct = c.progress === null ? null : clamp(c.progress * 100, 0, 100);
        return `
        <div class="w-line">
          <div class="w-item" style="flex:1">
            <div class="w-item-e" style="background:${catColor(it.category)}22">${esc(it.emoji)}</div>
            <div style="min-width:0;flex:1">
              <div class="w-item-n">${esc(it.name)}</div>
              <div class="w-item-s">${c.days} 天 · ${c.uses} 次</div>
              ${pct === null ? '' : `<div class="w-item-bar"><i style="width:${pct.toFixed(0)}%;background:${statusColor(c.status)}"></i></div>`}
            </div>
          </div>
          <button class="w-use" data-act="use" data-id="${it.id}" title="记一次使用">＋</button>
          <div class="w-item-v num" style="color:${r.color};min-width:62px">${money(c.daily)}<span>/天</span></div>
        </div>`;
      }).join('')}
    </div>
    <div class="w-sub num" style="border-top:1px solid var(--border);padding-top:6px;margin-top:6px">
      合计摊薄 ${money(s.perDay)}/天 · ${money(s.perDay * 365)}/年
    </div>
  </div>`;
}

// ---------- 组件：单品聚焦 ----------
function viewFocus() {
  const s = stats(state.items);
  if (!s.count) return `<div class="w"><div class="w-empty"><span class="e">🧾</span>还没有物品</div></div>`;
  const focus = state.items.find(i => i.id === state.settings?.focusItemId) || s.worst?.item;
  const it = focus || s.list[0].item;
  const c = calc(it, state.settings?.idleDays || 30);
  const r = ratingOf(c.daily);
  const pct = c.progress === null ? null : clamp(c.progress, 0, 1);
  const C = 2 * Math.PI * 42;
  const off = pct === null ? C : C * (1 - pct);

  return `
  <div class="w">
    <div class="w-head" data-act="next-focus" style="cursor:pointer">
      <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(it.emoji)} ${esc(it.name)}</span>
      <span style="margin-left:auto;flex:none">⇄</span>
    </div>
    <div style="display:flex;align-items:center;gap:10px;flex:1;justify-content:center">
      <div class="w-ring" style="width:104px;height:104px;flex:none">
        <svg viewBox="0 0 100 100" style="width:104px;height:104px;transform:rotate(-90deg)">
          <circle cx="50" cy="50" r="42" fill="none" stroke="var(--ring-track)" stroke-width="9"/>
          <circle cx="50" cy="50" r="42" fill="none" stroke="${statusColor(c.status)}" stroke-width="9"
            stroke-linecap="round" stroke-dasharray="${C.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}"/>
        </svg>
        <div class="w-ring-txt">
          <div class="w-ring-pct num" style="color:${r.color}">${money(c.daily, c.daily >= 100 ? 0 : c.daily >= 10 ? 1 : 2)}</div>
          <div class="w-ring-lbl">每天</div>
        </div>
      </div>
      <div style="min-width:0;flex:1">
        <div class="w-sub">买入 ${money(it.price)}</div>
        <div class="w-sub">持有 ${c.days} 天</div>
        <div class="w-sub">${c.perUse !== null ? `单次 ${money(c.perUse)}` : '暂无使用记录'}</div>
        <div class="w-sub" style="margin-top:5px;color:${statusColor(c.status)};font-weight:700">
          ${STATUS_TEXT[c.status]}${c.remaining !== null && c.remaining > 0 ? ` · 还需 ${c.remaining} ${c.goalText.includes('次') ? '次' : '天'}` : ''}
        </div>
      </div>
    </div>
    <div class="w-sub num" style="text-align:center">${r.emoji} ${r.label}${pct !== null ? ` · 回本 ${(pct * 100).toFixed(0)}%` : ''}</div>
  </div>`;
}

// ---------- 弹窗：物品编辑 ----------
let form = null;
let emojiCat = CATS[0].key;
let pendingConfirm = null;

function openEditor(item) {
  const it = item || { name: '', emoji: '📦', price: '', purchasedAt: Date.now(), category: CATS[0].key, tags: [], note: '', goalType: 'days', goalValue: 365, usageCount: 0 };
  form = { ...it, _new: !item };
  emojiCat = CATS.find(c => c.key === it.category)?.key || CATS[0].key;
  renderModal();
}

function renderModal() {
  const isNew = form._new;
  const cat = CATS.find(c => c.key === emojiCat) || CATS[0];
  const goalOn = form.goalType !== 'none';
  $('#modal-root').innerHTML = `
  <div class="mask" data-act="mask">
    <div class="modal" data-stop>
      <div class="modal-head"><h3>${isNew ? '添加物品' : '编辑物品'}</h3></div>
      <div class="modal-body">
        <div>
          <label class="lbl">图标与名称</label>
          <div class="pick-row">
            <div class="pick-emoji" data-act="toggle-emoji">${esc(form.emoji)}</div>
            <input class="inp" data-f="name" placeholder="例如：降噪耳机" value="${esc(form.name)}">
          </div>
        </div>
        <div data-emoji-panel style="${form._showEmoji ? '' : 'display:none'}">
          <div class="cat-tabs">
            ${CATS.map(c => `<button data-act="emoji-cat" data-v="${esc(c.key)}" class="${c.key === emojiCat ? 'on' : ''}">${esc(c.key)}</button>`).join('')}
          </div>
          <div class="emoji-grid" style="margin-top:6px">
            ${cat.emojis.map(e => `<button data-act="pick-emoji" data-v="${e}" class="${e === form.emoji ? 'on' : ''}">${e}</button>`).join('')}
          </div>
        </div>
        <div class="grid2">
          <div>
            <label class="lbl">购买价格（元）</label>
            <input class="inp num" data-f="price" type="number" min="0" step="0.01" placeholder="0.00" value="${form.price === '' ? '' : esc(form.price)}">
          </div>
          <div>
            <label class="lbl">购买日期</label>
            <input class="inp" data-f="purchasedAt" type="date" value="${dateStr(form.purchasedAt)}">
          </div>
        </div>
        <div class="grid2">
          <div>
            <label class="lbl">分类</label>
            <select class="inp" data-f="category">
              ${CATS.map(c => `<option value="${esc(c.key)}"${c.key === form.category ? ' selected' : ''}>${esc(c.key)}</option>`).join('')}
            </select>
          </div>
          <div>
            <label class="lbl">标签（逗号分隔）</label>
            <input class="inp" data-f="tags" placeholder="工作, 通勤" value="${esc((form.tags || []).join(', '))}">
          </div>
        </div>
        <div>
          <label class="lbl">回本目标</label>
          <div class="radio-row">
            <button data-act="goal" data-v="days" class="${form.goalType === 'days' ? 'on' : ''}">用满天数</button>
            <button data-act="goal" data-v="uses" class="${form.goalType === 'uses' ? 'on' : ''}">用满次数</button>
            <button data-act="goal" data-v="none" class="${form.goalType === 'none' ? 'on' : ''}">不设目标</button>
          </div>
        </div>
        ${goalOn ? `<div class="grid2">
          <div>
            <label class="lbl">${form.goalType === 'uses' ? '目标使用次数' : '目标使用天数'}</label>
            <input class="inp num" data-f="goalValue" type="number" min="1" step="1" value="${esc(form.goalValue)}">
          </div>
          <div>
            <label class="lbl">已使用次数</label>
            <input class="inp num" data-f="usageCount" type="number" min="0" step="1" value="${esc(form.usageCount || 0)}">
          </div>
        </div>` : ''}
        <div>
          <label class="lbl">备注</label>
          <textarea class="inp" data-f="note" placeholder="选填，记录购买理由、保修信息等">${esc(form.note)}</textarea>
        </div>
      </div>
      <div class="modal-foot">
        ${isNew ? '' : `<button class="btn btn-danger" data-act="del" data-id="${esc(form.id)}">删除</button>`}
        <div class="spacer"></div>
        <button class="btn" data-act="close">取消</button>
        <button class="btn btn-primary" data-act="save">保存</button>
      </div>
    </div>
  </div>`;
}

function readForm() {
  const root = $('#modal-root');
  const get = f => root.querySelector(`[data-f="${f}"]`)?.value;
  form.name = get('name');
  form.price = get('price');
  form.purchasedAt = fromDateStr(get('purchasedAt'));
  form.category = get('category');
  form.tags = String(get('tags') || '').split(/[,，\s]+/).map(s => s.trim()).filter(Boolean);
  form.note = get('note');
  if (form.goalType !== 'none') {
    form.goalValue = Number(get('goalValue')) || 365;
    form.usageCount = Number(get('usageCount')) || 0;
  }
}

function closeModal() { $('#modal-root').innerHTML = ''; form = null; }

async function saveForm() {
  readForm();
  if (!String(form.name || '').trim()) { toast('请填写物品名称', 'warning'); return; }
  const price = Number(form.price);
  if (!Number.isFinite(price) || price < 0) { toast('请填写有效的价格', 'warning'); return; }
  const payload = {
    name: form.name.trim(), emoji: form.emoji, price,
    purchasedAt: form.purchasedAt, category: form.category,
    tags: form.tags, note: form.note,
    goalType: form.goalType, goalValue: Number(form.goalValue) || 365,
    usageCount: Number(form.usageCount) || 0,
    lastUsedAt: form.lastUsedAt ?? null,
  };
  try {
    const isNew = form._new;
    if (isNew) await api('/api/items', { method: 'POST', body: JSON.stringify(payload) });
    else await api(`/api/items/${form.id}`, { method: 'PUT', body: JSON.stringify(payload) });
    closeModal();
    await loadState(); render();
    toast(isNew ? '已添加' : '已保存', 'success');
  } catch (e) { toast('保存失败：' + e.message, 'error'); }
}

function confirmDlg(title, msg, onOk) {
  $('#modal-root').innerHTML = `
  <div class="mask" data-act="mask">
    <div class="modal" data-stop style="max-width:380px">
      <div class="modal-head"><h3>${esc(title)}</h3></div>
      <div class="modal-body"><div style="color:var(--text-2);font-size:13.5px">${msg}</div></div>
      <div class="modal-foot"><div class="spacer"></div>
        <button class="btn" data-act="close">取消</button>
        <button class="btn btn-primary" data-act="confirm-ok">确定</button>
      </div>
    </div>
  </div>`;
}

// ---------- 事件 ----------
document.addEventListener('click', async (e) => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const act = t.dataset.act;
  const id = t.dataset.id;
  const v = t.dataset.v;

  // 弹窗内点击不穿透
  if (act === 'mask' && e.target === t) { closeModal(); return; }

  switch (act) {
    case 'add': openEditor(null); break;
    case 'edit': openEditor(state.items.find(i => i.id === id)); break;
    case 'close': closeModal(); break;

    case 'toggle-emoji': readForm(); form._showEmoji = !form._showEmoji; renderModal(); break;
    case 'emoji-cat': readForm(); emojiCat = v; renderModal(); break;
    case 'pick-emoji': readForm(); form.emoji = v; renderModal(); break;
    case 'goal': readForm(); form.goalType = v; renderModal(); break;

    case 'save': saveForm(); break;
    case 'confirm-ok': { const fn = pendingConfirm; pendingConfirm = null; closeModal(); fn && await fn(); break; }
    case 'del': {
      const it = state.items.find(i => i.id === id);
      closeModal();
      confirmDlg('删除物品', `确定删除「${esc(it?.name || '')}」吗？此操作不可撤销。`, async () => {
        try { await api(`/api/items/${id}`, { method: 'DELETE' }); await loadState(); render(); toast('已删除', 'success'); }
        catch (err) { toast('删除失败：' + err.message, 'error'); }
      });
      break;
    }

    case 'use': {
      e.stopPropagation();
      try {
        await api(`/api/items/${id}/use`, { method: 'POST', body: '{}' });
        await loadState(); render();
        toast('已记录一次使用', 'success');
      } catch (err) { toast('记录失败：' + err.message, 'error'); }
      break;
    }
    case 'focus': {
      e.stopPropagation();
      try { await api('/api/settings', { method: 'PUT', body: JSON.stringify({ focusItemId: id }) }); await loadState(); render(); toast('已设为组件聚焦物品', 'success'); }
      catch { /* 忽略 */ }
      break;
    }
    case 'next-focus': {
      const s = stats(state.items);
      const sorted = [...s.list].sort((a, b) => b.c.daily - a.c.daily);
      if (!sorted.length) break;
      const idx = sorted.findIndex(x => x.item.id === (state.settings?.focusItemId || sorted[0].item.id));
      const next = sorted[(idx + 1) % sorted.length].item.id;
      try { await api('/api/settings', { method: 'PUT', body: JSON.stringify({ focusItemId: next }) }); await loadState(); render(); } catch {}
      break;
    }
    case 'open':
      if (window.JSOS?.openApp) window.JSOS.openApp('daily-cost').catch(() => {});
      break;

    case 'view': ui.view = v; render(); break;
    case 'filter-cat': ui.cat = v; render(); break;
    case 'filter-status': ui.status = v; render(); break;

    case 'seed':
      try { await api('/api/seed', { method: 'POST', body: '{}' }); await loadState(); render(); toast('示例数据已载入', 'success'); }
      catch (err) { toast('载入失败：' + err.message, 'error'); }
      break;

    case 'export': {
      const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `daily-cost-${dateStr(Date.now())}.json`;
      a.click(); URL.revokeObjectURL(a.href);
      toast('备份已导出', 'success');
      break;
    }
    case 'import': {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = '.json,application/json';
      inp.onchange = async () => {
        const f = inp.files?.[0]; if (!f) return;
        try {
          const data = JSON.parse(await f.text());
          if (!Array.isArray(data.items)) throw new Error('文件格式不正确');
          await api('/api/import', { method: 'POST', body: JSON.stringify(data) });
          await loadState(); render(); toast(`已导入 ${data.items.length} 件物品`, 'success');
        } catch (err) { toast('导入失败：' + err.message, 'error'); }
      };
      inp.click();
      break;
    }
  }
});

document.addEventListener('change', (e) => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  if (t.dataset.act === 'sort') { ui.sort = t.value; render(); }
});

let searchTimer = null;
document.addEventListener('input', (e) => {
  const t = e.target.closest('[data-act="search"]');
  if (!t) return;
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { ui.q = t.value; render(); }, 180);
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && form) closeModal();
});

// ---------- 主题 ----------
async function initTheme() {
  const apply = t => { document.documentElement.dataset.theme = t === 'dark' ? 'dark' : 'light'; };
  try {
    if (window.JSOS?.getTheme) {
      apply(await window.JSOS.getTheme());
    } else {
      const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
      apply(mq?.matches ? 'dark' : 'light');
    }
    window.JSOS?.onThemeChange?.(apply);
  } catch { apply('light'); }
}

// ---------- 启动 ----------
async function boot() {
  await initTheme();
  await loadState();
  render();
  window.addEventListener('hashchange', render);
  // 多窗口 / 组件与主界面之间同步
  setInterval(async () => {
    await loadState();
    if (state.updatedAt !== lastRendered) render();
  }, 3000);
}
boot();
