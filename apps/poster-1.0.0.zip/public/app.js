import { loadState, saveState, onExternalChange, imgUrl, stepIndex, baseName } from './poster-core.js';

const $ = (id) => document.getElementById(id);
const els = {
  previewImg: $('previewImg'), previewEmpty: $('previewEmpty'),
  previewLabel: $('previewLabel'), btnPrev: $('btnPrev'), btnNext: $('btnNext'),
  modeSeg: $('modeSeg'), modeHint: $('modeHint'),
  srcLabel: $('srcLabel'), btnBrowse: $('btnBrowse'),
  srcChip: $('srcChip'), srcChipText: $('srcChipText'),
  autoRotate: $('autoRotate'), order: $('order'), interval: $('interval'),
  modal: $('browseModal'), crumbs: $('crumbs'), fileList: $('fileList'),
  btnCloseModal: $('btnCloseModal'), btnPickHere: $('btnPickHere'), browseHint: $('browseHint'),
};

let state = null;        // 与服务端一致的海报设置
let images = [];         // folder 模式的相册列表
let viewIndex = 0;       // 预览当前显示第几张（自动轮播只在本地走，不回写）
let rotateTimer = null;
let config = null;       // /api/config → { root }
let browsePath = null;   // 对话框当前目录

const DEFAULTS = {
  mode: 'single', imagePath: null, folderPath: null,
  autoRotate: false, order: 'sequential', interval: 5, index: 0,
};

const parentOf = (p) => p && p.includes('/') ? p.slice(0, p.lastIndexOf('/')) || '/' : null;

async function persist() {
  await saveState(state);
}

/* ---------------- 渲染 ---------------- */

function renderChip() {
  if (state.mode === 'single') {
    els.srcLabel.textContent = '选择一张图片';
    const has = !!state.imagePath;
    els.srcChip.classList.toggle('empty', !has);
    els.srcChip.querySelector('.chip-icon').textContent = '🖼️';
    els.srcChipText.textContent = has ? baseName(state.imagePath) : '未选择图片';
    els.srcChip.title = state.imagePath || '';
    els.modeHint.textContent = '展示选定的这一张图片';
  } else {
    els.srcLabel.textContent = '为幻灯片选择图像相册';
    const has = !!state.folderPath;
    els.srcChip.classList.toggle('empty', !has);
    els.srcChip.querySelector('.chip-icon').textContent = '📁';
    els.srcChipText.textContent = has ? baseName(state.folderPath) : '未选择文件夹';
    els.srcChip.title = state.folderPath || '';
    els.modeHint.textContent = '轮播相册文件夹里的图片';
  }
}

function currentImagePath() {
  if (state.mode === 'single') return state.imagePath;
  const it = images[viewIndex] || images[state.index];
  return it ? it.path : null;
}

function renderPreview() {
  const path = currentImagePath();
  const multi = state.mode === 'folder' && images.length > 1;
  els.btnPrev.disabled = !multi;
  els.btnNext.disabled = !multi;

  if (!path) {
    els.previewImg.hidden = true;
    els.previewImg.removeAttribute('src');
    els.previewEmpty.style.display = '';
    els.previewLabel.textContent = state.mode === 'folder'
      ? '相册里还没有图片'
      : '未选择图片';
    return;
  }
  els.previewEmpty.style.display = 'none';
  els.previewImg.hidden = false;
  if (els.previewImg.dataset.path !== path) {
    els.previewImg.dataset.path = path;
    els.previewImg.src = imgUrl(path);
  }
  const name = baseName(path);
  els.previewLabel.textContent = state.mode === 'folder' && images.length
    ? `${viewIndex + 1} / ${images.length} · ${name}`
    : name;
  els.previewImg.onerror = () => {
    els.previewImg.hidden = true;
    els.previewLabel.textContent = '图片加载失败（文件可能已被移动或删除）';
  };
}

function applyStateToControls() {
  els.autoRotate.value = state.autoRotate ? 'on' : 'off';
  els.order.value = state.order;
  els.interval.value = state.interval;
  for (const b of els.modeSeg.querySelectorAll('button')) {
    b.classList.toggle('active', b.dataset.mode === state.mode);
  }
  renderChip();
}

async function refreshAlbum() {
  if (state.mode !== 'folder' || !state.folderPath) { images = []; return; }
  try {
    const res = await fetch('/api/images?path=' + encodeURIComponent(state.folderPath), { cache: 'no-store' });
    const data = res.ok ? await res.json() : { images: [] };
    images = data.images || [];
  } catch {
    images = [];
  }
  if (viewIndex >= images.length) viewIndex = Math.min(state.index, images.length - 1);
  if (viewIndex < 0) viewIndex = 0;
}

function restartRotate() {
  if (rotateTimer) { clearInterval(rotateTimer); rotateTimer = null; }
  viewIndex = Math.min(state.index, Math.max(0, images.length - 1));
  if (!(state.mode === 'folder' && state.autoRotate && images.length > 1)) return;
  rotateTimer = setInterval(() => {
    viewIndex = stepIndex(viewIndex, images.length, state.order);
    renderPreview();
  }, state.interval * 1000);
}

/* ---------------- 事件 ---------------- */

els.modeSeg.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-mode]');
  if (!btn || btn.dataset.mode === state.mode) return;
  state.mode = btn.dataset.mode;
  state.index = 0;
  viewIndex = 0;
  applyStateToControls();
  refreshAlbum().then(() => { renderPreview(); restartRotate(); });
  persist();
});

els.autoRotate.addEventListener('change', () => {
  state.autoRotate = els.autoRotate.value === 'on';
  persist(); restartRotate();
});
els.order.addEventListener('change', () => {
  state.order = els.order.value;
  persist(); restartRotate();
});
els.interval.addEventListener('change', () => {
  const n = Math.round(Number(els.interval.value));
  const v = Math.min(86400, Math.max(1, Number.isFinite(n) ? n : 5));
  els.interval.value = v;
  state.interval = v;
  persist(); restartRotate();
});

els.btnPrev.addEventListener('click', () => {
  if (!images.length) return;
  viewIndex = (viewIndex - 1 + images.length) % images.length;
  state.index = viewIndex;
  renderPreview(); persist();
});
els.btnNext.addEventListener('click', () => {
  if (!images.length) return;
  viewIndex = stepIndex(viewIndex, images.length, 'sequential');
  state.index = viewIndex;
  renderPreview(); persist();
});

/* ---------------- 浏览对话框 ---------------- */

function crumbsRender(path) {
  els.crumbs.innerHTML = '';
  const segs = path.split('/').filter(Boolean);
  const mk = (label, target) => {
    const b = document.createElement('button');
    b.textContent = label;
    b.addEventListener('click', () => renderBrowse(target));
    els.crumbs.appendChild(b);
  };
  mk('根目录', '/');
  let acc = '';
  for (const s of segs) {
    acc += '/' + s;
    const sep = document.createElement('span');
    sep.className = 'sep';
    sep.textContent = '›';
    els.crumbs.appendChild(sep);
    mk(s, acc);
  }
  els.crumbs.scrollLeft = els.crumbs.scrollWidth;
}

function fileRow({ icon, thumb, name, meta, onClick, cls = '' }) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'file-item ' + cls;
  if (thumb) {
    const img = document.createElement('img');
    img.className = 'f-thumb';
    img.loading = 'lazy';
    img.src = thumb;
    b.appendChild(img);
  } else {
    const ic = document.createElement('span');
    ic.className = 'f-icon';
    ic.textContent = icon;
    b.appendChild(ic);
  }
  const nm = document.createElement('span');
  nm.className = 'f-name';
  nm.textContent = name;
  b.appendChild(nm);
  if (meta) {
    const mt = document.createElement('span');
    mt.className = 'f-meta';
    mt.textContent = meta;
    b.appendChild(mt);
  }
  b.addEventListener('click', onClick);
  return b;
}

async function renderBrowse(path) {
  browsePath = path;
  crumbsRender(path);
  els.fileList.innerHTML = '<div class="file-empty">加载中…</div>';
  let data;
  try {
    const res = await fetch('/api/browse?path=' + encodeURIComponent(path), { cache: 'no-store' });
    data = res.ok ? await res.json() : null;
  } catch {}
  if (!data) {
    els.fileList.innerHTML = '<div class="file-empty">目录不存在或无法读取</div>';
    return;
  }
  const dirs = data.entries.filter(e => e.isDirectory);
  const pics = data.entries.filter(e => e.isImage);

  els.fileList.innerHTML = '';
  if (data.parent !== null && data.parent !== undefined) {
    els.fileList.appendChild(fileRow({
      icon: '⬆️', name: '返回上一级', cls: 'up-item',
      onClick: () => renderBrowse(data.parent),
    }));
  }
  for (const d of dirs) {
    els.fileList.appendChild(fileRow({
      icon: '📁', name: d.name,
      onClick: () => renderBrowse((path === '/' ? '' : path) + '/' + d.name),
    }));
  }
  if (state.mode === 'single') {
    for (const f of pics) {
      els.fileList.appendChild(fileRow({
        thumb: imgUrl((path === '/' ? '' : path) + '/' + f.name),
        name: f.name,
        meta: f.size < 1024 ? '<1 KB' : (f.size / 1024).toFixed(0) + ' KB',
        onClick: () => {
          state.imagePath = (path === '/' ? '' : path) + '/' + f.name;
          state.index = 0; viewIndex = 0;
          persist();
          closeModal();
          renderChip(); renderPreview(); restartRotate();
        },
      }));
    }
  } else if (!pics.length && !dirs.length) {
    els.fileList.innerHTML = '<div class="file-empty">这个文件夹是空的</div>';
  }
  els.browseHint.textContent = `当前文件夹有 ${pics.length} 张图片`;
  els.btnPickHere.hidden = state.mode !== 'folder';
}

function openModal() {
  const start = state.mode === 'folder'
    ? (state.folderPath || (config && config.root) || '/')
    : (state.imagePath ? parentOf(state.imagePath) : (config && config.root) || '/');
  els.modal.hidden = false;
  renderBrowse(start);
}
function closeModal() { els.modal.hidden = true; }

els.btnBrowse.addEventListener('click', openModal);
els.btnCloseModal.addEventListener('click', closeModal);
els.modal.addEventListener('click', (e) => { if (e.target === els.modal) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !els.modal.hidden) closeModal(); });
els.btnPickHere.addEventListener('click', () => {
  state.folderPath = browsePath;
  state.index = 0; viewIndex = 0;
  persist();
  closeModal();
  renderChip();
  refreshAlbum().then(() => { renderPreview(); restartRotate(); });
});

/* ---------------- 跨页同步兜底 ---------------- */
onExternalChange(async () => {
  const fresh = await loadState();
  if (!fresh) return;
  state = { ...DEFAULTS, ...fresh };
  applyStateToControls();
  await refreshAlbum();
  renderPreview(); restartRotate();
});

/* ---------------- 启动 ---------------- */
(async function init() {
  const loaded = await loadState();
  state = { ...DEFAULTS, ...(loaded || {}) };
  try { config = await fetch('/api/config').then(r => r.json()); } catch {}
  applyStateToControls();
  await refreshAlbum();
  renderPreview();
  restartRotate();
})();
