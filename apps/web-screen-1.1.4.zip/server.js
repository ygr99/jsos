import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(join(__dirname, 'public')));

// 必应精选 JSON：服务端代理，规避浏览器跨源策略
app.get('/api/bing', async (req, res) => {
  try {
    const date = String(req.query.date || '').replace(/\D/g, '');
    const r = await fetch(`https://bing.ee123.net/img/?type=json${date ? `&date=${date}` : ''}`);
    res.set('Cache-Control', 'no-store').json(await r.json());
  } catch {
    res.status(502).json({});
  }
});

// 图片代理：仅允许必应图源，同源输出（应用 iframe 内 <img> 直连外域会被 COEP/SW 拦截）
app.get('/api/img', async (req, res) => {
  const url = String(req.query.url || '');
  if (!/^https:\/\/([a-z0-9.-]+\.bing\.com|bing\.ee123\.net)\//i.test(url)) {
    return res.status(400).end();
  }
  try {
    const r = await fetch(url);
    if (!r.ok) return res.status(502).end();
    const buf = Buffer.from(await r.arrayBuffer());
    res.set('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.set('Cache-Control', 'public, max-age=604800');
    res.send(buf);
  } catch {
    res.status(502).end();
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`web-screen running on ${port}`));
