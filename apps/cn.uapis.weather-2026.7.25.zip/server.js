import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, './dist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const LOCATIONS_PATH = path.join(DATA_DIR, 'locations.json');
const VERSION_PATH = path.join(DATA_DIR, 'version.txt');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.mjs': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function getVersion() {
  try {
    if (!fs.existsSync(VERSION_PATH)) {
      fs.writeFileSync(VERSION_PATH, '1', 'utf8');
      return 1;
    }
    return parseInt(fs.readFileSync(VERSION_PATH, 'utf8'), 10) || 1;
  } catch {
    return 1;
  }
}

function incrementVersion() {
  const v = getVersion() + 1;
  fs.writeFileSync(VERSION_PATH, String(v), 'utf8');
  return v;
}

function readLocations() {
  try {
    if (!fs.existsSync(LOCATIONS_PATH)) {
      return [];
    }
    return JSON.parse(fs.readFileSync(LOCATIONS_PATH, 'utf8'));
  } catch {
    return [];
  }
}

function writeLocations(locations) {
  fs.writeFileSync(LOCATIONS_PATH, JSON.stringify(locations, null, 2), 'utf8');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // 版本号接口 - 用于小组件监听变化
  if (pathname === '/api/version') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ version: getVersion() }));
  }

  // 语言接口 - 用于小组件获取当前语言
  if (pathname === '/api/lang') {
    const lang = process.env.LANG || 'zh-CN'
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ lang }));
  }

  if (pathname === '/api/locations') {
    try {
      let locations = readLocations();
      if (!locations.find(l => l.id === 'current')) {
        locations.unshift({ id: 'current', name: '当前位置', adcode: '', city: '', isCurrent: true });
        writeLocations(locations);
      }

      if (req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(locations));
      }
      if (req.method === 'POST') {
        const body = JSON.parse(await readBody(req));
        const location = {
          id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
          name: body.name || 'Unknown',
          adcode: body.adcode || '',
          city: body.city || '',
          isDefault: false,
        };
        locations.push(location);
        writeLocations(locations);
        incrementVersion();
        res.writeHead(201, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(location));
      }
      if (req.method === 'PUT') {
        const body = JSON.parse(await readBody(req));
        if (body.locations && Array.isArray(body.locations)) {
          locations = body.locations;
        } else if (body.id) {
          const idx = locations.findIndex(l => l.id === body.id);
          if (idx !== -1) {
            locations[idx] = { ...locations[idx], ...body };
          }
          // 如果设置了默认位置，更新其他位置的 isDefault
          if (body.isDefault) {
            locations = locations.map(l => ({
              ...l,
              isDefault: l.id === body.id ? true : false
            }));
          }
        }
        writeLocations(locations);
        incrementVersion();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(locations));
      }
      if (req.method === 'DELETE') {
        const body = JSON.parse(await readBody(req));
        const id = body.id;
        if (id && id !== 'current') {
          locations = locations.filter(l => l.id !== id);
          writeLocations(locations);
          incrementVersion();
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ success: true }));
      }
      res.writeHead(405);
      return res.end('Method Not Allowed');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  let decoded = decodeURIComponent(pathname);
  if (decoded.includes('\0')) {
    res.writeHead(400);
    return res.end('Bad Request');
  }
  let target = path.resolve(path.join(ROOT, decoded));
  if (!target.startsWith(ROOT + path.sep) && target !== ROOT) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  if (target.endsWith(path.sep) || (fs.existsSync(target) && fs.statSync(target).isDirectory())) {
    target = path.join(target, 'index.html');
  }
  fs.readFile(target, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      const ext = path.extname(target).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
