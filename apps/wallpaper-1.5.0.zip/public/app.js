/* ============================================================
   壁纸 · 前端
   - 必应壁纸：今日大图 + 历史网格（滚动加载，hover 出勾，点勾设为壁纸）
   - 动态壁纸：视频网格（hover 自动播放预览，点勾设为视频壁纸）
   - 设置壁纸走 window.JSOS.setWallpaper（应用到当前工作区，同「设置」应用）
   - 「每天自动更新」由服务端定时器驱动（经 JSOS 守护进程代调 setWallpaper）
   ============================================================ */
(() => {
  'use strict';

  const COLLAPSE_KEY = 'wallpaper.sidebar-collapsed';
  const PAGE_SIZE = 12;
  // 与「设置」应用的视频壁纸上限保持一致（超出平台存 IndexedDB 会吃力）
  const MAX_VIDEO_BYTES = 10 * 1024 * 1024;

  const CATS = [
    { id: 'solid', name: '纯色', icon: '<circle cx="12" cy="12" r="8.5"/>' },
    { id: 'official', name: '官方壁纸', icon: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><circle cx="8.5" cy="10" r="1.8"/><path d="m4.2 17.2 5-4.4 3.6 3.2 3-2.6 4 3.6"/>' },
    { id: 'bing', name: '必应壁纸', icon: '<path d="M7.4 3.6v16.8"/><circle cx="13.2" cy="14.6" r="5.6"/>' },
    { id: 'dynamic', name: '动态壁纸', icon: '<circle cx="12" cy="12" r="3.4"/><path d="M12 3v2.6M12 18.4V21M3 12h2.6M18.4 12H21M5.6 5.6l1.9 1.9M16.5 16.5l1.9 1.9M18.4 5.6l-1.9 1.9M7.5 16.5l-1.9 1.9"/>' },
    { id: 'wallhaven', name: 'Wallhaven', icon: '<path d="M3.2 7.2 6.4 17 12 5.4 17.6 17l3.2-9.8"/>' },
    { id: 'deepin', name: 'Deepin', icon: '<path d="m12 3.4 8.6 4.8L12 13 3.4 8.2 12 3.4Z"/><path d="m3.4 13.4 8.6 4.8 8.6-4.8"/>' },
    { id: 'custom', name: '自定义壁纸', icon: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M12 8.6v6.8M8.6 12h6.8"/>' },
    { id: 'fav', name: '我的收藏', icon: '<path d="M12 20.2s-7.2-4.5-7.2-9.6A4.2 4.2 0 0 1 12 7.5a4.2 4.2 0 0 1 7.2 3.1c0 5.1-7.2 9.6-7.2 9.6Z"/>' },
  ];

  const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4.5 4.5L19 7"/></svg>';

  // 纯色色板（自定义颜色那一排小圆点，顺序照设计稿）
  const SOLID_SWATCHES = ['#ffffff', '#3b82f6', '#06b6d4', '#6366f1', '#a855f7', '#14b8a6',
    '#22c55e', '#84cc16', '#f59e0b', '#ef4444', '#92400e', '#64748b'];
  // 渐变卡片（纯色栏下方的大卡）：双色线性渐变
  const GRADIENTS = [
    { id: 'g01', name: '紫粉', stops: ['#a18cd1', '#fbc2eb'] },
    { id: 'g02', name: '樱花粉', stops: ['#ff9a9e', '#fecfef'] },
    { id: 'g03', name: '晴空', stops: ['#a1c4fd', '#c2e9fb'] },
    { id: 'g04', name: '粉蓝', stops: ['#fbc2eb', '#a6c1ee'] },
    { id: 'g05', name: '蜜桃', stops: ['#fad0c4', '#ffd1ff'] },
    { id: 'g06', name: '青柠', stops: ['#d4fc79', '#96e6a1'] },
    { id: 'g07', name: '薄荷', stops: ['#a8edea', '#fed6e3'] },
    { id: 'g08', name: '翡翠', stops: ['#43e97b', '#38f9d7'] },
    { id: 'g09', name: '云灰', stops: ['#eef2f7', '#cfd9e6'] },
    { id: 'g10', name: '薰衣草', stops: ['#e0c3fc', '#8ec5fc'] },
    { id: 'g11', name: '品红', stops: ['#f093fb', '#f5576c'] },
    { id: 'g12', name: '落日', stops: ['#fa709a', '#fee140'] },
    { id: 'g13', name: '深海', stops: ['#30cfd0', '#330867'] },
    { id: 'g14', name: '海盐', stops: ['#4facfe', '#00f2fe'] },
    { id: 'g15', name: '森林', stops: ['#134e5e', '#71b280'] },
    { id: 'g16', name: '晨雾', stops: ['#f5f7fa', '#c3cfe2'] },
  ];

  const $ = id => document.getElementById(id);
  // 个别无头环境没有 rAF，退化到 setTimeout
  const raf = typeof window.requestAnimationFrame === 'function'
    ? window.requestAnimationFrame.bind(window)
    : cb => setTimeout(cb, 0);
  const el = {
    shell: $('shell'),
    nav: $('cat-nav'),
    bingView: $('bing-view'),
    solidView: $('solid-view'),
    solidDots: $('solid-dots'),
    solidRecent: $('solid-recent'),
    solidRecentRow: $('solid-recent-row'),
    solidPicker: $('solid-picker'),
    solidGrid: $('solid-grid'),
    solidMore: $('solid-more'),
    videoView: $('video-view'),
    videoGrid: $('video-grid'),
    videoMore: $('video-more'),
    officialView: $('official-view'),
    officialGrid: $('official-grid'),
    officialMore: $('official-more'),
    coming: $('coming'),
    comingEmoji: $('coming-emoji'),
    comingTitle: $('coming-title'),
    today: $('today'),
    todayCard: $('today-card'),
    todayImg: $('today-img'),
    todayTitle: $('today-title'),
    todayPick: $('today-pick'),
    autoChk: $('auto-chk'),
    autoHint: $('auto-hint'),
    dl4k: $('dl-4k'),
    grid: $('grid'),
    more: $('more'),
    toast: $('toast'),
  };

  let catId = 'bing';
  let state = { autoDaily: false, autoAppliedDate: null, lastSetKey: null, today: null };
  let videos = [];
  let officialItems = [];
  let todayDate = null;
  let nextFrom = null;
  let exhausted = false;
  let loading = false;
  let fillRounds = 0;
  let workspaceId = null;

  /* ------------------------------------------------------------ 小工具 */

  async function api(path, options) {
    const r = await fetch(path, options);
    if (!r.ok) {
      let msg = `HTTP ${r.status}`;
      try { const j = await r.json(); if (j && j.error) msg = j.error; } catch {}
      throw new Error(msg);
    }
    return r.json();
  }

  const postJSON = (path, body) => api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });

  let toastTimer = null;
  function toast(text) {
    el.toast.textContent = text;
    el.toast.hidden = false;
    raf(() => el.toast.classList.add('show'));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      el.toast.classList.remove('show');
      setTimeout(() => { el.toast.hidden = true; }, 220);
    }, 2600);
  }

  const fmtCN = dash => {
    const [y, m, d] = String(dash).split('-');
    return `${y}年${Number(m)}月${Number(d)}日`;
  };

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = () => reject(new Error('文件读取失败'));
      fr.readAsDataURL(blob);
    });
  }

  async function resolveWorkspaceId() {
    if (workspaceId) return workspaceId;
    const jsos = window.JSOS;
    if (!jsos || !jsos.getCurrentWorkspace) return null;
    try {
      const ws = await jsos.getCurrentWorkspace();
      workspaceId = ws && ws.id ? ws.id : null;
    } catch { workspaceId = null; }
    return workspaceId;
  }

  const pickButton = (label, title) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pick';
    btn.title = title;
    btn.setAttribute('aria-label', label);
    btn.innerHTML = CHECK_SVG;
    return btn;
  };

  /* ------------------------------------------------------------ 侧边栏 */

  function renderNav() {
    el.nav.innerHTML = CATS.map(c => `
      <button type="button" class="nav-item${c.id === catId ? ' active' : ''}" data-cat="${c.id}" title="${c.name}">
        <span class="nav-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"
          stroke-linecap="round" stroke-linejoin="round">${c.icon}</svg></span>
        <span class="nav-name">${c.name}</span>
      </button>`).join('');
    el.nav.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => selectCat(btn.dataset.cat));
    });
  }

  function selectCat(id) {
    if (catId === id) return;
    catId = id;
    renderNav();
    el.bingView.hidden = id !== 'bing';
    el.solidView.hidden = id !== 'solid';
    el.videoView.hidden = id !== 'dynamic';
    el.officialView.hidden = id !== 'official';
    const impl = id === 'bing' || id === 'solid' || id === 'dynamic' || id === 'official';
    el.coming.hidden = impl;
    if (!impl) {
      const cat = CATS.find(c => c.id === id);
      el.comingTitle.textContent = cat ? cat.name : '';
    }
  }

  function setCollapsed(collapsed) {
    el.shell.classList.toggle('collapsed', collapsed);
    $('ic-collapse').toggleAttribute('hidden', collapsed);
    $('ic-expand').toggleAttribute('hidden', !collapsed);
    $('collapse-btn').setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch {}
  }

  /* --------------------------------------------------------- 今日壁纸 */

  async function loadToday() {
    try {
      const meta = await api('/api/bing');
      todayDate = meta.date;
      el.todayCard.dataset.date = meta.date;
      el.todayCard.dataset.key = `bing:${meta.date}`;
      el.todayImg.src = `/api/img?date=${meta.date}&size=640x480`;
      el.todayImg.addEventListener('load', () => el.todayImg.classList.add('loaded'), { once: true });
      if (el.todayImg.complete && el.todayImg.naturalWidth) el.todayImg.classList.add('loaded');
      el.todayTitle.textContent = meta.copyright ? `${meta.title}  (${meta.copyright})` : meta.title;
      el.dl4k.href = meta.uhdUrl;
      el.today.hidden = false;
    } catch (e) {
      el.today.hidden = true;
      toast('今日必应壁纸加载失败：' + e.message);
    }
  }

  function updateAutoHint() {
    const lines = [];
    if (state.autoDaily) lines.push('已开启自动更新 · 每天 0:10 后自动换上当天壁纸');
    if (state.autoAppliedDate && todayDate && state.autoAppliedDate === todayDate) {
      lines.push(`今天的壁纸已自动应用 · ${fmtCN(state.autoAppliedDate)}`);
    }
    el.autoHint.innerHTML = lines.length ? lines.map(t => `<div>${t}</div>`).join('') : '';
    el.autoHint.hidden = lines.length === 0;
  }

  /* --------------------------------------------------- 设为壁纸（核心） */

  // state.lastSetKey 形如 'bing:2026-09-10' / 'video:84' / 'solid:#1e293b'，用它高亮当前壁纸的勾
  function markActive(key) {
    document.querySelectorAll('.card').forEach(c =>
      c.classList.toggle('active', !!key && c.dataset.key === key));
    renderSolidDots();   // 纯色小圆点的选中圈也跟着刷新
  }

  async function applyMedia(kind, id, cardEl) {
    const jsos = window.JSOS;
    if (!jsos || typeof jsos.setWallpaper !== 'function') {
      toast('当前环境不支持设置壁纸，请在 JSOS 里打开本应用');
      return;
    }
    if (cardEl) cardEl.classList.add('busy');
    try {
      let src, mimeType, type, label;
      if (kind === 'video') {
        const v = videos.find(x => x.id === id);
        if (!v) throw new Error('找不到这个视频');
        src = v.src; mimeType = v.mimeType; type = 'video'; label = v.name;
      } else if (kind === 'official') {
        const it = officialItems.find(x => x.id === id);
        if (!it) throw new Error('找不到这张官方壁纸');
        src = it.src; mimeType = it.mimeType; type = 'image'; label = it.name;
      } else {
        src = `/api/img?date=${id}&size=1920x1080`; mimeType = 'image/jpeg'; type = 'image'; label = fmtCN(id);
      }
      const res = await fetch(src);
      if (!res.ok) throw new Error(`文件下载失败 HTTP ${res.status}`);
      const blob = await res.blob();
      if (type === 'video' && blob.size > MAX_VIDEO_BYTES) {
        throw new Error(`视频 ${(blob.size / 1024 / 1024).toFixed(1)}MB，超过 10MB 上限`);
      }
      const dataUrl = await blobToDataUrl(blob);
      const wsId = await resolveWorkspaceId();
      await jsos.setWallpaper({
        type,
        data: dataUrl,
        mimeType,
        overlay: null,
        overlayOpacity: 0,
        blur: 0,
        workspaceId: wsId || undefined,
      });
      const key = `${kind}:${id}`;
      try {
        const r = await postJSON('/api/state', {
          lastSetKind: kind, lastSetKey: key, lastSetWorkspaceId: wsId, lastSetAt: Date.now(),
        });
        state = r.state;
      } catch {}
      markActive(key);
      if (jsos.toast) {
        jsos.toast({
          title: '壁纸已设置',
          description: type === 'video' ? `动态壁纸 · ${label}` : `${label} 的必应壁纸`,
          type: 'success',
        });
      }
      toast(type === 'video' ? `已设为动态壁纸 · ${label}` : `已设为壁纸 · ${label}`);
    } catch (e) {
      toast('设置壁纸失败：' + e.message);
    } finally {
      if (cardEl) cardEl.classList.remove('busy');
    }
  }

  /* ------------------------------------------------------- 必应历史网格 */

  function makeImageCard({ key, src, alt, title, lazy }) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.key = key;
    const img = document.createElement('img');
    img.alt = alt || '';
    img.title = title;
    if (lazy) { img.loading = 'lazy'; img.decoding = 'async'; }
    img.addEventListener('load', () => img.classList.add('loaded'), { once: true });
    img.src = src;
    card.append(img, pickButton(`设为壁纸 ${alt || ''}`, title));
    return card;
  }

  function makeBingCard(day) {
    const card = makeImageCard({
      key: `bing:${day.date}`,
      src: day.thumb,
      alt: day.date,
      title: `设为壁纸 · ${fmtCN(day.date)}`,
      lazy: true,
    });
    card.dataset.date = day.date;
    return card;
  }

  async function loadMore() {
    if (loading || exhausted) return;
    loading = true;
    try {
      const qs = nextFrom ? `?from=${nextFrom}&n=${PAGE_SIZE}` : `?n=${PAGE_SIZE}`;
      const data = await api('/api/days' + qs);
      nextFrom = data.nextFrom;
      exhausted = !!data.exhausted;
      const frag = document.createDocumentFragment();
      for (const day of data.days) frag.appendChild(makeBingCard(day));
      el.grid.appendChild(frag);
      markActive(state.lastSetKey);
      el.more.textContent = exhausted ? '已经翻到必应图库最早的一张了' : '滚动加载更早日期的壁纸…';
    } catch (e) {
      el.more.textContent = '加载失败：' + e.message;
    } finally {
      loading = false;
    }
    // 一屏没铺满就再补一轮。必须先确认容器真的可测量：无头环境（jsdom）不做布局，
    // clientHeight 恒为 0，不加这个判断会一路递归把 2010 年以来的图全拉下来。
    // 另外用 fillRounds 封顶，避免极端尺寸下滚雪球。
    const vh = el.bingView.clientHeight;
    if (vh > 0 && el.bingView.scrollHeight <= vh + 60 && fillRounds < 4) {
      fillRounds++;
      await loadMore();
    } else if (vh > 0 && el.bingView.scrollHeight > vh + 60) {
      fillRounds = 0;
    }
  }

  /* --------------------------------------------- 纯色 / 渐变（矢量，无素材文件） */

  // 颜色/渐变不需要任何图片文件：直接拼一个全屏 SVG（width/height=100% → 视口=屏幕，任何分辨率精准）
  function svgDataUrl(svg) {
    // encodeURIComponent 兜住非 ASCII，btoa 只见 ASCII
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
  }
  const solidSvg = c =>
    `<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">`
    + `<rect width="100%" height="100%" fill="${c}"/></svg>`;
  const gradientSvg = stops => {
    const n = stops.length;
    const st = stops.map((c, i) => `<stop offset="${(i / (n - 1)).toFixed(4)}" stop-color="${c}"/>`).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%"><defs>`
      + `<linearGradient id="g" x1="0" y1="0" x2="1" y2="1">${st}</linearGradient></defs>`
      + `<rect width="100%" height="100%" fill="url(#g)"/></svg>`;
  };

  async function applySvgWallpaper(key, label, dataUrl) {
    const jsos = window.JSOS;
    if (!jsos || typeof jsos.setWallpaper !== 'function') {
      toast('当前环境不支持设置壁纸，请在 JSOS 里打开本应用');
      return;
    }
    try {
      const wsId = await resolveWorkspaceId();
      await jsos.setWallpaper({
        type: 'image',
        data: dataUrl,
        mimeType: 'image/svg+xml',
        overlay: null,
        overlayOpacity: 0,
        blur: 0,
        workspaceId: wsId || undefined,
      });
      try {
        const r = await postJSON('/api/state', {
          lastSetKind: 'solid', lastSetKey: key, lastSetWorkspaceId: wsId, lastSetAt: Date.now(),
        });
        state = r.state;
      } catch {}
      markActive(key);
      if (jsos.toast) jsos.toast({ title: '壁纸已设置', description: `纯色 · ${label}`, type: 'success' });
      toast(`已设为纯色壁纸 · ${label}`);
    } catch (e) {
      toast('设置壁纸失败：' + e.message);
    }
  }

  function pushRecent(color) {
    const list = (Array.isArray(state.recentColors) ? state.recentColors : []).filter(c => c !== color);
    list.unshift(color);
    state = { ...state, recentColors: list.slice(0, 12) };
    postJSON('/api/state', { recentColors: state.recentColors })
      .then(r => { state = r.state; renderSolidDots(); })
      .catch(() => {});
  }

  function colorDot(color) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'color-dot' + (state.lastSetKey === `solid:${color}` ? ' active' : '');
    b.style.setProperty('--c', color);
    b.title = color;
    b.setAttribute('aria-label', `纯色 ${color}`);
    b.addEventListener('click', () => {
      applySvgWallpaper(`solid:${color}`, color, svgDataUrl(solidSvg(color)));
      pushRecent(color);
    });
    return b;
  }

  function renderSolidDots() {
    if (!el.solidDots) return;
    el.solidDots.innerHTML = '';
    for (const c of SOLID_SWATCHES) el.solidDots.appendChild(colorDot(c));
    const rec = Array.isArray(state.recentColors) ? state.recentColors : [];
    el.solidRecentRow.hidden = rec.length === 0;
    el.solidRecent.innerHTML = '';
    for (const c of rec) el.solidRecent.appendChild(colorDot(c));
  }

  function makeGradCard(g) {
    const card = document.createElement('div');
    card.className = 'card grad';
    card.dataset.key = `solid:${g.id}`;
    card.dataset.gradId = g.id;
    card.title = `${g.name}（${g.stops.join(' → ')}）`;
    card.style.background = `linear-gradient(135deg, ${g.stops[0]}, ${g.stops[1]})`;
    card.append(pickButton(`设为纯色壁纸 ${g.name}`, `设为壁纸 · ${g.name}`));
    return card;
  }

  function buildSolid() {
    renderSolidDots();
    el.solidGrid.innerHTML = '';
    for (const g of GRADIENTS) el.solidGrid.appendChild(makeGradCard(g));
    el.solidMore.textContent = `共 ${GRADIENTS.length} 个渐变 · 纯色用上面的色板，也可以自定任意颜色`;
    el.solidPicker.addEventListener('change', () => {
      const c = el.solidPicker.value;
      applySvgWallpaper(`solid:${c}`, c, svgDataUrl(solidSvg(c)));
      pushRecent(c);
    });
    el.solidGrid.addEventListener('click', e => {
      const btn = e.target.closest('.pick');
      if (!btn) return;
      const card = btn.closest('.card');
      if (!card || card.classList.contains('busy')) return;
      const g = GRADIENTS.find(x => x.id === card.dataset.gradId);
      if (g) applySvgWallpaper(`solid:${g.id}`, g.name, svgDataUrl(gradientSvg(g.stops)));
    });
  }

  /* ------------------------------------------------------- 动态（视频）壁纸 */

  function makeVideoCard(v) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.videoId = v.id;
    card.dataset.key = `video:${v.id}`;
    card.title = v.name;
    const vid = document.createElement('video');
    vid.src = v.src;
    vid.muted = true;
    vid.loop = true;
    vid.playsInline = true;
    vid.setAttribute('playsinline', '');
    vid.setAttribute('muted', '');
    vid.preload = 'none';
    if (v.poster) vid.poster = v.poster;
    card.append(vid, pickButton(`设为动态壁纸 ${v.name}`, `设为动态壁纸 · ${v.name}`));
    // 鼠标移上去播一小段预览，移开复位（视频卡片的"动态"感就靠这个）
    card.addEventListener('mouseenter', () => { vid.play().catch(() => {}); });
    card.addEventListener('mouseleave', () => {
      vid.pause();
      try { vid.currentTime = 0; } catch {}
    });
    return card;
  }

  async function loadVideos() {
    try {
      const data = await api('/api/videos');
      videos = data.videos || [];
    } catch (e) {
      videos = [];
      el.videoMore.textContent = '视频列表加载失败：' + e.message;
      return;
    }
    el.videoGrid.innerHTML = '';
    for (const v of videos) el.videoGrid.appendChild(makeVideoCard(v));
    el.videoMore.textContent = videos.length
      ? `共 ${videos.length} 个视频壁纸`
      : '还没有视频壁纸：把 mp4 放进应用的 public/videos/ 目录就会出现在这里';
    markActive(state.lastSetKey);
  }

  /* ------------------------------------------------------------- 官方壁纸 */

  function makeOfficialCard(it) {
    const card = makeImageCard({
      key: `official:${it.id}`,
      src: it.thumb || it.src,
      alt: it.name,
      title: `设为壁纸 · ${it.name}`,
      lazy: false,
    });
    card.dataset.itemId = it.id;
    return card;
  }

  async function loadOfficial() {
    try {
      const data = await api('/api/official');
      officialItems = data.items || [];
    } catch (e) {
      officialItems = [];
      el.officialMore.textContent = '官方壁纸加载失败：' + e.message;
      return;
    }
    el.officialGrid.innerHTML = '';
    for (const it of officialItems) el.officialGrid.appendChild(makeOfficialCard(it));
    el.officialMore.textContent = officialItems.length
      ? `共 ${officialItems.length} 张官方壁纸`
      : '还没有官方壁纸：把图片放进应用的 public/official/ 目录就会出现在这里';
    markActive(state.lastSetKey);
  }

  /* ------------------------------------------------------------- 事件 */

  function handlePickClick(e, kind) {
    const btn = e.target.closest('.pick');
    if (!btn) return;
    const card = btn.closest('.card');
    if (!card || card.classList.contains('busy')) return;
    const id = kind === 'video' ? card.dataset.videoId
      : kind === 'official' ? card.dataset.itemId
      : card.dataset.date;
    if (id) applyMedia(kind, id, card);
  }

  el.grid.addEventListener('click', e => handlePickClick(e, 'bing'));
  el.videoGrid.addEventListener('click', e => handlePickClick(e, 'video'));
  el.officialGrid.addEventListener('click', e => handlePickClick(e, 'official'));

  el.todayPick.addEventListener('click', () => {
    if (!el.todayCard.dataset.date) return;
    applyMedia('bing', el.todayCard.dataset.date, el.todayCard);
  });

  el.autoChk.addEventListener('change', async () => {
    const on = el.autoChk.checked;
    el.autoChk.disabled = true;
    try {
      const wsId = await resolveWorkspaceId();
      const r = await postJSON('/api/state', {
        autoDaily: on,
        autoWorkspaceId: on ? wsId : state.autoWorkspaceId,
        autoAppliedDate: on ? null : state.autoAppliedDate,
      });
      state = r.state;
      if (on) {
        const run = await postJSON('/api/auto/run');
        state = run.state;
        if (run.applied) {
          markActive(run.state.lastSetKey);
          toast(`已开启 · 并已应用今天的壁纸（${fmtCN(run.date)}）`);
        } else if (run.error) {
          toast('已开启，但立刻应用失败：' + run.error);
        } else if (run.upToDate) {
          toast('已开启 · 今天的壁纸已经是必应今日图了');
        } else {
          toast('已开启每天自动更新壁纸');
        }
      } else {
        toast('已关闭每天自动更新（当前壁纸保持不变）');
      }
      updateAutoHint();
    } catch (e) {
      el.autoChk.checked = !on;
      toast('操作失败：' + e.message);
    } finally {
      el.autoChk.disabled = false;
    }
  });

  el.bingView.addEventListener('scroll', () => {
    if (exhausted) return;
    const { scrollTop, scrollHeight, clientHeight } = el.bingView;
    if (scrollHeight - scrollTop - clientHeight < 320) loadMore();
  });

  $('collapse-btn').addEventListener('click', () =>
    setCollapsed(!el.shell.classList.contains('collapsed'))
  );

  /* ------------------------------------------------------------- 启动 */

  async function init() {
    let saved = '0';
    try { saved = localStorage.getItem(COLLAPSE_KEY) || '0'; } catch {}
    setCollapsed(saved === '1');

    renderNav();
    el.coming.hidden = true;

    try {
      state = await api('/api/state');
      el.autoChk.checked = !!state.autoDaily;
      updateAutoHint();
    } catch {}

    await Promise.all([loadToday(), loadVideos(), loadOfficial()]);
    await loadMore();
    buildSolid();
    markActive(state.lastSetKey);

    // 打开应用时兜一次自动更新（服务端定时器负责其余时间）
    if (state.autoDaily) {
      try {
        const run = await postJSON('/api/auto/run');
        state = run.state;
        if (run.applied) markActive(run.state.lastSetKey);
        updateAutoHint();
      } catch {}
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
