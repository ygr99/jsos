import express from 'express';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

// [存储规范 §7.9] 数据存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/<appId>，
// 卸载勾选「同时删除应用数据」时由平台整目录清除）；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const TASKS_FILE = join(DATA_DIR, 'tasks.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

// 中国时区（UTC+8）当日 YYYY-MM-DD（cnNow 的 UTC 字段 = 北京墙上时间）
function cnToday() {
  const n = cnNow();
  const p = (x) => String(x).padStart(2, '0');
  return `${n.getUTCFullYear()}-${p(n.getUTCMonth() + 1)}-${p(n.getUTCDate())}`;
}

function cnNow() {
  return new Date(Date.now() + 8 * 60 * 60 * 1000);
}

function cnISOString() {
  return cnNow().toISOString().replace('Z', '+08:00');
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// 旧数据兼容（v1.x 无 date、有 category）：计划日期 = 创建日期（北京时区，取 ISO 串前 10 位），
// category 字段废弃直接剥离——分类模型已由「计划日期 + 逾期滚入今天」取代
function normalizeTask(t) {
  if (!DATE_RE.test(t.date || '')) {
    const src = DATE_RE.test(t.date || '') ? t.date : String(t.createdAt || cnISOString());
    t.date = src.slice(0, 10);
  }
  delete t.category;
  return t;
}

function readTasks() {
  try {
    if (!fs.existsSync(TASKS_FILE)) return [];
    const raw = fs.readFileSync(TASKS_FILE, 'utf8');
    if (!raw.trim()) return [];
    const data = JSON.parse(raw);
    const list = Array.isArray(data) ? data : (data.tasks || []);
    return list.map(normalizeTask);
  } catch {
    return [];
  }
}

function writeTasks(tasks) {
  const tmp = TASKS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify({ tasks }, null, 2));
  fs.renameSync(tmp, TASKS_FILE);
}

app.get('/api/tasks', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(readTasks());
});

app.post('/api/tasks', (req, res) => {
  const { title, detail, process, date, status } = req.body || {};
  if (!title || !String(title).trim()) {
    return res.status(400).json({ error: '事项标题不能为空' });
  }
  const tasks = readTasks();
  const task = {
    id: crypto.randomUUID(),
    title: String(title).trim(),
    detail: detail ? String(detail).trim() : '',
    process: process ? String(process).trim() : '',
    status: status || '待办',
    date: DATE_RE.test(date || '') ? date : cnToday(),
    createdAt: cnISOString(),
    completedAt: null,
  };
  tasks.push(task);
  writeTasks(tasks);
  res.status(201).json(task);
});

app.put('/api/tasks/:id', (req, res) => {
  const tasks = readTasks();
  const task = tasks.find((t) => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: '事项不存在' });

  const { title, detail, process, date, status } = req.body || {};
  if (title !== undefined) task.title = String(title).trim();
  if (detail !== undefined) task.detail = detail ? String(detail).trim() : '';
  if (process !== undefined) task.process = process ? String(process).trim() : '';
  if (date !== undefined && DATE_RE.test(date)) task.date = date;
  if (status !== undefined) {
    task.status = status;
    if (status === '已完成' && !task.completedAt) task.completedAt = cnISOString();
    else if (status !== '已完成') task.completedAt = null;
  }
  writeTasks(tasks);
  res.json(task);
});

app.delete('/api/tasks/:id', (req, res) => {
  const tasks = readTasks();
  const idx = tasks.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: '事项不存在' });
  tasks.splice(idx, 1);
  writeTasks(tasks);
  res.json({ ok: true });
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`todo running on ${port}`));
