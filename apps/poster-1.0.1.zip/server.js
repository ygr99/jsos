import express from 'express';
import fs from 'fs';
import { createReadStream } from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname as up, join, extname } from 'path';

const __dirname = up(fileURLToPath(import.meta.url));

// [存储规范 §7.9 模式 A] 设置存平台注入的 DATA_DIR（JSOS 容器内 = workspace/data/poster），
// 主页面与小组件同源共读；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

// 浏览默认根 = 容器内 workspace 根（DATA_DIR 上两级），本机直跑 = 应用目录
const BROWSE_ROOT = process.env.DATA_DIR ? up(up(DATA_DIR)) : __dirname;

const IMAGE_EXTS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg', '.avif', '.ico']);
const MIME = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.bmp': 'image/bmp', '.svg': 'image/svg+xml',
  '.avif': 'image/avif', '.ico': 'image/x-icon',
};

const app = express();
app.use(express.json({ limit: '256kb' }));
app.use(express.static(join(__dirname, 'public')));

// ---------- 设置（模式 A：单文档 + 原子写） ----------
const DEFAULT_STATE = {
  mode: 'single',        // single=单张图片 | folder=文件夹轮播
  imagePath: null,       // mode=single 时的图片绝对路径
  folderPath: null,      // mode=folder 时的相册文件夹绝对路径
  autoRotate: false,     // 自动轮播
  order: 'sequential',   // sequential=顺序播放 | random=随机播放
  interval: 5,           // 轮播间隔（秒）
  index: 0,              // 当前显示第几张（应用里翻页会更新，小组件以此为起点）
};

app.get('/api/state', (req, res) => {
  try {
    if (!fs.existsSync(STATE_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  const b = req.body || {};
  const state = {
    mode: b.mode === 'folder' ? 'folder' : 'single',
    imagePath: typeof b.imagePath === 'string' && b.imagePath ? b.imagePath : null,
    folderPath: typeof b.folderPath === 'string' && b.folderPath ? b.folderPath : null,
    autoRotate: !!b.autoRotate,
    order: b.order === 'random' ? 'random' : 'sequential',
    interval: Math.min(86400, Math.max(1, Math.round(Number(b.interval) || 5))),
    index: Math.max(0, Math.round(Number(b.index) || 0)),
  };
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
    fs.renameSync(tmp, STATE_FILE);
    res.json({ ok: true, state });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---------- 文件浏览（与「文件」应用同一容器文件系统） ----------
function entryInfo(dir, name) {
  try {
    const st = fs.statSync(join(dir, name));
    const ext = extname(name).toLowerCase();
    return { name, isDirectory: st.isDirectory(), isImage: !st.isDirectory() && IMAGE_EXTS.has(ext), size: st.size, mtime: st.mtimeMs };
  } catch {
    return null;
  }
}

app.get('/api/config', (req, res) => {
  res.json({ root: BROWSE_ROOT, dataDir: DATA_DIR });
});

// 列目录：目录 + 图片文件（选择单张图片和选择文件夹共用）
app.get('/api/browse', (req, res) => {
  const dirPath = req.query.path || BROWSE_ROOT;
  try {
    if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
      return res.status(404).json({ error: '目录不存在' });
    }
    const entries = fs.readdirSync(dirPath)
      .map(name => entryInfo(dirPath, name))
      .filter(e => e && (e.isDirectory || e.isImage))
      .sort((a, b) => (b.isDirectory - a.isDirectory) || a.name.localeCompare(b.name, 'zh-CN', { numeric: true }));
    res.json({ path: dirPath, parent: dirPath === '/' ? null : up(dirPath), entries });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 列出文件夹里的图片（相册；不递归，就是「那个文件夹里面的图片」）
app.get('/api/images', (req, res) => {
  const dirPath = req.query.path;
  if (!dirPath) return res.status(400).json({ error: '缺少 path' });
  try {
    if (!fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
      return res.status(404).json({ error: '目录不存在' });
    }
    const images = fs.readdirSync(dirPath)
      .map(name => entryInfo(dirPath, name))
      .filter(e => e && !e.isDirectory && e.isImage)
      .sort((a, b) => a.name.localeCompare(b.name, 'zh-CN', { numeric: true }))
      .map(e => ({ name: e.name, path: join(dirPath, e.name), size: e.size, mtime: e.mtime }));
    res.json({ path: dirPath, images });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 图片字节（同源直出，绕开 COEP；ETag 按 mtime+size，改图自动失效）
app.get('/api/image', (req, res) => {
  const filePath = req.query.path;
  if (!filePath) return res.status(400).json({ error: '缺少 path' });
  const ext = extname(filePath).toLowerCase();
  if (!IMAGE_EXTS.has(ext)) return res.status(400).json({ error: '不是图片文件' });
  try {
    const st = fs.statSync(filePath);
    if (!st.isFile()) return res.status(400).json({ error: '不是文件' });
    const etag = `"${crypto.createHash('md5').update(`${filePath}:${st.mtimeMs}:${st.size}`).digest('hex')}"`;
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) return res.status(304).end();
    res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
    res.setHeader('Content-Length', st.size);
    createReadStream(filePath).pipe(res);
  } catch (e) {
    res.status(404).json({ error: '图片不存在' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`poster running on ${PORT} (root=${BROWSE_ROOT})`));
