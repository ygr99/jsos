import express from 'express';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3000;

// [存储规范 §7.9 模式 A] 数据存平台注入的 DATA_DIR（容器内 = workspace/data/wallpaper，
// 用户卸载勾选「同时删除应用数据」时由平台整目录清除）；本机直跑回退 ./data
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

// 必应每日一图数据源（第三方聚合，实测返回 Access-Control-Allow-Origin: * → 容器内可直连）
const BING = 'https://bing.ee123.net/img/';
// JSOS 守护进程（容器内常驻），可代任何 Node 进程调用主窗口的 JSOS API（setWallpaper 等）
const DAEMON_PORT = process.env.DAEMON_PORT || 1993;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36';

// 允许的分辨率白名单（文档列出的取值；任意拼接会浪费带宽，这里收敛一下）
const SIZES = new Set(['UHD', '1920x1200', '1920x1080', '1366x768', '1280x768', '1024x768',
  '800x600', '800x480', '640x480', '480x800', '400x240', '320x240', '240x320']);
const THUMB_SIZE = '640x480';
const WALLPAPER_SIZE = '1920x1080';

app.use(express.json({ limit: '4mb' }));
app.use(express.static(join(__dirname, 'public')));

/* ------------------------------------------------------------------ 出站 */

// AGENTS §7.5：直连优先，仅在直连失败且配置了 PROXY_URL 时兜底走 JSOS CORS 代理
// 代理走 Vercel 安全形态（encoded 路径 + key 走 query，避免 308 + preflight）
function proxyUrl(target) {
  const base = (process.env.PROXY_URL || '').replace(/\/+$/, '');
  if (!base) return null;
  const key = process.env.PROXY_KEY || '';
  return `${base}/${encodeURIComponent(target)}?x-cors-proxy-key=${encodeURIComponent(key)}`;
}

async function outbound(target) {
  try {
    return await fetch(target, { headers: { 'User-Agent': UA } });
  } catch (err) {
    const via = proxyUrl(target);
    if (!via) throw err;
    return await fetch(via, { headers: { 'User-Agent': UA } });
  }
}

/* ------------------------------------------------------------- 日期（东八区） */
// 必应每日一图按北京时间 0:10 更新；时间戳一律走 Intl 指定时区，不能截 ISO 字符串
const fmtCST = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
});
const todayCST = () => fmtCST.format(new Date());            // 2026-09-11
const compact = d => d.replace(/-/g, '');                     // 20260911
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
// 必应每日一图最早从 2010-01-01 开始
const FIRST_DAY = '2010-01-01';

function shiftDate(dash, days) {
  const [y, m, d] = dash.split('-').map(Number);
  const t = Date.UTC(y, m - 1, d) + days * 86400000;
  return new Date(t).toISOString().slice(0, 10);
}

/* ----------------------------------------------------------- 图片内存缓存 */
// 只缓存在内存里（不落盘）：DATA_DIR 会被平台快照进主站 IndexedDB，塞图片会撑爆快照
const imgCache = new Map();
const IMG_CACHE_MAX = 80;
function cacheGet(key) {
  if (!imgCache.has(key)) return null;
  const v = imgCache.get(key);
  imgCache.delete(key);          // LRU：命中后挪到队尾
  imgCache.set(key, v);
  return v;
}
function cachePut(key, buf) {
  imgCache.set(key, buf);
  while (imgCache.size > IMG_CACHE_MAX) imgCache.delete(imgCache.keys().next().value);
}

async function fetchImage(date, size) {
  const key = `${date}|${size}`;
  const hit = cacheGet(key);
  if (hit) return hit;
  const r = await outbound(`${BING}?date=${compact(date)}&size=${size}`);
  if (!r.ok) throw new Error(`数据源返回 ${r.status}`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length < 512) throw new Error('数据源返回内容异常');
  cachePut(key, buf);
  return buf;
}

async function fetchMeta(date, size) {
  const r = await outbound(`${BING}?date=${compact(date)}&size=${size}&type=json`);
  if (!r.ok) throw new Error(`数据源返回 ${r.status}`);
  const j = await r.json();
  if (j.status !== '200' || !j.imgurl) throw new Error('该日期没有壁纸数据');
  return {
    date: (j.date || '').replace(/\//g, '-') || date,
    title: (j.imgtitle || '').trim(),
    copyright: (j.imgcopyright || '').trim(),
    show: (j.imgshow || '').trim(),
    detail: (j.imgdetail || '').trim(),
    // 4K 高清下载直链（文档：/img/4k）
    uhdUrl: `${BING}4k?date=${compact(date)}`,
  };
}

/* ------------------------------------------------------------------ 接口 */

// 某个日期的必应壁纸元信息
app.get('/api/bing', async (req, res) => {
  const date = DATE_RE.test(req.query.date || '') ? req.query.date : todayCST();
  const size = SIZES.has(req.query.size) ? req.query.size : THUMB_SIZE;
  try {
    const meta = await fetchMeta(date, size);
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.json(meta);
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

// 图片字节同源代理（应用 iframe 受 COEP 限制，跨域图片直链会被拦，统一走同源）
app.get('/api/img', async (req, res) => {
  const date = DATE_RE.test(req.query.date || '') ? req.query.date : todayCST();
  const size = SIZES.has(req.query.size) ? req.query.size : THUMB_SIZE;
  try {
    const buf = await fetchImage(date, size);
    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=604800');
    res.end(buf);
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

// 给「滚动加载」用的批量日期列表（返回从某天往前 n 天的日期 + 缩略图地址）
app.get('/api/days', (req, res) => {
  let from = DATE_RE.test(req.query.from || '') ? req.query.from : shiftDate(todayCST(), -1);
  const n = Math.min(Math.max(parseInt(req.query.n, 10) || 12, 1), 40);
  const days = [];
  for (let i = 0; i < n; i++) {
    if (from < FIRST_DAY) break;
    days.push({
      date: from,
      thumb: `/api/img?date=${from}&size=${THUMB_SIZE}`,
    });
    from = shiftDate(from, -1);
  }
  res.json({ days, nextFrom: from, exhausted: from < FIRST_DAY });
});

/* ------------------------------------------------------------------ 状态 */
// 只存"丢了无所谓/可重建"的少量偏好 + 自动更新水位
const DEFAULT_STATE = {
  autoDaily: false,          // 是否开启「每天自动更新为当天必应壁纸」
  autoWorkspaceId: null,     // 自动更新作用于哪个工作区
  autoAppliedDate: null,     // 已经自动应用过的日期（YYYY-MM-DD，水位防重复）
  // 最近一次设置的壁纸，前端用它高亮"当前壁纸"的勾
  lastSetKind: null,         // 'bing' | 'video'
  lastSetKey: null,          // 'bing:2026-09-10' | 'video:84'
  lastSetWorkspaceId: null,
  lastSetAt: null,
};
let state = loadState();

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return { ...DEFAULT_STATE };
    return { ...DEFAULT_STATE, ...JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) };
  } catch {
    return { ...DEFAULT_STATE };
  }
}

function saveState() {
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state));
    fs.renameSync(tmp, STATE_FILE);
  } catch (e) {
    console.error('[wallpaper] 状态写入失败:', e.message);
  }
}

app.get('/api/state', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({ ...state, today: todayCST() });
});

app.post('/api/state', (req, res) => {
  const body = req.body || {};
  const patch = {};
  if (typeof body.autoDaily === 'boolean') patch.autoDaily = body.autoDaily;
  if (typeof body.autoWorkspaceId === 'string') patch.autoWorkspaceId = body.autoWorkspaceId;
  if (typeof body.autoAppliedDate === 'string' || body.autoAppliedDate === null) patch.autoAppliedDate = body.autoAppliedDate;
  if (typeof body.lastSetKind === 'string' || body.lastSetKind === null) patch.lastSetKind = body.lastSetKind;
  if (typeof body.lastSetKey === 'string' || body.lastSetKey === null) patch.lastSetKey = body.lastSetKey;
  if (typeof body.lastSetWorkspaceId === 'string') patch.lastSetWorkspaceId = body.lastSetWorkspaceId;
  if (typeof body.lastSetAt === 'number') patch.lastSetAt = body.lastSetAt;
  state = { ...state, ...patch };
  saveState();
  res.json({ ok: true, state: { ...state, today: todayCST() } });
});

/* ------------------------------------------------------- 动态（视频）壁纸 */
// 视频放在 public/videos/，服务端扫目录自动发现：丢一个 <id>.mp4（可选同名的 <id>.jpg 封面）
// 就能在「动态壁纸」栏看到，不用改代码。中文名写在 videos.json（{"84":"星夜湖畔"}），没有就用 id。
const VIDEO_DIR = join(__dirname, 'public', 'videos');

app.get('/api/videos', (req, res) => {
  let names = {};
  try { names = JSON.parse(fs.readFileSync(join(VIDEO_DIR, 'videos.json'), 'utf8')); } catch {}
  let files = [];
  try { files = fs.readdirSync(VIDEO_DIR); } catch {}
  const videos = files
    .filter(f => /\.(mp4|webm)$/i.test(f))
    .sort()
    .map(f => {
      const id = f.replace(/\.[^.]+$/, '');
      const poster = files.includes(`${id}.jpg`) ? `/videos/${id}.jpg` : (files.includes(`${id}.png`) ? `/videos/${id}.png` : null);
      return {
        id,
        name: names[id] || id,
        src: `/videos/${f}`,
        poster,
        mimeType: /\.webm$/i.test(f) ? 'video/webm' : 'video/mp4',
      };
    });
  res.setHeader('Cache-Control', 'no-store');
  res.json({ videos });
});

/* ------------------------------------------------- 每日自动更新（后台定时） */

function daemonCall(type, payload) {
  return fetch(`http://127.0.0.1:${DAEMON_PORT}/api/jsos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, payload }),
  }).then(async r => {
    const j = await r.json().catch(() => ({}));
    if (!j.ok) throw new Error(j.error || `守护进程返回 ${r.status}`);
    return j.result;
  });
}

let autoRunning = false;

/**
 * 检查并应用「今天」的必应壁纸。
 * 依赖 JSOS 守护进程（容器常驻）代调主窗口的 setWallpaper —— 应用服务进程在窗口关闭后
 * 依然存活，所以只要 JSOS 开着就能每天自动换。
 */
async function autoDailyTick() {
  if (autoRunning) return { skipped: 'busy' };
  if (!state.autoDaily || !state.autoWorkspaceId) return { skipped: 'off' };
  const today = todayCST();
  if (state.autoAppliedDate === today) return { upToDate: true, date: today };

  autoRunning = true;
  try {
    const buf = await fetchImage(today, WALLPAPER_SIZE);
    const dataUrl = 'data:image/jpeg;base64,' + buf.toString('base64');
    await daemonCall('setWallpaper', {
      type: 'image',
      data: dataUrl,
      mimeType: 'image/jpeg',
      overlay: null,
      overlayOpacity: 0,
      blur: 0,
      workspaceId: state.autoWorkspaceId,
    });
    state = {
      ...state,
      autoAppliedDate: today,
      lastSetKind: 'bing',
      lastSetKey: `bing:${today}`,
      lastSetWorkspaceId: state.autoWorkspaceId,
      lastSetAt: Date.now(),
    };
    saveState();
    console.log(`[wallpaper] 已自动更新为 ${today} 的必应壁纸`);
    return { applied: true, date: today };
  } catch (e) {
    console.error('[wallpaper] 自动更新失败:', e.message);
    return { error: e.message };
  } finally {
    autoRunning = false;
  }
}

// 手动触发一次（前端打开应用时调，让用户立刻看到效果；也便于排查）
app.post('/api/auto/run', async (req, res) => {
  const r = await autoDailyTick();
  res.json({ ok: !r.error, ...r, state: { ...state, today: todayCST() } });
});

// 每天 0:10（北京时间）之后首次命中即可，5 分钟一轮足够；启动后 5 秒先跑一次
setTimeout(autoDailyTick, 5000);
setInterval(autoDailyTick, 5 * 60 * 1000);

/* ------------------------------------------------------------------ 兜底 */
app.get('*', (req, res) => res.sendFile(join(__dirname, 'public', 'index.html')));

app.listen(port, () => console.log(`wallpaper running on ${port}`));
