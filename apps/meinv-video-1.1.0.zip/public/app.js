const $ = (id) => document.getElementById(id);
const video = $('video');
const veil = $('veil');
const veilText = $('veilText');
const spinner = $('spinner');
const retryBtn = $('retryBtn');
const nextBtn = $('nextBtn');
const soundBtn = $('soundBtn');
const srcLink = $('srcLink');

let busy = false;

// 浏览器自动播放手势策略：页面发生过任何用户交互后，才允许带声自动播放。
// 首次加载（无手势）→ 静音自动播放 + 显示「开启声音」按钮；点击按钮/换一个即解锁带声。
let interacted = false;
const markInteracted = () => { interacted = true; };
document.addEventListener('pointerdown', markInteracted, { capture: true, once: true });
document.addEventListener('keydown', markInteracted, { capture: true, once: true });

function showLoading(text) {
  veil.hidden = false;
  spinner.hidden = false;
  retryBtn.hidden = true;
  veilText.textContent = text;
}

function showError(text) {
  veil.hidden = false;
  spinner.hidden = true;
  retryBtn.hidden = false;
  veilText.textContent = text;
}

function hideVeil() {
  veil.hidden = true;
}

function syncSoundBtn() {
  soundBtn.hidden = !(video.src && video.muted);
}

async function playNext() {
  if (busy) return;
  busy = true;
  nextBtn.disabled = true;
  nextBtn.textContent = '换一个…';
  showLoading('加载中…');
  try {
    const r = await fetch('/api/random');
    const data = await r.json().catch(() => ({}));
    if (!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);

    video.src = `/api/video?u=${encodeURIComponent(data.url)}`;
    video.load();
    srcLink.href = data.url;
    srcLink.hidden = false;

    // 有交互手势 → 带声自动播；没有（首次打开/播完连播）→ 静音自动播
    video.muted = !interacted;
    video.play().catch(() => {});
    // veil 由 canplay 事件收起
  } catch (err) {
    showError(`获取失败：${err?.message || '未知错误'}`);
  } finally {
    busy = false;
    nextBtn.disabled = false;
    nextBtn.textContent = '换一个';
    syncSoundBtn();
  }
}

video.addEventListener('canplay', () => {
  if (video.src) hideVeil();
});

video.addEventListener('error', () => {
  if (video.src) showError('视频加载失败，请重试');
});

video.addEventListener('ended', () => playNext()); // 播完自动连播

// 用户也可能通过原生控制条的音量图标解锁声音
video.addEventListener('volumechange', syncSoundBtn);

nextBtn.addEventListener('click', playNext);
retryBtn.addEventListener('click', playNext);
soundBtn.addEventListener('click', () => {
  video.muted = false; // 点击本身是手势，解锁后带声播放放行
  if (video.paused) video.play().catch(() => {});
  syncSoundBtn();
});

playNext(); // 打开应用即自动加载并（静音）播放第一个
