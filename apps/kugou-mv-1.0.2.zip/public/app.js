/**
 * 酷狗音乐 MV —— 前端
 * ---------------------------------------------------------------
 * 视图：列表（搜索框 + 历史 + 结果）⇄ 播放（视频 + 信息）。
 * 渲染全部用 textContent（上游歌名/歌手不可信，不拼 HTML）。
 *
 * 播放阶段机（AGENTS.md §9：'playing' 事件驱动，绝不能由"点了播放"推定）：
 *   idle → loading → playing ⇄ paused，任一步失败 → error
 *   - waiting → loading（缓冲）；pause 不改写 error 态
 *   - error 判定用 getAttribute('src') 与 wantSrc 比对（拉流失败时 currentSrc
 *     会被清成空串，用它判定会把上一支被 abort 的旧错误算到新 MV 头上）
 *   - 30s 加载超时兜底；失败自动重试一次（重新拉详情——播放 URL 带签名有时效，
 *     重新拉比硬刷 URL 更对症），再失败才进 error 态
 */

const $ = (sel) => document.querySelector(sel);

const els = {
  form: $('#search-form'),
  input: $('#search-input'),
  searchBtn: $('#search-btn'),
  listView: $('#list-view'),
  playerView: $('#player-view'),
  historyBox: $('#history-box'),
  historyChips: $('#history-chips'),
  resultsHead: $('#results-head'),
  resultsTitle: $('#results-title'),
  resultsCount: $('#results-count'),
  list: $('#mv-list'),
  phIdle: $('#list-idle'),
  phSearching: $('#list-searching'),
  phError: $('#list-error'),
  phErrorMsg: $('#list-error-msg'),
  phNone: $('#list-none'),
  listRetry: $('#list-retry'),
  backBtn: $('#back-btn'),
  mvName: $('#mv-name'),
  mvSub: $('#mv-sub'),
  mvResolution: $('#mv-resolution'),
  videoBox: $('#video-box'),
  video: $('#mv-player'),
  videoCoverImg: $('#video-cover-img'),
  ovLoading: $('#ov-loading'),
  ovError: $('#ov-error'),
  ovErrorMsg: $('#ov-error-msg'),
  videoRetry: $('#video-retry'),
  statsBar: $('#mv-stats'),
  toast: $('#toast'),
};

const state = {
  keyword: '',
  currentN: 0,
  history: [],
  retried: false,
};

/* ------------------------------ 主题 ------------------------------ */

function applyTheme(t) {
  document.documentElement.classList.toggle('dark', t === 'dark');
}
function initTheme() {
  const mql = matchMedia('(prefers-color-scheme: dark)');
  applyTheme(mql.matches ? 'dark' : 'light');
  mql.addEventListener('change', (e) => applyTheme(e.matches ? 'dark' : 'light'));
  if (window.JSOS && window.JSOS.getTheme) {
    Promise.resolve(window.JSOS.getTheme()).then((t) => t && applyTheme(t)).catch(() => {});
    if (window.JSOS.onThemeChange) window.JSOS.onThemeChange((t) => applyTheme(t));
  }
}

/* ------------------------------ 小工具 ------------------------------ */

let toastTimer = 0;
function toast(msg) {
  els.toast.textContent = msg;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { els.toast.hidden = true; }, 3000);
}

function fmtCount(n) {
  if (!Number.isFinite(n) || n <= 0) return '—';
  if (n >= 1e8) return (n / 1e8).toFixed(1).replace(/\.0$/, '') + '亿';
  if (n >= 1e4) return (n / 1e4).toFixed(1).replace(/\.0$/, '') + '万';
  return String(n);
}
function fmtSize(bytes) {
  if (!bytes) return '';
  return (bytes / 1024 / 1024).toFixed(1).replace(/\.0$/, '') + 'MB';
}

/** 无封面占位图：深灰底 + 播放三角 */
const PLACEHOLDER =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 60">' +
      '<rect width="96" height="60" fill="#3a4450"/>' +
      '<path d="M42 20l18 10-18 10z" fill="#8a95a3"/></svg>',
  );

function showPlaceholder(which) {
  for (const el of [els.phIdle, els.phSearching, els.phError, els.phNone]) el.hidden = true;
  if (which) which.hidden = false;
}

/* ------------------------------ 搜索历史（服务端持久化） ------------------------------ */

function renderHistory() {
  els.historyChips.textContent = '';
  for (const kw of state.history) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    const text = document.createElement('span');
    text.className = 'chip-text';
    text.textContent = kw;
    const x = document.createElement('span');
    x.className = 'chip-x';
    x.textContent = '×';
    x.title = '删除';
    text.addEventListener('click', () => {
      els.input.value = kw;
      doSearch(kw);
    });
    x.addEventListener('click', (e) => {
      e.stopPropagation();
      removeHistory(kw);
    });
    chip.append(text, x);
    els.historyChips.appendChild(chip);
  }
  els.historyBox.hidden = state.history.length === 0;
}

async function loadHistory() {
  try {
    const r = await fetch('/api/state');
    const j = await r.json();
    if (j?.ok && Array.isArray(j.history)) {
      state.history = j.history;
      renderHistory();
    }
  } catch { /* 历史丢了无所谓，不阻塞主流程 */ }
}

async function saveHistory() {
  try {
    await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ history: state.history }),
    });
  } catch { /* 同上 */ }
}

function addHistory(kw) {
  const i = state.history.indexOf(kw);
  if (i !== -1) state.history.splice(i, 1);
  state.history.unshift(kw);
  if (state.history.length > 10) state.history.length = 10;
  renderHistory();
  saveHistory();
}

function removeHistory(kw) {
  const i = state.history.indexOf(kw);
  if (i === -1) return;
  state.history.splice(i, 1);
  renderHistory();
  saveHistory();
}

/* ------------------------------ 搜索 ------------------------------ */

async function doSearch(kw) {
  kw = String(kw || '').trim();
  if (!kw) {
    toast('请输入搜索关键词');
    els.input.focus();
    return;
  }
  state.keyword = kw;
  addHistory(kw);

  els.resultsHead.hidden = false;
  els.resultsTitle.textContent = `“${kw}” 的搜索结果`;
  els.resultsCount.textContent = '';
  els.list.textContent = '';
  showPlaceholder(els.phSearching);
  els.searchBtn.disabled = true;

  try {
    const r = await fetch(`/api/search?kw=${encodeURIComponent(kw)}`);
    const j = await r.json();
    if (!j?.ok) throw new Error(j?.error || '搜索失败');
    if (!j.list?.length) {
      showPlaceholder(els.phNone);
      return;
    }
    renderList(j.list);
    els.resultsCount.textContent = `${j.list.length} 个结果`;
    showPlaceholder(null);
  } catch (err) {
    els.phErrorMsg.textContent = err?.message || '搜索出错，请稍后再试';
    showPlaceholder(els.phError);
  } finally {
    els.searchBtn.disabled = false;
  }
}

function renderList(items) {
  els.list.textContent = '';
  for (const it of items) {
    const li = document.createElement('li');
    li.className = 'mv-item';
    li.dataset.n = String(it.n);

    const img = document.createElement('img');
    img.className = 'mv-cover';
    img.loading = 'lazy';
    img.alt = it.name;
    img.src = it.coverSrc || PLACEHOLDER; // 代理路径由服务端签发

    const info = document.createElement('div');
    info.className = 'mv-info';
    const title = document.createElement('div');
    title.className = 'mv-title';
    title.textContent = it.name;
    const artist = document.createElement('div');
    artist.className = 'mv-artist';
    artist.textContent = it.singer || '未知歌手';
    info.append(title, artist);

    const side = document.createElement('div');
    side.className = 'mv-side';
    if (it.resolution) {
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = it.resolution;
      side.appendChild(badge);
    }
    if (it.hot) {
      const hot = document.createElement('span');
      hot.className = 'mv-hot';
      hot.textContent = `热度 ${fmtCount(it.hot)}`;
      side.appendChild(hot);
    }

    li.append(img, info, side);
    li.addEventListener('click', () => playMv(it.n));
    els.list.appendChild(li);
  }
}

/* ------------------------------ 播放（阶段机） ------------------------------ */

let stage = 'idle'; // idle | loading | playing | paused | error
let wantSrc = '';   // 本次期望的 src（error 判定用，currentSrc 失败时会被清空不可靠）
let loadTimer = 0;

function setStage(s) {
  stage = s;
  els.videoBox.dataset.stage = s;
  els.ovLoading.hidden = s !== 'loading';
  els.ovError.hidden = s !== 'error';
}

function clearLoadTimer() {
  clearTimeout(loadTimer);
  loadTimer = 0;
}

function armLoadTimer() {
  clearLoadTimer();
  loadTimer = setTimeout(() => {
    if (stage === 'loading') handleVideoFailure('加载超时');
  }, 30000);
}

/** 播放失败统一入口：先自动重试一次（重新拉详情换新签名 URL），再失败进 error 态 */
function handleVideoFailure(reason) {
  if (state.retried) {
    setStage('error');
    els.ovErrorMsg.textContent = reason || '视频加载失败';
    return;
  }
  state.retried = true;
  els.ovLoading.hidden = false;
  els.ovError.hidden = true;
  playMv(state.currentN, { isRetry: true });
}

async function playMv(n, { isRetry = false } = {}) {
  const kw = state.keyword;
  if (!kw || !Number.isInteger(n) || n < 1) return;
  state.currentN = n;
  if (!isRetry) state.retried = false;

  if (!isRetry) {
    els.listView.hidden = true;
    els.playerView.hidden = false;
    els.mvName.textContent = '加载中…';
    els.mvSub.textContent = kw;
    els.mvResolution.hidden = true;
    els.statsBar.hidden = true;
    els.videoCoverImg.hidden = true;
    setStage('loading');
  }
  armLoadTimer();

  let mv;
  try {
    const r = await fetch(`/api/detail?kw=${encodeURIComponent(kw)}&n=${n}`);
    const j = await r.json();
    if (!j?.ok) throw new Error(j?.error || '获取 MV 详情失败');
    mv = j.mv;
  } catch (err) {
    clearLoadTimer();
    handleVideoFailure(err?.message || '获取 MV 详情失败');
    return;
  }

  // 请求期间用户已点别的 MV / 返回列表 → 丢弃过期响应
  if (state.currentN !== n || els.playerView.hidden) return;

  els.mvName.textContent = mv.name || '未知 MV';
  // 歌手名与搜索词相同时不重复显示（如搜「周杰伦」→ 副标题只显示「周杰伦」）
  const subSinger = mv.singer || '未知歌手';
  els.mvSub.textContent = subSinger === kw ? subSinger : `${subSinger} · ${kw}`;
  if (mv.resolution) {
    els.mvResolution.textContent = mv.resolution;
    els.mvResolution.hidden = false;
  } else {
    els.mvResolution.hidden = true;
  }

  const stats = [];
  const stat = (label, v) => {
    const s = document.createElement('span');
    s.className = 'stat';
    s.textContent = label;
    const b = document.createElement('b');
    b.textContent = v;
    s.appendChild(b);
    return s;
  };
  els.statsBar.textContent = '';
  els.statsBar.append(
    stat('播放', fmtCount(mv.playCount)),
    stat('点赞', fmtCount(mv.likeCount)),
    stat('评论', fmtCount(mv.commentCount)),
    stat('收藏', fmtCount(mv.collectCount)),
  );
  const extra = [mv.upTime && `发布 ${mv.upTime}`, mv.duration && `时长 ${mv.duration}`, fmtSize(mv.filesize)]
    .filter(Boolean).join(' · ');
  if (extra) {
    const s = document.createElement('span');
    s.textContent = extra;
    els.statsBar.appendChild(s);
  }
  els.statsBar.hidden = false;

  if (mv.videoUrl) {
    els.videoCoverImg.src = mv.coverSrc || PLACEHOLDER;
    els.videoCoverImg.hidden = !mv.cover;
  }

  if (!mv.videoUrl) {
    clearLoadTimer();
    handleVideoFailure('未获取到播放地址');
    return;
  }

  // 播放路径（/api/video?u=..&sig=..）由服务端签发：URL 带时效签名，
  // 每次实时拉详情换新地址，前端不缓存不复用
  const src = mv.videoSrc;
  wantSrc = src;
  els.video.src = src;
  els.video.load();
  try {
    await els.video.play();
    // play() resolved 不代表在播——交给 'playing' 事件确认
  } catch { /* AbortError 等由阶段机事件处理 */ }
}

function showList() {
  clearLoadTimer();
  wantSrc = '';
  els.video.pause();
  els.video.removeAttribute('src');
  els.video.load();
  setStage('idle');
  els.playerView.hidden = true;
  els.listView.hidden = false;
}

/* 视频事件 → 阶段机 */
els.video.addEventListener('playing', () => {
  clearLoadTimer();
  setStage('playing');
});
els.video.addEventListener('waiting', () => {
  if (stage === 'playing' || stage === 'paused') {
    setStage('loading');
    armLoadTimer();
  }
});
els.video.addEventListener('pause', () => {
  if (stage !== 'error' && stage !== 'loading') setStage('paused');
});
els.video.addEventListener('error', () => {
  // 过期错误守卫：src 已被换掉/清掉的旧错误不算数
  const attr = els.video.getAttribute('src');
  if (!attr || attr !== wantSrc) return;
  clearLoadTimer();
  handleVideoFailure('视频加载失败');
});

/* ------------------------------ 事件绑定 ------------------------------ */

els.form.addEventListener('submit', (e) => {
  e.preventDefault();
  doSearch(els.input.value);
});
els.listRetry.addEventListener('click', () => doSearch(state.keyword));
els.backBtn.addEventListener('click', showList);
els.videoRetry.addEventListener('click', () => {
  state.retried = false;
  playMv(state.currentN);
});

/* ------------------------------ 初始化 ------------------------------ */

initTheme();
loadHistory();
setStage('idle');
showPlaceholder(els.phIdle);
