/**
 * 酷狗音乐 MV —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 五组接口：
 *   /api/health  健康检查（测试轮询就绪用）
 *   /api/search  搜索 MV（上游 api.suol.cc；容器内必走平台 CORS 代理，
 *                实测其 ACAO 头为重复的 "*, *"，浏览器 CORS 检查必失败，直连是死路）
 *   /api/detail  取单条 MV 详情（实时拿带签名的播放地址，URL 约 2 小时时效，不缓存）
 *   /api/video   同源流式代理 MV 视频源（透传 Range 支持拖动；上游 http:// 且域名不固定，
 *                容器内 https 上下文直连会被混合内容拦 → 上游请求经 outbound 走平台代理）
 *   /api/img     同源图片代理（封面；跨域图片无 CORP 头会被 COEP 拦）
 *   /api/state   搜索历史持久化（AGENTS.md §6 铁律：使用数据存服务端 DATA_DIR）
 *
 * 防开放代理/SSRF：代理端点只接受本服务签发（HMAC）的 URL + 拒绝私网/localhost。
 * 出站策略见 lib/http.js。
 */

import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';
import { outbound, IN_CONTAINER, ok, fail } from './lib/http.js';
import { searchMv, fetchDetail } from './lib/kugou.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');

/* ------------------------------ URL 签名（防开放代理/SSRF） ------------------------------
 * 2026-09-24 容器内实测：上游视频 CDN 域名不固定（fsmvpc.tx.kugou.com / fsrmvpc.swayay.com:8089…），
 * 死白名单追不完。改为 HMAC 签名：代理端点只接受「本服务 /api/search、/api/detail 签发过」的 URL
 * （secret 仅存服务端内存，外部构造的 u 任何 sig 都过不了），私网/localhost 另行硬拦做纵深防御
 * （防上游被黑时借代理探测内网）。进程重启换 secret → 旧签名失效，前端本来就每次播放实时拉详情。
 */

const SECRET = crypto.randomBytes(16).toString('hex');
const sign = (url) => crypto.createHmac('sha256', SECRET).update(String(url)).digest('base64url');

function sigOk(url, sig) {
  if (!sig) return false;
  const want = Buffer.from(sign(url));
  let got;
  try {
    got = Buffer.from(String(sig));
  } catch {
    return false;
  }
  return want.length === got.length && crypto.timingSafeEqual(want, got);
}

function isPrivateHost(hostname) {
  const h = String(hostname || '').toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.internal') || h.endsWith('.local')) return true;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (m) {
    const [a, b] = m.slice(1).map(Number);
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    return false;
  }
  if (h === '::1' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80')) return true;
  return false;
}

/** 校验并解析媒体地址：协议受限 + 拒绝私网 + 签名校验。extra 参数（_r 重试戳）剥离。 */
function parseMediaUrl(raw, sig, { httpsOnly }) {
  let u;
  try {
    u = new URL(String(raw || ''));
  } catch {
    return null;
  }
  if (httpsOnly && u.protocol !== 'https:') return null;
  if (!httpsOnly && u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (isPrivateHost(u.hostname)) return null;
  if (!sigOk(u.href, sig)) return null;
  u.searchParams.delete('_r'); // 前端重试戳，不透传给上游
  return u;
}

/** 生成带签名的同源代理路径（服务端签发，前端直接用） */
const videoSrc = (url) => `/api/video?u=${encodeURIComponent(url)}&sig=${sign(url)}`;
const coverSrcOf = (url) => (url ? `/api/img?u=${encodeURIComponent(url)}&sig=${sign(url)}` : null);

/* ------------------------------ 搜索历史（模式 A） ------------------------------ */

function readState() {
  try {
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    return raw && typeof raw === 'object' ? raw : {};
  } catch {
    return {};
  }
}

function writeState(obj) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = STATE_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, STATE_FILE); // 原子写
}

/* ------------------------------ 应用 ------------------------------ */

const app = express();
app.use(express.static(join(__dirname, 'public')));

app.get('/api/health', (req, res) => {
  ok(res, { service: 'kugou-mv', proxy: IN_CONTAINER, time: new Date().toISOString() });
});

/* ------------------------------ 搜索 / 详情 ------------------------------ */

app.get('/api/search', async (req, res) => {
  try {
    const kw = String(req.query.kw || '').trim();
    if (!kw) return fail(res, '请输入歌名或歌手', 400);
    const { list, via } = await searchMv(kw);
    // 封面代理路径服务端签发（签名校验见 parseMediaUrl）
    ok(res, {
      kw,
      list: list.map((it) => ({ ...it, coverSrc: coverSrcOf(it.cover) })),
      via,
    });
  } catch (err) {
    fail(res, `搜索失败：${err?.message || '未知错误'}`);
  }
});

app.get('/api/detail', async (req, res) => {
  try {
    const kw = String(req.query.kw || '').trim();
    const n = Number(req.query.n);
    if (!kw) return fail(res, '缺少搜索关键词', 400);
    const { mv, via } = await fetchDetail(kw, n);
    ok(res, {
      mv: {
        ...mv,
        coverSrc: coverSrcOf(mv.cover),
        // 播放地址约 2h 时效且域名不固定 → 前端每次播放实时拉详情拿新签名路径
        videoSrc: mv.videoUrl ? videoSrc(mv.videoUrl) : null,
      },
      via,
    });
  } catch (err) {
    fail(res, `获取 MV 详情失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 视频同源代理（Range 透传） ------------------------------
 * 2026-09-24 容器内实测（用户报障 + 控制台 Mixed Content）：应用 iframe 页面上下文是
 * https（blob:），而上游视频 CDN 是 http:// 且域名不固定 → 容器内 Node fetch 走浏览器
 * 网络栈，http 上游必被混合内容拦截（本机 http→http 直连成功完全掩盖这一点）。
 * 故上游请求一律经 outbound：容器内走平台 CORS 代理（https→代理→http，代理侧无混合内容，
 * Range 属 CORS 安全列表头可透传，实测 206）；本机直跑保持直连。
 */

app.get('/api/video', async (req, res) => {
  const target = parseMediaUrl(req.query.u, req.query.sig, { httpsOnly: false });
  if (!target) {
    return fail(res, '视频地址无效或签名不匹配', 400);
  }

  const headers = {};
  if (req.headers.range) headers.Range = String(req.headers.range);

  try {
    const { res: up, via } = await outbound(target.href, {
      headers,
      timeout: 30000,
    });
    // isOk 按内容类型判，不能只看状态码：上游/代理层异常可能回 200 + 文本错误体，
    // 只看状态码会把错误体喂给 <video>，静默不播且不触发 error 兜底。
    const ct = up.headers.get('content-type') || '';
    const playable = /^(video\/|application\/octet-stream|binary\/)/i.test(ct);
    if (!(up.status === 200 || up.status === 206) || !playable) {
      await up.body?.cancel().catch(() => {});
      return fail(res, `视频源响应异常（HTTP ${up.status}，${ct || '无类型'}，via ${via}）`, 502);
    }

    res.status(up.status);
    for (const h of ['content-type', 'content-length', 'content-range']) {
      const v = up.headers.get(h);
      if (v) res.setHeader(h, v);
    }
    // 显式告知可 Range 定位：上游 206 响应常不带 accept-ranges，缺了浏览器就不给拖动
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-store');

    if (req.query.dl === '1') {
      const name = decodeURIComponent(target.pathname.split('/').pop() || 'mv.mp4')
        .replace(/[\\/:*?"<>|]/g, '_');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${name.replace(/[^\x20-\x7e]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(name)}`,
      );
    }

    if (!up.body) {
      res.end();
      return;
    }
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy()); // 必须挂 error handler，否则出错静默挂起
    stream.pipe(res);
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `视频拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

/* ------------------------------ 图片同源代理（封面） ------------------------------ */
app.get('/api/img', async (req, res) => {
  const target = parseMediaUrl(req.query.u, req.query.sig, { httpsOnly: true });
  if (!target) {
    return fail(res, '图片地址无效或签名不匹配', 400);
  }

  try {
    const { res: up, via } = await outbound(target.href, { timeout: 15000 });
    const ct = up.headers.get('content-type') || '';
    if (!up.ok || !ct.startsWith('image/')) {
      await up.body?.cancel().catch(() => {});
      return fail(res, `封面拉取失败（HTTP ${up.status}，via ${via}）`, 502);
    }
    res.status(200);
    res.setHeader('Content-Type', ct);
    const cl = up.headers.get('content-length');
    if (cl) res.setHeader('Content-Length', cl);
    res.setHeader('Cache-Control', 'max-age=86400'); // 封面按 URL 稳定，可缓存
    const stream = Readable.fromWeb(up.body);
    stream.on('error', () => res.destroy());
    stream.pipe(res);
    res.on('close', () => stream.destroy());
  } catch (err) {
    if (!res.headersSent) {
      fail(res, `封面拉取失败：${err?.message || '未知错误'}`);
    } else {
      res.destroy();
    }
  }
});

/* ------------------------------ 搜索历史 ------------------------------ */

app.get('/api/state', (req, res) => {
  const state = readState();
  const history = Array.isArray(state.history) ? state.history : [];
  res.json({ ok: true, history });
});

app.post('/api/state', express.json({ limit: '16kb' }), (req, res) => {
  const raw = req.body?.history;
  if (!Array.isArray(raw)) return fail(res, 'history 必须是数组', 400);
  // 只收非空字符串、去重、单项限长、总量限 10（与前端历史条数上限一致）
  const seen = new Set();
  const history = [];
  for (const item of raw) {
    const s = String(item ?? '').trim().slice(0, 50);
    if (!s || seen.has(s)) continue;
    seen.add(s);
    history.push(s);
    if (history.length >= 10) break;
  }
  try {
    writeState({ history });
    ok(res, { history });
  } catch (err) {
    fail(res, `保存失败：${err?.message || '未知错误'}`);
  }
});

/* ------------------------------ 启动 ------------------------------ */

// 全局兜底：未捕获异常打日志，不静默
process.on('unhandledRejection', (err) => {
  console.error('[kugou-mv] unhandledRejection:', err?.message || err);
});

app.listen(port, () => {
  console.log(`[kugou-mv] listening on http://localhost:${port} (proxy: ${IN_CONTAINER ? 'on' : 'off'})`);
});
