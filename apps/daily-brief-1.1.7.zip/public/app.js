/**
 * 每日速览 —— 前端
 * 侧边栏切换「每日电影」/「每日英语」，内容按天由服务端缓存。
 * 所有用户内容写进 DOM 前统一转义。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 4000);
  }

  async function api(path) {
    let res;
    try {
      res = await fetch(path);
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data;
  }

  /* ------------------------------ 侧边栏切换 ------------------------------ */

  function switchView(view) {
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    $('#view-movie').hidden = view !== 'movie';
    $('#view-english').hidden = view !== 'english';
  }

  /* ------------------------------ 侧边栏折叠 ------------------------------ */

  const COLLAPSE_KEY = 'daily-brief.sidebar-collapsed';

  function setCollapsed(collapsed) {
    $('.shell').classList.toggle('collapsed', collapsed);
    // ⚠️ 必须用 toggleAttribute 写 content attribute：hidden 是 HTMLElement 的 IDL 属性，
    // SVGElement 上 svg.hidden = true 只是 JS expando，不写 DOM attribute、CSS [hidden] 也不匹配
    $('#ic-collapse').toggleAttribute('hidden', collapsed);
    $('#ic-expand').toggleAttribute('hidden', !collapsed);
    $('#collapse-btn').setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    // 折叠时导航只显示图标 → 悬浮提示补全语义（对齐 appmanager 官方模式）
    $$('.nav-item').forEach((b) => { b.title = collapsed ? b.querySelector('span').textContent : ''; });
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch { /* 忽略 */ }
  }

  function initCollapse() {
    let collapsed = false;
    try { collapsed = localStorage.getItem(COLLAPSE_KEY) === '1'; } catch { /* 忽略 */ }
    setCollapsed(collapsed);
    $('#collapse-btn').addEventListener('click', () => {
      setCollapsed(!$('.shell').classList.contains('collapsed'));
    });
  }

  /* ------------------------------ 每日电影 ------------------------------ */

  // 海报经 weserv 图片代理：解决 cikeee 防盗链，且其有缓存（源站失联时海报仍可显示）
  const posterUrl = (poster) =>
    poster ? `https://images.weserv.nl/?url=www.cikeee.com${poster.startsWith('http') ? new URL(poster).pathname : poster}` : '';

  // 观影搜索按钮（复用起始页 DailyMovie 的平台清单）
  const WATCH_PLATFORMS = [
    { name: '摸鱼TV', url: (t) => `https://tv.yucoder.cn/search?q=${encodeURIComponent(t)}`, alt: false },
    { name: '腾讯视频', url: (t) => `https://v.qq.com/x/search/?q=${encodeURIComponent(t)}`, alt: true },
    { name: '爱奇艺', url: (t) => `https://so.iqiyi.com/so/q_${encodeURIComponent(t)}`, alt: true },
    { name: '优酷', url: (t) => `https://so.youku.com/search_video/q_${encodeURIComponent(t)}`, alt: true },
    { name: '抖音', url: (t) => `https://www.douyin.com/search/${encodeURIComponent(t)}`, alt: true },
  ];

  function renderMovie(m) {
    const img = $('#m-poster');
    img.onerror = () => { img.style.visibility = 'hidden'; };
    img.onload = () => { img.style.visibility = 'visible'; };
    img.src = posterUrl(m.poster);

    $('#m-title').textContent = m.title || '未知影片';
    const score = $('#m-score');
    score.textContent = m.score ? `${m.score}分` : '';
    score.hidden = !m.score;

    $('#m-meta').innerHTML = [
      escapeHtml([m.category, m.year, m.region].filter(Boolean).join(' | ')),
      m.director ? `导演：${escapeHtml(m.director)}` : '',
      m.actors ? `主演：${escapeHtml(m.actors)}` : '',
    ].filter(Boolean).join('<br>');

    $('#m-quote').textContent = m.quote || '';
    $('#m-quote').hidden = !m.quote;
    $('#m-intro').textContent = m.introduction || '';
    $('#m-intro').hidden = !m.introduction;

    const actions = $('#m-actions');
    actions.innerHTML = '<span class="actions-label">在线观看：</span>';
    if (m.title) {
      for (const p of WATCH_PLATFORMS) {
        const a = document.createElement('a');
        a.className = 'action-btn' + (p.alt ? ' alt' : '');
        a.href = p.url(m.title);
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = p.name;
        actions.appendChild(a);
      }
      actions.hidden = false;
    } else {
      actions.hidden = true;
    }

    $('#movie-card').hidden = false;
  }

  /* ------------------------------ 每日英语 ------------------------------ */

  let audioEl = null;

  function renderEnglish(e) {
    $('#e-english').textContent = e.english || '';
    $('#e-chinese').textContent = e.chinese || '';

    // 发音：经服务端代理播放（frdic 有 Referer/CORP 校验，容器 iframe 直连会被拦）
    const proxied = (u) => (u ? `/api/audio?url=${encodeURIComponent(u)}` : '');
    const hasAudio = !!(e.normalAudioUrl || e.slowAudioUrl);
    $('#e-audio').hidden = !hasAudio;
    $('#e-normal').hidden = !e.normalAudioUrl;
    $('#e-slow').hidden = !e.slowAudioUrl;
    $('#e-normal').dataset.url = proxied(e.normalAudioUrl);
    $('#e-slow').dataset.url = proxied(e.slowAudioUrl);

    // 详细解析（服务端给的是 HTML 片段，来自固定站点，直接注入）
    $('#e-explain').innerHTML = e.explanation || '';

    $('#english-card').hidden = false;
  }

  function playAudio(url) {
    if (!url) return;
    if (!audioEl) audioEl = new Audio();
    audioEl.src = url;
    audioEl.play().catch(() => toast('发音播放失败', 'error'));
  }

  /* ------------------------------ 启动 ------------------------------ */

  async function init() {
    $('#today-date').textContent = new Date().toLocaleDateString('zh-CN');

    // 两个视图并行加载，先到先显示
    const loadMovie = api('/api/daily-movie')
      .then((d) => { renderMovie(d); $('#movie-state').hidden = true; })
      .catch((e) => { $('#movie-state').textContent = '加载失败：' + e.message; });
    const loadEnglish = api('/api/daily-english')
      .then((d) => { renderEnglish(d); $('#english-state').hidden = true; })
      .catch((e) => { $('#english-state').textContent = '加载失败：' + e.message; });
    await Promise.allSettled([loadMovie, loadEnglish]);
  }

  $$('.nav-item').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));
  $('#e-normal').addEventListener('click', () => playAudio($('#e-normal').dataset.url || ''));
  $('#e-slow').addEventListener('click', () => playAudio($('#e-slow').dataset.url || ''));

  initCollapse();
  init().catch((e) => toast(e.message, 'error'));
})();
