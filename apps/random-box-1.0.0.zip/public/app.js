/**
 * 随机盒子 —— 前端
 * ---------------------------------------------------------------
 * 界面只做两件事：抽一条、看记录。
 * 站点配置写在服务端的 lib/sites.js，这里不提供增删改，只控制开关。
 *
 * 所有用户内容写进 DOM 前统一转义，不直接 innerHTML 拼接。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  let sites = [];
  let history = [];
  let lastPick = null;

  /* ------------------------------ 工具 ------------------------------ */

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  async function api(path, options = {}) {
    let res;
    try {
      res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...options });
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    let data = null;
    try { data = await res.json(); } catch { /* 非 JSON 响应 */ }
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data || {};
  }

  const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body || {}) });
  const del = (path) => api(path, { method: 'DELETE' });

  function formatTime(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  /* ------------------------------ 渲染 ------------------------------ */

  function renderSites() {
    $('#badge-sites').textContent = String(sites.length);
    $('#site-empty').hidden = sites.length > 0;
    $('#site-list').innerHTML = sites.map((s) => `
      <div class="site-card ${s.enabled ? '' : 'disabled'}" data-id="${escapeHtml(s.id)}">
        <div class="site-top">
          <div class="site-main">
            <div class="site-name">
              <b>${escapeHtml(s.name)}</b>
              <span class="tag">${escapeHtml(s.kindLabel || s.kind || '')}</span>
              ${s.enabled ? '' : '<span class="tag">已关闭</span>'}
            </div>
            <div class="site-url">${escapeHtml(s.listUrl || '')}</div>
            ${s.note ? `<div class="site-note">${escapeHtml(s.note)}</div>` : ''}
          </div>
          <div class="site-actions">
            <button class="switch ${s.enabled ? 'on' : ''}" data-act="toggle"
                    title="${s.enabled ? '点击关闭' : '点击开启'}" aria-label="启用状态"></button>
            <button class="btn ghost small" data-act="pick">抽一条</button>
          </div>
        </div>
      </div>`).join('');
  }

  function renderHistory() {
    $('#badge-history').textContent = String(history.length);
    $('#history-count').textContent = history.length ? `共 ${history.length} 条，最多保留 200 条` : '';
    $('#history-empty').hidden = history.length > 0;
    $('#history-list').innerHTML = history.map((h) => `
      <div class="history-item" data-id="${escapeHtml(h.id)}">
        <div class="history-body">
          <a class="history-title" href="${escapeHtml(h.url)}" target="_blank" rel="noopener noreferrer" title="${escapeHtml(h.title)}">${escapeHtml(h.title)}</a>
          <div class="history-meta">${escapeHtml(h.siteName || '')}${h.page ? ` · 第 ${escapeHtml(h.page)} 页` : ''}${h.maxPage ? ' / 共 ' + escapeHtml(h.maxPage) + ' 页' : ''} · ${escapeHtml(formatTime(h.at))}</div>
        </div>
        <button class="icon-btn" data-act="del-history" title="删除这条">
          <svg viewBox="0 0 24 24" class="i"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>`).join('');
  }

  async function refresh() {
    const [s, h] = await Promise.all([api('/api/sites'), api('/api/history')]);
    const kinds = Object.fromEntries((s.kinds || []).map((k) => [k.kind, k.label]));
    sites = (s.sites || []).map((x) => ({ ...x, kindLabel: kinds[x.kind] || x.kind }));
    history = h.history || [];
    renderSites();
    renderHistory();
  }

  /* ------------------------------ 抽取 ------------------------------ */

  function setBusy(busy) {
    const btn = $('#btn-flip');
    btn.disabled = busy;
    btn.classList.toggle('spinning', busy);
    btn.querySelector('span').textContent = busy ? '抽取中…' : '随机盒子';
  }

  async function doFlip(siteId) {
    setBusy(true);
    $('#flip-status').textContent = '正在探测页码并抓取内容…';
    try {
      const data = await post('/api/pick', { siteId: siteId || undefined });
      lastPick = data.item;
      showResult(data.item);
      const d = data.item.detail || {};
      $('#flip-status').textContent = d.page
        ? `已抽到「${data.item.siteName}」第 ${d.page} / ${d.maxPage} 页`
        : `已抽到「${data.item.siteName}」`;
      history = (await api('/api/history')).history || [];
      renderHistory();
    } catch (e) {
      $('#flip-status').textContent = '抽取失败，可重试或换个站点';
      toast(e.message || '抽取失败', 'error');
    } finally {
      setBusy(false);
    }
  }

  function showResult(item) {
    const d = item.detail || {};
    $('#result-card').hidden = false;
    $('#result-meta').textContent = [
      item.siteName,
      d.page ? `第 ${d.page} / ${d.maxPage} 页` : '',
      d.total ? `本页 ${d.total} 条` : '',
      item.fromCache ? '命中缓存' : '',
      `${item.ms}ms`,
    ].filter(Boolean).join(' · ');

    const a = $('#result-title');
    a.textContent = item.title;
    a.href = item.url;
    a.title = item.title;
    $('#result-open').href = item.url;
    $('#result-logs').innerHTML = (item.logs || []).map((l) => `
      <div class="log-item ${l.ok ? 'ok' : 'bad'}">
        <span class="pg">${escapeHtml(l.page === '-' ? '—' : '第 ' + l.page + ' 页')}</span>
        <span class="nt">${escapeHtml(l.note || '')}</span>
      </div>`).join('') || '<div class="log-item"><span class="nt">无日志</span></div>';
  }

  /* ------------------------------ 事件 ------------------------------ */

  function bind() {
    $('#btn-flip').addEventListener('click', () => doFlip());

    $('#btn-clearcache').addEventListener('click', async () => {
      try { await post('/api/cache/clear'); toast('页码缓存已清理', 'ok'); }
      catch (e) { toast(e.message, 'error'); }
    });

    $('#tabs').addEventListener('click', (e) => {
      const btn = e.target.closest('.tab');
      if (!btn) return;
      $$('.tab').forEach((b) => b.classList.toggle('active', b === btn));
      const name = btn.dataset.tab;
      $('#panel-sites').hidden = name !== 'sites';
      $('#panel-history').hidden = name !== 'history';
    });

    // 站点列表：开关 + 单站抽取（按 data-id 定位，不用数组下标）
    $('#site-list').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const id = btn.closest('.site-card')?.dataset.id;
      if (!id) return;

      if (btn.dataset.act === 'toggle') {
        try {
          const r = await post(`/api/sites/${encodeURIComponent(id)}/toggle`);
          sites = r.sites || sites;
          renderSites();
        } catch (err) { toast(err.message, 'error'); }
      } else if (btn.dataset.act === 'pick') {
        doFlip(id);
      }
    });

    $('#history-list').addEventListener('click', async (e) => {
      if (!e.target.closest('[data-act="del-history"]')) return;
      const id = e.target.closest('.history-item')?.dataset.id;
      if (!id) return;
      try {
        history = (await del(`/api/history/${encodeURIComponent(id)}`)).history || [];
        renderHistory();
      } catch (err) { toast(err.message, 'error'); }
    });

    $('#btn-clear-history').addEventListener('click', async () => {
      if (!confirm('确定清空全部历史记录？')) return;
      try {
        history = (await del('/api/history')).history || [];
        renderHistory();
        toast('历史已清空', 'ok');
      } catch (e) { toast(e.message, 'error'); }
    });

    $('#result-another').addEventListener('click', () => doFlip(lastPick?.siteId));
    $('#result-copy').addEventListener('click', async () => {
      if (!lastPick) return;
      try {
        await navigator.clipboard.writeText(lastPick.url);
        toast('链接已复制', 'ok');
      } catch { toast('复制失败，请手动复制'); }
    });
  }

  bind();
  refresh().catch((e) => {
    $('#flip-status').textContent = '加载失败：' + e.message;
    toast(e.message, 'error');
  });
})();
