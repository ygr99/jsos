import express from 'express';
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>日期时间</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:#1e1e2e;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none}
#clock{text-align:center;font-size:3.5rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.3)}
@media(max-width:480px){#clock{font-size:2rem}}
</style>
</head>
<body>
<div id="clock"></div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  document.getElementById('clock').textContent=y+'年'+mo+'月'+da+'日 '+wd+wn+'周 '+h+':'+mi;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

app.get('/widget/clock', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{display:flex;align-items:center;justify-content:center;background:transparent;color:#cdd6f4;font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;-webkit-user-select:none;user-select:none;overflow:hidden}
#clock{text-align:center}
.date{font-size:1rem;font-weight:500;opacity:.85;letter-spacing:1px}
.time{font-size:2.8rem;font-weight:700;letter-spacing:2px;text-shadow:0 0 20px rgba(137,180,250,.4);line-height:1.2}
.seconds{font-size:1.2rem;font-weight:400;opacity:.6;margin-left:4px}
</style>
</head>
<body>
<div id="clock">
  <div class="date" id="date"></div>
  <div class="time"><span id="time"></span><span class="seconds" id="seconds"></span></div>
</div>
<script>
function getWeekNumber(d){
  const date=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));
  date.setUTCDate(date.getUTCDate()+4-(date.getUTCDay()||7));
  const yearStart=new Date(Date.UTC(date.getUTCFullYear(),0,1));
  return Math.ceil((((date-yearStart)/86400000)+1)/7);
}
function update(){
  const n=new Date();
  const y=n.getFullYear();
  const mo=String(n.getMonth()+1).padStart(2,'0');
  const da=String(n.getDate()).padStart(2,'0');
  const wd=['周日','周一','周二','周三','周四','周五','周六'][n.getDay()];
  const wn=getWeekNumber(n);
  const h=String(n.getHours()).padStart(2,'0');
  const mi=String(n.getMinutes()).padStart(2,'0');
  const s=String(n.getSeconds()).padStart(2,'0');
  document.getElementById('date').textContent=y+'\u5E74'+mo+'\u6708'+da+'\u65E5 '+wd+wn+'\u5468';
  document.getElementById('time').textContent=h+':'+mi;
  document.getElementById('seconds').textContent=s;
}
update();
setInterval(update,1000);
</script>
</body>
</html>`);
});

app.listen(port, () => console.log(`running on ${port}`));
