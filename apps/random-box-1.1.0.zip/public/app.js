/**
 * 随机盒子 —— 前端
 * ---------------------------------------------------------------
 * 界面只做一件事：随机抽一条，新标签打开。
 * 站点配置写在服务端的 lib/sites.js，这里不提供增删改，只控制开关。
 *
 * 所有用户内容写进 DOM 前统一转义，不直接 innerHTML 拼接。
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  let sites = [];

  /* ------------------------------ 工具 ------------------------------ */

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (type ? ' ' + type : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  async function api(path, options = {}) {
    let res;
    try {
      res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...options });
    } catch (e) {
      throw new Error('无法连接应用服务：' + (e?.message || e));
    }
    let data = null;
    try { data = await res.json(); } catch { /* 非 JSON 响应 */ }
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || `请求失败（HTTP ${res.status}）`);
    }
    return data || {};
  }

  const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body || {}) });

  /* ------------------------------ 渲染 ------------------------------ */

  function renderSites() {
    $('#site-empty').hidden = sites.length > 0;
    $('#site-list').innerHTML = sites.map((s) => `
      <div class="site-card ${s.enabled ? '' : 'disabled'}" data-id="${escapeHtml(s.id)}">
        <div class="site-top">
          <div class="site-main">
            <div class="site-name">
              <b>${escapeHtml(s.name)}</b>
              <span class="tag">${escapeHtml(s.kindLabel || s.kind || '')}</span>
              ${s.enabled ? '' : '<span class="tag">已关闭</span>'}
            </div>
            ${s.note ? `<div class="site-note">${escapeHtml(s.note)}</div>` : ''}
          </div>
          <div class="site-actions">
            <button class="switch ${s.enabled ? 'on' : ''}" data-act="toggle"
                    title="${s.enabled ? '点击关闭' : '点击开启'}" aria-label="启用状态"></button>
            <button class="btn ghost small" data-act="pick" ${s.enabled ? '' : 'disabled'}>随机</button>
          </div>
        </div>
      </div>`).join('');
  }

  async function refresh() {
    const s = await api('/api/sites');
    const kinds = Object.fromEntries((s.kinds || []).map((k) => [k.kind, k.label]));
    sites = (s.sites || []).map((x) => ({ ...x, kindLabel: kinds[x.kind] || x.kind }));
    renderSites();
  }

  /* ------------------------------ 随机抽取 ------------------------------ */

  function setBusy(busy) {
    const btn = $('#btn-flip');
    btn.disabled = busy;
    btn.querySelector('span').textContent = busy ? '抽取中…' : '随机全部';
  }

  /**
   * 抽取后在新标签打开。
   * pick 是异步的，等返回再 window.open 会被浏览器的弹窗拦截器拦掉，
   * 所以在点击手势内先同步开一个空白标签写入提示，抓到后跳转过去。
   */
  function openLoadingWindow() {
    const w = window.open('about:blank', '_blank');
    if (w) {
      try {
        w.document.write('<meta charset="utf-8"><title>随机盒子</title>'
          + '<body style="font-family:system-ui,sans-serif;display:flex;align-items:center;'
          + 'justify-content:center;height:100vh;margin:0;color:#777"><p>抽取中，请稍候…</p></body>');
        w.document.close();
      } catch { /* 某些环境不让写 about:blank，空着也行 */ }
    }
    return w;
  }

  async function doFlip(siteId) {
    setBusy(true);
    const win = openLoadingWindow();
    try {
      const data = await post('/api/pick', { siteId: siteId || undefined });
      const item = data.item;
      if (item.openMode === 'text') {
        writeTextPage(win, item);
      } else {
        const url = item.url;
        if (win) win.location.href = url;
        else window.open(url, '_blank', 'noopener');
      }
    } catch (e) {
      if (win) win.close();
      toast(e.message || '抽取失败', 'error');
    } finally {
      setBusy(false);
    }
  }

  /** 无 URL 的内容（签文/诗词）直接在预开窗口里排版展示 */
  function writeTextPage(win, item) {
    if (!win) { toast(`${item.title}：${(item.text || '').slice(0, 120)}`); return; }
    try {
      win.document.write(`<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>${item.title}</title><style>
body{font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
background:#f6f5fb;color:#221f31;margin:0;padding:48px 20px;line-height:2}
.sheet{max-width:640px;margin:0 auto;background:#fff;border:1px solid #e6e3f0;
border-radius:16px;padding:36px 40px;box-shadow:0 8px 24px rgba(34,31,49,.06)}
h1{font-size:18px;margin:0 0 18px;color:#7c3aed}
pre{white-space:pre-wrap;word-break:break-word;font:inherit;margin:0}
footer{margin-top:26px;font-size:12px;color:#8d88a0}
</style></head><body><div class="sheet"><h1>${item.title}</h1>
<pre>${item.text}</pre>
<footer>随机盒子 · ${item.siteName || ''}</footer></div></body></html>`);
      win.document.close();
    } catch { /* 窗口可能已被用户关掉 */ }
  }

  /* ------------------------------ 启动 ------------------------------ */

  /**
   * 把 JSOS 的 CORS 代理配置上报给服务端。
   * WebContainer 内服务端直连外站会被 CORS 拦掉，抓取层需要代理兜底；
   * 本机直跑时拿不到 window.JSOS，跳过上报（直连本来就能通）。
   */
  async function relayProxyConfig() {
    try {
      const cfg = await window.JSOS?.getProxyConfig?.();
      if (cfg && cfg.url) await post('/api/relay', { url: cfg.url, key: cfg.key });
    } catch { /* 拿不到就算了，直连优先 */ }
  }

  function bind() {
    $('#btn-flip').addEventListener('click', () => doFlip());

    // 站点列表：开关 + 单站随机（按 data-id 定位，不用数组下标）
    $('#site-list').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const id = btn.closest('.site-card')?.dataset.id;
      if (!id) return;

      if (btn.dataset.act === 'toggle') {
        try {
          const r = await post(`/api/sites/${encodeURIComponent(id)}/toggle`);
          sites = r.sites || sites;
          renderSites();
        } catch (err) { toast(err.message, 'error'); }
      } else if (btn.dataset.act === 'pick') {
        doFlip(id);
      }
    });
  }

  bind();
  relayProxyConfig();
  refresh().catch((e) => toast('加载失败：' + e.message, 'error'));
})();
