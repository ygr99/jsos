import express from 'express';
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const DB_DIR = join(DATA_DIR, 'db');
const ASSETS_DIR = join(DATA_DIR, 'assets');

app.use(express.json({ limit: '40mb' }));
app.use(express.static(join(__dirname, 'public')));

// ---------- uTools db 的服务端备份仓 ----------
// 注意：主存储在应用前端（内存 + IndexedDB，见 public/utools-shim.js）。
// 部署环境的预览代理只放行 GET（PUT/POST/DELETE 全 403），所以服务端只是
// 「本机直跑时」的持久化备份，前端同步失败完全不影响应用运行。
function dbFile(id) { return join(DB_DIR, encodeURIComponent(id) + '.json'); }
function readDoc(id) {
  const f = dbFile(id);
  if (!existsSync(f)) return null;
  try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return null; }
}
function writeDoc(doc) {
  mkdirSync(DB_DIR, { recursive: true });
  writeFileSync(dbFile(doc._id), JSON.stringify(doc), 'utf8');
}

app.get('/api/db-all', (req, res) => {
  mkdirSync(DB_DIR, { recursive: true });
  const docs = [];
  for (const f of readdirSync(DB_DIR)) {
    if (!f.endsWith('.json')) continue;
    try { docs.push(JSON.parse(readFileSync(join(DB_DIR, f), 'utf8'))); } catch {}
  }
  res.json(docs);
});

app.get('/api/db/*', (req, res) => {
  res.json(readDoc(decodeURIComponent(req.params[0])));
});

// 前端同步（尽力而为）：带 _rev 冲突检测的常规写
app.post('/api/db/*', (req, res) => {
  const id = decodeURIComponent(req.params[0]);
  const incoming = req.body;
  if (!incoming || incoming._id !== id) return res.json({ error: true, message: '文档 _id 与路径不一致' });
  const stored = readDoc(id);
  if (stored && stored._rev !== incoming._rev) {
    return res.json({ error: true, message: '服务端文档版本较旧，跳过同步' });
  }
  const rev = '1-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  writeDoc({ ...incoming, _id: id, _rev: rev });
  res.json({ id, rev });
});

// 前端同步（强制覆盖）：前端是唯一写入方，冲突时以前端为准
app.post('/api/db-force/*', (req, res) => {
  const id = decodeURIComponent(req.params[0]);
  const incoming = req.body;
  if (!incoming || incoming._id !== id) return res.json({ error: true, message: '文档 _id 与路径不一致' });
  writeDoc({ ...incoming, _id: id });
  res.json({ id, rev: incoming._rev || null });
});

app.delete('/api/db/*', (req, res) => {
  const id = decodeURIComponent(req.params[0]);
  if (!readDoc(id)) return res.json({ error: true, message: '文档不存在' });
  unlinkSync(dbFile(id));
  res.json({ id });
});

app.post('/api/db-attachment', (req, res) => {
  const { id, contentType, data } = req.body || {};
  if (typeof id !== 'string' || !id || typeof data !== 'string') {
    return res.json({ error: true, message: '参数不完整' });
  }
  const rev = '1-' + Date.now().toString(36);
  writeDoc({ _id: id, _rev: rev, _attachments: [{ content_type: contentType || 'application/octet-stream', data }] });
  res.json({ id, rev });
});

app.get('/api/db-attachment/*', (req, res) => {
  const doc = readDoc(decodeURIComponent(req.params[0]));
  const a = doc && doc._attachments && doc._attachments[0];
  if (!a) return res.status(404).end();
  res.set('Content-Type', a.content_type).send(Buffer.from(a.data, 'base64'));
});

// ---------- 图片直读（兼容入口；预览主链路已走前端 blob: URL） ----------
app.get('/api/attachment/:digest', (req, res) => {
  const doc = readDoc('attachment/' + req.params.digest);
  const a = doc && doc._attachments && doc._attachments[0];
  if (!a) return res.status(404).end();
  res.set('Content-Type', a.content_type).send(Buffer.from(a.data, 'base64'));
});

// ---------- 独立图片仓（saveImgToFileBySrc；部署模式下前端会静默降级） ----------
app.post('/api/attachment-store', (req, res) => {
  const { digest, contentType, data } = req.body || {};
  if (typeof digest !== 'string' || !/^[0-9a-f]{32}$/.test(digest) || typeof data !== 'string') {
    return res.status(400).json({ error: '参数不完整' });
  }
  const ext = { 'image/bmp': '.bmp', 'image/gif': '.gif', 'image/jpeg': '.jpg', 'image/png': '.png', 'image/svg+xml': '.svg', 'image/webp': '.webp' }[contentType] || '.png';
  mkdirSync(ASSETS_DIR, { recursive: true });
  writeFileSync(join(ASSETS_DIR, digest + ext), Buffer.from(data, 'base64'));
  res.json({ url: `/assets/${digest}${ext}` });
});
app.use('/assets', express.static(ASSETS_DIR));

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`md-notes running on ${port}`));
