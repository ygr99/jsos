/* uTools API 垫片 —— 让官方「Markdown 笔记」插件的 bundle 原样跑在 JSOS 里
 *
 * 数据架构（第一性原理）：uTools 的 db 本来就是本地数据库，浏览器里的等价物是
 * iframe 自己的 IndexedDB —— 全量载入内存后同步语义与 uTools 完全一致。
 * 服务端 DATA_DIR/db 只是「本机直跑时」的尽力而为备份：部署环境的预览代理
 * 只放行 GET（PUT/POST/DELETE 全部 403），所以一切写失败都不影响应用运行。
 *   - 本机直跑：内存 + IndexedDB + 服务端备份（容器重建后可从服务端恢复）
 *   - 部署代理：内存 + IndexedDB（数据随容器重建丢失，与 uTools 本地库一致）
 * subInput（uTools 全局搜索条）→ 页面顶部假搜索条
 */
(function () {
  'use strict';

  // ---------- 同步 XHR / base64 工具 ----------
  function jsonSync(method, url, body) {
    try {
      const x = new XMLHttpRequest();
      x.open(method, url, false);
      if (body !== undefined) x.setRequestHeader('Content-Type', 'application/json');
      x.send(body === undefined ? null : JSON.stringify(body));
      return x.status >= 200 && x.status < 300 ? JSON.parse(x.responseText) : null;
    } catch {
      return null;
    }
  }
  function bytesToBase64(bytes) {
    let bin = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
    }
    return btoa(bin);
  }
  function base64ToBytes(b64) {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }

  // ---------- 粘贴暂存（剪贴板读取需要同步返回，靠 paste 捕获阶段先囤起来） ----------
  const clipboardStash = { text: '', html: '' };
  const clipboardImages = new Map();   // blobUrl -> {name, type}
  window.addEventListener('paste', (e) => {
    try {
      const dt = e.clipboardData;
      if (!dt) return;
      if (dt.getData('text/plain')) clipboardStash.text = dt.getData('text/plain');
      if (dt.getData('text/html')) clipboardStash.html = dt.getData('text/html');
      for (const item of dt.items) {
        if (!item.type.startsWith('image/')) continue;
        const f = item.getAsFile();
        if (!f) continue;
        // 给 File 补一个 path 属性（electron 文件有 .path，浏览器没有），
        // 让插件的「1 个图片文件 + t.path」粘贴分支继续工作；值是 blob: URL，同步可读
        const blobUrl = URL.createObjectURL(f);
        clipboardImages.set(blobUrl, { name: '截图', type: f.type });
        try { Object.defineProperty(f, 'path', { value: blobUrl, configurable: true }); } catch {}
      }
    } catch {}
  }, true);

  // ---------- db：内存 + IndexedDB 持久化 + 服务端尽力同步 ----------
  const DB_NAME = 'mdnotes-db';
  const STORE_DOCS = 'docs';
  const docsMap = new Map();           // _id -> doc（唯一写入方，同步语义）
  let revSeq = 0;
  let serverWritable = null;           // null=未探测 / true / false
  let idbPromise = null;

  function nextRev() {
    return '2-' + Date.now().toString(36) + '-' + (++revSeq);
  }
  function idbOpen() {
    if (idbPromise) return idbPromise;
    idbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => {
          if (!req.result.objectStoreNames.contains(STORE_DOCS)) {
            req.result.createObjectStore(STORE_DOCS, { keyPath: '_id' });
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
        req.onblocked = () => resolve(null);
      } catch { resolve(null); }
    });
    return idbPromise;
  }
  function idbPut(db, doc) {
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_DOCS, 'readwrite');
        tx.objectStore(STORE_DOCS).put(doc);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
        tx.onabort = () => resolve(false);
      } catch { resolve(false); }
    });
  }
  function idbDelete(db, id) {
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_DOCS, 'readwrite');
        tx.objectStore(STORE_DOCS).delete(id);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
        tx.onabort = () => resolve(false);
      } catch { resolve(false); }
    });
  }
  function idbGetAll(db) {
    return new Promise((resolve) => {
      try {
        const req = db.transaction(STORE_DOCS, 'readonly').objectStore(STORE_DOCS).getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve(null);
      } catch { resolve(null); }
    });
  }

  // 写入后的持久化：IndexedDB 立即落（不阻塞），服务端尽力同步（部署代理下静默失败）
  function persistDoc(doc, removed) {
    (async () => {
      const idb = await idbOpen();
      if (idb) {
        if (removed) await idbDelete(idb, doc._id);
        else await idbPut(idb, doc);
      }
    })();
    (async () => {
      if (serverWritable === false) return;
      try {
        if (removed) {
          const r = await fetch('/api/db-delete/' + encodeURIComponent(doc._id), {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rev: doc._rev || '' }),
          });
          serverWritable = r.ok;
        } else {
          const r = await fetch('/api/db-force/' + encodeURIComponent(doc._id), {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(doc),
          });
          serverWritable = r.ok;
        }
      } catch { serverWritable = false; }
    })();
  }

  const db = {
    get(id) {
      if (typeof id !== 'string' || !id) return null;
      const d = docsMap.get(id);
      return d ? JSON.parse(JSON.stringify(d)) : null;
    },
    put(doc) {
      if (!doc || typeof doc._id !== 'string' || !doc._id) return { error: true, message: '文档缺少 _id' };
      const stored = JSON.parse(JSON.stringify(doc));
      stored._id = doc._id;
      stored._rev = nextRev();
      docsMap.set(doc._id, stored);
      persistDoc(stored, false);
      return { id: doc._id, rev: stored._rev };
    },
    remove(doc) {
      const id = doc && doc._id;
      if (typeof id !== 'string' || !id || !docsMap.has(id)) return { error: true, message: '文档不存在' };
      const old = docsMap.get(id);
      docsMap.delete(id);
      persistDoc({ _id: id, _rev: old._rev }, true);
      return { id, rev: old._rev };
    },
    postAttachment(id, data, contentType) {
      if (typeof id !== 'string' || !id) return { error: true, message: '附件缺少 _id' };
      if (docsMap.has(id)) return { error: true, message: '附件已存在' };
      const doc = {
        _id: id,
        _rev: nextRev(),
        _attachments: [{
          content_type: contentType || 'application/octet-stream',
          data: bytesToBase64(data instanceof Uint8Array ? data : new Uint8Array(data)),
        }],
      };
      docsMap.set(id, doc);
      persistDoc(doc, false);
      return { id, rev: doc._rev };
    },
    getAttachment(id) {
      const doc = docsMap.get(id);
      const a = doc && doc._attachments && doc._attachments[0];
      return a ? base64ToBytes(a.data) : null;
    },
    // 同步版全量枚举
    allDocs() {
      return [...docsMap.values()].map((d) => JSON.parse(JSON.stringify(d)));
    },
    // uTools 云同步：无云端，返回 true 让应用跳过"清理无引用附件"分支（避免误删）
    replicateStateFromCloud() {
      return true;
    },
    promises: {
      async allDocs() {
        return [...docsMap.values()].map((d) => JSON.parse(JSON.stringify(d)));
      },
    },
  };

  // ---------- dbStorage（排序等键值；同步语义，localStorage 承载） ----------
  const dbStorage = {
    setItem(key, value) {
      try { localStorage.setItem('mdnotes-kv-' + key, JSON.stringify(value === undefined ? null : value)); } catch {}
    },
    getItem(key) {
      try {
        const s = localStorage.getItem('mdnotes-kv-' + key);
        return s === null ? null : JSON.parse(s);
      } catch { return null; }
    },
    removeItem(key) {
      try { localStorage.removeItem('mdnotes-kv-' + key); } catch {}
    },
  };

  // ---------- 假 subInput（搜索条，挂在左侧 sidebar-body 顶部） ----------
  let subInputCb = null;
  let subInputActive = false;
  const ShimSubInput = (() => {
    let bar = null, input = null, retryTimer = null;
    function mount() {
      if (bar && bar.isConnected) return true;
      const host = document.querySelector('.sidebar-body');
      if (!host) return false;   // 侧栏尚未渲染
      bar = document.createElement('div');
      bar.id = 'utools-shim-subinput';
      bar.style.cssText = 'padding:10px 10px 4px;';
      input = document.createElement('input');
      input.type = 'text';
      input.style.cssText = 'width:100%;box-sizing:border-box;padding:6px 10px;border-radius:6px;border:1px solid #d0d7de;font-size:13px;outline:none;background:#fff;color:#24292f;';
      bar.appendChild(input);
      host.insertBefore(bar, host.firstChild);
      input.addEventListener('input', () => {
        // uTools subInput 回调形状：{ text: 输入内容 }（bundle 里 handleSearch 解构 {text}）
        if (subInputCb) { try { subInputCb({ text: input.value }); } catch {} }
      });
      return true;
    }
    function ensure() {
      subInputActive = true;
      if (mount()) return;
      clearInterval(retryTimer);
      let tries = 0;
      retryTimer = setInterval(() => {
        if (mount() || ++tries > 40) clearInterval(retryTimer);
      }, 250);
    }
    // React 重渲染会拔掉外插节点：活跃期间监视并重新挂载
    document.addEventListener('DOMContentLoaded', () => {
      new MutationObserver(() => {
        if (subInputActive && (!bar || !bar.isConnected)) mount();
      }).observe(document.documentElement, { childList: true, subtree: true });
    });
    return {
      show(placeholder) { ensure(); if (input) input.placeholder = placeholder || '搜索'; },
      focus() { ensure(); if (input) input.focus(); },
      blur() { if (input) input.blur(); },
      setValue(v) {
        ensure();
        if (input) {
          input.value = v == null ? '' : v;
          if (subInputCb) { try { subInputCb({ text: input.value }); } catch {} }
        }
      },
    };
  })();

  // ---------- 侧栏树行标题高亮（伪元素文字，Range 走不到） ----------
  // 树行的标题不是真实文本，而是 CSS 伪元素生成的：
  //   .sidebar-node-leaf > div::after { content: attr(data-name) }
  //   渲染：createElement("div", { title: n.title, "data-name": n.title })
  // 后果：div 里没有 text node，TreeWalker 走不到、CSS Highlight 也无 Range 可标。
  // 实测（Chrome 154）：div.childNodes.length === 0、div.textContent === ""。
  // 办法：搜索期把该 div 的 ::after 关掉、灌入真实文本节点，退出搜索再还原。
  //   —— 不碰 react 的 props/state（虚拟列表滚动复用节点，改 props 会被覆盖），
  //      只在渲染完成后动 DOM，并用 MutationObserver 跟随列表重渲染补齐。
  const ShimTreeHighlight = (() => {
    const STYLE_ID = 'mdnotes-tree-find-style';
    let term = '';
    const patched = new WeakSet();   // 本轮已灌文本的 div，退出搜索时还原

    function styleEl() {
      let el = document.getElementById(STYLE_ID);
      if (el) return el;
      el = document.createElement('style');
      el.id = STYLE_ID;
      // 灌了真实文本就必须关掉伪元素，否则同一标题显示两遍
      el.textContent = '.sidebar-node-leaf > div[data-mdnotes-lit]::after,' +
        '.sidebar-node-folder > div[data-mdnotes-lit]::after{content:none !important}';
      document.head.appendChild(el);
      return el;
    }
    // 把某行 div 的标题灌成真实文本，并返回其中命中的 Range
    function lightRow(div) {
      const name = div.getAttribute('data-name') || '';
      if (!name) return [];
      if (patched.has(div)) { div.removeAttribute('data-mdnotes-lit'); patched.delete(div); }
      div.textContent = name;                 // 真实 text node，TreeWalker/Highlight 都能走
      div.setAttribute('data-mdnotes-lit', '1');
      patched.add(div);
      const lower = name.toLowerCase();
      const t = term.toLowerCase();
      const out = [];
      let from = 0, at;
      while ((at = lower.indexOf(t, from)) !== -1) {
        const r = document.createRange();
        r.setStart(div.firstChild, at);
        r.setEnd(div.firstChild, at + t.length);
        out.push(r);
        from = at + t.length;
      }
      return out;
    }
    function revertAll() {
      for (const el of document.querySelectorAll('[data-mdnotes-lit]')) {
        el.removeAttribute('data-mdnotes-lit');
        el.textContent = '';                   // 交回伪元素渲染
      }
    }
    // 扫描当前可见的树行（虚拟列表只渲染视口内的，所以每次都重扫）
    function scan() {
      if (!term || !CSS.highlights) return [];
      styleEl();
      const rows = document.querySelectorAll(
        '.sidebar-node-leaf > div[data-name], .sidebar-node-folder > div[data-name]');
      const out = [];
      for (const div of rows) {
        if ((div.getAttribute('data-name') || '').toLowerCase().includes(term.toLowerCase())) {
          out.push(...lightRow(div));
        } else {
          // 未命中的行也要灌文本，否则整个列表会出现"有的行有字、有的行空"
          lightRow(div);
        }
      }
      return out;
    }
    return {
      setTerm(t) { term = t || ''; },
      scan,
      revertAll,
      isActive() { return !!term; },
    };
  })();

  // uTools 的窗口内查找高亮由宿主实现，插件只调 findInPage/stopFindInPage。
  // 移植到浏览器后这两个 API 原本是空实现 → 搜索时编辑器正文一个高亮都没有。
  // 实现约束（第一性原理）：
  //   1) 编辑器是 Slate，`[data-slate-node="text"]` 里直接放 text node。
  //      往里插 <mark> 会让 Slate 与 DOM 结构失配（下次 reconcile 直接崩），
  //      所以**不能改 DOM**。
  //   2) 用 CSS Custom Highlight API（Chrome 105+）：只往 Range 上打标记，
  //      由浏览器渲染层着色，DOM 零改动 → Slate 完全无感。
  const ShimFindInPage = (() => {
    const HL = 'mdnotes-find';
    const HL_CUR = 'mdnotes-find-current';
    let ranges = [];       // 正文全部命中
    let treeRanges = [];   // 侧栏树标题命中（标题优先，Enter 先在这里跳）
    let current = -1;      // 当前命中的下标（Enter 键逐个跳）
    let lastTerm = '';     // 上次查找的词，用来判断是"继续跳"还是"重新找"

    function styleEl() {
      let el = document.getElementById('mdnotes-find-style');
      if (el) return el;
      el = document.createElement('style');
      el.id = 'mdnotes-find-style';
      el.textContent =
        '::highlight(' + HL + '){background:#ffe58f;color:inherit}' +
        '::highlight(' + HL_CUR + '){background:#ff9f43;color:inherit}';
      document.head.appendChild(el);
      return el;
    }
    function clear() {
      if (!CSS.highlights) return;
      CSS.highlights.delete(HL);
      CSS.highlights.delete(HL_CUR);
      ranges = [];
      treeRanges = [];
      current = -1;
      ShimTreeHighlight.revertAll();     // 退出搜索：树行文字交回伪元素渲染
    }
    // 只重绘、不动 current —— findNext 要靠它接着往下跳
    function clearPaint() {
      if (!CSS.highlights) return;
      CSS.highlights.delete(HL);
      CSS.highlights.delete(HL_CUR);
    }
    // 遍历编辑器文本节点，收集命中 Range
    function collect(term) {
      const out = [];
      const host = document.querySelector('.editor-body') || document.body;
      const walker = document.createTreeWalker(host, NodeFilter.SHOW_TEXT);
      const lower = term.toLowerCase();
      let node;
      while ((node = walker.nextNode())) {
        const text = node.nodeValue.toLowerCase();
        let from = 0, at;
        while ((at = text.indexOf(lower, from)) !== -1) {
          const r = document.createRange();
          r.setStart(node, at);
          r.setEnd(node, at + term.length);
          out.push(r);
          from = at + term.length;
        }
      }
      return out;
    }
    function paint(idx) {
      styleEl();
      // 树标题只参与"总高亮着色"，不进当前项（橙色）与 findNext 循环 —— 与原版一致：
      // 原版 handleSelect 选中树行后调的是 findInPage()（无 findNext），只重新定位、
      // 不推进游标；findNext:true 只有 keydown 按 Enter 才会传，而那时人在正文。
      const all = [...treeRanges, ...ranges];
      CSS.highlights.set(HL, new Highlight(...all));
      current = idx;
      const cur = ranges[idx];
      if (idx >= 0 && cur) {
        CSS.highlights.set(HL_CUR, new Highlight(cur));
        scrollIntoViewIfNeeded(cur);
      } else {
        CSS.highlights.delete(HL_CUR);
      }
    }
    function scrollIntoViewIfNeeded(range) {
      // 复用全局 nearest 垫片：直接 scrollIntoView 可能把外层 JSOS 窗口卷动
      // （九韵笺同款"底部透明"bug，见下方 scrollIntoView 补丁）
      try {
        const el = range.startContainer.parentElement;
        if (!el) return;
        // 树行标题：滚它所在的虚拟列表容器，不是 .editor-body
        const inTree = !!el.closest('.sidebar-tree');
        const scroller = inTree
          ? (el.closest('.sidebar-tree') || document.body)
          : (document.querySelector('.editor-body') || document.body);
        const rect = range.getBoundingClientRect();
        const host = scroller.getBoundingClientRect();
        if (rect.top < host.top || rect.bottom > host.bottom) {
          el.scrollIntoView({ block: 'center' });
        }
      } catch {}
    }
    return {
      find(term, opt) {
        if (!CSS.highlights) return;
        const t = String(term == null ? '' : term).trim();
        if (!t) { clear(); return; }
        const wantNext = !!(opt && opt.findNext);
        // 同一个词连续查找时保留 current，Enter 才能一路跳下去（bundle 传 {findNext:true}）
        // 树是虚拟列表、每次滚动都换一批节点 → 无论如何都要重扫树
        if (!wantNext || lastTerm !== t) current = -1;
        lastTerm = t;
        clearPaint();
        ShimTreeHighlight.setTerm(t);
        treeRanges = ShimTreeHighlight.scan();
        ranges = collect(t);
        // 游标只在正文里走：树标题只着色，不参与跳转（paint 里也只从 ranges 取当前项）
        if (!ranges.length) { paint(-1); return; }
        paint(wantNext && current >= 0 ? (current + 1) % ranges.length : 0);
      },
      clear() { lastTerm = ''; clear(); },
      // 侧栏虚拟列表滚动后重扫并重绘（不清 current，Enter 不会跳飞）
      repaint() {
        if (!lastTerm || !CSS.highlights) return;
        treeRanges = ShimTreeHighlight.scan();
        ranges = collect(lastTerm);
        styleEl();
        const all = [...treeRanges, ...ranges];
        if (all.length) CSS.highlights.set(HL, new Highlight(...all));
        else CSS.highlights.delete(HL);
        if (current >= 0 && current < ranges.length) {
          CSS.highlights.set(HL_CUR, new Highlight(ranges[current]));
        } else {
          CSS.highlights.delete(HL_CUR);
        }
      },
    };
  })();

  // 搜索期侧栏树重渲染（虚拟列表滚动 / 过滤后换节点）就补一次高亮。
  // 用 rAF 节流：MutationObserver 在虚拟滚动时每帧都可能触发。
  (() => {
    let queued = false;
    const pump = () => {
      queued = false;
      if (!ShimFindInPage.repaint) return;
      ShimFindInPage.repaint();
    };
    new MutationObserver(() => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(pump);
    }).observe(document.documentElement, { childList: true, subtree: true });
  })();

  // bundle 内部与浏览器原生（光标显现/焦点滚动）的滚动请求，在内容触底时会
  // 把溢出量链式卷动到外层 JSOS 窗口（iframe 包装层上移 28px，底部透明且不自愈）。
  // 全局拦一层 scrollIntoView 强制 nearest：就近滚动，永远在滚动容器内可满足。
  (() => {
    const orig = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function (arg) {
      const safe = (typeof arg === 'object' && arg) ? { ...arg, block: 'nearest', inline: 'nearest' } : arg;
      window.__mdnotesLastScrollIntoView = safe;
      try { return orig.call(this, safe); } catch { try { orig.call(this); } catch {} }
    };
  })();

  // ---------- 抑制浏览器原生右键菜单 ----------
  // 插件自带右键菜单（文件夹/笔记/编辑器），但个别路径没拦默认行为，
  // 原生菜单会弹出来顶掉自绘菜单。捕获阶段只取消默认行为，不阻断传播，
  // 插件自己的 contextmenu 处理器照常工作。
  window.addEventListener('contextmenu', (e) => e.preventDefault(), true);

  // ---------- 事件监听 ----------
  const enterCbs = [];
  const outCbs = [];
  let enterFired = false;
  let lastEnterPayload = null;

  // ---------- utools ----------
  window.utools = {
    isMacOS: () => false,
    isWindows: () => true,
    isLinux: () => false,
    getNativeId: () => '',
    // 插件启动时做版本门槛检查：parseFloat(getAppVersion()) < 7.2 会渲染"请升级 uTools"拦截页
    getAppVersion: () => '9.9.9',
    getPath: (name) => 'C:/JSOS/' + (name || 'downloads'),
    db,
    dbStorage,
    onPluginEnter(cb) {
      if (typeof cb !== 'function') return;
      enterCbs.push(cb);
      // bundle 注册晚于派发时（慢网络/大文件），立即补发，绝不让应用卡在"读取中"
      if (enterFired && lastEnterPayload) { try { cb(lastEnterPayload); } catch (e) { console.error(e); } }
    },
    onPluginOut(cb) { if (typeof cb === 'function') outCbs.push(cb); },
    onDbPull() {},
    outPlugin() {},
    hideMainWindow() {},
    removeFeature() {},
    setFeature() {},
    registerTool() {},
    setSubInput(cb, placeholder) {
      subInputCb = typeof cb === 'function' ? cb : null;
      ShimSubInput.show(placeholder);
    },
    subInputFocus() { ShimSubInput.focus(); },
    subInputBlur() { ShimSubInput.blur(); },
    setSubInputValue(v) { ShimSubInput.setValue(v); },
    // 浏览器文件选择是异步的，无法同步返回路径（原 API 为同步）→ 返回 null
    showOpenDialog() { return null; },
    showSaveDialog() { return null; },
    showNotification(m) { console.log('[通知] ' + m); },
    copyText(t) { try { navigator.clipboard.writeText(String(t)); } catch {} },
    copyFile() {},
    startDrag() {},
    findInPage(term, opt) { ShimFindInPage.find(term, opt); },
    stopFindInPage() { ShimFindInPage.clear(); },
    shellOpenExternal(url) { try { window.open(url, '_blank'); } catch {} },
    shellOpenPath(p) { if (window.services) window.services.shellOpenPath(p); },
    shellShowItemInFolder() {},
    allAiModels() { return Promise.resolve([]); },
    ai() { return Promise.reject(new Error('JSOS 环境暂不支持 AI 功能')); },
    _fireEnter(payload) {
      enterFired = true;
      lastEnterPayload = payload;
      enterCbs.forEach((cb) => { try { cb(payload); } catch (e) { console.error(e); } });
    },
    _fireOut() { outCbs.forEach((cb) => { try { cb(); } catch {} }); },
  };

  window.addEventListener('pagehide', () => { try { window.utools._fireOut(); } catch {} });

  // ---------- 预览图片地址修正 ----------
  // 插件预览把 attachment:<md5> 重写为 file:// + getAttachmentTempPath() 返回值；
  // 垫片返回 blob: URL（从内存生成，不经 HTTP），这里把多余的 file:// 前缀去掉
  function fixImg(img) {
    const s = img.getAttribute('src') || '';
    if (s.startsWith('file://')) {
      const rest = s.slice('file://'.length);
      if (rest.startsWith('blob:') || rest.startsWith('/api/')) img.setAttribute('src', rest);
    }
  }
  document.addEventListener('DOMContentLoaded', () => {
    const obs = new MutationObserver((muts) => {
      for (const m of muts) {
        if (m.type === 'attributes') fixImg(m.target);
        for (const n of m.addedNodes) {
          if (n.nodeType !== 1) continue;
          if (n.tagName === 'IMG') fixImg(n);
          else if (n.querySelectorAll) {
            n.querySelectorAll('img[src^="file://"]').forEach(fixImg);
          }
        }
      }
    });
    obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
  });

  // ---------- 启动：预取静态资源 → 加载本地库（空则尝试服务端恢复）→ 派发 onPluginEnter ----------
  const bootState = { firstMd: '', githubCss: '', katexCss: '', clipboardStash, clipboardImages };
  window.__mdnotesBoot = bootState;
  (async function boot() {
    const get = (u) => fetch(u).then((r) => (r.ok ? r.text() : '')).catch(() => '');
    bootState.firstMd = await get('first.md');
    bootState.githubCss = await get('export-file/github-markdown.css');
    bootState.katexCss = await get('katex-inline.css');

    const idb = await idbOpen();
    let localDocs = idb ? (await idbGetAll(idb)) || [] : [];
    let serverDocs = null;
    try {
      const r = await fetch('/api/db-all');
      if (r.ok) serverDocs = await r.json();
    } catch {}
    // 本地库为空而服务端有备份（本机直跑、容器重建后）→ 从服务端恢复
    const source = (Array.isArray(serverDocs) && serverDocs.length && !localDocs.length) ? serverDocs : localDocs;
    for (const d of source) {
      if (d && typeof d._id === 'string') docsMap.set(d._id, d);
    }
    if (source === serverDocs && idb) {
      for (const d of serverDocs) await idbPut(idb, d);
    }

    // 等 bundle 注册 onPluginEnter 后再派发（2.2MB 的 index.js 在慢网络下执行更晚；
    // 派发早了会落空，应用永远停在"读取中..."）——最多等 10s，晚注册的靠补发兜底
    for (let i = 0; i < 200 && !enterCbs.length; i++) {
      await new Promise((r) => setTimeout(r, 50));
    }
    setTimeout(() => window.utools._fireEnter({ type: 'text', code: 'notes', payload: '' }), 30);
  })();
})();
