﻿/* window.services 垫片 —— 把插件 preload.js 从 electron/fs 移植到浏览器 + JSOS 服务端
 * 导出：Markdown/HTML 直接 Blob 下载；PDF 走打印窗口；图片走 html2canvas
 * 附件图片：统一走同源 /api/attachment/<md5>
 */
(function () {
  'use strict';

  const boot = window.__mdnotesBoot || {};
  const md5fn = window.md5;   // vendor 的 blueimp-md5

  // 摘要：对 base64 字符串做 md5（blueimp-md5 不支持按字节哈希；
  // 摘要只要求内部自洽——同字节同摘要，供去重与 attachment:<md5> 引用）
  function digestOf(bytes) {
    return md5fn(bytesToBase64(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)));
  }

  // ---------- 小工具 ----------
  function xhrText(method, url, body, contentType) {
    const x = new XMLHttpRequest();
    x.open(method, url, false);
    if (contentType) x.setRequestHeader('Content-Type', contentType);
    x.send(body === undefined ? null : body);
    return x.status >= 200 && x.status < 300 ? x.responseText : null;
  }
  function jsonSync(method, url, body) {
    const t = xhrText(method, url, body === undefined ? null : JSON.stringify(body), 'application/json');
    return t === null ? null : JSON.parse(t);
  }
  function xhrBytes(url) {
    const x = new XMLHttpRequest();
    x.open('GET', url, false);
    x.overrideMimeType('text/plain; charset=x-user-defined');
    x.send(null);
    if (x.status < 200 || x.status >= 300) return null;
    const raw = x.responseText;
    const u8 = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) u8[i] = raw.charCodeAt(i) & 0xff;
    return u8;
  }
  function bytesToBase64(bytes) {
    let bin = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
    }
    return btoa(bin);
  }
  function dataUrlToBytes(dataUrl) {
    const m = /^data:([^;,]+)?(;base64)?,([\s\S]*)$/.exec(dataUrl);
    if (!m) return null;
    if (m[2]) {
      const bin = atob(m[3]);
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      return { bytes: u8, contentType: m[1] || 'application/octet-stream' };
    }
    return { bytes: new TextEncoder().encode(decodeURIComponent(m[3])), contentType: m[1] || 'text/plain' };
  }
  function sanitizeName(name) {
    return String(name == null ? '' : name).replace(/[/\\]/g, '').trim() || String(Date.now());
  }
  function download(name, blob) {
    const a = document.createElement('a');
    a.download = name;
    a.style.display = 'none';
    a.href = URL.createObjectURL(blob);
    document.body.appendChild(a);
    a.click();
    a.remove();
  }
  function downloadText(name, text, mime) {
    download(name, new Blob([text], { type: mime }));
  }

  // ---------- 附件（读内存库，不经 HTTP；部署代理模式下服务端不可写） ----------
  function memDoc(digest) {
    try { return window.utools.db.get('attachment/' + digest); } catch { return null; }
  }
  function attachmentDataUrl(digest) {
    const doc = memDoc(digest);
    const a = doc && doc._attachments && doc._attachments[0];
    if (!a) return null;
    return 'data:' + a.content_type + ';base64,' + a.data;
  }
  // getAttachmentTempPath 生成的 blob: URL → base64 暂存（导出 HTML 内联用，同步可查）
  const blobUrlB64 = new Map();
  // 把渲染结果里的图片地址内联成 dataURL：blob:（内存附件）或 /api/attachment/（服务端兜底）
  function inlineAttachmentUrls(text) {
    if (!text) return text;
    return String(text)
      .replace(/src="(blob:[^"]+)"/g, (m, url) => {
        const b64 = blobUrlB64.get(url);
        if (!b64) return m;
        const meta = (boot.clipboardImages || new Map()).get(url);
        return 'src="data:' + ((meta && meta.type) || 'image/png') + ';base64,' + b64 + '"';
      })
      .replace(/(?:file:\/\/)?\/api\/attachment\/([0-9a-f]{32})/g, (m, digest) => {
        return attachmentDataUrl(digest) || m;
      });
  }

  // ---------- 导出 ----------
  const exportStash = new Map();   // 'export:<name>' -> Blob（供 shellOpenPath 再次下载）
  const shellOpen = (name, blob) => {
    exportStash.set(name, blob);
    download(name, blob);
  };

  function exportHtmlString(title, bodyHtml, extraCss, includeKatex) {
    const githubCss = boot.githubCss || '';
    const katexCss = includeKatex ? (boot.katexCss || '') : '';
    return '<!doctype html>\n<html>\n<head>\n<meta charset="utf-8"/>\n<title>' + title + '</title>\n'
      + (katexCss ? '<style>' + katexCss + '</style>\n' : '')
      + '<style>\nhtml, body { margin: 0; padding: 0; background-color: #ffffff; }\n'
      + '.markdown-body { box-sizing: border-box; min-width: 200px; max-width: 980px; margin: 0 auto; padding: 45px; }\n'
      + '@media (max-width: 767px) { .markdown-body { padding: 15px; } }\n'
      + githubCss.replace(/^\s*[\r\n]/gm, '') + '\n'
      + (extraCss || '') + '\n</style>\n</head>\n<body>\n<article class="markdown-body">\n'
      + String(bodyHtml || '').trim() + '\n</article>\n</body>\n</html>';
  }

  // ---------- window.services ----------
  window.services = {
    getFirstMDFileContent: () => boot.firstMd || '',

    readClipboardHtml: () => boot.clipboardStash.html || '',
    readClipboardData: () => ({ text: boot.clipboardStash.text || '', html: boot.clipboardStash.html || '' }),
    writeClipboardData(t) {
      if (!t) return;
      if (t.text) {
        boot.clipboardStash.text = t.text;
        try { navigator.clipboard.writeText(t.text); } catch {}
      }
      if (t.html) boot.clipboardStash.html = t.html;
    },
    copyHtml(html) {
      boot.clipboardStash.html = html || '';
      try { navigator.clipboard.writeText(html || ''); } catch {}
    },

    makeFolder(dir, name) {
      return (dir ? dir.replace(/[\\/]+$/, '') + '/' : '') + name;
    },

    writeMarkdownFile(dir, name, content) {
      downloadText(sanitizeName(name) + '.md', content == null ? '' : String(content), 'text/markdown;charset=utf-8');
    },

    writeHtmlFile(name, bodyHtml, css, attachments, includeKatex) {
      const html = exportHtmlString(sanitizeName(name), inlineAttachmentUrls(bodyHtml), css, includeKatex);
      downloadText(sanitizeName(name) + '.html', html, 'text/html;charset=utf-8');
    },

    // electron 隐藏窗口渲染导出 → 浏览器等价物：图片用 html2canvas，PDF 用打印窗口
    exportFile(format, bodyHtml, css, callback, dir) {
      try {
        const inlined = inlineAttachmentUrls(bodyHtml);
        const title = sanitizeName(Date.now());
        if (format === 'image') {
          if (typeof window.html2canvas !== 'function') {
            return callback(new Error('渲染库未加载'));
          }
          const wrap = document.createElement('div');
          const style = document.createElement('style');
          style.textContent = (boot.githubCss || '') + '\n.markdown-body{padding:45px;background:#fff;}';
          const container = document.createElement('div');
          container.className = 'markdown-body';
          container.innerHTML = inlined;
          wrap.appendChild(style);
          wrap.appendChild(container);
          container.style.cssText = 'position:fixed;left:-99999px;top:0;width:900px;background:#fff;';
          document.body.appendChild(wrap);
          window.html2canvas(container, { backgroundColor: '#ffffff', scale: window.devicePixelRatio || 1 })
            .then((canvas) => {
              wrap.remove();
              canvas.toBlob((blob) => {
                if (!blob) return callback(new Error('图片生成失败'));
                const fname = 'markdown-' + title + '.png';
                shellOpen(fname, blob);
                callback(null, 'export:' + fname);
              }, 'image/png');
            })
            .catch((err) => { wrap.remove(); callback(err); });
          return;
        }
        if (format === 'pdf') {
          const html = exportHtmlString(title, inlined, css, true)
            .replace('</body>', '<script>setTimeout(function(){window.print()},900)</script></body>');
          const w = window.open('', '_blank');
          if (!w) return callback(new Error('打印窗口被拦截'));
          w.document.write(html);
          w.document.close();
          return callback(null, '打印窗口已打开，请在打印对话框中选择"另存为 PDF"');
        }
        callback(new Error('不支持的导出格式：' + format));
      } catch (err) {
        callback(err);
      }
    },

    dialogSaveExportFile(tempPath, name, ext) {
      // exportFile 已经直接下载过，这里不再重复下载
    },

    getImageData(t) {
      // 1) dataURL（截图/网页图片）
      if (typeof t === 'string' && /^data:image\//i.test(t)) {
        const r = dataUrlToBytes(t);
        if (!r || !r.bytes.length) return null;
        return { digest: digestOf(r.bytes), name: 'screen-capture', data: r.bytes, contentType: r.contentType };
      }
      // 2) 粘贴的图片文件（capture 阶段补上的 blob: 虚拟路径，同步可读）
      if (typeof t === 'string' && /^blob:/.test(t)) {
        const meta = (boot.clipboardImages || new Map()).get(t);
        if (!meta) return null;
        const bytes = xhrBytes(t);
        if (!bytes || !bytes.length) return null;
        return { digest: digestOf(bytes), name: meta.name || '截图', data: bytes, contentType: meta.type || 'image/png' };
      }
      // 3) 内存附件（/api/attachment/<md5> 仅作兼容入口，字节直接来自内存库）
      if (typeof t === 'string' && /^\/api\/attachment\/([0-9a-f]{32})$/.test(t)) {
        const doc = memDoc(RegExp.$1);
        const a = doc && doc._attachments && doc._attachments[0];
        if (!a) return null;
        const bytes = bytesFromBase64(a.data);
        return { digest: digestOf(bytes), name: RegExp.$1, data: bytes, contentType: a.content_type };
      }
      return null;
    },

    getClipboardImage() {
      // 从最近一次粘贴事件的暂存里取图片（blob: 路径同步可读）
      for (const [blobUrl, meta] of (boot.clipboardImages || new Map()).entries()) {
        const bytes = xhrBytes(blobUrl);
        if (bytes && bytes.length) {
          return { digest: digestOf(bytes), name: meta.name || '截图', data: bytes, contentType: meta.type || 'image/png' };
        }
      }
      return null;
    },

    getAttachmentTempPath(digest) {
      // 从内存库生成 blob: URL（不经 HTTP，部署代理模式下也能渲染）；
      // 预览里的 file:// 前缀由 utools-shim 的 MutationObserver 纠正
      if (typeof digest !== 'string' || !/^[0-9a-f]{32}$/.test(digest)) return null;
      const doc = memDoc(digest);
      const a = doc && doc._attachments && doc._attachments[0];
      if (!a) return null;
      try {
        const bytes = bytesFromBase64(a.data);
        const url = URL.createObjectURL(new Blob([bytes], { type: a.content_type }));
        blobUrlB64.set(url, a.data);
        (boot.clipboardImages || new Map()).set(url, { name: '附件', type: a.content_type });
        return url;
      } catch {
        return null;
      }
    },

    getFileBaseName: (p) => String(p || '').split(/[\\/]/).pop(),

    getFileContent(p) {
      if (typeof p !== 'string') return '';
      if (/^\/api\//.test(p)) {
        const t = xhrText('GET', p);
        return t === null ? '' : t;
      }
      return '';
    },

    fileUrlToPath: (u) => String(u || '').replace(/^file:\/\//, ''),

    saveImgToFileBySrc: async (src) => {
      let bytes, contentType;
      if (/^data:image\//i.test(src)) {
        const r = dataUrlToBytes(src);
        if (!r) return null;
        bytes = r.bytes; contentType = r.contentType;
      } else if (/^https?:\/\//i.test(src)) {
        const resp = await fetch(src);
        if (!resp.ok) return null;
        const buf = await resp.arrayBuffer();
        bytes = new Uint8Array(buf);
        contentType = resp.headers.get('content-type') || 'image/png';
      } else {
        return null;
      }
      const digest = digestOf(bytes);
      // 尽力而为转存到服务端图片仓（部署代理下 POST 被拦 → 返回 null，调用方降级）
      try {
        const r = await fetch('/api/attachment-store', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ digest, contentType, data: bytesToBase64(bytes) }),
        });
        if (r.ok) {
          const j = await r.json();
          if (j && j.url) return j.url;
        }
      } catch {}
      return null;
    },

    shellOpenPath(p) {
      const s = String(p || '');
      if (exportStash.has(s)) {
        download(s.slice('export:'.length) || 'export', exportStash.get(s));
        return;
      }
      if (/^\/api\//.test(s)) {
        fetch(s).then((r) => r.blob()).then((b) => download(s.split('/').pop(), b)).catch(() => {});
      }
    },

    convertMdFileImageURLToAbsolutePath: () => null,
  };

  function bytesFromBase64(b64) {
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  }
})();
