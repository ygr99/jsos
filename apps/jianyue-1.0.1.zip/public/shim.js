/* 简阅 JSOS 垫片 —— 让 uTools 插件「简阅」v1.2.0 的 bundle 原样跑在 JSOS 里。
 * 本文件在 bundle 之前执行，由 index.html 注入（见 setup-plugin.cjs），并负责在
 * 「数据就绪后」动态 import bundle（module 脚本已从 index.html 摘除）。
 *
 * 数据架构（2026-10-06 真机实测后定案）：
 *   JSOS 部署形态下，应用 iframe 的请求经 WebContainer 预览代理转发，代理
 *   **只放行 GET**（POST/DELETE 一律 403，md-notes 移植时已踩过）。而本插件
 *   bundle 对 services / dbStorage 全是同步调用，写请求被拦后 filePath 落 null、
 *   书打不开。因此：
 *
 *   ★ 主存储在前端：内存 Map（同步语义）+ IndexedDB（跨会话持久，books/covers/
 *     fonts/ai-cache 文件与 kv 元数据全存）；bundle 眼里的一切读写都是内存操作。
 *   ★ 服务端降级为「尽力备份」：仅当本机直跑（location.hostname 是 localhost/
 *     127.0.0.1，POST 真的可达）才回写 DATA_DIR；部署形态下静默跳过，控制台零噪音。
 *   ★ boot 时序：IDB + 服务端种子（GET 可穿透代理）都就绪、按 kv 记录把缺失文件
 *     从服务端拉回内存之后，才 import bundle —— bundle 挂载时数据已在内存。
 *
 * 垫片与 bundle 的对接口径（保持 uTools 原语义）：
 *   1. window.utools.dbStorage —— 书架/书签/划线/设置/AI 会话元数据（键全为 reader:*），
 *      值是 JSON 字符串，同步 get/set/remove。
 *   2. window.services —— 原 preload（Node fs）的全部操作；同步读写内存，
 *      写操作附带 IDB 持久化 + 尽力服务端备份。
 *   3. 原生文件对话框只能异步 → bundle 已打 await 补丁（setup-plugin.cjs）；
 *      选中文件吸入内存 pick 表，pick://<字节数>/<文件名> 虚拟路径对 bundle 透明
 *      （bookId 按路径哈希，同名同大小重复导入仍能去重）。
 *
 * 虚拟路径（内存 files Map 的 key，同时是 IDB files store 的 key）：
 *   cache://books/<bookId>.<ext>   书籍（bundle 按路径取扩展名，必须带真实扩展名）
 *   cache://covers/<bookId>.<ext>  封面
 *   cache://fonts/<显示名>.<ext>   自定义字体（显示名可中文）
 *   cache://ai-cache/<sessionId>.json  AI 对话历史
 *   字体对外路径是 blob: URL（@font-face 直接可用；foliate iframe 带
 *   allow-same-origin，blob 可加载）。每个会话一个稳定 URL，旧会话的失效 URL
 *   由 boot 时的 healFontPaths 按 name 重写。
 */
(function () {
  'use strict';

  if (window.__jianyueShimLoaded) return;
  window.__jianyueShimLoaded = true;

  const KV_LS_PREFIX = 'jianyue:kv:'; // localStorage 二级镜像（IDB 打不开时的兜底）
  const AI_DIR = 'cache://ai-cache';
  const DB_NAME = 'jianyue-shim';
  // 本机直跑 = 写请求真的可达（部署形态经预览代理，POST 必 403）
  const WRITABLE = /^(localhost|127\.0\.0\.1|::1|\[::1\])$/.test(location.hostname);

  // ============ 内存主存 ============
  const kv = new Map();        // dbStorage 键值（值为字符串）
  const files = new Map();     // virtualPath -> ArrayBuffer
  const fontUrls = new Map();  // cache://fonts/x -> blob: URL（会话内稳定）
  const fontByBlob = new Map();// blob: URL -> cache://fonts/x
  const picks = new Map();     // pick://<size>/<name> -> { name, buffer }
  let idb = null;

  function putFile(path, buffer) {
    files.set(path, buffer);
    idbPut('files', path, buffer);
  }

  function delFile(path) {
    files.delete(path);
    idbDelete('files', path);
  }

  // ============ IndexedDB（前端持久层） ============
  function idbOpen() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
        if (!db.objectStoreNames.contains('files')) db.createObjectStore('files');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error('idb blocked'));
    });
  }

  function idbRun(store, mode, action) {
    if (!idb) return;
    try {
      const tx = idb.transaction(store, mode);
      tx.onerror = () => {};
      tx.onabort = () => {};
      action(tx.objectStore(store));
    } catch {}
  }

  function idbPut(store, key, val) {
    idbRun(store, 'readwrite', (os) => os.put(val, key));
  }

  function idbDelete(store, key) {
    idbRun(store, 'readwrite', (os) => os.delete(key));
  }

  function idbGetAll(store) {
    return new Promise((resolve) => {
      if (!idb) return resolve(new Map());
      try {
        const out = new Map();
        const os = idb.transaction(store, 'readonly').objectStore(store);
        const kReq = os.getAllKeys();
        const vReq = os.getAll();
        kReq.onerror = vReq.onerror = () => resolve(out);
        kReq.onsuccess = () => {
          const keys = kReq.result;
          vReq.onsuccess = () => {
            const vals = vReq.result;
            for (let i = 0; i < keys.length; i++) out.set(keys[i], vals[i]);
            resolve(out);
          };
          if (vReq.readyState === 'done') resolve(out);
        };
      } catch {
        resolve(new Map());
      }
    });
  }

  // ============ 服务端尽力备份（仅 WRITABLE） ============
  let flushTimer = null;
  let flushPending = false;

  function serverGetKv() {
    return fetch('/api/storage')
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null);
  }

  function serverFlushSoon() {
    if (!WRITABLE) return;
    flushPending = true;
    clearTimeout(flushTimer);
    flushTimer = setTimeout(() => serverFlushNow(false), 600);
  }

  function serverFlushNow(keepalive) {
    if (!WRITABLE) return;
    flushPending = false;
    try {
      fetch('/api/storage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(kv)),
        keepalive: !!keepalive,
      }).catch(() => {});
    } catch {}
  }

  function serverUploadFile(url, buffer) {
    if (!WRITABLE) return;
    try {
      fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer),
      }).catch(() => {});
    } catch {}
  }

  function serverDelete(url) {
    if (!WRITABLE) return;
    try {
      fetch(url, { method: 'DELETE' }).catch(() => {});
    } catch {}
  }

  // ============ 同步 XHR（仅剩 findEpubCover 兜底用） ============
  function jsonSync(method, url) {
    try {
      const x = new XMLHttpRequest();
      x.open(method, url, false);
      x.send(null);
      return x.status >= 200 && x.status < 300 ? JSON.parse(x.responseText) : null;
    } catch {
      return null;
    }
  }

  // ============ utools.dbStorage（同步语义，内存即事实源） ============
  function mirrorLocal(key, value) {
    try {
      if (value === undefined || value === null) localStorage.removeItem(KV_LS_PREFIX + key);
      else localStorage.setItem(KV_LS_PREFIX + key, value);
    } catch {}
  }

  window.utools = {
    dbStorage: {
      getItem(key) {
        const v = kv.get(String(key));
        return v === undefined ? null : v;
      },
      setItem(key, value) {
        const k = String(key);
        const v = typeof value === 'string' ? value : String(value);
        kv.set(k, v);
        mirrorLocal(k, v);
        idbPut('kv', k, v);
        serverFlushSoon();
      },
      removeItem(key) {
        const k = String(key);
        kv.delete(k);
        mirrorLocal(k, null);
        idbDelete('kv', k);
        serverFlushSoon();
      },
    },
    copyText(text) {
      const t = String(text == null ? '' : text);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(t).catch(() => copyViaExecCommand(t));
      } else {
        copyViaExecCommand(t);
      }
    },
  };

  function copyViaExecCommand(t) {
    try {
      const ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    } catch {}
  }

  // ============ 文件选择（pick 表） ============
  function pickFiles(accept, multiple) {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept;
      if (multiple) input.multiple = true;
      input.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
      input.addEventListener('change', () => {
        resolve(Array.from(input.files || []));
        setTimeout(() => input.remove(), 0);
      });
      input.addEventListener('cancel', () => {
        resolve([]);
        setTimeout(() => input.remove(), 0);
      });
      window.__jianyueLastFileInput = input; // 测试钩子
      document.body.appendChild(input);
      input.click();
    });
  }

  function pickPathFor(file) {
    return 'pick://' + file.size + '/' + file.name;
  }

  async function ingestFiles(filesPicked) {
    const paths = [];
    for (const f of filesPicked) {
      const p = pickPathFor(f);
      if (!picks.has(p)) picks.set(p, { name: f.name, buffer: await f.arrayBuffer() });
      paths.push(p);
    }
    return paths;
  }

  const BOOK_ACCEPT = '.epub,.txt,.mobi,.azw3,.cbz,.cbr';
  const IMAGE_ACCEPT = '.jpg,.jpeg,.png,.gif,.webp,.bmp';
  const FONT_ACCEPT = '.ttf,.otf,.woff,.woff2';

  // ============ 虚拟路径工具 ============
  function extOf(p) {
    const m = /\.([A-Za-z0-9]+)$/.exec(p || '');
    return m ? m[1].toLowerCase() : '';
  }

  function fileNameOf(p) {
    return String(p || '').split(/[\\/]/).pop() || '';
  }

  function fontMime(ext) {
    return { ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff', woff2: 'font/woff2' }[ext] || 'application/octet-stream';
  }

  function getOrCreateFontUrl(vpath) {
    let url = fontUrls.get(vpath);
    if (url) return url;
    const buf = files.get(vpath);
    if (!buf) return '';
    url = URL.createObjectURL(new Blob([buf], { type: fontMime(extOf(vpath)) }));
    fontUrls.set(vpath, url);
    fontByBlob.set(url, vpath);
    return url;
  }

  // ============ window.services ============
  window.services = {
    readFileAsBuffer(p) {
      if (String(p).startsWith('pick://')) {
        const e = picks.get(String(p));
        return e && e.buffer ? e.buffer : new ArrayBuffer(0);
      }
      const buf = files.get(String(p));
      return buf || new ArrayBuffer(0);
    },

    readFileAsText(p) {
      const buf = String(p).startsWith('pick://')
        ? (picks.get(String(p)) || {}).buffer
        : files.get(String(p));
      if (!buf) return '';
      try {
        return new TextDecoder('utf-8').decode(new Uint8Array(buf));
      } catch {
        return '';
      }
    },

    checkFileExists(p) {
      const s = String(p);
      return s.startsWith('pick://') ? picks.has(s) : files.has(s);
    },

    showFilePicker() {
      return pickFiles(BOOK_ACCEPT, true).then(ingestFiles);
    },

    showImagePicker() {
      return pickFiles(IMAGE_ACCEPT, false).then(ingestFiles);
    },

    showFontPicker() {
      return pickFiles(FONT_ACCEPT, true).then(ingestFiles);
    },

    // 浏览器没有「选目录写文件」；直接触发下载。返回值只需为真值
    // （bundle 拿它判断成功，随后传给 showItemInFolder）
    saveFile(defaultName, data) {
      const name = String(defaultName || ('export-' + Date.now()));
      downloadBlob(name, data, typeof data === 'string' ? 'text/markdown' : 'application/octet-stream');
      return 'download://' + name;
    },

    writeTextFile(text) {
      const name = Date.now() + '.txt';
      downloadBlob(name, String(text == null ? '' : text), 'text/plain');
      return 'download://' + name;
    },

    writeImageFile(base64Url) {
      const m = /^data:image\/([a-z]{1,20});base64,/i.exec(base64Url || '');
      if (!m) return null;
      const name = Date.now() + '.' + m[1];
      const bin = atob(base64Url.substring(m[0].length));
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      downloadBlob(name, u8, 'image/' + m[1]);
      return 'download://' + name;
    },

    getFileName(p) {
      return fileNameOf(p);
    },

    getFileSize(p) {
      const s = String(p);
      if (s.startsWith('pick://')) {
        const m = /^pick:\/\/(\d+)\//.exec(s);
        return m ? Number(m[1]) : 0;
      }
      const buf = files.get(s);
      return buf ? buf.byteLength : 0;
    },

    copyBookToCache(bookId, srcPath) {
      const e = picks.get(String(srcPath));
      const ext = '.' + (extOf(srcPath) || 'epub');
      const path = 'cache://books/' + bookId + ext;
      const buffer = e && e.buffer ? e.buffer : new ArrayBuffer(0);
      putFile(path, buffer);
      serverUploadFile('/api/fs/book/' + encodeURIComponent(bookId) + '?ext=' + encodeURIComponent(ext), buffer);
      return path;
    },

    deleteCachedBook(p) {
      if (!p || !String(p).startsWith('cache://books/')) return;
      delFile(String(p));
      serverDelete('/api/fs/delete?path=' + encodeURIComponent(p));
    },

    cachedBookExists(p) {
      return !!p && String(p).startsWith('cache://') && files.has(String(p));
    },

    saveCoverFile(bookId, base64DataUrl) {
      const m = /^data:image\/([a-z]{1,20});base64,/i.exec(base64DataUrl || '');
      if (!m) return null;
      const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
      const path = 'cache://covers/' + bookId + '.' + ext;
      const bin = atob(base64DataUrl.substring(m[0].length));
      const u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      putFile(path, u8.buffer);
      if (WRITABLE) {
        try {
          fetch('/api/fs/cover/' + encodeURIComponent(bookId), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dataUrl: base64DataUrl }),
          }).catch(() => {});
        } catch {}
      }
      return path;
    },

    deleteCoverFile(p) {
      if (!p || !String(p).startsWith('cache://covers/')) return;
      delFile(String(p));
      serverDelete('/api/fs/delete?path=' + encodeURIComponent(p));
    },

    coverFileExists(p) {
      return !!p && String(p).startsWith('cache://covers/') && files.has(String(p));
    },

    // EPUB 封面兜底提取在服务端（GET 可穿透预览代理；书籍也须已在服务端——
    // 仅本机直跑满足）。真机上主路径 sf()（浏览器内 foliate 解析）已覆盖绝大多数场景
    findEpubCover(bookId, p) {
      if (!WRITABLE || !p || !String(p).startsWith('cache://books/')) return null;
      const r = jsonSync('GET', '/api/fs/epub-cover?bookId=' + encodeURIComponent(bookId) + '&path=' + encodeURIComponent(p));
      return r && r.path ? r.path : null;
    },

    // ---------- 自定义字体（对外路径是 blob: URL，@font-face 直接可用） ----------
    copyFontToCache(pickPath) {
      const e = picks.get(String(pickPath));
      const name = fileNameOf(pickPath);
      if (!name) return null;
      const vpath = 'cache://fonts/' + name;
      putFile(vpath, e && e.buffer ? e.buffer : new ArrayBuffer(0));
      const url = getOrCreateFontUrl(vpath);
      serverUploadFile('/api/fs/font?name=' + encodeURIComponent(name), files.get(vpath));
      return url;
    },

    deleteFontFile(p) {
      const s = String(p || '');
      let vpath = fontByBlob.get(s);
      if (!vpath && s.startsWith('/api/font-file?name=')) {
        try {
          const m = /[?&]name=([^&]+)/.exec(s);
          vpath = 'cache://fonts/' + decodeURIComponent(m[1]);
        } catch {}
      }
      if (!vpath) return;
      delFile(vpath);
      const url = fontUrls.get(vpath);
      if (url) {
        try { URL.revokeObjectURL(url); } catch {}
        fontUrls.delete(vpath);
        fontByBlob.delete(url);
      }
      const name = fileNameOf(vpath);
      serverDelete('/api/fs/font?name=' + encodeURIComponent(name));
    },

    getFontFiles() {
      const out = [];
      for (const key of files.keys()) {
        if (!key.startsWith('cache://fonts/')) continue;
        const filename = fileNameOf(key);
        if (!/\.(ttf|otf|woff|woff2)$/i.test(filename)) continue;
        out.push({
          name: filename.replace(/\.(ttf|otf|woff|woff2)$/i, ''),
          path: getOrCreateFontUrl(key),
        });
      }
      return out;
    },

    showItemInFolder() {
      // 浏览器里导出即触发下载，没有「在文件夹中显示」
    },

    // ---------- AI 缓存（对话历史） ----------
    ensureAiCacheDir() {
      return AI_DIR;
    },

    readAiCacheFile(p) {
      const s = String(p || '');
      if (!s.startsWith(AI_DIR + '/')) return null;
      const buf = files.get(s);
      if (!buf) return null;
      try {
        return new TextDecoder('utf-8').decode(new Uint8Array(buf));
      } catch {
        return null;
      }
    },

    writeAiCacheFile(p, data) {
      const s = String(p || '');
      if (!s.startsWith(AI_DIR + '/')) return;
      const bytes = new TextEncoder().encode(String(data == null ? '' : data));
      putFile(s, bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
      serverUploadFile('/api/fs/ai-write?name=' + encodeURIComponent(fileNameOf(s)), bytes);
    },

    deleteAiCacheFile(p) {
      const s = String(p || '');
      if (!s.startsWith(AI_DIR + '/')) return;
      delFile(s);
      serverDelete('/api/fs/ai-delete?name=' + encodeURIComponent(fileNameOf(s)));
    },

    listAiCacheFiles() {
      const out = [];
      for (const key of files.keys()) {
        if (key.startsWith(AI_DIR + '/') && fileNameOf(key).endsWith('.json')) out.push(fileNameOf(key));
      }
      return out;
    },

    // ---------- 浮窗阅读（uTools 独立窗口 → 浏览器弹出窗） ----------
    createFloatReader(text, chapterTitle, opacity) {
      try {
        const w = 420;
        const h = 560;
        const left = Math.max(0, (screen.availWidth || 1280) - w - 20);
        const top = Math.max(0, (screen.availHeight || 800) - h - 40);
        const win = window.open('', 'jianyue-float-reader',
          'popup=yes,width=' + w + ',height=' + h + ',left=' + left + ',top=' + top);
        if (!win) return false;
        win.document.write(floatReaderHtml());
        win.document.close();
        try {
          win.document.title = '简阅 · 浮窗阅读';
          const titleEl = win.document.getElementById('chapterTitle');
          const contentEl = win.document.getElementById('content');
          const slider = win.document.getElementById('opacitySlider');
          if (titleEl) titleEl.textContent = '简阅 · ' + (chapterTitle || '当前章节');
          if (contentEl) {
            if (text && String(text).trim()) contentEl.textContent = text;
            else contentEl.innerHTML = '<div class="empty-hint">当前章节无文字内容</div>';
          }
          if (slider && typeof opacity === 'number') slider.value = Math.round(opacity * 100);
          win.addEventListener('pagehide', () => { floatWin = null; });
        } catch {}
        floatWin = win;
        return true;
      } catch {
        return false;
      }
    },

    closeFloatReader() {
      try { if (floatWin) floatWin.close(); } catch {}
      floatWin = null;
    },

    isFloatReaderOpen() {
      try { return !!(floatWin && !floatWin.closed); } catch { return false; }
    },

    // 拖拽导入：浏览器 File 没有 .path，先吸入内存再返回虚拟路径（bundle P6 补丁）
    resolveDropFiles(filesDropped) {
      return ingestFiles(filesDropped);
    },
  };

  let floatWin = null;

  function downloadBlob(name, data, mime) {
    try {
      const blob = data instanceof Blob ? data : new Blob([data], { type: mime || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
    } catch {}
  }

  function floatReaderHtml() {
    return '<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><style>' +
      '*{margin:0;padding:0;box-sizing:border-box}html,body{background:transparent;height:100%;overflow:hidden;' +
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',system-ui,sans-serif;user-select:none}" +
      '.container{height:100%;display:flex;flex-direction:column;background:rgba(30,30,30,1);border-radius:12px;' +
      'border:1px solid rgba(255,255,255,.1);overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.4)}' +
      '.header{display:flex;align-items:center;padding:8px 12px;background:rgba(255,255,255,.05);' +
      'border-bottom:1px solid rgba(255,255,255,.08);gap:8px;flex-shrink:0}' +
      '.title{flex:1;font-size:12px;color:rgba(255,255,255,.7);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.opacity-control{display:flex;align-items:center;gap:6px}.opacity-label{font-size:10px;color:rgba(255,255,255,.5)}' +
      '.opacity-slider{width:60px;height:3px;-webkit-appearance:none;appearance:none;background:rgba(255,255,255,.2);' +
      'border-radius:2px;outline:none;cursor:pointer}' +
      '.opacity-slider::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;' +
      'background:#fff;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.3)}' +
      '.close-btn{width:22px;height:22px;border-radius:50%;border:none;background:rgba(255,255,255,.1);' +
      'color:rgba(255,255,255,.7);font-size:11px;cursor:pointer;display:flex;align-items:center;justify-content:center}' +
      '.close-btn:hover{background:#e74c3c;color:#fff}' +
      '.content{flex:1;overflow-y:auto;padding:16px 20px;font-size:14px;line-height:1.8;color:rgba(255,255,255,.85);' +
      'white-space:pre-wrap;word-break:break-word;user-select:text}' +
      '.content::-webkit-scrollbar{width:4px}.content::-webkit-scrollbar-thumb{background:rgba(255,255,255,.15);border-radius:2px}' +
      '.empty-hint{display:flex;align-items:center;justify-content:center;height:100%;color:rgba(255,255,255,.3);font-size:13px}' +
      '</style></head><body><div class="container" id="app">' +
      '<div class="header"><span class="title" id="chapterTitle">简阅 · 浮窗阅读</span>' +
      '<div class="opacity-control"><span class="opacity-label">透明度</span>' +
      '<input type="range" class="opacity-slider" id="opacitySlider" min="20" max="100" value="85"></div>' +
      '<button class="close-btn" id="closeBtn" title="关闭">&#10005;</button></div>' +
      '<div class="content" id="content"><div class="empty-hint">加载中...</div></div></div>' +
      '<script>' +
      'var s=document.getElementById("opacitySlider"),c=document.getElementById("app"),b=document.getElementById("closeBtn");' +
      's.addEventListener("input",function(e){c.style.opacity=Number(e.target.value)/100});' +
      'b.addEventListener("click",function(){try{window.close()}catch(e){}});' +
      '<\/script></body></html>';
  }

  // ============ 跨域 fetch → 服务端出站代理 ============
  // 容器内 iframe 直连外部 API 受 CORS 约束；AI 解读/朗读是 bundle 里裸 fetch 的
  // OpenAI 兼容接口，统一改走同源 /api/outbound（GET 能穿透部署代理，SSE 流式透传）。
  const origFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    try {
      if (typeof input !== 'string' && !(input instanceof URL)) return origFetch(input, init);
      const url = new URL(String(input), location.href);
      if (url.origin === location.origin || !/^https?:$/.test(url.protocol)) return origFetch(input, init);
      return origFetch('/api/outbound?url=' + encodeURIComponent(url.href), init);
    } catch {
      return origFetch(input, init);
    }
  };

  // ============ boot：数据就绪后再拉起 bundle ============
  function domReady() {
    return new Promise((resolve) => {
      if (document.readyState !== 'loading') return resolve();
      document.addEventListener('DOMContentLoaded', () => resolve(), { once: true });
    });
  }

  function parseKv(raw, fallback) {
    try {
      const v = JSON.parse(raw);
      return v;
    } catch {
      return fallback;
    }
  }

  async function recoverFilesFromServer() {
    // 场景：浏览器数据被清（IDB 空）但服务端备份还在（本机直跑写过）。
    // 依 kv 记录把缺失文件逐个 GET 回内存。部署形态下服务端没有数据，
    // kv 也为空，这里一次请求都不会发。
    const wanted = [];
    const books = parseKv(kv.get('reader:books') || '[]', []);
    for (const b of books) {
      if (b && b.filePath && !files.has(b.filePath)) wanted.push(b.filePath);
      if (b && b.coverKey && !files.has(b.coverKey)) wanted.push(b.coverKey);
    }
    for (const [k, v] of kv) {
      if (!k.startsWith('reader:ai-chat:')) continue;
      const meta = parseKv(v || '{}', {});
      if (meta && meta.filePath && !files.has(meta.filePath)) wanted.push(meta.filePath);
    }
    for (const path of wanted) {
      try {
        const r = await fetch('/api/fs/read?path=' + encodeURIComponent(path));
        if (!r.ok) continue;
        putFile(path, await r.arrayBuffer());
      } catch {}
    }
    // 字体：reader:fonts 里存的 path 可能是上个会话的失效 blob: URL
    const fonts = parseKv(kv.get('reader:fonts') || '[]', []);
    if (Array.isArray(fonts) && fonts.length) {
      let changed = false;
      for (const f of fonts) {
        if (!f || !f.name) continue;
        let vpath = null;
        for (const key of files.keys()) {
          if (key.startsWith('cache://fonts/') && fileNameOf(key).replace(/\.[a-z0-9]+$/i, '') === f.name) {
            vpath = key;
            break;
          }
        }
        if (!vpath && WRITABLE) {
          // 内存缺失再问服务端（GET 可穿透；按显示名匹配）
          try {
            const r = await fetch('/api/fs/fonts');
            const list = r.ok ? (await r.json()).fonts || [] : [];
            const hit = list.find((x) => x.name === f.name);
            if (hit) {
              const buf = await (await fetch(hit.path)).arrayBuffer();
              // hit.path 形如 /api/font-file?name=<enc>，文件名取 query 里的原名
              const nm = decodeURIComponent(hit.path.split('name=')[1] || '');
              vpath = 'cache://fonts/' + (nm || f.name);
              putFile(vpath, buf);
            }
          } catch {}
        }
        if (vpath) {
          const url = getOrCreateFontUrl(vpath);
          if (url && f.path !== url) {
            f.path = url;
            changed = true;
          }
        }
      }
      if (changed) {
        const raw = JSON.stringify(fonts);
        kv.set('reader:fonts', raw);
        mirrorLocal('reader:fonts', raw);
        idbPut('kv', 'reader:fonts', raw);
        serverFlushSoon();
      }
    }
  }

  async function boot() {
    const [serverKv] = await Promise.all([
      serverGetKv(),
      idbOpen().then((db) => { idb = db; }).catch(() => { idb = null; }),
    ]);
    // kv：IDB 优先，服务端补缺
    const idbKv = await idbGetAll('kv');
    for (const [k, v] of idbKv) kv.set(k, v);
    if (serverKv && typeof serverKv === 'object') {
      for (const [k, v] of Object.entries(serverKv)) {
        if (!kv.has(k) && typeof v === 'string') {
          kv.set(k, v);
          mirrorLocal(k, v);
          idbPut('kv', k, v);
        }
      }
    }
    if (!idb) {
      // IDB 打不开（罕见）：localStorage 镜像兜底，至少元数据活一个会话
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(KV_LS_PREFIX)) kv.set(k.slice(KV_LS_PREFIX.length), localStorage.getItem(k));
        }
      } catch {}
    }
    const idbFiles = await idbGetAll('files');
    for (const [k, v] of idbFiles) files.set(k, v);
    await recoverFilesFromServer();
    await domReady();
    try {
      await import('./assets/index-Dt4k5D0c.js');
    } catch (e) {
      console.error('[jianyue] bundle 加载失败:', e);
      return;
    }
    setTimeout(() => {
      try {
        window.dispatchEvent(new CustomEvent('plugin-enter', { detail: { code: 'reader', type: '', payload: null } }));
      } catch {}
    }, 300);
  }

  // ============ uTools 生命周期事件 ============
  // bundle 在 onMounted 里监听 plugin-out 并保存进度；页面卸载时补发并回存服务端
  window.addEventListener('pagehide', () => {
    try {
      window.dispatchEvent(new CustomEvent('plugin-out'));
    } catch {}
    clearTimeout(flushTimer);
    serverFlushNow(true);
  });
  setInterval(() => serverFlushNow(false), 30000);

  boot();
})();
