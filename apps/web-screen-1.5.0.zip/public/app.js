/* ============================================================
 * 网页屏保 Web Screen — Canvas 屏保合集
 * 每款屏保：create(ctx, w, h) => step(dt)，dt 为秒
 * ============================================================ */
'use strict';

const $ = (s) => document.querySelector(s);

/* ---------- 工具 ---------- */
function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
const line = (ctx, x1, y1, x2, y2) => { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };

/* ---------- 1. 矩阵字符雨（经典实现：只画头部字符，拖尾由黑色罩渐隐形成） ---------- */
function matrixCreate(ctx, w, h) {
  const glyphs = 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789';
  const fs = 18;
  const cols = Math.ceil(w / fs);
  const rows = Math.ceil(h / fs) + 2;
  const reset = (d, first) => {
    d.y = -(first ? Math.random() * rows * 2 : 4 + Math.random() * 12);
    d.sp = 18 + Math.random() * 8;  // 行/秒，快速但可辨
  };
  const drops = Array.from({ length: cols }, () => {
    const d = {};
    reset(d, true); // 首次出场错开
    return d;
  });
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
  return (dt) => {
    ctx.fillStyle = 'rgba(0,0,0,0.08)'; ctx.fillRect(0, 0, w, h);
    ctx.font = fs + 'px monospace'; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
    for (let i = 0; i < cols; i++) {
      const d = drops[i];
      const prev = d.y;
      d.y += d.sp * dt;
      // 头部进入新的一行才画一个字符（拖尾 = 之前画的字符被黑罩慢慢盖暗）
      if (d.y > 0 && Math.floor(d.y) !== Math.floor(prev)) {
        ctx.fillStyle = Math.random() < 0.1 ? '#eafff0' : '#3dff70';
        ctx.fillText(glyphs[Math.floor(Math.random() * glyphs.length)], i * fs, Math.floor(d.y) * fs);
      }
      if (d.y > rows && Math.random() < 0.035) reset(d, false);
    }
  };
}

/* ---------- 2. 纯黑 ---------- */
function blackCreate(ctx, w, h) {
  return () => { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h); };
}

/* ---------- 3. DVD 弹跳 ---------- */
function dvdCreate(ctx, w, h) {
  const lw = Math.min(180, w * 0.22), lh = lw * 0.45;
  let x = Math.random() * (w - lw), y = Math.random() * (h - lh);
  const speed = Math.min(w, h) * 0.18;
  let vx = speed * (Math.random() < 0.5 ? 1 : -1), vy = speed * (Math.random() < 0.5 ? 1 : -1);
  let hue = Math.random() * 360;
  return (dt) => {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    x += vx * dt; y += vy * dt;
    if (x <= 0 || x >= w - lw) { vx = -vx; hue = (hue + 47) % 360; x = Math.max(0, Math.min(w - lw, x)); }
    if (y <= 0 || y >= h - lh) { vy = -vy; hue = (hue + 47) % 360; y = Math.max(0, Math.min(h - lh, y)); }
    ctx.save();
    ctx.shadowColor = `hsl(${hue} 90% 55%)`; ctx.shadowBlur = 30;
    rr(ctx, x, y, lw, lh, 14);
    ctx.fillStyle = `hsl(${hue} 90% 52%)`; ctx.fill();
    ctx.restore();
    ctx.fillStyle = `hsl(${hue} 95% 80%)`;
    ctx.font = `900 ${lh * 0.52}px Arial, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('DVD', x + lw / 2, y + lh / 2 + 2);
    ctx.textAlign = 'left';
  };
}

/* ---------- 4. 星际穿越 ---------- */
function starfieldCreate(ctx, w, h) {
  const N = 420, cx = w / 2, cy = h / 2, f = Math.min(w, h) * 0.45;
  const newStar = () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * 0.9 + 0.1 });
  const stars = Array.from({ length: N }, newStar);
  return (dt) => {
    ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#dfe8ff';
    for (const s of stars) {
      s.z -= dt * 0.35;
      if (s.z <= 0.02) Object.assign(s, newStar());
      const px = cx + (s.x / s.z) * f, py = cy + (s.y / s.z) * f;
      if (px < 0 || px > w || py < 0 || py > h) { Object.assign(s, newStar()); continue; }
      ctx.globalAlpha = 1 - s.z;
      ctx.beginPath(); ctx.arc(px, py, (1 - s.z) * 2.6 + 0.3, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
  };
}

/* ---------- 5. 极光 ---------- */
function auroraCreate(ctx, w, h) {
  const stars = Array.from({ length: 130 }, () => ({ x: Math.random() * w, y: Math.random() * h * 0.65, r: Math.random() * 1.3 + 0.3, tw: Math.random() * 6 }));
  const bands = [
    { hue: 145, y: 0.40, amp: 60, speed: 0.25, alpha: 0.32 },
    { hue: 175, y: 0.50, amp: 80, speed: 0.18, alpha: 0.28 },
    { hue: 262, y: 0.58, amp: 70, speed: 0.12, alpha: 0.24 },
  ];
  let t = 0;
  return (dt) => {
    t += dt;
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#020308'); bg.addColorStop(0.7, '#050810'); bg.addColorStop(1, '#0a0f1e');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#cdd8ff';
    for (const s of stars) {
      ctx.globalAlpha = 0.25 + 0.6 * Math.abs(Math.sin(t * 0.8 + s.tw));
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'lighter';
    for (const b of bands) {
      ctx.beginPath(); ctx.moveTo(0, h);
      for (let x = 0; x <= w + 8; x += 8) {
        const y = h * b.y
          + Math.sin(x * 0.004 + t * b.speed * 2) * b.amp
          + Math.sin(x * 0.011 - t * b.speed * 3.1) * b.amp * 0.4;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h); ctx.closePath();
      const g = ctx.createLinearGradient(0, h * b.y - b.amp, 0, h);
      g.addColorStop(0, `hsla(${b.hue + Math.sin(t * 0.3) * 20} 90% 60% / ${b.alpha})`);
      g.addColorStop(1, 'hsla(0 0% 0% / 0)');
      ctx.fillStyle = g; ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  };
}

/* ---------- 6. 时钟 ---------- */
function clockCreate(ctx, w, h) {
  let last = -1;
  const week = '日一二三四五六';
  return (dt) => {
    const d = new Date(), s = d.getSeconds();
    if (s === last) return;
    last = s;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const ss = String(s).padStart(2, '0');
    const fs = Math.min(w / 3.8, h / 2.4);
    const fs2 = fs * 0.45;
    ctx.textBaseline = 'middle';
    ctx.save();
    ctx.shadowColor = 'rgba(120,180,255,0.75)'; ctx.shadowBlur = fs * 0.1;
    ctx.textAlign = 'left';
    const cy = h / 2 - fs * 0.1;
    ctx.font = `700 ${fs}px 'Segoe UI', system-ui, sans-serif`;
    const t1 = `${hh}:${mm}`;
    const w1 = ctx.measureText(t1).width;
    ctx.font = `500 ${fs2}px 'Segoe UI', system-ui, sans-serif`;
    const w2 = ctx.measureText(ss).width;
    const x0 = w / 2 - (w1 + fs * 0.12 + w2) / 2;
    ctx.fillStyle = '#eaf2ff';
    ctx.font = `700 ${fs}px 'Segoe UI', system-ui, sans-serif`;
    ctx.fillText(t1, x0, cy);
    ctx.fillStyle = 'rgba(150,195,255,0.9)';
    ctx.font = `500 ${fs2}px 'Segoe UI', system-ui, sans-serif`;
    ctx.fillText(ss, x0 + w1 + fs * 0.12, cy + fs * 0.2);
    ctx.restore();
    ctx.fillStyle = 'rgba(150,195,255,0.85)';
    ctx.font = `500 ${fs * 0.18}px 'Segoe UI', system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(`${d.getFullYear()} 年 ${d.getMonth() + 1} 月 ${d.getDate()} 日 · 星期${week[d.getDay()]}`, w / 2, h / 2 + fs * 0.52);
  };
}

/* ---------- 7. 3D 管道 ---------- */
function pipesCreate(ctx, w, h) {
  const GX = 8, GY = 6, GZ = 6;               // 三维晶格规模
  const cell = 2;                              // 单格世界尺寸
  const pipeR = cell * 0.22;                   // 管道半径（世界单位）
  const DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
  const D = 52;                                // 相机距离
  const sceneR = Math.hypot(GX - 1, GY - 1, GZ - 1) * cell / 2 + cell;
  const f = Math.min(w, h) * 0.46 * D / sceneR; // 焦距：保证整景可见
  let grid, segs, nodes, walker, hue, filled, t = 0;
  const world = (x, y, z) => [(x - (GX - 1) / 2) * cell, (y - (GY - 1) / 2) * cell, (z - (GZ - 1) / 2) * cell];
  const freeCell = () => {
    for (let i = 0; i < 60; i++) {
      const x = Math.floor(Math.random() * GX), y = Math.floor(Math.random() * GY), z = Math.floor(Math.random() * GZ);
      if (!grid[x][y][z]) return { x, y, z };
    }
    return { x: 0, y: 0, z: 0 };
  };
  const newWalker = () => {
    hue = (hue + 83) % 360;
    const p = freeCell();
    walker = { x: p.x, y: p.y, z: p.z, dir: Math.floor(Math.random() * 6), life: 14 + Math.random() * 30 };
    nodes.push({ x: p.x, y: p.y, z: p.z, hue });
  };
  const reset = () => {
    grid = Array.from({ length: GX }, () => Array.from({ length: GY }, () => new Uint8Array(GZ)));
    segs = []; nodes = [];
    filled = 0; hue = Math.random() * 360; newWalker();
    grid[walker.x][walker.y][walker.z] = 1;
  };
  reset();
  const move = () => {
    let moved = false;
    for (let tries = 0; tries < 10 && !moved; tries++) {
      if (Math.random() < 0.4) walker.dir = Math.floor(Math.random() * 6);
      const d = DIRS[walker.dir];
      const x2 = walker.x + d[0], y2 = walker.y + d[1], z2 = walker.z + d[2];
      if (x2 >= 0 && x2 < GX && y2 >= 0 && y2 < GY && z2 >= 0 && z2 < GZ && !grid[x2][y2][z2]) {
        segs.push({ a: world(walker.x, walker.y, walker.z), b: world(x2, y2, z2), hue });
        grid[x2][y2][z2] = 1; filled++;
        walker.x = x2; walker.y = y2; walker.z = z2;
        nodes.push({ x: x2, y: y2, z: z2, hue });
        moved = true;
      }
    }
    if (!moved || --walker.life <= 0) newWalker();
    if (filled > GX * GY * GZ * 0.5) reset();
  };
  const drawCyl = (p, q, r, hu) => {
    ctx.lineCap = 'round';
    ctx.strokeStyle = `hsl(${hu} 60% 18%)`; ctx.lineWidth = r * 2.2; line(ctx, p[0], p[1], q[0], q[1]);
    ctx.strokeStyle = `hsl(${hu} 85% 55%)`; ctx.lineWidth = r * 2; line(ctx, p[0], p[1], q[0], q[1]);
    ctx.strokeStyle = `hsla(${hu} 100% 88% / .75)`; ctx.lineWidth = r * 0.6; line(ctx, p[0], p[1], q[0], q[1]);
  };
  const drawJoint = (x, y, r, hu) => {
    ctx.beginPath(); ctx.arc(x, y, r * 1.15, 0, 7); ctx.fillStyle = `hsl(${hu} 60% 18%)`; ctx.fill();
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fillStyle = `hsl(${hu} 85% 55%)`; ctx.fill();
    ctx.beginPath(); ctx.arc(x - r * 0.32, y - r * 0.36, r * 0.42, 0, 7); ctx.fillStyle = `hsla(${hu} 100% 88% / .85)`; ctx.fill();
  };
  let acc = 0;
  return (dt) => {
    t += dt;
    acc += dt * 8;
    while (acc >= 1) { acc -= 1; move(); }
    // 相机：绕 Y 轴缓慢旋转 + 轻微俯仰摆动
    const ay = t * 0.22, axx = 0.42 + Math.sin(t * 0.13) * 0.18;
    const cA = Math.cos(ay), sA = Math.sin(ay), cB = Math.cos(axx), sB = Math.sin(axx);
    const proj = (v) => {
      const x1 = v[0] * cA - v[2] * sA, z1 = v[0] * sA + v[2] * cA;
      const y1 = v[1] * cB - z1 * sB, z2 = v[1] * sB + z1 * cB + D;
      const s = f / z2;
      return [w / 2 + x1 * s, h / 2 + y1 * s, z2, s];
    };
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    // 全部图元投影 + 按深度排序（画家算法：远 → 近）
    const prims = [];
    for (const sg of segs) {
      const p = proj(sg.a), q = proj(sg.b);
      prims.push({ z: (p[2] + q[2]) / 2, seg: true, p, q, hue: sg.hue });
    }
    for (const nd of nodes) {
      const p = proj(world(nd.x, nd.y, nd.z));
      prims.push({ z: p[2], seg: false, p, hue: nd.hue });
    }
    prims.sort((a, b) => b.z - a.z);
    for (const pr of prims) {
      const r = pipeR * pr.p[3];
      if (pr.seg) drawCyl(pr.p, pr.q, r, pr.hue);
      else drawJoint(pr.p[0], pr.p[1], r, pr.hue);
    }
  };
}

/* ---------- 8. 智能贪吃蛇（BFS 自动寻路） ---------- */
function snakeCreate(ctx, w, h) {
  const cols = 28;
  const rows = Math.max(12, Math.round(cols * h / w));
  const cs = Math.min(w / cols, h / rows);
  const ox = (w - cs * cols) / 2, oy = (h - cs * rows) / 2;
  let snake, dir, food, acc, speed;
  const occ = (c, r, skipTail) => snake.slice(0, skipTail ? -1 : snake.length).some(s => s.c === c && s.r === r);
  const placeFood = () => {
    let c, r;
    do { c = Math.floor(Math.random() * cols); r = Math.floor(Math.random() * rows); } while (occ(c, r));
    food = { c, r };
  };
  const reset = () => {
    const mid = Math.floor(rows / 2);
    snake = [{ c: 5, r: mid }, { c: 4, r: mid }, { c: 3, r: mid }];
    dir = { c: 1, r: 0 }; acc = 0; speed = 7;
    placeFood();
    ctx.fillStyle = '#05070c'; ctx.fillRect(0, 0, w, h);
  };
  const nextDir = () => {
    const head = snake[0];
    const key = (c, r) => r * cols + c;
    const blocked = new Set(snake.slice(0, -1).map(s => key(s.c, s.r)));
    const prev = new Map(), seen = new Set([key(head.c, head.r)]), q = [head];
    while (q.length) {
      const cur = q.shift();
      if (cur.c === food.c && cur.r === food.r) {
        let n = cur;
        while (true) {
          const p = prev.get(key(n.c, n.r));
          if (!p || (p.c === head.c && p.r === head.r)) break;
          n = p;
        }
        return { c: n.c - head.c, r: n.r - head.r };
      }
      for (const [dc, dr] of [[1, 0], [0, 1], [-1, 0], [0, -1]]) {
        const c2 = cur.c + dc, r2 = cur.r + dr, k = key(c2, r2);
        if (c2 < 0 || c2 >= cols || r2 < 0 || r2 >= rows || seen.has(k) || blocked.has(k)) continue;
        seen.add(k); prev.set(k, cur); q.push({ c: c2, r: r2 });
      }
    }
    return null;
  };
  const safeMove = () => {
    const head = snake[0];
    for (const d of [dir, { c: 1, r: 0 }, { c: -1, r: 0 }, { c: 0, r: 1 }, { c: 0, r: -1 }]) {
      const c2 = head.c + d.c, r2 = head.r + d.r;
      if (c2 >= 0 && c2 < cols && r2 >= 0 && r2 < rows && !occ(c2, r2, true)) return d;
    }
    return null;
  };
  const draw = () => {
    ctx.fillStyle = '#05070c'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(139,124,255,0.06)';
    for (let c = 0; c <= cols; c += 2) ctx.fillRect(ox + c * cs, oy, 1, cs * rows);
    for (let r = 0; r <= rows; r += 2) ctx.fillRect(ox, oy + r * cs, cs * cols, 1);
    ctx.save();
    ctx.shadowColor = 'rgba(255,90,90,.8)'; ctx.shadowBlur = 14;
    ctx.fillStyle = '#ff5a5a';
    ctx.beginPath();
    ctx.arc(ox + (food.c + 0.5) * cs, oy + (food.r + 0.5) * cs, cs * 0.34, 0, 7);
    ctx.fill();
    ctx.restore();
    snake.forEach((s, i) => {
      const t = i / snake.length;
      ctx.fillStyle = `hsl(${145 - t * 40} ${80 - t * 25}% ${58 - t * 22}%)`;
      rr(ctx, ox + s.c * cs + cs * 0.08, oy + s.r * cs + cs * 0.08, cs * 0.84, cs * 0.84, cs * 0.3);
      ctx.fill();
    });
  };
  const step = () => {
    const nd = nextDir() || safeMove();
    if (!nd) { reset(); return; }
    dir = nd;
    const head = { c: snake[0].c + dir.c, r: snake[0].r + dir.r };
    if (head.c < 0 || head.c >= cols || head.r < 0 || head.r >= rows || occ(head.c, head.r, true)) { reset(); return; }
    snake.unshift(head);
    if (head.c === food.c && head.r === food.r) {
      speed = Math.min(14, speed + 0.25);
      placeFood();
    } else snake.pop();
  };
  reset();
  return (dt) => {
    acc += dt * speed;
    while (acc >= 1) { acc -= 1; step(); }
    draw();
  };
}

/* ---------- 9. 文字滚动 ---------- */
function textCreate(ctx, w, h) {
  const text = localStorage.getItem('ws-text') || 'HELLO JSOS · 屏保时间到 · 起来活动一下吧 ✨';
  let x = w, t = 0;
  return (dt) => {
    t += dt;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    const fs = Math.min(h * 0.26, 150);
    ctx.font = `800 ${fs}px 'Segoe UI', 'Microsoft YaHei', system-ui, sans-serif`;
    const tw = ctx.measureText(text).width;
    x -= dt * (w * 0.1 + 80);
    if (x < -tw) x = w;
    const hue = (t * 30) % 360;
    const g = ctx.createLinearGradient(0, h / 2 - fs / 2, 0, h / 2 + fs / 2);
    g.addColorStop(0, `hsl(${hue} 95% 72%)`);
    g.addColorStop(1, `hsl(${(hue + 60) % 360} 95% 55%)`);
    ctx.save();
    ctx.shadowColor = `hsla(${hue} 95% 60% / .8)`; ctx.shadowBlur = 26;
    ctx.fillStyle = g; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    ctx.fillText(text, x, h / 2);
    ctx.restore();
  };
}

/* ---------- 10. 照片相册（必应精选 / 本地照片） ---------- */
const album = {
  settings: Object.assign(
    { source: 'net', dwell: 30, effect: 'fade', kenburns: true, showIndex: false },
    (() => { try { return JSON.parse(localStorage.getItem('ws-album') || '{}'); } catch { return {}; } })()
  ),
  netPhotos: [],   // { src, title, bad? }（流式追加）
  localPhotos: [], // { src, title }
  idx: 0,
  played: 0,
  fetching: false,
};
function saveAlbumSettings() { localStorage.setItem('ws-album', JSON.stringify(album.settings)); }

// 本地照片持久化（IndexedDB，仅存浏览器本地）
function idbOpen() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('ws-album-db', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('photos');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function idbAllPhotos() {
  const db = await idbOpen();
  return new Promise((res, rej) => {
    const req = db.transaction('photos').objectStore('photos').getAll();
    req.onsuccess = () => res(req.result || []);
    req.onerror = () => rej(req.error);
  });
}
async function idbSavePhotos(files) {
  const db = await idbOpen();
  await Promise.all(files.map(f => new Promise((res, rej) => {
    const tx = db.transaction('photos', 'readwrite');
    tx.objectStore('photos').put(f, f.name + '_' + f.size + '_' + f.lastModified);
    tx.oncomplete = res; tx.onerror = () => rej(tx.error);
  })));
}
async function idbClearPhotos() {
  const db = await idbOpen();
  return new Promise((res, rej) => {
    const tx = db.transaction('photos', 'readwrite');
    tx.objectStore('photos').clear();
    tx.oncomplete = res; tx.onerror = () => rej(tx.error);
  });
}
async function loadAlbumLocal() {
  try {
    const blobs = await idbAllPhotos();
    album.localPhotos.forEach(p => URL.revokeObjectURL(p.src));
    album.localPhotos = blobs.map(b => ({ src: URL.createObjectURL(b), title: '' }));
  } catch { /* IndexedDB 不可用则仅本次会话有效 */ }
}

// 必应随机壁纸：流式逐张追加到队列（官方 /img/rand 端点，经服务器同源回传；之后可扩展更多来源 API）
async function fetchMoreNet(n = 1) {
  let ok = 0;
  for (let i = 0; i < n; i++) {
    try {
      const r = await fetch('/api/bing-rand');
      if (!r.ok) break;
      const blob = await r.blob();
      album.netPhotos.push({ src: URL.createObjectURL(blob), title: '' });
      ok++;
    } catch { break; }
  }
  return ok;
}

function albumCreate(ctx, w, h) {
  const isNet = () => album.settings.source === 'net';
  const list = () => (isNet() ? album.netPhotos : album.localPhotos);
  const cache = new Map(); // src -> HTMLImageElement
  const ensureImg = (item) => {
    let img = cache.get(item.src);
    if (!img) {
      img = new Image();
      img.onerror = () => { item.bad = true; };
      img.src = item.src;
      cache.set(item.src, img);
    }
    return img;
  };
  const ready = (img) => img.complete && img.naturalWidth > 0;
  // 流式补充：网络模式下保证当前图后方有 3 张余量
  const ensureQueue = () => {
    if (!isNet() || album.fetching) return;
    if (album.netPhotos.length - album.idx < 3) {
      album.fetching = true;
      fetchMoreNet(3).finally(() => { album.fetching = false; });
    }
  };
  const drawCover = (img, scale = 1, dx = 0, dy = 0) => {
    const r = Math.max(w / img.width, h / img.height) * scale;
    const dw = img.width * r, dh = img.height * r;
    ctx.drawImage(img, (w - dw) / 2 + dx, (h - dh) / 2 + dy, dw, dh);
  };
  const centerText = (txt, size, alpha) => {
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.font = `500 ${Math.min(w, h) * size}px 'Segoe UI', 'Microsoft YaHei', system-ui, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, w / 2, h / 2);
  };
  let cur = null, prev = null, shownAt = 0, kbSeed = Math.random() * 6.28;
  return (dt) => {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    const L = list();
    if (album.settings.source === 'local' && !L.length) {
      centerText('请先在设置中选择本地照片', 0.045, 0.75);
      return;
    }
    if (!L.length) {
      if (!album.fetching) {
        album.fetching = true;
        fetchMoreNet(2).finally(() => { album.fetching = false; });
      }
      centerText(album.fetching ? '正在获取照片…' : '照片获取失败，请检查网络', 0.04, 0.6);
      return;
    }
    const dwell = album.settings.dwell;
    const kb = album.settings.kenburns;
    // 某一时刻的 Ken Burns 状态（供切换时记录旧图终态 / 每帧绘制新图）
    const kbState = (t) => {
      const p = Math.min(1, t / dwell);
      return kb
        ? { scale: 1 + 0.1 * p, dx: Math.sin(kbSeed) * 20 * p, dy: Math.cos(kbSeed) * 14 * p }
        : { scale: 1, dx: 0, dy: 0 };
    };
    if (!cur) {
      // 首图：找到一张可用的就立即显示（加载期间保持黑屏，无提示文字）
      for (let i = 0; i < L.length; i++) {
        const item = L[(album.idx + i) % L.length];
        if (item.bad) continue;
        const img = ensureImg(item);
        if (!ready(img)) return; // 静默等待
        album.idx = (album.idx + i) % L.length;
        cur = { item, img }; shownAt = 0; kbSeed = Math.random() * 6.28;
        break;
      }
      if (!cur) { centerText('暂无可用照片', 0.04, 0.6); return; }
    } else {
      shownAt += dt;
      if (shownAt >= dwell) {
        // 停留结束：下一张就绪才切换，期间保持显示当前图
        // 网络流：下一张是追加项（idx+1），无回绕；本地：循环回绕
        const j = album.idx + 1;
        const item = isNet() ? L[j] : L[j % L.length];
        if (item && !item.bad) {
          const img = ensureImg(item);
          if (ready(img)) {
            album.idx = isNet() ? j : j % L.length;
            // 记录旧图淡出时的 Ken Burns 终态，避免切换瞬间尺寸突跳
            prev = { img: cur.img, ...kbState(shownAt) };
            cur = { item, img }; shownAt = 0; kbSeed = Math.random() * 6.28;
            if (isNet()) album.played++;
          }
        }
      }
    }
    // 流式补充 + 缓存清理（只保留当前与下一张，防长会话内存膨胀）
    if (cur) {
      ensureQueue();
      const nextItem = isNet() ? L[album.idx + 1] : L[(album.idx + 1) % L.length];
      if (nextItem && !nextItem.bad) ensureImg(nextItem);
      for (const key of cache.keys()) {
        if (key !== cur.item.src && !(nextItem && key === nextItem.src)) cache.delete(key);
      }
    }
    // 绘制：当前图 + Ken Burns + 交叉淡入
    const fadeT = album.settings.effect === 'fade' ? Math.min(1, shownAt / 1.2) : 1;
    const k = kbState(shownAt);
    if (prev && fadeT < 1) drawCover(prev.img, prev.scale, prev.dx, prev.dy);
    ctx.globalAlpha = fadeT;
    drawCover(cur.img, k.scale, k.dx, k.dy);
    ctx.globalAlpha = 1;
    if (album.settings.showIndex) {
      const fs = Math.min(w, h) * 0.024;
      const txt = isNet() ? `第 ${album.played + 1} 张` : `${album.idx + 1} / ${L.length}`;
      ctx.font = `600 ${fs}px 'Segoe UI', system-ui, sans-serif`;
      const tw = ctx.measureText(txt).width;
      ctx.fillStyle = 'rgba(0,0,0,.45)';
      rr(ctx, 18, h - 18 - fs * 1.7, tw + 26, fs * 1.7, fs * 0.85);
      ctx.fill();
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, 31, h - 18 - fs * 0.85);
    }
  };
}

/* ---------- 相册设置面板 ---------- */
const albumModal = $('#albumModal');
function amNote(msg) { $('#amNote').textContent = msg || ''; }
function closeAlbumSettings() { albumModal.classList.remove('show'); }

function openAlbumSettings() {
  const s = album.settings;
  albumModal.querySelectorAll('[data-src]').forEach(b => b.classList.toggle('on', b.dataset.src === s.source));
  albumModal.querySelectorAll('[data-fx]').forEach(b => b.classList.toggle('on', b.dataset.fx === s.effect));
  $('#amLocalRow').style.display = s.source === 'local' ? '' : 'none';
  $('#amSrcNote').textContent = s.source === 'net'
    ? '必应每日精选 · 随机壁纸流式加载，自动补充'
    : '🔒 本地照片只在浏览器里显示，不会上传到任何服务器';
  $('#amDwell').value = s.dwell;
  $('#amDwellVal').textContent = s.dwell + 's';
  $('#amKb').checked = s.kenburns;
  $('#amIdx').checked = s.showIndex;
  amNote('');
  albumModal.classList.add('show');
  if (s.source === 'net' && !album.netPhotos.length) { amNote('正在获取照片…'); fetchMoreNet(2).then(n => amNote(n ? '' : '获取失败，请检查网络')); }
  loadAlbumLocal().then(() => { $('#amLocalCount').textContent = album.localPhotos.length ? `已存 ${album.localPhotos.length} 张` : '尚未选择照片'; });
}

albumModal.querySelectorAll('[data-src]').forEach(b => b.addEventListener('click', () => {
  album.settings.source = b.dataset.src;
  album.idx = 0; saveAlbumSettings(); openAlbumSettings();
}));
albumModal.querySelectorAll('[data-fx]').forEach(b => b.addEventListener('click', () => {
  album.settings.effect = b.dataset.fx; saveAlbumSettings(); openAlbumSettings();
}));
$('#amDwell').addEventListener('input', (e) => {
  album.settings.dwell = +e.target.value;
  $('#amDwellVal').textContent = album.settings.dwell + 's';
  saveAlbumSettings();
});
$('#amKb').addEventListener('change', (e) => { album.settings.kenburns = e.target.checked; saveAlbumSettings(); });
$('#amIdx').addEventListener('change', (e) => { album.settings.showIndex = e.target.checked; saveAlbumSettings(); });
$('#amClearPhotos').addEventListener('click', async () => {
  await idbClearPhotos();
  album.localPhotos.forEach(p => URL.revokeObjectURL(p.src));
  album.localPhotos = []; album.idx = 0;
  $('#amLocalCount').textContent = '尚未选择照片';
});
$('#amFiles').addEventListener('change', async (e) => {
  const files = [...e.target.files].filter(f => f.type.startsWith('image/'));
  if (!files.length) return;
  amNote('保存中…');
  try { await idbSavePhotos(files); } catch { /* 保存失败则仅会话内可用 */ }
  await loadAlbumLocal();
  $('#amLocalCount').textContent = `已存 ${album.localPhotos.length} 张`;
  amNote(`已添加 ${files.length} 张照片`);
  e.target.value = '';
});
$('#amPlay').addEventListener('click', async () => {
  const s = album.settings;
  if (s.source === 'local' && !album.localPhotos.length) { amNote('请先选择本地照片'); return; }
  if (s.source === 'net') {
    if (!album.netPhotos.length) {
      $('#amPlay').disabled = true;
      amNote('正在获取照片…');
      const n = await fetchMoreNet(2);
      $('#amPlay').disabled = false;
      if (!n) { amNote('获取失败，请检查网络'); return; }
    }
  }
  if (s.source === 'local') album.idx = 0; // 本地从头循环；网络流继续向后取新图
  closeAlbumSettings();
  play(SAVERS.find(x => x.id === 'album'));
});
$('#amClose').addEventListener('click', closeAlbumSettings);
albumModal.addEventListener('click', (e) => { if (e.target === albumModal) closeAlbumSettings(); });

/* ---------- 屏保注册表 ---------- */
const SAVERS = [
  { id: 'album',     name: '照片相册',   en: 'Photo Album', desc: '必应精选/本地照片，交叉淡入切换', icon: '🖼️', tile: 'linear-gradient(135deg,#3d5a4d,#1a2a22)', create: albumCreate },
  { id: 'black',     name: '纯黑',       en: 'Black Out',   desc: '纯黑画面，OLED 省电防烧屏',     icon: '⬛', tile: 'linear-gradient(135deg,#14141c,#000)', create: blackCreate },
  { id: 'matrix',    name: '矩阵字符雨', en: 'Matrix Rain', desc: '黑客帝国绿色数字雨，头字发光', icon: '💚', tile: 'linear-gradient(135deg,#0d3320,#071a10)', create: matrixCreate },
  { id: 'dvd',       name: 'DVD 弹跳',   en: 'DVD Bounce',  desc: '经典待机动画，撞角变色',       icon: '📀', tile: 'linear-gradient(135deg,#3a2a55,#1a1430)', create: dvdCreate },
  { id: 'starfield', name: '星际穿越',   en: 'Starfield',   desc: '超空间穿梭，繁星扑面而来',     icon: '🌌', tile: 'linear-gradient(135deg,#1a2a55,#0d1430)', create: starfieldCreate },
  { id: 'aurora',    name: '极光',       en: 'Aurora',      desc: '夜空中流动的绿紫色光幕',       icon: '🌈', tile: 'linear-gradient(135deg,#1d4038,#0c1e22)', create: auroraCreate },
  { id: 'clock',     name: '时钟',       en: 'Clock',       desc: '极简大字实时时钟，适合展示',   icon: '🕐', tile: 'linear-gradient(135deg,#243a5e,#101a30)', create: clockCreate },
  { id: 'flipclock', name: '翻页时钟',   en: 'Flip Clock',  desc: '复古翻页数字钟，整点报时可设置', icon: '⏰', tile: 'linear-gradient(135deg,#4a4a55,#1f1f28)', iframe: 'flipclock/index.html', hint: 'ESC 退出 · 双击时钟复位', },
  { id: 'pipes',     name: '3D 管道',    en: 'Pipes',       desc: '复古屏保管道路径无限生长',     icon: '🔧', tile: 'linear-gradient(135deg,#4d3a24,#241a10)', create: pipesCreate },
  { id: 'snake',     name: '智能贪吃蛇', en: 'Snake AI',    desc: 'BFS 寻路，小蛇自己觅食',       icon: '🐍', tile: 'linear-gradient(135deg,#1d4d2a,#0c2412)', create: snakeCreate },
  { id: 'text',      name: '文字滚动',   en: 'Text Scroll', desc: '彩虹流光跑马灯，内容可自定义', icon: '💬', tile: 'linear-gradient(135deg,#4d2440,#24101e)', create: textCreate },
  { id: 'ink',       name: '水墨流体',   en: 'Ink in Water', desc: 'GPU 流体模拟，墨入清水自动晕染', icon: '🖌️', tile: 'linear-gradient(135deg,#e8e4da,#8f887a)', iframe: 'ink.html' },
];

/* ---------- 启动器渲染 ---------- */
const grid = $('#grid');
for (const s of SAVERS) {
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <div class="tile" style="--tile-bg:${s.tile}">${s.icon}</div>
    <div class="go">▶</div>
    <div class="name">${s.name}</div>
    <div class="en">${s.en}</div>
    <div class="desc">${s.desc}</div>`;
  card.addEventListener('click', () => (s.id === 'album' ? openAlbumSettings() : play(s)));
  grid.appendChild(card);
}

/* ---------- 播放器 ---------- */
const overlay = $('#overlay'), cv = $('#cv'), hint = $('#hint'), title = $('#title'), toastEl = $('#toast');
const ctx = cv.getContext('2d');
let step = null, raf = 0, lastT = 0, playing = false, wakeLock = null, hideTimer = 0, resizeTimer = 0, currentSaver = null;

async function requestWakeLock() {
  try {
    wakeLock = await navigator.wakeLock?.request('screen');
    wakeLock?.addEventListener('release', () => { wakeLock = null; });
  } catch { /* 不支持或被拒绝则静默 */ }
}
function releaseWakeLock() {
  try { wakeLock?.release(); } catch { /* 忽略 */ }
  wakeLock = null;
}

function sizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  cv.width = Math.floor(innerWidth * dpr);
  cv.height = Math.floor(innerHeight * dpr);
  cv.style.width = innerWidth + 'px';
  cv.style.height = innerHeight + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { w: innerWidth, h: innerHeight };
}

function loop(ts) {
  raf = requestAnimationFrame(loop);
  const dt = Math.min((ts - lastT) / 1000, 0.05);
  lastT = ts;
  step?.(dt);
}

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 1800);
}

async function play(saver) {
  if (saver.id === 'text') {
    const t = prompt('滚动文字（取消则使用已有/默认内容）', localStorage.getItem('ws-text') || '');
    if (t && t.trim()) localStorage.setItem('ws-text', t.trim());
  }
  if (saver.iframe) { startIframeSaver(saver); return; }
  const { w, h } = sizeCanvas();
  overlay.classList.add('show');
  title.textContent = `${saver.icon} ${saver.name} · ${saver.en}`;
  hint.children[0].textContent = '单击屏幕退出';
  hint.classList.remove('fade'); title.classList.remove('fade');
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { hint.classList.add('fade'); title.classList.add('fade'); }, 3000);
  playing = true;
  currentSaver = saver;
  step = saver.create(ctx, w, h);
  lastT = performance.now();
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(loop);
  requestWakeLock();
}

/* iframe 型屏保（如水墨流体）：内嵌独立页面，交互/退出经 postMessage 桥接 */
let inkFrame = null;
function startIframeSaver(saver) {
  overlay.classList.add('show');
  title.textContent = `${saver.icon} ${saver.name} · ${saver.en}`;
  hint.children[0].textContent = saver.hint || '单击画墨 · ESC 退出';
  hint.classList.remove('fade'); title.classList.remove('fade');
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { hint.classList.add('fade'); title.classList.add('fade'); }, 3000);
  playing = true;
  currentSaver = saver;
  step = null;
  inkFrame = document.createElement('iframe');
  inkFrame.className = 'saver-frame';
  inkFrame.allow = 'fullscreen';
  inkFrame.src = saver.iframe;
  overlay.insertBefore(inkFrame, title);
  requestWakeLock();
}

function stop() {
  if (!playing) return;
  playing = false;
  cancelAnimationFrame(raf);
  step = null;
  if (inkFrame) { inkFrame.remove(); inkFrame = null; }
  currentSaver = null;
  overlay.classList.remove('show');
  releaseWakeLock();
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
}

function toggleFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(() => {});
  } else {
    const p = document.documentElement.requestFullscreen?.();
    p?.then(() => {}).catch(() => toast('当前环境不支持全屏（iframe 受限）'));
  }
}

overlay.addEventListener('click', (e) => {
  if (e.target === $('#fsBtn')) return;
  stop();
});
$('#fsBtn').addEventListener('click', (e) => { e.stopPropagation(); toggleFullscreen(); });
// 右键：切换系统全屏
overlay.addEventListener('contextmenu', (e) => {
  if (e.target === $('#fsBtn')) return;
  e.preventDefault();
  toggleFullscreen();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (albumModal.classList.contains('show')) { closeAlbumSettings(); return; }
    stop();
  } else if (playing && e.key.toLowerCase() === 'f') toggleFullscreen();
});
// iframe 型屏保经 postMessage 桥接 ESC 退出 / 全屏切换
window.addEventListener('message', (e) => {
  if (e.data === 'ws-esc') stop();
  else if (e.data === 'ws-fs') toggleFullscreen();
});
// 视口尺寸变化（进/出全屏、窗口拉伸）：按新尺寸重建屏保状态（iframe 型由页面自适应）
window.addEventListener('resize', () => {
  if (!playing) return;
  if (currentSaver?.iframe) return;
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (!playing || !currentSaver) return;
    const { w, h } = sizeCanvas();
    step = currentSaver.create(ctx, w, h);
  }, 120);
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && playing) requestWakeLock();
});
