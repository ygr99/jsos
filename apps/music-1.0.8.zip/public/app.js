// 音乐播放器应用
const MusicApp = {
  // 状态
  state: {
    search: '',
    searching: false,
    results: [],
    source: 'netease',
    playlists: [],
    activeListId: '',
    nowPlayingListId: '',
    currentIndex: -1,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    loopMode: 'order', // order, repeat, single, shuffle
    volume: 100,
    playbackRate: 1,
    dynamicTheme: false,
    eqGains: new Array(10).fill(0),
    eqPreset: 'Default',
    eqConnected: false,
    loadingSongId: null,
    isRetrying: false,
    editContext: null
  },

  // 常量
  constants: {
    PLAYLISTS_STORAGE_KEY: 'music_page_playlists_v1',
    LAST_STATE_STORAGE_KEY: 'music_page_last_state_v1',
    THEME_STORAGE_KEY: 'musicDynamicTheme',
    AI_ANALYSIS_STORAGE_KEY: 'music_page_ai_analysis_v1',
    EQ_BANDS: [80, 100, 125, 250, 500, 1000, 2000, 4000, 8000, 16000],
    EQ_PRESETS: {
      'Default': [0,0,0,0,0,0,0,0,0,0],
      'Pop': [4,3,2,1,0,0,1,2,3,2],
      'Dance': [6,5,4,2,0,-1,0,1,2,1],
      'Blues': [2,2,2,3,2,1,2,1,0,-1],
      'Classical': [0,0,0,0,0,0,0,1,2,3],
      'Jazz': [2,2,1,1,0,0,1,2,1,0],
      'Ballad': [1,1,0,0,2,3,2,1,0,-1],
      'Electronic': [5,4,3,0,-1,-2,0,2,4,5],
      'Rock': [3,2,1,0,-1,0,2,3,2,1],
      'Country': [0,0,0,1,2,2,3,2,1,0],
      'Vocal': [-2,-1,0,1,3,4,3,1,-1,-2]
    },
    EQ_PRESET_TEXT: {
      'Default': '默认',
      'Pop': '流行',
      'Dance': '舞曲',
      'Blues': '蓝调',
      'Classical': '古典',
      'Jazz': '爵士',
      'Ballad': '慢歌',
      'Electronic': '电子乐',
      'Rock': '摇滚',
      'Country': '乡村',
      'Vocal': '人声'
    },
    MUSIC_SOURCES: [
      { key: 'netease', name: '网易云', icon: '🎵' },
      { key: 'qq', name: 'QQ音乐', icon: '🎶' },
      { key: 'bilibili', name: '哔哩哔哩', icon: '📺' },
      { key: 'douyin', name: '抖音', icon: '🎬' }
    ],
    LOOP_MODES: [
      { key: 'order', icon: 'fa-repeat', title: '顺序播放' },
      { key: 'repeat', icon: 'fa-rotate', title: '列表循环' },
      { key: 'single', icon: 'fa-rotate', title: '单曲循环', badge: '1' },
      { key: 'shuffle', icon: 'fa-shuffle', title: '随机播放' }
    ],
    PLAN_ITEMS: [
      { id: 1, text: '音乐解析：抖音视频解析，QQ音乐，酷狗，酷我等等等', completed: false },
      { id: 2, text: '音乐推荐：不知道咋推荐', completed: false },
      { id: 3, text: '导入功能：导入在线歌单，音乐数据导出本地和导入本地', completed: false },
      { id: 4, text: '播放功能：缓存歌曲播放失败重试机制，刷新音频链接', completed: true },
      { id: 5, text: '播放功能：音量控制，速度控制，全局的', completed: true },
      { id: 6, text: '搜索歌词：支持搜索歌词（有些歌曲没有歌词，搜索添加歌词）', completed: true },
      { id: 7, text: '歌词效果：逐字歌词，模糊歌词，等等等', completed: false },
      { id: 8, text: '外观设置：音乐可视化动效，页面背景，毛玻璃效果，等等等', completed: false },
      { id: 9, text: '其他设置：一些音乐平台推荐', completed: false },
      { id: 10, text: '（更多想法，敬请期待…）', completed: false }
    ]
  },

  // DOM 元素
  elements: {},

  // 音频上下文
  audioContext: null,
  mediaSource: null,
  eqFilters: null,

  // 初始化
  init() {
    this.cacheElements();
    this.bindEvents();
    this.initPlaylists();
    this.initEQ();
    this.loadTheme();
    this.renderPlanList();
    this.renderEQPresets();
    this.renderEQSliders();
    this.updatePlaceholder();
    this.initLyricsInteraction();
  },

  // 缓存 DOM 元素
  cacheElements() {
    this.elements = {
      musicPage: document.getElementById('musicPage'),
      settingsBtn: document.getElementById('settingsBtn'),
      sourceSelect: document.getElementById('sourceSelect'),
      searchInput: document.getElementById('searchInput'),
      searchBtn: document.getElementById('searchBtn'),
      clearSearch: document.getElementById('clearSearch'),
      albumCover: document.getElementById('albumCover'),
      albumPlaceholder: document.getElementById('albumPlaceholder'),
      randomSongBtn: document.getElementById('randomSongBtn'),
      randomSongBtnMobile: document.getElementById('randomSongBtnMobile'),
      songTitle: document.getElementById('songTitle'),
      songArtist: document.getElementById('songArtist'),
      lyricsList: document.getElementById('lyricsList'),
      lyricsEmpty: document.getElementById('lyricsEmpty'),
      lyricsContainer: document.getElementById('lyricsContainer'),
      timeLeft: document.getElementById('timeLeft'),
      timeRight: document.getElementById('timeRight'),
      progressBar: document.getElementById('progressBar'),
      volumeBtn: document.getElementById('volumeBtn'),
      volumeSlider: document.getElementById('volumeSlider'),
      volumeSliderContainer: document.getElementById('volumeSliderContainer'),
      speedBtn: document.getElementById('speedBtn'),
      speedSlider: document.getElementById('speedSlider'),
      speedSliderContainer: document.getElementById('speedSliderContainer'),
      loopBtn: document.getElementById('loopBtn'),
      prevBtn: document.getElementById('prevBtn'),
      playBtn: document.getElementById('playBtn'),
      nextBtn: document.getElementById('nextBtn'),
      playlistBtn: document.getElementById('playlistBtn'),
      searchModal: document.getElementById('searchModal'),
      closeSearchModal: document.getElementById('closeSearchModal'),
      searchLoading: document.getElementById('searchLoading'),
      searchEmpty: document.getElementById('searchEmpty'),
      resultList: document.getElementById('resultList'),
      settingsModal: document.getElementById('settingsModal'),
      closeSettingsModal: document.getElementById('closeSettingsModal'),
      dynamicTheme: document.getElementById('dynamicTheme'),
      settingsItems: document.querySelectorAll('.settings-item'),
      basicTab: document.getElementById('basicTab'),
      planTab: document.getElementById('planTab'),
      changelogTab: document.getElementById('changelogTab'),
      planList: document.getElementById('planList'),
      eqModal: document.getElementById('eqModal'),
      closeEqModal: document.getElementById('closeEqModal'),
      eqWarning: document.getElementById('eqWarning'),
      eqPresets: document.getElementById('eqPresets'),
      eqSliders: document.getElementById('eqSliders'),
      playlistDrawer: document.getElementById('playlistDrawer'),
      closeDrawer: document.getElementById('closeDrawer'),
      playlistCount: document.getElementById('playlistCount'),
      newPlaylistBtn: document.getElementById('newPlaylistBtn'),
      playlistTabs: document.getElementById('playlistTabs'),
      playlistFilter: document.getElementById('playlistFilter'),
      clearFilter: document.getElementById('clearFilter'),
      playlistItems: document.getElementById('playlistItems'),
      editModal: document.getElementById('editModal'),
      closeEditModal: document.getElementById('closeEditModal'),
      editName: document.getElementById('editName'),
      editArtist: document.getElementById('editArtist'),
      editLrc: document.getElementById('editLrc'),
      lrcGroup: document.getElementById('lrcGroup'),
      searchLrcBtn: document.getElementById('searchLrcBtn'),
      clearLrcBtn: document.getElementById('clearLrcBtn'),
      saveEditBtn: document.getElementById('saveEditBtn'),
      cancelEditBtn: document.getElementById('cancelEditBtn'),
      lyricSearchModal: document.getElementById('lyricSearchModal'),
      closeLyricSearchModal: document.getElementById('closeLyricSearchModal'),
      lyricSource: document.getElementById('lyricSource'),
      lyricSearchInput: document.getElementById('lyricSearchInput'),
      searchLyricBtn: document.getElementById('searchLyricBtn'),
      lyricSearchLoading: document.getElementById('lyricSearchLoading'),
      lyricSearchEmpty: document.getElementById('lyricSearchEmpty'),
      lyricResultList: document.getElementById('lyricResultList'),
      analyzeBtn: document.getElementById('analyzeBtn'),
      analyzeBtnMobile: document.getElementById('analyzeBtnMobile'),
      analyzeModal: document.getElementById('analyzeModal'),
      closeAnalyzeModal: document.getElementById('closeAnalyzeModal'),
      analyzeSongName: document.getElementById('analyzeSongName'),
      analyzeSongArtist: document.getElementById('analyzeSongArtist'),
      analyzeLoading: document.getElementById('analyzeLoading'),
      analyzeActions: document.getElementById('analyzeActions'),
      analyzeRetryBtn: document.getElementById('analyzeRetryBtn'),
      analyzeContent: document.getElementById('analyzeContent'),
      audioPlayer: document.getElementById('audioPlayer'),
      loadingOverlay: document.getElementById('loadingOverlay')
    };
  },

  // 显示加载动画
  showLoading() {
    if (this.elements.loadingOverlay) {
      this.elements.loadingOverlay.style.display = 'block';
    }
  },

  // 隐藏加载动画
  hideLoading() {
    if (this.elements.loadingOverlay) {
      this.elements.loadingOverlay.style.display = 'none';
    }
  },

  // 绑定事件
  bindEvents() {
    const { elements, state } = this;

    // 搜索
    elements.sourceSelect.addEventListener('change', (e) => {
      state.source = e.target.value;
      this.updatePlaceholder();
    });

    elements.searchInput.addEventListener('input', (e) => {
      state.search = e.target.value;
      elements.clearSearch.classList.toggle('visible', state.search.length > 0);
    });

    elements.searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.performSearch();
    });

    elements.searchBtn.addEventListener('click', () => this.performSearch());
    elements.clearSearch.addEventListener('click', () => {
      state.search = '';
      elements.searchInput.value = '';
      elements.clearSearch.classList.remove('visible');
    });

    // 设置
    elements.settingsBtn.addEventListener('click', () => {
      elements.settingsModal.classList.add('active');
    });

    elements.closeSettingsModal.addEventListener('click', () => {
      elements.settingsModal.classList.remove('active');
    });

    elements.dynamicTheme.addEventListener('change', (e) => {
      state.dynamicTheme = e.target.checked;
      localStorage.setItem(this.constants.THEME_STORAGE_KEY, state.dynamicTheme ? '1' : '0');
      if (state.dynamicTheme) {
        this.applyThemeFromCurrentSong();
      } else {
        this.resetTheme();
      }
    });

    elements.settingsItems.forEach(item => {
      item.addEventListener('click', () => {
        elements.settingsItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        const tab = item.dataset.tab;
        elements.basicTab.style.display = tab === 'basic' ? 'block' : 'none';
        elements.planTab.style.display = tab === 'plan' ? 'block' : 'none';
        elements.changelogTab.style.display = tab === 'changelog' ? 'block' : 'none';
      });
    });

    // 搜索结果弹窗
    elements.closeSearchModal.addEventListener('click', () => {
      elements.searchModal.classList.remove('active');
    });

    // 播放控制
    elements.playBtn.addEventListener('click', () => this.togglePlay());
    elements.prevBtn.addEventListener('click', () => this.handlePrev());
    elements.nextBtn.addEventListener('click', () => this.handleNext());
    elements.loopBtn.addEventListener('click', () => this.toggleLoopMode());

    // 进度条
    elements.progressBar.addEventListener('input', (e) => {
      const time = (e.target.value / 100) * state.duration;
      elements.audioPlayer.currentTime = time;
      state.currentTime = time;
    });

    // 音量
    elements.volumeBtn.addEventListener('click', () => {
      const visible = elements.volumeSliderContainer.style.display === 'block';
      elements.volumeSliderContainer.style.display = visible ? 'none' : 'block';
      elements.speedSliderContainer.style.display = 'none';
    });

    elements.volumeSlider.addEventListener('input', (e) => {
      state.volume = parseInt(e.target.value);
      elements.audioPlayer.volume = state.volume / 100;
      this.updateVolumeIcon();
      // 更新音量数值显示
      const volumeValue = document.getElementById('volumeValue');
      if (volumeValue) {
        volumeValue.textContent = state.volume + '%';
      }
    });

    // 速度
    elements.speedBtn.addEventListener('click', () => {
      const visible = elements.speedSliderContainer.style.display === 'block';
      elements.speedSliderContainer.style.display = visible ? 'none' : 'block';
      elements.volumeSliderContainer.style.display = 'none';
    });

    elements.speedSlider.addEventListener('input', (e) => {
      state.playbackRate = parseFloat(e.target.value);
      elements.audioPlayer.playbackRate = state.playbackRate;
      // 更新速度数值显示
      const speedValue = document.getElementById('speedValue');
      if (speedValue) {
        speedValue.textContent = state.playbackRate.toFixed(1) + 'x';
      }
    });

    // 歌单
    elements.playlistBtn.addEventListener('click', () => {
      elements.playlistDrawer.classList.add('active');
      this.renderPlaylistTabs();
      this.renderPlaylistItems();
    });

    elements.closeDrawer.addEventListener('click', () => {
      elements.playlistDrawer.classList.remove('active');
    });

    elements.newPlaylistBtn.addEventListener('click', () => this.createPlaylist());

    elements.playlistFilter.addEventListener('input', () => {
      this.renderPlaylistItems();
    });

    elements.clearFilter.addEventListener('click', () => {
      elements.playlistFilter.value = '';
      this.renderPlaylistItems();
    });

    // 编辑弹窗
    elements.closeEditModal.addEventListener('click', () => {
      elements.editModal.classList.remove('active');
    });

    elements.cancelEditBtn.addEventListener('click', () => {
      elements.editModal.classList.remove('active');
    });

    elements.saveEditBtn.addEventListener('click', () => this.saveEdit());

    elements.searchLrcBtn.addEventListener('click', () => {
      elements.lyricSearchModal.classList.add('active');
      elements.lyricSearchInput.value = `${elements.editName.value} ${elements.editArtist.value}`;
    });

    elements.clearLrcBtn.addEventListener('click', () => {
      elements.editLrc.value = '';
    });

    // 歌词搜索
    elements.closeLyricSearchModal.addEventListener('click', () => {
      elements.lyricSearchModal.classList.remove('active');
    });

    elements.searchLyricBtn.addEventListener('click', () => this.searchLyrics());

    elements.lyricSearchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.searchLyrics();
    });

    // AI歌词解读
    elements.analyzeBtn.addEventListener('click', () => this.openAnalyzeModal());
    if (elements.analyzeBtnMobile) {
      elements.analyzeBtnMobile.addEventListener('click', () => this.openAnalyzeModal());
    }
    elements.closeAnalyzeModal.addEventListener('click', () => {
      elements.analyzeModal.classList.remove('active');
    });

    // 随机一首歌按钮
    if (elements.randomSongBtn) {
      elements.randomSongBtn.addEventListener('click', () => this.openRandomSong());
    }
    if (elements.randomSongBtnMobile) {
      elements.randomSongBtnMobile.addEventListener('click', () => this.openRandomSong());
    }

    // 重新解析按钮
    if (elements.analyzeRetryBtn) {
      elements.analyzeRetryBtn.addEventListener('click', () => this.reanalyzeLyrics());
    }

    // 音频事件
    elements.audioPlayer.addEventListener('timeupdate', () => {
      state.currentTime = elements.audioPlayer.currentTime;
      state.duration = elements.audioPlayer.duration || 0;
      this.updateProgress();
      this.updateLyrics();
    });

    elements.audioPlayer.addEventListener('loadedmetadata', () => {
      state.duration = elements.audioPlayer.duration;
      this.updateProgress();
    });

    elements.audioPlayer.addEventListener('ended', () => {
      this.handleEnded();
    });

    elements.audioPlayer.addEventListener('playing', () => {
      // 播放成功即清零连续失败计数
      this.state.playFailCount = 0;
    });

    elements.audioPlayer.addEventListener('error', (e) => {
      const error = e.target.error;
      console.log('音频播放错误:', error?.code, error?.message);

      // 只在特定错误码时触发重试
      // 2 = NETWORK_ERROR, 4 = MEDIA_ERR_SRC_NOT_SUPPORTED
      if (!state.isRetrying && state.currentIndex >= 0) {
        const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
        const currentSong = list?.songs[state.currentIndex];

        // 如果当前歌曲标记为解析失败，则不重试
        if (currentSong?.parseFailed) {
          console.log('歌曲已标记为解析失败，跳过重试');
          return;
        }

        // 防无限循环：同一首歌连续 3 次播放失败（刷新链接也没用）→ 停止重试
        this.state.playFailCount = (this.state.playFailCount || 0) + 1;
        if (this.state.playFailCount >= 3) {
          console.error('连续 3 次播放失败，标记解析失败并停止重试');
          if (currentSong && list) {
            list.songs[state.currentIndex] = { ...currentSong, parseFailed: true };
            this.savePlaylists();
          }
          this.showToast('多次播放失败，已停止重试，请切换歌曲');
          return;
        }

        if (!error || error.code === 2 || error.code === 4) {
          console.log('音频链接可能已过期，触发重试机制...');
          this.retryCurrentSong();
        }
      }
    });

    // 点击外部关闭弹窗和下拉菜单
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
      }
      // 关闭下拉菜单
      if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');
      }
    });
  },

  // 更新搜索框占位符
  updatePlaceholder() {
    const { source } = this.state;
    const placeholders = {
      netease: '搜索歌曲/歌手',
      qq: '搜索歌曲/歌手',
      bilibili: '请输入哔哩哔哩视频链接',
      douyin: '请输入抖音视频链接',
      soda: '搜索汽水音乐歌曲/歌手'
    };
    this.elements.searchInput.placeholder = placeholders[source] || '搜索歌曲/歌手';
  },

  // 初始化歌单
  initPlaylists() {
    const stored = localStorage.getItem(this.constants.PLAYLISTS_STORAGE_KEY);
    if (stored) {
      try {
        this.state.playlists = JSON.parse(stored);
      } catch (e) {
        this.createDefaultPlaylists();
      }
    } else {
      this.createDefaultPlaylists();
    }

    // 存量数据迁移：早期版本存过被反引号包裹的脏 URL（封面 404 / 音频失效），加载时统一清洗
    let migrated = false;
    this.state.playlists.forEach((p) => {
      (p.songs || []).forEach((s) => {
        ['url', 'cover', 'lrc', 'name', 'artist', 'album'].forEach((k) => {
          if (typeof s[k] === 'string' && s[k].includes('`')) {
            s[k] = this.stripBackticks(s[k]);
            migrated = true;
          }
        });
      });
    });
    if (migrated) this.savePlaylists();

    // 设置默认活动歌单
    if (this.state.playlists.length > 0) {
      this.state.activeListId = this.state.playlists[0].id;
      this.state.nowPlayingListId = this.state.playlists[0].id;
    }

    // 恢复最后状态
    this.restoreLastState();
  },

  // 创建默认歌单
  createDefaultPlaylists() {
    const generateId = () => `pl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.state.playlists = [
      { id: generateId(), title: '播放历史', songs: [], system: 'history' },
      { id: generateId(), title: '默认收藏', songs: [], system: 'default' }
    ];
    this.savePlaylists();
  },

  // 保存歌单
  savePlaylists() {
    localStorage.setItem(this.constants.PLAYLISTS_STORAGE_KEY, JSON.stringify(this.state.playlists));
  },

  // 恢复最后状态
  restoreLastState() {
    const stored = localStorage.getItem(this.constants.LAST_STATE_STORAGE_KEY);
    if (stored) {
      try {
        const { nowPlayingListId, currentIndex } = JSON.parse(stored);
        const list = this.state.playlists.find(p => p.id === nowPlayingListId);
        if (list && currentIndex >= 0 && currentIndex < list.songs.length) {
          this.state.nowPlayingListId = nowPlayingListId;
          this.state.currentIndex = currentIndex;
          this.loadSong(list.songs[currentIndex], false);
        }
      } catch (e) {}
    }
  },

  // 保存最后状态
  saveLastState() {
    const { nowPlayingListId, currentIndex } = this.state;
    localStorage.setItem(this.constants.LAST_STATE_STORAGE_KEY, JSON.stringify({
      nowPlayingListId,
      currentIndex
    }));
  },

  // 初始化均衡器
  initEQ() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.audioContext = new AudioContext();
      }
    } catch (e) {}
  },

  // 加载主题
  loadTheme() {
    const stored = localStorage.getItem(this.constants.THEME_STORAGE_KEY);
    this.state.dynamicTheme = stored === '1';
    this.elements.dynamicTheme.checked = this.state.dynamicTheme;
  },

  // 渲染计划列表
  renderPlanList() {
    const html = this.constants.PLAN_ITEMS.map(item => `
      <div class="plan-item">
        <input type="checkbox" class="plan-checkbox" ${item.completed ? 'checked' : ''} disabled>
        <span class="plan-text ${item.completed ? 'completed' : ''}">${item.text}</span>
      </div>
    `).join('');
    this.elements.planList.innerHTML = html;
  },

  // 渲染均衡器预设
  renderEQPresets() {
    const presets = Object.keys(this.constants.EQ_PRESETS);
    const html = presets.map(preset => `
      <button class="eq-preset ${preset === this.state.eqPreset ? 'active' : ''}" data-preset="${preset}">
        ${this.constants.EQ_PRESET_TEXT[preset] || preset}
      </button>
    `).join('');
    this.elements.eqPresets.innerHTML = html;

    this.elements.eqPresets.querySelectorAll('.eq-preset').forEach(btn => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;
        this.applyEQPreset(preset);
      });
    });
  },

  // 渲染均衡器滑块
  renderEQSliders() {
    const html = this.constants.EQ_BANDS.map((freq, i) => `
      <div class="eq-slider-group">
        <input type="range" class="eq-slider" min="-12" max="12" step="0.5" value="0" data-index="${i}" orient="vertical">
        <span class="eq-label">${freq >= 1000 ? Math.round(freq/1000) + 'k' : freq}Hz</span>
      </div>
    `).join('');
    this.elements.eqSliders.innerHTML = html;

    this.elements.eqSliders.querySelectorAll('.eq-slider').forEach(slider => {
      slider.addEventListener('input', (e) => {
        const index = parseInt(e.target.dataset.index);
        const value = parseFloat(e.target.value);
        this.state.eqGains[index] = value;
        this.updateEQ();
      });
    });
  },

  // 应用均衡器预设
  applyEQPreset(preset) {
    this.state.eqPreset = preset;
    this.state.eqGains = [...this.constants.EQ_PRESETS[preset]];

    this.elements.eqPresets.querySelectorAll('.eq-preset').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.preset === preset);
    });

    this.elements.eqSliders.querySelectorAll('.eq-slider').forEach((slider, i) => {
      slider.value = this.state.eqGains[i];
    });

    this.updateEQ();
  },

  // 更新均衡器
  updateEQ() {
    if (this.eqFilters && this.state.eqConnected) {
      this.eqFilters.forEach((filter, i) => {
        filter.gain.value = Math.max(-12, Math.min(12, this.state.eqGains[i]));
      });
    }
  },

  // 连接均衡器
  connectEQ() {
    if (!this.audioContext || this.state.eqConnected) return;

    const audio = this.elements.audioPlayer;
    if (!this.mediaSource) {
      this.mediaSource = this.audioContext.createMediaElementSource(audio);
    }

    if (!this.eqFilters) {
      this.eqFilters = this.constants.EQ_BANDS.map(freq => {
        const filter = this.audioContext.createBiquadFilter();
        filter.type = 'peaking';
        filter.frequency.value = freq;
        filter.Q.value = 1.0;
        filter.gain.value = 0;
        return filter;
      });
    }

    let node = this.mediaSource;
    this.eqFilters.forEach(filter => {
      node.connect(filter);
      node = filter;
    });
    node.connect(this.audioContext.destination);

    this.state.eqConnected = true;
  },

  // 执行搜索
  async performSearch() {
    const { search, source } = this.state;
    if (!search.trim()) return;

    this.state.searching = true;
    this.elements.searchModal.classList.add('active');
    this.elements.searchLoading.style.display = 'block';
    this.elements.searchEmpty.style.display = 'none';
    this.elements.resultList.innerHTML = '';

    try {
      let results = [];

      if (source === 'netease') {
        results = await this.searchNetease(search);
      } else if (source === 'qq') {
        results = await this.searchQQ(search);
      } else if (source === 'bilibili') {
        results = await this.parseBilibili(search);
      } else if (source === 'douyin') {
        results = await this.parseDouyin(search);
      } else if (source === 'soda') {
        results = await this.searchSoda(search);
      }

      this.state.results = results;
      this.renderSearchResults();
    } catch (e) {
      console.error('搜索失败:', e);
      this.elements.searchEmpty.style.display = 'block';
    } finally {
      this.state.searching = false;
      this.elements.searchLoading.style.display = 'none';
    }
  },

  // 搜索网易云 - 使用后端接口
  async searchNetease(keyword) {
    const response = await fetch(`/api/netease/search?q=${encodeURIComponent(keyword)}&limit=30&offset=0`);
    const data = await response.json();

    if (data.code === 200 && data.data?.result?.songs) {
      return data.data.result.songs.map(s => ({
        id: s.id,
        name: s.name,
        artist: s.ar?.map(a => a.name).join(', ') || s.artists?.map(a => a.name).join(', '),
        album: s.al?.name || s.album?.name,
        cover: s.al?.picUrl || s.album?.picUrl,
        duration: s.dt ? Math.round(s.dt / 1000) : undefined,
        source: 'netease'
      }));
    }
    return [];
  },

  // 搜索QQ音乐
  async searchQQ(keyword) {
    const response = await fetch(`/api/qq/search?q=${encodeURIComponent(keyword)}&p=1&n=30`);
    const data = await response.json();

    if (data.code === 200 && data.data?.songs) {
      return data.data.songs.map(s => ({
        id: s.songmid,
        name: s.songname,
        artist: s.singers,
        album: s.album,
        cover: s.cover,
        duration: s.interval,
        source: 'qq',
        albumMid: s.albummid
      }));
    }
    return [];
  },

  // 搜索汽水音乐
  async searchSoda(keyword) {
    const response = await fetch(`/api/soda/search?q=${encodeURIComponent(keyword)}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.result_groups?.[0]?.data) {
      return data.data.result_groups[0].data.map(item => {
        const track = item.entity?.track || {};
        const album = track.album || {};
        const artists = track.artists || [];
        // 使用图片代理解决跨域问题
        let coverUrl = null;
        if (album.url_cover?.urls?.[0]) {
          const originalCoverUrl = `${album.url_cover.urls[0]}${album.url_cover.uri}~c5_375x375.jpg`;
          coverUrl = `/api/proxy/image?url=${encodeURIComponent(originalCoverUrl)}`;
        }
        return {
          id: track.id,
          name: track.name,
          artist: artists.map(a => a.name).join(', '),
          album: album.name,
          cover: coverUrl,
          duration: track.duration ? Math.round(track.duration / 1000) : undefined,
          source: 'soda'
        };
      });
    }
    return [];
  },

  // 解析B站
  async parseBilibili(url) {
    const response = await fetch(`/api/bilibili/audio?url=${encodeURIComponent(url)}`);
    const data = await response.json();

    if (data.code === 200 && data.data) {
      const payload = data.data;
      if (payload.isMultiPart && payload.pages) {
        return payload.pages.map(p => ({
          id: `${payload.videoId}#${p.page}`,
          name: p.part || payload.title,
          artist: payload.owner?.name || 'UP主',
          cover: payload.cover,
          source: 'bilibili'
        }));
      }
      return [{
        id: payload.videoId || url,
        name: payload.title,
        artist: payload.owner?.name || 'UP主',
        cover: payload.cover,
        url: payload.audioUrl,
        source: 'bilibili'
      }];
    }
    return [];
  },

  // 解析抖音
  async parseDouyin(url) {
    const response = await fetch('/api/douyin/parse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await response.json();

    if (data.code === 200 && data.data) {
      return [{
        id: url,
        name: data.data.title || '未命名',
        artist: '抖音',
        cover: data.data.cover,
        url: data.data.audioUrl,
        source: 'douyin'
      }];
    }
    return [];
  },

  // 渲染搜索结果
  renderSearchResults() {
    const { results } = this.state;

    if (results.length === 0) {
      this.elements.searchEmpty.style.display = 'block';
      this.elements.resultList.innerHTML = '';
      return;
    }

    this.elements.searchEmpty.style.display = 'none';
    this.elements.resultList.innerHTML = results.map((item, index) => `
      <li class="result-item" data-index="${index}">
        <span class="result-title">${this.escapeHtml(item.name)}</span>
        <span class="result-sub">${this.escapeHtml(item.artist)} ${item.album ? '- ' + this.escapeHtml(item.album) : ''}</span>
      </li>
    `).join('');

    this.elements.resultList.querySelectorAll('.result-item').forEach(item => {
      item.addEventListener('click', () => {
        const index = parseInt(item.dataset.index);
        this.playSong(this.state.results[index]);
        this.elements.searchModal.classList.remove('active');
      });
    });
  },

  // 播放歌曲
  async playSong(song) {
    const { source } = song;
    this.state.loadingSongId = song.id;

    // 显示加载动画
    this.showLoading();

    try {
      let targetSong = { ...song };

      // 获取播放链接
      if (!targetSong.url) {
        if (source === 'netease') {
          targetSong = await this.getNeteaseUrl(targetSong);
        } else if (source === 'qq') {
          targetSong = await this.getQQUrl(targetSong);
        } else if (source === 'bilibili' && song.id.includes('#')) {
          const [vid, page] = song.id.split('#');
          targetSong = await this.getBilibiliPageUrl(vid, page);
        } else if (source === 'soda') {
          targetSong = await this.getSodaUrl(targetSong);
        }
      }

      // 如果解析失败且标记为不可重试，显示友好提示
      if (targetSong.parseFailed) {
        this.hideLoading();
        this.showToast('网易云音乐解析失败，请尝试其他平台');
        return;
      }

      if (!targetSong.url) {
        this.hideLoading();
        this.showToast('无法获取播放链接');
        return;
      }

      // 添加到对应歌单
      this.addToPlaylist(targetSong);

      // 加载并播放
      this.loadSong(targetSong, true);

    } finally {
      this.state.loadingSongId = null;
      this.hideLoading();
    }
  },

  // 获取网易云链接 - 使用多个备用接口
  // 部分第三方解析接口返回的字符串被反引号包裹（封面 404 / 音频失效），统一剥离
  stripBackticks(v) {
    return typeof v === 'string' ? v.replace(/^\s*`+|`+\s*$/g, '').trim() : v;
  },

  async getNeteaseUrl(song) {
    const level = 'exhigh';

    // 先尝试后端API，后端会处理多个解析接口
    try {
      const response = await fetch(`/api/netease/play?id=${song.id}&level=${level}`);
      const data = await response.json();

      if (data.code === 200 && data.data?.audioUrl) {
        console.log('网易云解析成功:', data.data.source);
        return {
          ...song,
          url: this.stripBackticks(data.data.audioUrl),
          cover: this.stripBackticks(data.data.cover) || song.cover,
          lrc: this.stripBackticks(data.data.lyric) || song.lrc
        };
      }
      
      // 如果后端明确返回不重试标志，直接返回，不再尝试其他接口
      if (data.retry === false) {
        console.log('后端返回不重试标志，跳过其他解析接口');
        return { ...song, parseFailed: true };
      }
    } catch (err) {
      console.log('后端API失败:', err.message);
    }

    // 如果后端失败，尝试备用的前端直连接口
    const parsers = [
      // 1. cenguigui API (更新版)
      async () => {
        const response = await fetch(`https://music-api2.cenguigui.cn/?wy=&id=${song.id}&type=song&format=json&level=${level}`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.url) {
          return {
            ...song,
            url: data.data.url,
            cover: data.data.pic || song.cover,
            lrc: data.data.lyric || song.lrc
          };
        }
        return null;
      },
      // 2. haitangw API
      async () => {
        const response = await fetch(`https://musicapi.haitangw.net/music/wy.php?id=${song.id}&level=${level}&type=json`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.url) {
          return {
            ...song,
            url: data.data.url,
            cover: data.data.pic || song.cover
          };
        }
        return null;
      },
      // 3. cunyuapi
      async () => {
        const response = await fetch(`https://www.cunyuapi.top/163music_play?id=${song.id}&quality=${level}`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.song_file_url) {
          return {
            ...song,
            url: data.song_file_url,
            cover: data.img || song.cover,
            lrc: data.lyric || song.lrc
          };
        }
        return null;
      },
      // 4. xcvts API
      async () => {
        const response = await fetch(`https://api.xcvts.cn/api/music/163music?id=${song.id}&br=999000`, {
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data?.music) {
          return {
            ...song,
            url: data.data.music,
            cover: data.data.cover || song.cover,
            lrc: data.data.lyric || song.lrc
          };
        }
        return null;
      },
      // 5. ceseeet API
      async () => {
        const response = await fetch(`https://m-api.ceseet.me/url/wy/${song.id}/hires`, {
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'lx-music-request/2.6.0',
            'X-Request-Key': ''
          },
          signal: AbortController.timeout ? AbortController.timeout(8000) : undefined
        });
        const data = await response.json();
        if (data.data) {
          return {
            ...song,
            url: data.data
          };
        }
        return null;
      }
    ];

    let failedCount = 0;
    const maxFailures = 2;

    for (const parser of parsers) {
      try {
        const result = await parser();
        if (result && result.url) {
          result.url = this.stripBackticks(result.url);
          if (result.cover) result.cover = this.stripBackticks(result.cover);
          if (result.lrc) result.lrc = this.stripBackticks(result.lrc);
        }
        if (result && result.url && result.url.startsWith('http')) {
          console.log('网易云备用解析成功');
          return result;
        }
      } catch (err) {
        failedCount++;
        console.log(`备用解析接口失败 (${failedCount}/${maxFailures}):`, err.message);
        
        if (failedCount >= maxFailures) {
          console.log('达到最大失败次数，停止解析');
          break;
        }
        continue;
      }
    }

    console.error('所有网易云解析接口均失败');
    return { ...song, parseFailed: true };
  },

  // MD5 辅助函数
  async md5(string) {
    const encoder = new TextEncoder();
    const data = encoder.encode(string);
    const hashBuffer = await crypto.subtle.digest('MD5', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  // 获取QQ音乐链接
  async getQQUrl(song) {
    const response = await fetch(`/api/qq/play?songmid=${song.id}&albumMid=${song.albumMid || ''}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.audioUrl) {
      // 获取歌词
      try {
        const lrcResp = await fetch(`/api/qq/lyric?songmid=${song.id}`);
        const lrcData = await lrcResp.json();
        if (lrcData.code === 200 && lrcData.data?.lyric) {
          song.lrc = lrcData.data.lyric;
        }
      } catch (e) {}

      return {
        ...song,
        url: data.data.audioUrl,
        cover: data.data.cover || song.cover
      };
    }

    return song;
  },

  // 获取汽水音乐链接
  async getSodaUrl(song) {
    const response = await fetch(`/api/soda/play?id=${song.id}`);
    const data = await response.json();

    if (data.code === 200 && data.data?.audioUrl) {
      // 获取歌词
      try {
        const lrcResp = await fetch(`/api/soda/lyric?id=${song.id}`);
        const lrcData = await lrcResp.json();
        if (lrcData.code === 200 && lrcData.data?.lyric) {
          song.lrc = lrcData.data.lyric;
        }
      } catch (e) {}

      return {
        ...song,
        url: data.data.audioUrl,
        cover: data.data.cover || song.cover
      };
    }

    return song;
  },

  // 获取B站分P链接
  async getBilibiliPageUrl(bvid, page) {
    const response = await fetch(`/api/bilibili/audio?url=https://www.bilibili.com/video/${bvid}?p=${page}`);
    const data = await response.json();

    if (data.code === 200 && data.data) {
      return {
        id: `${bvid}#${page}`,
        name: data.data.title,
        artist: data.data.owner?.name || 'UP主',
        cover: data.data.cover,
        url: data.data.audioUrl,
        source: 'bilibili'
      };
    }

    return null;
  },

  // 添加歌曲到歌单
  addToPlaylist(song) {
    const { source } = song;
    let targetList;

    if (source === 'bilibili') {
      targetList = this.state.playlists.find(p => p.title === '哔哩哔哩');
      if (!targetList) {
        targetList = { id: this.generateId(), title: '哔哩哔哩', songs: [] };
        this.state.playlists.push(targetList);
      }
    } else if (source === 'douyin') {
      targetList = this.state.playlists.find(p => p.title === '抖音');
      if (!targetList) {
        targetList = { id: this.generateId(), title: '抖音', songs: [] };
        this.state.playlists.push(targetList);
      }
    } else {
      targetList = this.state.playlists.find(p => p.system === 'history');
    }

    if (!targetList) return;

    const existingIndex = targetList.songs.findIndex(s => s.id === song.id);
    if (existingIndex >= 0) {
      targetList.songs[existingIndex] = song;
      this.state.currentIndex = existingIndex;
    } else {
      targetList.songs.push(song);
      this.state.currentIndex = targetList.songs.length - 1;
    }

    this.state.nowPlayingListId = targetList.id;
    this.savePlaylists();
    this.saveLastState();
  },

  // 加载歌曲
  loadSong(song, autoPlay = false) {
    const audio = this.elements.audioPlayer;
    this.state.playFailCount = 0;
    let url = this.stripBackticks(song.url);

    // 使用代理
    if (song.source === 'bilibili') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://www.bilibili.com/`;
    } else if (song.source === 'douyin') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://www.douyin.com/`;
    } else if (song.source === 'netease') {
      url = `/api/proxy/audio?url=${encodeURIComponent(url)}&referer=https://music.163.com/`;
    }

    audio.src = url;
    audio.volume = this.state.volume / 100;
    audio.playbackRate = this.state.playbackRate;

    // 更新UI
    this.elements.songTitle.textContent = song.name || '未知歌曲';
    this.elements.songArtist.textContent = song.artist || '--';

    if (song.cover) {
      let coverUrl = song.cover;
      if (song.source === 'bilibili') {
        coverUrl = `/api/proxy/image?url=${encodeURIComponent(coverUrl)}`;
      }
      this.elements.albumCover.src = coverUrl;
      this.elements.albumCover.style.display = 'block';
      this.elements.albumPlaceholder.style.display = 'none';

      if (this.state.dynamicTheme) {
        this.applyThemeFromCover(coverUrl);
      }
    } else {
      this.elements.albumCover.style.display = 'none';
      this.elements.albumPlaceholder.style.display = 'flex';
    }

    // 解析歌词
    this.parseLyrics(song.lrc);

    if (autoPlay) {
      audio.play().then(() => {
        this.state.isPlaying = true;
        this.updatePlayButton();
      }).catch(() => {});
    }
  },

  // 解析歌词
  parseLyrics(lrc) {
    this.state.lyrics = [];
    this.elements.lyricsList.innerHTML = '';

    if (!lrc) {
      this.elements.lyricsEmpty.style.display = 'block';
      this.elements.lyricsContainer.style.display = 'none';
      return;
    }

    const lines = lrc.split(/\r?\n/);
    const timeRegex = /\[(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?]/g;
    const lyrics = [];

    lines.forEach(line => {
      let match;
      const times = [];
      while ((match = timeRegex.exec(line)) !== null) {
        const mm = parseInt(match[1]);
        const ss = parseInt(match[2]);
        const ms = match[3] ? parseInt(match[3].padEnd(3, '0')) : 0;
        times.push(mm * 60 + ss + ms / 1000);
      }

      const text = line.replace(timeRegex, '').trim();
      times.forEach(time => {
        lyrics.push({ time, text });
      });
    });

    this.state.lyrics = lyrics.filter(l => l.text).sort((a, b) => a.time - b.time);

    if (this.state.lyrics.length === 0) {
      this.elements.lyricsEmpty.style.display = 'block';
      this.elements.lyricsContainer.style.display = 'none';
    } else {
      this.elements.lyricsEmpty.style.display = 'none';
      this.elements.lyricsContainer.style.display = 'block';
      this.elements.lyricsList.innerHTML = this.state.lyrics.map((l, i) =>
        `<li data-index="${i}">${this.escapeHtml(l.text)}</li>`
      ).join('');
    }
  },

  // 初始化歌词交互
  initLyricsInteraction() {
    const container = this.elements.lyricsContainer;
    let scrollTimeout = null;

    // 鼠标进入 - 暂停自动滚动
    container.addEventListener('mouseenter', () => {
      this.state.lyricsAutoScroll = false;
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
        scrollTimeout = null;
      }
    });

    // 鼠标离开 - 1秒后恢复自动滚动
    container.addEventListener('mouseleave', () => {
      scrollTimeout = setTimeout(() => {
        this.state.lyricsAutoScroll = true;
        this.scrollToActiveLyrics(true); // 带动画回到当前歌词
      }, 1000);
    });

    // 触摸设备支持
    container.addEventListener('touchstart', () => {
      this.state.lyricsAutoScroll = false;
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
        scrollTimeout = null;
      }
    }, { passive: true });

    container.addEventListener('touchend', () => {
      scrollTimeout = setTimeout(() => {
        this.state.lyricsAutoScroll = true;
        this.scrollToActiveLyrics(true);
      }, 2000);
    });
  },

  // 滚动到当前歌词 - 使用 requestAnimationFrame 实现丝滑动画
  scrollToActiveLyrics(animate = false) {
    const activeItem = this.elements.lyricsList.querySelector('li.active');

    if (activeItem) {
      const container = this.elements.lyricsContainer;
      const targetScrollTop = activeItem.offsetTop - container.clientHeight / 2 + activeItem.clientHeight / 2;

      if (!animate) {
        container.scrollTop = targetScrollTop;
        return;
      }

      // 使用自定义动画实现更丝滑的效果
      const startScrollTop = container.scrollTop;
      const distance = targetScrollTop - startScrollTop;
      const duration = 600; // 动画持续时间
      const startTime = performance.now();

      const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

      const animateScroll = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easedProgress = easeOutCubic(progress);

        container.scrollTop = startScrollTop + distance * easedProgress;

        if (progress < 1) {
          requestAnimationFrame(animateScroll);
        }
      };

      requestAnimationFrame(animateScroll);
    }
  },

  // 更新歌词显示
  updateLyrics() {
    const { currentTime, lyrics } = this.state;
    if (!lyrics || lyrics.length === 0) return;

    let activeIndex = -1;
    for (let i = lyrics.length - 1; i >= 0; i--) {
      if (currentTime >= lyrics[i].time) {
        activeIndex = i;
        break;
      }
    }

    if (activeIndex < 0) activeIndex = 0;

    // 只在高亮行变化时才更新
    const items = this.elements.lyricsList.querySelectorAll('li');
    const currentActive = this.elements.lyricsList.querySelector('li.active');
    const currentActiveIndex = currentActive ? parseInt(currentActive.dataset.index) : -1;

    if (currentActiveIndex !== activeIndex) {
      items.forEach((item, i) => {
        item.classList.toggle('active', i === activeIndex);
      });

      // 只有在自动滚动模式下才滚动到当前歌词
      if (this.state.lyricsAutoScroll !== false && items[activeIndex]) {
        this.scrollToActiveLyrics(true); // 使用动画滚动
      }
    }
  },

  // 切换播放/暂停
  togglePlay() {
    const audio = this.elements.audioPlayer;
    if (this.state.isPlaying) {
      audio.pause();
      this.state.isPlaying = false;
    } else {
      if (!audio.src && this.state.currentIndex >= 0) {
        const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
        if (list && list.songs[this.state.currentIndex]) {
          this.loadSong(list.songs[this.state.currentIndex], true);
          return;
        }
      }
      audio.play().then(() => {
        this.state.isPlaying = true;
        this.updatePlayButton();
      }).catch(() => {});
    }
    this.updatePlayButton();
  },

  // 更新播放按钮
  updatePlayButton() {
    const icon = this.elements.playBtn.querySelector('i');
    icon.className = this.state.isPlaying ? 'fas fa-pause-circle' : 'fas fa-play-circle';
  },

  // 更新进度
  updateProgress() {
    const { currentTime, duration } = this.state;
    this.elements.timeLeft.textContent = this.formatTime(currentTime);
    this.elements.timeRight.textContent = this.formatTime(duration);

    if (duration > 0) {
      const percent = (currentTime / duration) * 100;
      this.elements.progressBar.value = percent;
    }
  },

  // 更新音量图标
  updateVolumeIcon() {
    const { volume } = this.state;
    const icon = this.elements.volumeBtn.querySelector('i');
    if (volume === 0) {
      icon.className = 'fas fa-volume-mute';
    } else if (volume < 50) {
      icon.className = 'fas fa-volume-down';
    } else {
      icon.className = 'fas fa-volume-up';
    }
  },

  // 切换循环模式
  toggleLoopMode() {
    const modes = ['order', 'repeat', 'single', 'shuffle'];
    const currentIndex = modes.indexOf(this.state.loopMode);
    this.state.loopMode = modes[(currentIndex + 1) % modes.length];

    const mode = this.constants.LOOP_MODES.find(m => m.key === this.state.loopMode);
    this.elements.loopBtn.innerHTML = mode.badge
      ? `<i class="fas ${mode.icon}"></i><span style="font-size:10px;position:absolute;">${mode.badge}</span>`
      : `<i class="fas ${mode.icon}"></i>`;
    this.elements.loopBtn.title = mode.title;
  },

  // 上一首
  handlePrev() {
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list || list.songs.length === 0) return;

    if (this.state.loopMode === 'shuffle') {
      this.state.currentIndex = Math.floor(Math.random() * list.songs.length);
    } else {
      this.state.currentIndex = this.state.currentIndex <= 0
        ? list.songs.length - 1
        : this.state.currentIndex - 1;
    }

    this.playSong(list.songs[this.state.currentIndex]);
  },

  // 下一首
  handleNext() {
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list || list.songs.length === 0) return;

    if (this.state.loopMode === 'shuffle') {
      this.state.currentIndex = Math.floor(Math.random() * list.songs.length);
    } else {
      this.state.currentIndex = this.state.currentIndex >= list.songs.length - 1
        ? 0
        : this.state.currentIndex + 1;
    }

    this.playSong(list.songs[this.state.currentIndex]);
  },

  // 播放结束
  handleEnded() {
    if (this.state.loopMode === 'single') {
      this.elements.audioPlayer.play();
    } else if (this.state.loopMode === 'repeat' || this.state.loopMode === 'shuffle') {
      this.handleNext();
    } else {
      const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
      if (list && this.state.currentIndex < list.songs.length - 1) {
        this.handleNext();
      }
    }
  },

  // 重试当前歌曲 - 带多次重试机制
  async retryCurrentSong(maxRetries = 3) {
    if (this.state.isRetrying) return;

    this.state.isRetrying = true;
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list) {
      this.state.isRetrying = false;
      return;
    }

    const song = list.songs[this.state.currentIndex];
    if (!song) {
      this.state.isRetrying = false;
      return;
    }

    // 如果歌曲已经标记为解析失败，不再重试
    if (song.parseFailed) {
      console.log('歌曲已标记为解析失败，不再重试');
      this.state.isRetrying = false;
      return;
    }

    // 显示重试提示
    this.showLoading();

    let lastError = null;
    let parseFailedCount = 0;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`第 ${attempt}/${maxRetries} 次尝试重新获取音频...`);

        let newSong;
        if (song.source === 'netease') {
          newSong = await this.getNeteaseUrl(song);
          
          // 如果网易云解析失败且标记为不可重试，直接退出
          if (newSong?.parseFailed) {
            parseFailedCount++;
            console.log('网易云解析接口返回失败，标记不可重试');
            
            if (parseFailedCount >= 2) {
              console.log('多次解析失败，停止重试');
              break;
            }
            continue;
          }
        } else if (song.source === 'qq') {
          newSong = await this.getQQUrl(song);
        } else if (song.source === 'bilibili') {
          const [vid, page] = song.id.split('#');
          newSong = await this.getBilibiliPageUrl(vid, page || 1);
        } else if (song.source === 'douyin') {
          const response = await fetch('/api/douyin/parse', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: song.id })
          });
          const data = await response.json();
          if (data.code === 200 && data.data) {
            newSong = { ...song, url: data.data.audioUrl };
          }
        } else if (song.source === 'soda') {
          newSong = await this.getSodaUrl(song);
        }

        if (newSong && newSong.url) {
          // 防死循环：重试拿到的仍是同一个失败 URL → 解析源没有恢复，标记失败停止循环
          if (newSong.url === song.url) {
            console.error('重试返回同一 URL，标记解析失败并停止重试');
            list.songs[this.state.currentIndex] = { ...song, parseFailed: true };
            this.savePlaylists();
            this.hideLoading();
            this.state.isRetrying = false;
            this.showToast('音频源暂不可用，请稍后重试或切换歌曲');
            return;
          }
          // 更新歌曲信息，清除失败标记
          list.songs[this.state.currentIndex] = { ...song, ...newSong, parseFailed: false };
          this.savePlaylists();

          // 重新加载并播放
          this.hideLoading();
          this.loadSong(list.songs[this.state.currentIndex], true);
          this.showToast('音频已刷新，继续播放');
          this.state.isRetrying = false;
          return;
        }
      } catch (e) {
        lastError = e;
        console.error(`第 ${attempt} 次重试失败:`, e.message);

        if (attempt < maxRetries) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
    }

    // 所有重试都失败了，标记歌曲为解析失败
    list.songs[this.state.currentIndex] = { ...song, parseFailed: true };
    this.savePlaylists();
    
    this.hideLoading();
    this.state.isRetrying = false;
    this.showToast('音频获取失败，请尝试切换歌曲');
    console.error('音频重试机制最终失败:', lastError);
  },

  // 渲染歌单标签
  renderPlaylistTabs() {
    const html = this.state.playlists.map(p => `
      <div class="playlist-tab ${p.id === this.state.activeListId ? 'active' : ''}" data-id="${p.id}">
        ${this.escapeHtml(p.title)}
        ${!p.system ? `<span class="more-btn" data-id="${p.id}"><i class="fas fa-ellipsis-v"></i></span>` : ''}
      </div>
    `).join('');

    this.elements.playlistTabs.innerHTML = html;

    this.elements.playlistTabs.querySelectorAll('.playlist-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        if (e.target.closest('.more-btn')) {
          e.stopPropagation();
          this.showPlaylistMenu(e.target.closest('.more-btn').dataset.id);
        } else {
          this.state.activeListId = tab.dataset.id;
          this.renderPlaylistTabs();
          this.renderPlaylistItems();
        }
      });
    });
  },

  // 渲染歌单列表
  renderPlaylistItems() {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list) return;

    const filter = this.elements.playlistFilter.value.toLowerCase();
    const songs = filter
      ? list.songs.filter(s =>
          (s.name || '').toLowerCase().includes(filter) ||
          (s.artist || '').toLowerCase().includes(filter)
        )
      : list.songs;

    this.elements.playlistCount.textContent = `歌曲 ${songs.length}${filter ? ` / 共 ${list.songs.length}` : ''} 首`;

    if (songs.length === 0) {
      this.elements.playlistItems.innerHTML = '<div class="empty">暂无歌曲</div>';
      return;
    }

    this.elements.playlistItems.innerHTML = songs.map((song, index) => {
      const realIndex = list.songs.findIndex(s => s.id === song.id);
      const isPlaying = this.state.nowPlayingListId === this.state.activeListId &&
                        realIndex === this.state.currentIndex;
      
      // 构建"移动到"下拉菜单选项
      const isBilibiliOrDouyin = list.title === '哔哩哔哩' || list.title === '抖音';
      const moveMenuItems = isBilibiliOrDouyin
        ? (this.state.playlists.find(p => p.title === '抖音')
            ? [{ key: 'douyin', label: '抖音' }]
            : [])
        : [
            { key: 'create', label: '＋ 新建歌单' },
            ...this.state.playlists
              .filter(p => p.id !== this.state.activeListId && p.title !== '哔哩哔哩' && p.title !== '抖音')
              .map(p => ({ key: p.id, label: p.title }))
          ];
      
      const moveDropdown = moveMenuItems.length > 0 ? `
        <div class="dropdown">
          <button class="dropdown-toggle" onclick="MusicApp.toggleMoveMenu(${realIndex})">移动到 <i class="fas fa-chevron-down"></i></button>
          <div class="dropdown-menu" id="moveMenu-${realIndex}">
            ${moveMenuItems.map(item => `
              <div class="dropdown-item" onclick="MusicApp.handleMoveClick(${realIndex}, '${item.key}')">${this.escapeHtml(item.label)}</div>
            `).join('')}
          </div>
        </div>
      ` : '';
      
      return `
        <li class="playlist-item ${isPlaying ? 'active' : ''}" data-index="${realIndex}">
          <div class="playlist-item-info">
            <div class="playlist-item-title">${this.escapeHtml(song.name)}</div>
            <div class="playlist-item-artist">${this.escapeHtml(song.artist)}</div>
          </div>
          <div class="playlist-item-actions">
            <button onclick="MusicApp.playFromPlaylist(${realIndex})">播放</button>
            <button onclick="MusicApp.removeFromPlaylist(${realIndex})">删除</button>
            ${isBilibiliOrDouyin ? `<button onclick="MusicApp.openEditModal(${realIndex})">修改</button>` : ''}
            ${moveDropdown}
          </div>
        </li>
      `;
    }).join('');
  },

  // 切换移动菜单显示
  toggleMoveMenu(index) {
    const menu = document.getElementById(`moveMenu-${index}`);
    if (menu) {
      const isVisible = menu.style.display === 'block';
      // 关闭所有其他菜单
      document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');
      menu.style.display = isVisible ? 'none' : 'block';
    }
  },

  // 处理移动点击
  handleMoveClick(index, key) {
    // 关闭菜单
    document.querySelectorAll('.dropdown-menu').forEach(m => m.style.display = 'none');

    if (key === 'create') {
      this.createPlaylist();
      return;
    }

    const sourceList = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!sourceList || !sourceList.songs[index]) return;

    const song = sourceList.songs[index];

    // 找到目标歌单
    let targetList;
    if (key === 'douyin') {
      targetList = this.state.playlists.find(p => p.title === '抖音');
    } else {
      targetList = this.state.playlists.find(p => p.id === key);
    }

    if (!targetList || targetList.id === this.state.activeListId) return;

    // 检查是否已存在
    const exists = targetList.songs.find(s => s.id === song.id);
    if (exists) {
      alert('该歌曲已在目标歌单中');
      return;
    }

    // 添加到目标歌单
    targetList.songs.push({ ...song });

    // 判断是否为复制模式（播放历史不删除原歌曲）
    const isCopyMode = sourceList.system === 'history';

    if (!isCopyMode) {
      // 从当前歌单删除
      sourceList.songs.splice(index, 1);

      // 更新当前播放索引
      if (this.state.activeListId === this.state.nowPlayingListId) {
        if (index === this.state.currentIndex) {
          this.state.currentIndex = -1;
          this.state.isPlaying = false;
          this.elements.audioPlayer.pause();
          this.elements.audioPlayer.src = '';
          localStorage.removeItem(this.constants.LAST_STATE_STORAGE_KEY);
        } else if (index < this.state.currentIndex) {
          this.state.currentIndex--;
        }
      }
    }

    this.savePlaylists();
    this.saveLastState();
    this.renderPlaylistItems();

    // 显示提示
    const actionText = isCopyMode ? '已添加到' : '已移动到';
    this.showToast(`${actionText}「${targetList.title}」`);
  },

  // 显示提示
  showToast(message) {
    const existingToast = document.querySelector('.toast-message');
    if (existingToast) {
      existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  },

  // 从歌单播放
  playFromPlaylist(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs[index]) return;

    this.state.nowPlayingListId = this.state.activeListId;
    this.state.currentIndex = index;
    this.playSong(list.songs[index]);
    this.saveLastState();
  },

  // 从歌单删除
  removeFromPlaylist(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list) return;

    list.songs.splice(index, 1);

    if (this.state.activeListId === this.state.nowPlayingListId) {
      if (index === this.state.currentIndex) {
        this.state.isPlaying = false;
        this.state.currentTime = 0;
        this.state.duration = 0;
        this.state.currentIndex = -1;
        this.elements.audioPlayer.pause();
        this.elements.audioPlayer.src = '';
        localStorage.removeItem(this.constants.LAST_STATE_STORAGE_KEY);
      } else if (index < this.state.currentIndex) {
        this.state.currentIndex--;
      }
    }

    this.savePlaylists();
    this.renderPlaylistItems();
  },

  // 创建歌单
  createPlaylist() {
    const name = prompt('新建歌单名称', '新建歌单');
    if (!name || !name.trim()) return;

    const newPlaylist = {
      id: this.generateId(),
      title: name.trim(),
      songs: []
    };

    this.state.playlists.push(newPlaylist);
    this.savePlaylists();
    this.renderPlaylistTabs();
  },

  // 显示歌单菜单
  showPlaylistMenu(id) {
    const action = confirm('删除此歌单？') ? 'delete' : null;
    if (action === 'delete') {
      const index = this.state.playlists.findIndex(p => p.id === id);
      if (index >= 0 && !this.state.playlists[index].system) {
        this.state.playlists.splice(index, 1);
        if (this.state.activeListId === id) {
          this.state.activeListId = this.state.playlists[0]?.id || '';
        }
        this.savePlaylists();
        this.renderPlaylistTabs();
        this.renderPlaylistItems();
      }
    }
  },

  // 打开编辑弹窗
  openEditModal(index) {
    const list = this.state.playlists.find(p => p.id === this.state.activeListId);
    if (!list || !list.songs[index]) return;

    const song = list.songs[index];
    this.state.editContext = { listId: this.state.activeListId, index };

    this.elements.editName.value = song.name || '';
    this.elements.editArtist.value = song.artist || '';
    this.elements.editLrc.value = song.lrc || '';

    this.elements.editModal.classList.add('active');
  },

  // 保存编辑
  saveEdit() {
    if (!this.state.editContext) return;

    const { listId, index } = this.state.editContext;
    const list = this.state.playlists.find(p => p.id === listId);
    if (!list || !list.songs[index]) return;

    list.songs[index].name = this.elements.editName.value.trim();
    list.songs[index].artist = this.elements.editArtist.value.trim();
    list.songs[index].lrc = this.elements.editLrc.value;

    this.savePlaylists();
    this.renderPlaylistItems();
    this.elements.editModal.classList.remove('active');
    this.state.editContext = null;
  },

  // 搜索歌词
  async searchLyrics() {
    const keyword = this.elements.lyricSearchInput.value.trim();
    if (!keyword) return;

    const source = this.elements.lyricSource.value;
    this.elements.lyricSearchLoading.style.display = 'block';
    this.elements.lyricSearchEmpty.style.display = 'none';
    this.elements.lyricResultList.innerHTML = '';

    try {
      let results = [];

      if (source === 'netease') {
        results = await this.searchNetease(keyword);
      } else if (source === 'qq') {
        results = await this.searchQQ(keyword);
      }

      this.renderLyricSearchResults(results, source);
    } catch (e) {
      this.elements.lyricSearchEmpty.style.display = 'block';
    } finally {
      this.elements.lyricSearchLoading.style.display = 'none';
    }
  },

  // 渲染歌词搜索结果
  renderLyricSearchResults(results, source) {
    if (results.length === 0) {
      this.elements.lyricSearchEmpty.style.display = 'block';
      return;
    }

    this.elements.lyricResultList.innerHTML = results.map((song, index) => `
      <li class="result-item" data-index="${index}" data-id="${song.id}" data-source="${source}">
        <span class="result-title">${this.escapeHtml(song.name)}</span>
        <span class="result-sub">${this.escapeHtml(song.artist)}</span>
      </li>
    `).join('');

    this.elements.lyricResultList.querySelectorAll('.result-item').forEach(item => {
      item.addEventListener('click', async () => {
        const id = item.dataset.id;
        const src = item.dataset.source;
        let lrc = '';

        if (src === 'netease') {
          const response = await fetch('https://api.kxzjoker.cn/api/163_music', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `url=${encodeURIComponent(id)}&level=exhigh&type=json`
          });
          const data = await response.json();
          lrc = data.lyric || '';
        } else if (src === 'qq') {
          const response = await fetch(`/api/qq/lyric?songmid=${id}`);
          const data = await response.json();
          lrc = data.data?.lyric || '';
        }

        this.elements.editLrc.value = lrc;
        this.elements.lyricSearchModal.classList.remove('active');
      });
    });
  },

  // 应用主题
  applyThemeFromCover(coverUrl) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 100;
      canvas.height = 100;
      ctx.drawImage(img, 0, 0, 100, 100);

      const { data } = ctx.getImageData(0, 0, 100, 100);
      let r = 0, g = 0, b = 0;
      for (let i = 0; i < data.length; i += 4) {
        r += data[i];
        g += data[i + 1];
        b += data[i + 2];
      }
      r = Math.round(r / (data.length / 4));
      g = Math.round(g / (data.length / 4));
      b = Math.round(b / (data.length / 4));

      const root = document.documentElement;
      root.style.setProperty('--music-bg-start', `rgb(${r + 100}, ${g + 100}, ${b + 100})`);
      root.style.setProperty('--music-bg-end', `rgb(${r + 80}, ${g + 80}, ${b + 80})`);
      root.style.setProperty('--music-accent', `rgb(${r}, ${g}, ${b})`);
      root.style.setProperty('--music-panel-bg', `rgb(${r + 120}, ${g + 120}, ${b + 120})`);
      // 同时更新 primary-color，让搜索按钮等组件也能跟随主题
      root.style.setProperty('--primary-color', `rgb(${r}, ${g}, ${b})`);
      root.style.setProperty('--primary-hover', `rgb(${Math.max(0, r - 20)}, ${Math.max(0, g - 20)}, ${Math.max(0, b - 20)})`);
      // 动态主题激活时，移除 content 区域的背景色让其继承主题色
      document.querySelector('.content')?.classList.add('theme-active');
    };
    img.src = coverUrl;
  },

  // 应用当前歌曲主题
  applyThemeFromCurrentSong() {
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list || this.state.currentIndex < 0) return;

    const song = list.songs[this.state.currentIndex];
    if (song && song.cover) {
      let coverUrl = song.cover;
      if (song.source === 'bilibili') {
        coverUrl = `/api/proxy/image?url=${encodeURIComponent(coverUrl)}`;
      }
      this.applyThemeFromCover(coverUrl);
    }
  },

  // 重置主题
  resetTheme() {
    const root = document.documentElement;
    root.style.setProperty('--music-bg-start', '#f6fafc');
    root.style.setProperty('--music-bg-end', '#eef4f8');
    root.style.setProperty('--music-accent', '#2563eb');
    root.style.setProperty('--music-panel-bg', '#F4F8FB');
    root.style.setProperty('--music-text-secondary', '#65708a');
    root.style.setProperty('--primary-color', '#1890ff');
    root.style.setProperty('--primary-hover', '#40a9ff');
    // 重置时移除 content 区域的 theme-active 类，恢复默认背景色
    document.querySelector('.content')?.classList.remove('theme-active');
  },

  // 随机打开一首歌
  async openRandomSong() {
    // 显示加载动画
    this.showLoading();

    try {
      const response = await fetch('/api/random-song');
      const data = await response.json();

      if (data.code === 200 && data.data && data.data.playUrl) {
        window.open(data.data.playUrl, '_blank');
      }
    } catch (e) {
      console.error('获取随机歌曲失败:', e);
    } finally {
      this.hideLoading();
    }
  },

  // 生成ID
  generateId() {
    return `pl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  },

  // 格式化时间
  formatTime(sec) {
    if (!isFinite(sec) || sec < 0) return '00:00';
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  },

  // HTML转义
  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  // 获取缓存的AI分析结果
  getCachedAnalysis(songId) {
    try {
      const stored = localStorage.getItem(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        const cache = JSON.parse(stored);
        return cache[songId] || null;
      }
    } catch (e) {}
    return null;
  },

  // 保存AI分析结果到缓存
  saveAnalysisToCache(songId, content) {
    try {
      let cache = {};
      const stored = localStorage.getItem(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        cache = JSON.parse(stored);
      }
      cache[songId] = {
        content,
        timestamp: Date.now()
      };
      localStorage.setItem(this.constants.AI_ANALYSIS_STORAGE_KEY, JSON.stringify(cache));
    } catch (e) {
      console.error('保存AI分析缓存失败:', e);
    }
  },

  // 当前正在分析的歌曲ID
  currentAnalyzingSongId: null,

  // 打开AI解读弹窗
  openAnalyzeModal() {
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list || this.state.currentIndex < 0) {
      this.showToast('请先播放一首歌曲');
      return;
    }

    const song = list.songs[this.state.currentIndex];
    if (!song || !song.lrc) {
      this.showToast('当前歌曲暂无歌词');
      return;
    }

    // 更新歌曲信息
    this.elements.analyzeSongName.textContent = song.name || '未知歌曲';
    this.elements.analyzeSongArtist.textContent = song.artist || '--';

    // 显示弹窗
    this.elements.analyzeModal.classList.add('active');

    // 保存当前歌曲ID
    this.currentAnalyzingSongId = song.id;

    // 检查是否有缓存
    const cached = this.getCachedAnalysis(song.id);
    if (cached && cached.content) {
      // 显示缓存内容
      this.elements.analyzeLoading.style.display = 'none';
      this.elements.analyzeActions.style.display = 'flex';
      this.elements.analyzeContent.innerHTML = this.renderAnalyzeContent(cached.content);
    } else {
      // 开始新的分析
      this.analyzeLyrics(song, false);
    }
  },

  // 重新解析
  reanalyzeLyrics() {
    const list = this.state.playlists.find(p => p.id === this.state.nowPlayingListId);
    if (!list || this.state.currentIndex < 0) return;

    const song = list.songs[this.state.currentIndex];
    if (!song) return;

    // 清除缓存
    try {
      const stored = localStorage.getItem(this.constants.AI_ANALYSIS_STORAGE_KEY);
      if (stored) {
        const cache = JSON.parse(stored);
        delete cache[song.id];
        localStorage.setItem(this.constants.AI_ANALYSIS_STORAGE_KEY, JSON.stringify(cache));
      }
    } catch (e) {}

    // 重新分析
    this.analyzeLyrics(song, true);
  },

  // AI分析歌词
  async analyzeLyrics(song, isRetry = false) {
    const { analyzeLoading, analyzeActions, analyzeContent } = this.elements;

    analyzeLoading.style.display = 'flex';
    analyzeActions.style.display = 'none';
    analyzeContent.innerHTML = '';

    // 提取纯歌词文本（去掉时间戳）
    const pureLyrics = this.extractPureLyrics(song.lrc);

    try {
      const response = await fetch('/api/ai/analyze-lyrics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          lyrics: pureLyrics,
          songName: song.name,
          artist: song.artist
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullContent = '';

      analyzeLoading.style.display = 'none';
      analyzeActions.style.display = 'flex';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;

            try {
              const parsed = JSON.parse(data);
              const delta = parsed.choices?.[0]?.delta?.content;
              if (delta) {
                fullContent += delta;
                analyzeContent.innerHTML = this.renderAnalyzeContent(fullContent);
              }
            } catch (e) {}
          }
        }
      }

      // 保存到缓存
      if (fullContent && this.currentAnalyzingSongId) {
        this.saveAnalysisToCache(this.currentAnalyzingSongId, fullContent);
      }
    } catch (error) {
      analyzeLoading.style.display = 'none';
      analyzeContent.innerHTML = `
        <div class="analyze-placeholder">
          <i class="fas fa-exclamation-circle" style="color: #f85149;"></i>
          <p>分析失败: ${error.message}</p>
          <p style="font-size: 12px; margin-top: 8px;">请检查网络连接或稍后重试</p>
        </div>
      `;
      console.error('AI分析失败:', error);
    }
  },

  // 提取纯歌词文本（去掉时间戳）
  extractPureLyrics(lrc) {
    if (!lrc) return '';
    const lines = lrc.split(/\r?\n/);
    const timeRegex = /\[\d{1,2}:\d{1,2}(?:\.\d{1,3})?]/g;

    return lines
      .map(line => line.replace(timeRegex, '').trim())
      .filter(text => text.length > 0)
      .join('\n');
  },

  // 渲染分析内容（支持Markdown）
  renderAnalyzeContent(text) {
    if (!text) return '';

    // 转义HTML
    let html = this.escapeHtml(text);

    // 处理标题 # ## ### #### ##### ######
    html = html.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
    html = html.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
    html = html.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');

    // 处理加粗 **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // 处理斜体 *text*
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // 处理引用 >
    html = html.replace(/^&gt;\s*(.+)$/gm, '<blockquote>$1</blockquote>');

    // 处理列表项 * 或 -
    html = html.replace(/^[\*\-]\s+(.+)$/gm, '<li>$1</li>');

    // 将连续的li包裹在ul中
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

    // 处理换行 - 将单个换行转为 <br>，但避免连续的 <br><br>
    html = html.replace(/\n/g, '<br>');

    // 移除连续的多个 <br>，只保留一个
    html = html.replace(/(<br>\s*){2,}/g, '<br>');

    // 移除标题标签后的 <br>
    html = html.replace(/(<\/?h[1-6][^>]*>)<br>/g, '$1');

    // 移除列表项前的 <br>
    html = html.replace(/<br>(<li>)/g, '$1');

    // 移除列表后的 <br>
    html = html.replace(/(<\/ul>)<br>/g, '$1');

    // 移除引用块后的 <br>
    html = html.replace(/(<\/blockquote>)<br>/g, '$1');

    return `<div class="analyze-result">${html}</div>`;
  }
};

// 启动应用
document.addEventListener('DOMContentLoaded', () => {
  MusicApp.init();
});
