/**
 * 小猪 · 零依赖 node:http 服务
 * ---------------------------------------------------------------
 * 上游：oiapi.net/api/RollPig（method=random 单只 / method=list 全量 199 只）
 *
 * 两个必守铁律（违反即真机翻车，来源见 jsos-apps/AGENTS.md）：
 *1. /api/pig/img/:id 必须做同源图片代理。上游图片端点实测**无
 *    Cross-Origin-Resource-Policy**，而 JSOS 强制 COEP: require-corp，
 *    前端 <img> 直连必被 ERR_BLOCKED_BY_RESPONSE 拦（petdex 4874 张缩略图全 404 同款坑）。
 *    且代理**必须按 content-type 判成功** —— 上游 404 回的是 text/plain（howtocook 踩过）。
 * 2. /api/ping 必须是极快的 GET 探活端点，不读凭据、不出网。平台小组件自愈靠它
 *    确认后台是否真死；复用查数据的路由会让每次心跳都是一次出网开销。
 *
 * 出站 CORS 契约（2026-10-09 实测）：API 端点带 ACAO: *，容器内 Node fetch 可直连，
 * 无需 PROXY_URL 兜底。图片端点不带 CORP 但走代理后不再受 COEP 约束。
 */
import http from 'node:http';
import { promises as fsp, existsSync, readFileSync } from 'node:fs';
import { join, extname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const STATE_FILE = join(DATA_DIR, 'state.json');
const CACHE_FILE = join(DATA_DIR, 'pigs.json');
const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 全量列表缓存 6 小时
const PUBLIC_DIR = join(__dirname, 'public');

const UPSTREAM = 'https://oiapi.net/api/RollPig';
const UPSTREAM_IMG = 'https://oiapi.net/api/RollPig/cache/';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const TIMEOUT_MS = 10000;

/** 全量列表的进程内缓存。⚠️ 只在真读到内容时赋值 —— 冷启动可能早于DATA_DIR 快照恢复，
 *  若`if (!cache) cache = tryParse() || []` 则空数组是 truthy，整个进程余生都拿不到数据。 */
let listCache = null; // { at: number, pigs: Array }
let listInFlight = null;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(body));
}

/* ------------------------------ 出站 ------------------------------ */

async function fetchUpstream(url, timeout = TIMEOUT_MS) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeout);
  try {
    return await fetch(url, {
      signal: ac.signal,
      headers: { Accept: 'application/json', 'User-Agent': UA },
    });
  } finally {
    clearTimeout(timer);
  }
}

/** 拉单只。校验 code===1 且 text 非空，失败时抛出可展示的中文原因。 */
async function fetchOnePig() {
  const res = await fetchUpstream(`${UPSTREAM}?method=random`);
  if (!res.ok) throw new Error(`上游返回 HTTP ${res.status}`);
  const data = await res.json();
  if (data?.code !== 1 || !data?.data?.id) throw new Error('上游返回了无法解析的数据');
  const p = data.data;
  return {
    id: String(p.id),
    name: String(p.name || '').trim(),
    description: String(p.description || '').trim(),
    analysis: String(p.analysis || '').trim(),
  };
}

/** 拉全量并落DATA_DIR 缓存。并发调用共用同一个 in-flight promise。 */
async function loadPigs() {
  if (listCache && Date.now() - listCache.at < CACHE_TTL_MS) return listCache.pigs;
  if (listInFlight) return listInFlight;

  listInFlight = (async () => {
    // 先试磁盘缓存（进程重启后不必再出网）
    try {
      const raw = JSON.parse(await fsp.readFile(CACHE_FILE, 'utf8'));
      if (Array.isArray(raw) && raw.length && Date.now() - (raw.__at || 0) < CACHE_TTL_MS) {
        listCache = { at: raw.__at, pigs: raw.pigs };
        return listCache.pigs;
      }
    } catch {
      /* 无缓存，继续出网 */
    }

    const res = await fetchUpstream(`${UPSTREAM}?method=list`, 20000);
    if (!res.ok) throw new Error(`上游返回 HTTP ${res.status}`);
    const data = await res.json();
    if (data?.code !== 1 || !Array.isArray(data?.data) || !data.data.length) {
      throw new Error('上游返回了无法解析的数据');
    }
    const pigs = data.data.map((p) => ({
      id: String(p.id),
      name: String(p.name || '').trim(),
      description: String(p.description || '').trim(),
      analysis: String(p.analysis || '').trim(),
    }));
    const at = Date.now();
    listCache = { at, pigs };
    // 缓存写入失败不影响本次响应
    fsp.mkdir(DATA_DIR, { recursive: true })
      .then(() => fsp.writeFile(CACHE_FILE, JSON.stringify({ __at: at, pigs })))
      .catch(() => {});
    return pigs;
  })();

  try {
    return await listInFlight;
  } finally {
    listInFlight = null;
  }
}

/* ------------------------------ 状态 ------------------------------ */
/** { collected: string[], today: { date, id } } —— 抽到即入collected，无需单独收藏。 */

async function readState() {
  try {
    return JSON.parse(await fsp.readFile(STATE_FILE, 'utf8'));
  } catch {
    return { collected: [], today: null };
  }
}

async function writeState(state) {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  const tmp = STATE_FILE + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(state));
  await fsp.rename(tmp, STATE_FILE);
}

function todayStr() {
  const d = new Date();
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 读改写串行化。主界面与小组件是两个独立 iframe，会并发打到同一份 state.json；
 * 不串行则「抽一只」写入的 collected 会被「今日猪」写入的 today 覆盖掉。
 */
let writeChain = Promise.resolve();
function withStateLock(fn) {
  const run = writeChain.then(fn, fn);
  writeChain = run.then(
    () => {},
    () => {}
  );
  return run;
}

/** 今日猪：当天固定。state 里没有或日期变了才重抽一只，并落盘。 */
async function resolveToday(state) {
  const date = todayStr();
  if (state?.today?.date === date && state.today.id) return state.today.id;
  const pig = await fetchOnePig();
  state.today = { date, id: pig.id };
  await writeState(state); // 必须落盘，否则同一天内每次请求都会重新出网抽一只
  return pig.id;
}

/* ------------------------------ 静态文件 ------------------------------ */

function serveStatic(res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const abs = resolve(join(PUBLIC_DIR, rel));
  if (!abs.startsWith(resolve(PUBLIC_DIR))) return sendJson(res, 403, { error: 'forbidden' });
  try {
    const buf = readFileSync(abs);
    res.writeHead(200, { 'Content-Type': MIME[extname(abs).toLowerCase()] || 'application/octet-stream' });
    res.end(buf);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Not Found');
  }
}

/* ------------------------------ 服务 ------------------------------ */

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const path = u.pathname;

  try {
    // 铁律 2：极快探活，不读凭据、不出网。禁用 HEAD（语义错，会掉到静态分支永远 404）
    if (path === '/api/ping') {
      return sendJson(res, 200, { ok: true, t: Date.now() });
    }

    // 抽一只（含「图鉴里点已收集的那只重看」）
    if (path === '/api/pig/random') {
      const pig = await fetchOnePig();
      const collected = await withStateLock(async () => {
        const state = await readState();
        if (!Array.isArray(state.collected)) state.collected = [];
        if (!state.collected.includes(pig.id)) {
          state.collected.push(pig.id);
          await writeState(state);
        }
        return state.collected.length;
      });
      return sendJson(res, 200, { ok: true, pig, collected });
    }

    // 全量列表 + 已收集（前端本地筛图鉴，服务端不做搜索）
    if (path === '/api/pig/list') {
      const [pigs, state] = await Promise.all([loadPigs(), readState()]);
      return sendJson(res, 200, {
        ok: true,
        total: pigs.length,
        pigs,
        collected: Array.isArray(state.collected) ? state.collected : [],
      });
    }

    // 今日猪（小组件与「今日运势」共用）
    if (path === '/api/pig/today') {
      const id = await withStateLock(async () => {
        const state = await readState();
        return resolveToday(state);
      });
      const pigs = await loadPigs();
      const pig = pigs.find((p) => p.id === id);
      return sendJson(res, 200, {
        ok: true,
        date: todayStr(),
        pig: pig || { id, name: '', description: '', analysis: '' },
      });
    }

    // 铁律 1：同源图片代理。id 原样透传（上游 id 命名不统一：连字符/下划线/纯字母混用，不可规范化）
    if (path.startsWith('/api/pig/img/')) {
      const id = decodeURIComponent(path.slice('/api/pig/img/'.length));
      if (!id || id.includes('/') || id.includes('..')) return sendJson(res, 400, { error: 'bad pig id' });
      let up;
      try {
        up = await fetchUpstream(encodeURI(UPSTREAM_IMG + id), 15000);
      } catch {
        return sendJson(res, 502, { error: 'pig image unreachable' });
      }
      const type = up.headers.get('content-type') || '';
      // 必须按 content-type 判成功：上游出错时回的是 text/plain 而非图片
      if (!up.ok || !/^image\//i.test(type)) {
        return sendJson(res, 502, { error: `bad upstream image (http ${up.status}, ${type || 'no content-type'})` });
      }
      const buf = Buffer.from(await up.arrayBuffer());
      res.writeHead(200, { 'Content-Type': type, 'Content-Length': buf.length, 'cache-control': 'public, max-age=604800' });
      return res.end(buf);
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405).end('Method Not Allowed');
      return;
    }
    serveStatic(res, path);
  } catch (err) {
    sendJson(res, 502, { error: err?.message || 'upstream failed' });
  }
});

server.listen(PORT, () => {
  console.log(`[random-pig] listening on http://localhost:${PORT}`);
});