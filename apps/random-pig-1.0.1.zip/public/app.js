/**
 * 小猪 · 主界面逻辑
 * ---------------------------------------------------------------
 * 两个视图：抽签（抽一只 + 今日这只）/ 图鉴（199 格收集进度）。
 * 图鉴里未收集的格子不显示也不可点 —— 集齐全靠运气，没有指定抽取的作弊路径。
 *
 * 图片一律走同源代理 /api/pig/img/:id：上游图片端点无 CORP，
 * JSOS 强制 COEP: require-corp，<img> 直连必被拦。
 */
(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  const els = {
    tabs: $('#tabs'),
    pigImg: $('#pigImg'),
    pigPlaceholder: $('#pigPlaceholder'),
    pigName: $('#pigName'),
    pigDesc: $('#pigDesc'),
    pigStory: $('#pigStory'),
    btnDraw: $('#btnDraw'),
    btnToday: $('#btnToday'),
    drawHint: $('#drawHint'),
    albumCount: $('#albumCount'),
    albumGrid: $('#albumGrid'),
    progressBar: $('#progressBar'),
    progressText: $('#progressText'),
    searchInput: $('#searchInput'),
    toast: $('#toast'),
  };

  let allPigs = [];      // 全量列表
  let collected = new Set();
  let loading = false;
  let toastTimer = null;

  /* ------------------------------ 工具 ------------------------------ */

  function showToast(msg, ms = 2600) {
    els.toast.textContent = msg;
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), ms);
  }

  /** 统一取JSON：先读 text 再 parse —— 掉线时预览SW 回的是 200 + HTML 占位页，
   * 直接 r.json() 抛的错会掩盖真实原因。 */
  async function getJSON(url) {
    const res = await fetch(url, { cache: 'no-store' });
    const text = await res.text();
    if (!res.ok) throw new Error(extractError(text) || `请求失败（HTTP ${res.status}）`);
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error(text.includes('.localservice@no-server')
        ? '后台进程已停止，请重新打开应用'
        : '服务返回了非 JSON 内容');
    }
    if (!data || data.ok !== true) throw new Error(data?.error || '服务返回失败');
    return data;
  }

  function extractError(text) {
    try {
      return JSON.parse(text).error || null;
    } catch {
      return null;
    }
  }

  const imgUrl = (id) => `/api/pig/img/${encodeURIComponent(id)}`;

  /** 图片加载失败 → 换占位符，绝不留破图 */
  function setPigImage(id, name) {
    els.pigImg.hidden = false;
    els.pigPlaceholder.hidden = true;
    els.pigImg.alt = name || '小猪';
    els.pigImg.onerror = () => {
      els.pigImg.hidden = true;
      els.pigPlaceholder.hidden = false;
      els.pigPlaceholder.textContent = (name || '猪').slice(0, 1);
    };
    els.pigImg.src = imgUrl(id);
  }

  /* ------------------------------ 抽签 ------------------------------ */

  function renderPig(pig) {
    els.pigName.textContent = pig.name || '小猪';
    els.pigDesc.textContent = pig.description ? `「${pig.description}」` : '';
    els.pigStory.textContent = pig.analysis || '';
    setPigImage(pig.id, pig.name);
  }

  async function draw() {
    if (loading) return;
    loading = true;
    els.btnDraw.disabled = true;
    els.btnDraw.textContent = '抽签中…';
    try {
      const data = await getJSON('/api/pig/random');
      renderPig(data.pig);
      const isNew = !collected.has(data.pig.id);
      collected.add(data.pig.id);
      renderAlbum();
      els.drawHint.textContent = isNew
        ? `新面孔！已收进图鉴（${collected.size}/${allPigs.length}）`
        : `这只已经在图鉴里了（${collected.size}/${allPigs.length}）`;
    } catch (err) {
      showToast(`抽签失败：${err.message}`);
      els.drawHint.textContent = '';
    } finally {
      loading = false;
      els.btnDraw.disabled = false;
      els.btnDraw.textContent = '再抽一只';
    }
  }

  async function showToday() {
    els.btnToday.disabled = true;
    els.btnToday.textContent = '取今日…';
    try {
      const data = await getJSON('/api/pig/today');
      renderPig(data.pig);
      if (data.pig.id) {
        collected.add(data.pig.id);
        renderAlbum();
      }
      els.drawHint.textContent = `今日小猪 · ${data.date} · 零点自动换`;
    } catch (err) {
      showToast(`取今日小猪失败：${err.message}`);
    } finally {
      els.btnToday.disabled = false;
      els.btnToday.textContent = '今日这只';
    }
  }

  /* ------------------------------ 图鉴 ------------------------------ */

  function renderAlbum() {
    const kw = els.searchInput.value.trim().toLowerCase();
    const total = allPigs.length;
    els.albumCount.textContent = `${collected.size}/${total}`;
    els.progressText.textContent = `已收集 ${collected.size} / ${total}`;
    els.progressBar.style.width = total ? `${(collected.size / total) * 100}%` : '0';

    const frag = document.createDocumentFragment();
    for (const pig of allPigs) {
      const got = collected.has(pig.id);
      if (kw && !got) continue; // 未收集的不参与搜索（也点不到）

      const cell = document.createElement('div');
      cell.className = got ? 'cell' : 'cell locked';

      if (got) {
        const img = document.createElement('img');
        img.loading = 'lazy';
        img.alt = pig.name;
        img.onerror = () => {
          // 取不到图就只留名字，绝不留破图
          img.remove();
          cell.classList.remove('has-img');
        };
        img.src = imgUrl(pig.id);
        cell.appendChild(img);
        const mark = document.createElement('span');
        mark.className = 'cell-mark';
        mark.textContent = '★';
        cell.appendChild(mark);
        cell.title = `${pig.name}｜${pig.description || ''}`;
        cell.addEventListener('click', () => {
          renderPig(pig);
          switchView('draw'); // 点已收集的猪 → 回抽签视图读完整故事
        });
      } else {
        cell.title = '还没抽到这只';
        // 未收集：只显示名字首字，不给任何点击入口
        cell.textContent = pig.name.slice(0, 1);
      }

      const label = document.createElement('div');
      label.className = 'cell-label';
      label.textContent = pig.name;
      cell.appendChild(label);
      frag.appendChild(cell);
    }
    els.albumGrid.replaceChildren(frag);
  }

  /* ------------------------------ 启动 ------------------------------ */

  function switchView(view) {
    $$('.tab', els.tabs).forEach((t) => t.classList.toggle('active', t.dataset.view === view));
    $$('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${view}`));
  }

  els.tabs.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab');
    if (tab) switchView(tab.dataset.view);
  });
  els.btnDraw.addEventListener('click', draw);
  els.btnToday.addEventListener('click', showToday);
  els.searchInput.addEventListener('input', renderAlbum);

  (async function init() {
    try {
      const data = await getJSON('/api/pig/list');
      allPigs = data.pigs || [];
      collected = new Set(data.collected || []);
      renderAlbum();
      draw(); // 首屏直接来一只，不让用户面对空卡
    } catch (err) {
      showToast(`加载失败：${err.message}`);
      els.pigStory.textContent = '点「再抽一只」重试。';
    }
  })();
})();