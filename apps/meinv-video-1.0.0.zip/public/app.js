const $ = (id) => document.getElementById(id);
const video = $('video');
const veil = $('veil');
const veilText = $('veilText');
const spinner = $('spinner');
const retryBtn = $('retryBtn');
const nextBtn = $('nextBtn');
const srcLink = $('srcLink');

let busy = false;

function showLoading(text) {
  veil.hidden = false;
  spinner.hidden = false;
  retryBtn.hidden = true;
  veilText.textContent = text;
}

function showError(text) {
  veil.hidden = false;
  spinner.hidden = true;
  retryBtn.hidden = false;
  veilText.textContent = text;
}

function hideVeil() {
  veil.hidden = true;
}

async function playNext() {
  if (busy) return;
  busy = true;
  nextBtn.disabled = true;
  nextBtn.textContent = '换一个…';
  showLoading('加载中…');
  try {
    const r = await fetch('/api/random');
    const data = await r.json().catch(() => ({}));
    if (!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);

    video.src = `/api/video?u=${encodeURIComponent(data.url)}`;
    video.load();
    srcLink.href = data.url;
    srcLink.hidden = false;

    // 换一个的点击是用户手势 → 带声自动播放通常放行；首载/被拒则静默停在首帧
    video.play().catch(() => {});
    // veil 由 canplay 事件收起
  } catch (err) {
    showError(`获取失败：${err?.message || '未知错误'}`);
  } finally {
    busy = false;
    nextBtn.disabled = false;
    nextBtn.textContent = '换一个';
  }
}

video.addEventListener('canplay', () => {
  if (video.src) hideVeil();
});

video.addEventListener('error', () => {
  if (video.src) showError('视频加载失败，请重试');
});

video.addEventListener('ended', () => playNext()); // 播完自动连播

nextBtn.addEventListener('click', playNext);
retryBtn.addEventListener('click', playNext);

playNext(); // 打开应用即加载第一个
