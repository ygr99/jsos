/* ============================================================
   壁纸 · 前端
   - 必应壁纸：今日大图 + 历史网格（滚动加载，hover 出勾，点勾设为壁纸）
   - 设置壁纸走 window.JSOS.setWallpaper（应用到当前工作区，同「设置」应用）
   - 「每天自动更新」由服务端定时器驱动（经 JSOS 守护进程代调 setWallpaper）
   ============================================================ */
(() => {
  'use strict';

  const COLLAPSE_KEY = 'wallpaper.sidebar-collapsed';
  const PAGE_SIZE = 12;

  const CATS = [
    { id: 'solid', name: '纯色', icon: '<circle cx="12" cy="12" r="8.5"/>' },
    { id: 'official', name: '官方壁纸', icon: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><circle cx="8.5" cy="10" r="1.8"/><path d="m4.2 17.2 5-4.4 3.6 3.2 3-2.6 4 3.6"/>' },
    { id: 'bing', name: '必应壁纸', icon: '<path d="M7.4 3.6v16.8"/><circle cx="13.2" cy="14.6" r="5.6"/>' },
    { id: 'dynamic', name: '动态壁纸', icon: '<circle cx="12" cy="12" r="3.4"/><path d="M12 3v2.6M12 18.4V21M3 12h2.6M18.4 12H21M5.6 5.6l1.9 1.9M16.5 16.5l1.9 1.9M18.4 5.6l-1.9 1.9M7.5 16.5l-1.9 1.9"/>' },
    { id: 'wallhaven', name: 'Wallhaven', icon: '<path d="M3.2 7.2 6.4 17 12 5.4 17.6 17l3.2-9.8"/>' },
    { id: 'deepin', name: 'Deepin', icon: '<path d="m12 3.4 8.6 4.8L12 13 3.4 8.2 12 3.4Z"/><path d="m3.4 13.4 8.6 4.8 8.6-4.8"/>' },
    { id: 'custom', name: '自定义壁纸', icon: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M12 8.6v6.8M8.6 12h6.8"/>' },
    { id: 'fav', name: '我的收藏', icon: '<path d="M12 20.2s-7.2-4.5-7.2-9.6A4.2 4.2 0 0 1 12 7.5a4.2 4.2 0 0 1 7.2 3.1c0 5.1-7.2 9.6-7.2 9.6Z"/>' },
  ];

  const $ = id => document.getElementById(id);
  // 个别无头环境没有 rAF，退化到 setTimeout
  const raf = typeof window.requestAnimationFrame === 'function'
    ? window.requestAnimationFrame.bind(window)
    : cb => setTimeout(cb, 0);
  const el = {
    shell: $('shell'),
    nav: $('cat-nav'),
    bingView: $('bing-view'),
    coming: $('coming'),
    comingEmoji: $('coming-emoji'),
    comingTitle: $('coming-title'),
    today: $('today'),
    todayCard: $('today-card'),
    todayImg: $('today-img'),
    todayTitle: $('today-title'),
    todayPick: $('today-pick'),
    autoChk: $('auto-chk'),
    autoHint: $('auto-hint'),
    dl4k: $('dl-4k'),
    grid: $('grid'),
    more: $('more'),
    toast: $('toast'),
  };

  let catId = 'bing';
  let state = { autoDaily: false, autoAppliedDate: null, lastSetDate: null, today: null };
  let todayDate = null;
  let nextFrom = null;
  let exhausted = false;
  let loading = false;
  let fillRounds = 0;
  let workspaceId = null;

  /* ------------------------------------------------------------ 小工具 */

  async function api(path, options) {
    const r = await fetch(path, options);
    if (!r.ok) {
      let msg = `HTTP ${r.status}`;
      try { const j = await r.json(); if (j && j.error) msg = j.error; } catch {}
      throw new Error(msg);
    }
    return r.json();
  }

  const postJSON = (path, body) => api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });

  let toastTimer = null;
  function toast(text) {
    el.toast.textContent = text;
    el.toast.hidden = false;
    raf(() => el.toast.classList.add('show'));    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      el.toast.classList.remove('show');
      setTimeout(() => { el.toast.hidden = true; }, 220);
    }, 2600);
  }

  const fmtCN = dash => {
    const [y, m, d] = String(dash).split('-');
    return `${y}年${Number(m)}月${Number(d)}日`;
  };

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = () => reject(new Error('图片读取失败'));
      fr.readAsDataURL(blob);
    });
  }

  async function resolveWorkspaceId() {
    if (workspaceId) return workspaceId;
    const jsos = window.JSOS;
    if (!jsos || !jsos.getCurrentWorkspace) return null;
    try {
      const ws = await jsos.getCurrentWorkspace();
      workspaceId = ws && ws.id ? ws.id : null;
    } catch { workspaceId = null; }
    return workspaceId;
  }

  /* ------------------------------------------------------------ 侧边栏 */

  function renderNav() {
    el.nav.innerHTML = CATS.map(c => `
      <button type="button" class="nav-item${c.id === catId ? ' active' : ''}" data-cat="${c.id}" title="${c.name}">
        <span class="nav-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"
          stroke-linecap="round" stroke-linejoin="round">${c.icon}</svg></span>
        <span class="nav-name">${c.name}</span>
      </button>`).join('');
    el.nav.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => selectCat(btn.dataset.cat));
    });
  }

  function selectCat(id) {
    if (catId === id) return;
    catId = id;
    renderNav();
    const cat = CATS.find(c => c.id === id);
    const impl = id === 'bing';
    el.bingView.hidden = !impl;
    el.coming.hidden = impl;
    if (!impl) {
      el.comingTitle.textContent = cat ? cat.name : '';
    }
  }

  function setCollapsed(collapsed) {
    el.shell.classList.toggle('collapsed', collapsed);
    $('ic-collapse').toggleAttribute('hidden', collapsed);
    $('ic-expand').toggleAttribute('hidden', !collapsed);
    $('collapse-btn').setAttribute('aria-label', collapsed ? '展开侧边栏' : '折叠侧边栏');
    try { localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0'); } catch {}
  }

  /* --------------------------------------------------------- 今日壁纸 */

  async function loadToday() {
    try {
      const meta = await api('/api/bing');
      todayDate = meta.date;
      el.todayCard.dataset.date = meta.date;
      el.todayImg.src = `/api/img?date=${meta.date}&size=640x480`;
      el.todayImg.addEventListener('load', () => el.todayImg.classList.add('loaded'), { once: true });
      if (el.todayImg.complete && el.todayImg.naturalWidth) el.todayImg.classList.add('loaded');
      el.todayTitle.textContent = meta.copyright ? `${meta.title}  (${meta.copyright})` : meta.title;
      el.dl4k.href = meta.uhdUrl;
      el.today.hidden = false;
    } catch (e) {
      el.today.hidden = true;
      toast('今日必应壁纸加载失败：' + e.message);
    }
  }

  function updateAutoHint() {
    const lines = [];
    if (state.autoDaily) lines.push('已开启自动更新 · 每天 0:10 后自动换上当天壁纸');
    if (state.autoAppliedDate && todayDate && state.autoAppliedDate === todayDate) {
      lines.push(`今天的壁纸已自动应用 · ${fmtCN(state.autoAppliedDate)}`);
    }
    el.autoHint.innerHTML = lines.length ? lines.map(t => `<div>${t}</div>`).join('') : '';
    el.autoHint.hidden = lines.length === 0;
  }

  /* --------------------------------------------------- 设为壁纸（核心） */

  function markActive(date) {
    document.querySelectorAll('.card.active').forEach(c => c.classList.remove('active'));
    if (!date) return;
    document.querySelectorAll('.card').forEach(c => {
      if (c.dataset.date === date) c.classList.add('active');
    });
  }

  async function applyWallpaper(date, cardEl) {
    const jsos = window.JSOS;
    if (!jsos || typeof jsos.setWallpaper !== 'function') {
      toast('当前环境不支持设置壁纸，请在 JSOS 里打开本应用');
      return;
    }
    if (cardEl) cardEl.classList.add('busy');
    try {
      const res = await fetch(`/api/img?date=${date}&size=1920x1080`);
      if (!res.ok) throw new Error(`图片下载失败 HTTP ${res.status}`);
      const blob = await res.blob();
      const dataUrl = await blobToDataUrl(blob);
      const wsId = await resolveWorkspaceId();
      await jsos.setWallpaper({
        type: 'image',
        data: dataUrl,
        mimeType: 'image/jpeg',
        overlay: null,
        overlayOpacity: 0,
        blur: 0,
        workspaceId: wsId || undefined,
      });
      try {
        const r = await postJSON('/api/state', { lastSetDate: date, lastSetWorkspaceId: wsId, lastSetAt: Date.now() });
        state = r.state;
      } catch {}
      markActive(date);
      if (jsos.toast) {
        jsos.toast({ title: '壁纸已设置', description: `${fmtCN(date)} 的必应壁纸`, type: 'success' });
      }
      toast(`已设为壁纸 · ${fmtCN(date)}`);
    } catch (e) {
      toast('设置壁纸失败：' + e.message);
    } finally {
      if (cardEl) cardEl.classList.remove('busy');
    }
  }

  /* ------------------------------------------------------- 历史壁纸网格 */

  function makeCard(day) {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.date = day.date;
    const img = document.createElement('img');
    img.alt = day.date;
    img.loading = 'lazy';
    img.decoding = 'async';
    img.addEventListener('load', () => img.classList.add('loaded'), { once: true });
    img.src = day.thumb;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pick';
    btn.title = `设为壁纸 · ${fmtCN(day.date)}`;
    btn.setAttribute('aria-label', `设为壁纸 ${day.date}`);
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 13 4.5 4.5L19 7"/></svg>';
    card.append(img, btn);
    card.dataset.thumb = day.thumb;
    return card;
  }

  async function loadMore() {
    if (loading || exhausted) return;
    loading = true;
    try {
      const qs = nextFrom ? `?from=${nextFrom}&n=${PAGE_SIZE}` : `?n=${PAGE_SIZE}`;
      const data = await api('/api/days' + qs);
      nextFrom = data.nextFrom;
      exhausted = !!data.exhausted;
      const frag = document.createDocumentFragment();
      for (const day of data.days) frag.appendChild(makeCard(day));
      el.grid.appendChild(frag);
      markActive(state.lastSetDate);
      el.more.textContent = exhausted ? '已经翻到必应图库最早的一张了' : '滚动加载更早日期的壁纸…';
    } catch (e) {
      el.more.textContent = '加载失败：' + e.message;
    } finally {
      loading = false;
    }
    // 一屏没铺满就再补一轮。必须先确认容器真的可测量：无头环境（jsdom）不做布局，
    // clientHeight 恒为 0，不加这个判断会一路递归把 2010 年以来的图全拉下来。
    // 另外用 fillRounds 封顶，避免极端尺寸下滚雪球。
    const vh = el.bingView.clientHeight;
    if (vh > 0 && el.bingView.scrollHeight <= vh + 60 && fillRounds < 4) {
      fillRounds++;
      await loadMore();
    } else if (vh > 0 && el.bingView.scrollHeight > vh + 60) {
      fillRounds = 0;
    }
  }

  /* ------------------------------------------------------------- 事件 */

  el.grid.addEventListener('click', e => {
    const btn = e.target.closest('.pick');
    if (!btn) return;
    const card = btn.closest('.card');
    if (!card || card.classList.contains('busy')) return;
    applyWallpaper(card.dataset.date, card);
  });

  el.todayPick.addEventListener('click', () => {
    if (!el.todayCard.dataset.date) return;
    applyWallpaper(el.todayCard.dataset.date, el.todayCard);
  });

  el.autoChk.addEventListener('change', async () => {
    const on = el.autoChk.checked;
    el.autoChk.disabled = true;
    try {
      const wsId = await resolveWorkspaceId();
      const r = await postJSON('/api/state', {
        autoDaily: on,
        autoWorkspaceId: on ? wsId : state.autoWorkspaceId,
        autoAppliedDate: on ? null : state.autoAppliedDate,
      });
      state = r.state;
      if (on) {
        const run = await postJSON('/api/auto/run');
        state = run.state;
        if (run.applied) {
          markActive(run.date);
          toast(`已开启 · 并已应用今天的壁纸（${fmtCN(run.date)}）`);
        } else if (run.error) {
          toast('已开启，但立刻应用失败：' + run.error);
        } else if (run.upToDate) {
          toast('已开启 · 今天的壁纸已经是必应今日图了');
        } else {
          toast('已开启每天自动更新壁纸');
        }
      } else {
        toast('已关闭每天自动更新（当前壁纸保持不变）');
      }
      updateAutoHint();
    } catch (e) {
      el.autoChk.checked = !on;
      toast('操作失败：' + e.message);
    } finally {
      el.autoChk.disabled = false;
    }
  });

  el.bingView.addEventListener('scroll', () => {
    if (exhausted) return;
    const { scrollTop, scrollHeight, clientHeight } = el.bingView;
    if (scrollHeight - scrollTop - clientHeight < 320) loadMore();
  });

  $('collapse-btn').addEventListener('click', () =>
    setCollapsed(!el.shell.classList.contains('collapsed'))
  );

  /* ------------------------------------------------------------- 启动 */

  async function init() {
    let saved = '0';
    try { saved = localStorage.getItem(COLLAPSE_KEY) || '0'; } catch {}
    setCollapsed(saved === '1');

    renderNav();
    el.coming.hidden = true;

    try {
      state = await api('/api/state');
      el.autoChk.checked = !!state.autoDaily;
      updateAutoHint();
    } catch {}

    await loadToday();
    await loadMore();
    markActive(state.lastSetDate);

    // 打开应用时兜一次自动更新（服务端定时器负责其余时间）
    if (state.autoDaily) {
      try {
        const run = await postJSON('/api/auto/run');
        state = run.state;
        if (run.applied) markActive(run.date);
        updateAutoHint();
      } catch {}
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
