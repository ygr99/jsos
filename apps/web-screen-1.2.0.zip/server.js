import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(join(__dirname, 'public')));

// 必应随机壁纸：服务端拉取后同源回传（应用 iframe 内直连外域会被环境策略拦截）
app.get('/api/bing-rand', async (req, res) => {
  try {
    const r = await fetch('https://bing.ee123.net/img/rand?size=1920x1080');
    if (!r.ok) return res.status(502).end();
    const buf = Buffer.from(await r.arrayBuffer());
    res.set('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.set('Cache-Control', 'no-store');
    res.send(buf);
  } catch {
    res.status(502).end();
  }
});

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`web-screen running on ${port}`));
