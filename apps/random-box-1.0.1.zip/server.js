/**
 * 随机盒子 —— 服务端
 * ---------------------------------------------------------------
 * express 托管静态页 + 抓取代理。
 * 抓取必须放服务端：浏览器直连目标站会被 CORS 拦死。
 *
 * 站点配置硬编码在 lib/sites.js，不支持运行时增删改——这是自用随机入口，
 * 不是配置工具。界面上唯一可改的是每个站点的启用开关（存在 data/state.json）。
 */
import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { SITES } from './lib/sites.js';
import { getSource, listKinds } from './lib/registry.js';
import {
  loadState, setEnabled, loadHistory, pushHistory, clearHistory,
  deleteHistoryItem, clearCache,
} from './lib/store.js';
import { CrawlError, fetchPageItems, setProxyConfig, getProxyConfig } from './lib/crawl.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(join(__dirname, 'public')));

const ok = (res, data) => res.json({ ok: true, ...data });
const fail = (res, msg, code = 400) => res.status(code).json({ ok: false, error: msg });

function handle(res, err, fallback = '操作失败') {
  if (err instanceof CrawlError) return fail(res, err.message);
  console.error('[random-box]', err);
  return fail(res, err?.message || fallback, 500);
}

/** 内置站点 + 运行时的开关状态合并后输出 */
async function sitesWithState() {
  const state = await loadState();
  return SITES.map((s) => ({
    ...s,
    // 状态文件里没记录过的站点，用 sites.js 里的默认值
    enabled: state[s.id]?.enabled ?? s.enabled !== false,
  }));
}

/* ------------------------------ 基础 ------------------------------ */

app.get('/api/health', (req, res) => {
  ok(res, { service: 'random-box', time: new Date().toISOString() });
});

/**
 * 前端启动时上报 JSOS 的 CORS 代理配置（getProxyConfig）。
 * WebContainer 内 Node 直连外站会被 CORS 拦掉，抓取层在直连失败时
 * 自动改走这个代理（GET {proxy}/{url} + x-cors-proxy-key）。
 * 本机直跑时前端拿不到 JSOS API，不会上报，直连即可。
 */
app.post('/api/relay', (req, res) => {
  const { url, key } = req.body || {};
  if (!url || !/^https?:\/\//.test(String(url))) return fail(res, '代理配置无效');
  setProxyConfig({ url, key });
  ok(res, { proxy: { url: String(url).replace(/\/+$/, ''), hasKey: !!key } });
});

/** 网络自检：直连与代理两条路径都测（WebContainer 环境排障用） */
app.post('/api/diag', async (req, res) => {
  const target = String(req.body?.url || 'https://www.chinawriter.com.cn/404057/419383/index1.html');
  const started = Date.now();
  try {
    const r = await fetchPageItems({ mode: 'html', listUrl: target, itemSelector: 'a', startPage: 1 }, 1);
    ok(res, {
      url: target,
      reachable: r.meta?.ok ?? false,
      status: r.meta?.status ?? 0,
      bytes: r.meta?.bytes ?? 0,
      charset: r.meta?.charset || '',
      viaProxy: !!r.meta?.viaProxy,
      proxyConfigured: !!getProxyConfig(),
      ms: Date.now() - started,
      reason: r.meta?.reason || '',
    });
  } catch (err) {
    ok(res, { url: target, reachable: false, ms: Date.now() - started, reason: err?.message || '未知错误' });
  }
});

/* ------------------------------ 站点 ------------------------------ */

app.get('/api/sites', async (req, res) => {
  try { ok(res, { sites: await sitesWithState(), kinds: listKinds() }); }
  catch (err) { handle(res, err, '读取站点失败'); }
});

app.post('/api/sites/:id/toggle', async (req, res) => {
  try {
    const site = SITES.find((s) => s.id === req.params.id);
    if (!site) return fail(res, '站点不存在', 404);
    const current = (await sitesWithState()).find((s) => s.id === req.params.id);
    await setEnabled(site.id, !current.enabled);
    ok(res, { sites: await sitesWithState() });
  } catch (err) { handle(res, err, '切换状态失败'); }
});

/* ------------------------------ 随机翻阅 ------------------------------ */

/**
 * 抽一条。
 * body: { siteId?, refreshMax? }
 *   不传 siteId → 从已启用站点里随机挑一个
 *   refreshMax  → 忽略页码缓存重新探测
 */
app.post('/api/pick', async (req, res) => {
  const started = Date.now();
  try {
    const sites = await sitesWithState();
    const enabled = sites.filter((s) => s.enabled);
    if (!enabled.length) return fail(res, '所有站点都关着，先打开一个');

    const site = req.body?.siteId
      ? sites.find((s) => s.id === req.body.siteId)
      : enabled[Math.floor(Math.random() * enabled.length)];
    if (!site) return fail(res, '站点不存在', 404);
    if (!site.listUrl) return fail(res, `站点「${site.name}」没有配置列表页 URL`);

    const logs = [];
    const source = getSource(site);
    const result = await source.pick(site, {
      log: (e) => logs.push(e),
      refreshMax: !!req.body?.refreshMax,
    });

    const item = {
      siteId: site.id,
      siteName: site.name,
      kind: source.label,
      title: result.title,
      url: result.url,
      detail: result.detail || {},
      fromCache: !!result.fromCache,
      viaProxy: !!result.viaProxy,
      logs,
      ms: Date.now() - started,
    };
    await pushHistory({
      siteId: site.id, siteName: site.name, title: result.title, url: result.url, ...(result.detail || {}),
    });
    ok(res, { item });
  } catch (err) { handle(res, err, '翻阅失败'); }
});

/* ------------------------------ 历史 ------------------------------ */

app.get('/api/history', async (req, res) => {
  try { ok(res, { history: await loadHistory() }); }
  catch (err) { handle(res, err, '读取历史失败'); }
});

app.delete('/api/history', async (req, res) => {
  try { ok(res, { history: await clearHistory() }); }
  catch (err) { handle(res, err, '清空历史失败'); }
});

app.delete('/api/history/:id', async (req, res) => {
  try { ok(res, { history: await deleteHistoryItem(req.params.id) }); }
  catch (err) { handle(res, err, '删除失败'); }
});

/* ------------------------------ 缓存 ------------------------------ */

app.post('/api/cache/clear', async (req, res) => {
  try { await clearCache(); ok(res, {}); }
  catch (err) { handle(res, err, '清理缓存失败'); }
});

/* ------------------------------ 静态回退 ------------------------------ */

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => console.log(`random-box running on ${port}`));
