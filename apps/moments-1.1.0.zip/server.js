// 朋友圈 — express 托管 + 服务端存储（§7.9）
// 帖子/资料经 /api/state 原子写 DATA_DIR/state.json；
// 上传的图片·音频·视频经 /api/media 存 DATA_DIR/media/<key>，由 /media/<key> 同源直出。
// 容器内 DATA_DIR = workspace/data/moments：资源管理器可见，卸载勾选「同时删除应用数据」整目录清除。
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

const DATA_DIR = process.env.DATA_DIR || join(__dirname, 'data');
const MEDIA_DIR = join(DATA_DIR, 'media');
const STATE_FILE = join(DATA_DIR, 'state.json');
fs.mkdirSync(MEDIA_DIR, { recursive: true });

const KEY_RE = /^[A-Za-z0-9_-]+$/; // 媒体文件名白名单，防路径穿越

// 媒体文件不带扩展名，express.static 只能给 application/octet-stream：
// <img> 靠浏览器嗅探还能显示，但 <video>/<audio> 依赖 Content-Type，容易直接不播。
// 所以在 setHeaders 里按魔数补一个正确的类型（send 只在未设置时才自己猜，这里设了就以这里为准）。
const SNIFF_PREFIX = [
  [[0xff, 0xd8, 0xff], 'image/jpeg'],
  [[0x89, 0x50, 0x4e, 0x47], 'image/png'],
  [[0x47, 0x49, 0x46, 0x38], 'image/gif'],
  [[0x42, 0x4d], 'image/bmp'],
  [[0x49, 0x44, 0x33], 'audio/mpeg'],
  [[0xff, 0xfb], 'audio/mpeg'],
  [[0x4f, 0x67, 0x67, 0x53], 'audio/ogg'],
  [[0x1a, 0x45, 0xdf, 0xa3], 'video/webm'],
];
const FTYP = {
  isom: 'video/mp4', iso2: 'video/mp4', iso4: 'video/mp4', mp41: 'video/mp4', mp42: 'video/mp4',
  avc1: 'video/mp4', dash: 'video/mp4', M4A: 'audio/mp4', M4V: 'video/mp4',
  qt: 'video/quicktime', heic: 'image/heic', heix: 'image/heic', avif: 'image/avif',
};

function sniffMime(file) {
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(16);
    fs.readSync(fd, buf, 0, 16, 0);
    for (const [sig, mime] of SNIFF_PREFIX) if (sig.every((v, i) => buf[i] === v)) return mime;
    if (buf.slice(4, 8).toString('latin1') === 'ftyp') return FTYP[buf.slice(8, 12).toString('latin1')] || 'video/mp4';
    if (buf.slice(0, 4).toString('latin1') === 'RIFF') {
      const fourcc = buf.slice(8, 12).toString('latin1');
      if (fourcc === 'WEBP') return 'image/webp';
      if (fourcc === 'WAVE') return 'audio/wav';
      if (fourcc === 'AVI ') return 'video/x-msvideo';
    }
  } catch {} finally { if (fd !== undefined) { try { fs.closeSync(fd); } catch {} } }
  return null;
}

// 应用文档显式声明 COEP credentialless，打断从 WebContainer 运行时 iframe 继承来的
// require-corp——否则外链视频 frame（player.bilibili.com 等）会被要求自带 COEP 头而遭拦截
app.use((req, res, next) => {
  res.set('Cross-Origin-Embedder-Policy', 'credentialless');
  next();
});

app.use(express.json({ limit: '10mb' }));

// ---- 帖子/资料状态：原子写 ----
app.get('/api/state', (req, res) => {
  try {
    if (!fs.existsSync(STATE_FILE)) return res.json(null);
    res.setHeader('Cache-Control', 'no-store');
    res.json(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    res.json(null);
  }
});

app.post('/api/state', (req, res) => {
  if (!req.body || !Array.isArray(req.body.posts)) return res.status(400).json({ error: 'invalid state' });
  try {
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(req.body));
    fs.renameSync(tmp, STATE_FILE);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ---- 媒体（图片/音频/视频）：body 为原始字节，key 走 query ----
// ⚠️ type 必须写成「永远匹配」的函数：没带 Content-Type 的请求（Blob 无 type、Node 端 fetch 传 Buffer 等）
// 用 '*/*' 匹配不上 → 中间件跳过 → req.body 为空 → 400，媒体会被静默丢掉
app.post('/api/media', express.raw({ type: () => true, limit: '200mb' }), (req, res) => {
  const key = String(req.query.key || '');
  if (!KEY_RE.test(key)) return res.status(400).json({ error: 'invalid key' });
  if (!req.body || !req.body.length) return res.status(400).json({ error: 'empty body' });
  try {
    const tmp = join(MEDIA_DIR, key + '.tmp');
    fs.writeFileSync(tmp, req.body);
    fs.renameSync(tmp, join(MEDIA_DIR, key));
    res.json({ ok: true, url: '/media/' + key });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/media/:key', (req, res) => {
  const key = String(req.params.key || '');
  if (!KEY_RE.test(key)) return res.status(400).json({ error: 'invalid key' });
  try { fs.rmSync(join(MEDIA_DIR, key), { force: true }); } catch {}
  res.json({ ok: true });
});

app.use(express.static(join(__dirname, 'public'), {
  setHeaders(res) {
    // json 不缓存避免读到旧种子
    res.set('Cache-Control', 'no-cache');
  }
}));
app.use('/media', express.static(MEDIA_DIR, {
  setHeaders(res, file) {
    res.set('Cache-Control', 'no-cache');
    res.setHeader('Content-Type', sniffMime(file) || 'application/octet-stream');
  }
}));
// 缺附件时明确 404 —— 否则会落到下面的 SPA 兜底，把 index.html 当图片返回
app.use('/media', (req, res) => res.status(404).json({ error: 'media not found' }));

app.get('*', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

const server = app.listen(port, () => console.log(`moments running on ${server.address().port}`));
