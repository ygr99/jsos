/**
 * 看电视 —— 前端逻辑
 * 移植自 99-起始页 WatchTV 组件：分类侧边栏 + 频道网格 + HLS 播放。
 * 播放地址一律经同源 /api/hls 代理（COEP/CORS/混合内容，见 server.js 头注释），
 * 播放失败自动切换同频道下一个备用源。
 */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const els = {
    sidebar: $('sidebar'), collapseBtn: $('collapse-btn'),
    searchInput: $('search-input'), searchClear: $('search-clear'), catNav: $('cat-nav'),
    video: $('video'), nowName: $('now-name'), nowSource: $('now-source'), nowStatus: $('now-status'),
    playerTip: $('player-tip'),
    grid: $('channel-grid'), gridTitle: $('grid-title'), gridCount: $('grid-count'),
    emptyState: $('empty-state'), emptyTitle: $('empty-title'), toast: $('toast'),
  };

  /* ------------------------------ 状态 ------------------------------ */

  let channelData = {};      // 分类 → [{name, url}]（去重展示）
  let backups = {};          // 频道名 → [url...]（同名聚合备用源）
  let categories = [];       // ['央视频道', ...]
  let activeCat = null;
  let currentChannel = null; // {name, cat}
  let sourceIndex = 0;
  let playToken = 0;         // 换台令牌：过期回调直接忽略
  let hls = null;

  const CAT_ICONS = {
    央视频道: '<svg class="cat-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="15" rx="2"/><polyline points="17 2 12 7 7 2"/></svg>',
    卫视频道: '<svg class="cat-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.9 16.1C1 12.2 1 5.8 4.9 1.9"/><path d="M7.8 4.7a6.14 6.14 0 0 0-.8 7.5"/><circle cx="12" cy="9" r="2"/><path d="M16.2 4.8c2 2 2.26 5.1.8 7.47"/><path d="M19.1 1.9a9.96 9.96 0 0 1 0 14.1"/><path d="M9.5 18h5"/><path d="m12 13.5 0 4.5"/></svg>',
    地方频道: '<svg class="cat-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
  };

  /* ------------------------------ 数据解析 ------------------------------ */

  async function loadChannels() {
    const res = await fetch('data/channels.txt');
    if (!res.ok) throw new Error('频道列表加载失败 ' + res.status);
    parseM3U(await res.text());
    categories = Object.keys(channelData);
    activeCat = categories[0] || null;
  }

  /** 解析 #genre# 格式：分类,#genre# / 频道名,URL（同名聚合备用源） */
  function parseM3U(content) {
    channelData = {};
    backups = {};
    let cat = '';
    for (const raw of content.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      if (line.includes('#genre#')) {
        cat = line.split(',')[0].trim();
        if (cat && !channelData[cat]) channelData[cat] = [];
      } else if (cat && line.includes(',')) {
        const i = line.indexOf(',');
        const name = line.slice(0, i).trim();
        const url = line.slice(i + 1).trim();
        if (!name || !/^https?:/i.test(url)) continue;
        if (!channelData[cat].some((c) => c.name === name)) channelData[cat].push({ name, url });
        (backups[name] = backups[name] || []).push(url);
      }
    }
  }

  /* ------------------------------ 搜索过滤（§7.8） ------------------------------ */

  const matchChannel = (ch, catName, q) => {
    if (!q) return true;
    const hay = (ch.name + '\n' + catName).toLowerCase();
    return hay.includes(q);
  };

  /** 返回过滤结果：[{cat, channels, count}]（0 命中的分类不出现） */
  function filtered() {
    const q = els.searchInput.value.trim().toLowerCase();
    const out = [];
    for (const cat of categories) {
      const hits = (channelData[cat] || []).filter((ch) => matchChannel(ch, cat, q));
      if (hits.length) out.push({ cat, channels: hits, count: hits.length });
    }
    return out;
  }

  /* ------------------------------ 渲染 ------------------------------ */

  function renderSidebar() {
    const q = els.searchInput.value.trim().toLowerCase();
    const groups = filtered();
    els.catNav.innerHTML = '';
    for (const g of groups) {
      const btn = document.createElement('button');
      btn.className = 'cat-item' + (g.cat === activeCat ? ' active' : '');
      btn.title = g.cat;
      btn.innerHTML = (CAT_ICONS[g.cat] || CAT_ICONS['地方频道'])
        + `<span class="cat-label">${esc(g.cat)}</span>`
        + `<span class="cat-count">${g.count}</span>`;
      btn.addEventListener('click', () => {
        activeCat = g.cat;
        els.searchInput.value = '';
        syncClearBtn();
        renderSidebar();
        renderGrid();
      });
      els.catNav.appendChild(btn);
    }
  }

  function renderGrid() {
    const q = els.searchInput.value.trim().toLowerCase();
    const groups = filtered();
    // 有搜索词时展示全部命中（跨分类）；否则展示当前分类
    const showAll = Boolean(q);
    const list = showAll
      ? groups.flatMap((g) => g.channels.map((ch) => ({ ...ch, cat: g.cat })))
      : (channelData[activeCat] || []).map((ch) => ({ ...ch, cat: activeCat }));

    els.gridTitle.textContent = showAll ? `搜索“${els.searchInput.value.trim()}”` : (activeCat || '频道');
    els.gridCount.textContent = list.length ? `${list.length} 个频道` : '';

    els.grid.innerHTML = '';
    const frag = document.createDocumentFragment();
    for (const ch of list) {
      const item = document.createElement('button');
      item.className = 'channel-item'
        + (currentChannel && currentChannel.name === ch.name && currentChannel.cat === ch.cat ? ' active' : '');
      item.textContent = ch.name;
      const n = (backups[ch.name] || []).length;
      if (n > 1) item.title = `共 ${n} 个播放源`;
      item.addEventListener('click', () => playChannel(ch));
      frag.appendChild(item);
    }
    els.grid.appendChild(frag);

    // 空态区分：搜索无结果 vs 分类无数据
    const noResult = showAll && !list.length;
    const noData = !showAll && !list.length;
    els.emptyState.hidden = !(noResult || noData);
    els.emptyTitle.textContent = noResult ? '没有找到频道' : '该分类暂无频道';
  }

  /* ------------------------------ 播放 ------------------------------ */

  /** 原始 URL → 同源 HLS 代理地址（播放列表重写/分段转发都由服务端续接） */
  const proxied = (url) => '/api/hls?u=' + encodeURIComponent(url);

  function destroyPlayer() {
    playToken++;
    if (hls) {
      try { hls.destroy(); } catch { /* ignore */ }
      hls = null;
    }
    els.video.removeAttribute('src');
    els.video.load();
  }

  function playChannel(ch, srcIdx = 0) {
    const sources = backups[ch.name] && backups[ch.name].length ? backups[ch.name] : [ch.url];
    if (srcIdx >= sources.length) {
      toast(`「${ch.name}」所有 ${sources.length} 个源均无法播放，试试其他频道`, 'error');
      setStatus('全部源播放失败', true);
      return;
    }

    destroyPlayer();
    currentChannel = { name: ch.name, cat: ch.cat };
    sourceIndex = srcIdx;
    const token = playToken;
    const url = sources[srcIdx];

    // 高亮 + 头部信息
    document.querySelectorAll('.channel-item.active').forEach((el) => el.classList.remove('active'));
    const items = [...els.grid.children];
    const idx = (channelData[ch.cat] || []).findIndex((c) => c.name === ch.name);
    if (!els.searchInput.value.trim() && idx >= 0 && items[idx]) items[idx].classList.add('active');
    els.nowName.textContent = ch.name;
    els.nowSource.hidden = sources.length <= 1;
    els.nowSource.textContent = sources.length > 1 ? `源 ${srcIdx + 1}/${sources.length}` : '';
    setStatus('连接中…');

    const urlObj = new URL(url);
    const failToNext = (reason) => {
      if (token !== playToken) return;
      toast(`「${ch.name}」源 ${srcIdx + 1} 播放失败（${reason}），切换下一个源`, 'error');
      playChannel(ch, srcIdx + 1);
    };

    if (window.Hls && window.Hls.isSupported()) {
      hls = new Hls({
        liveDurationInfinity: true,
        manifestLoadingTimeOut: 10000,
        manifestLoadingMaxRetry: 2,
        levelLoadingTimeOut: 10000,
        levelLoadingMaxRetry: 3,
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 4,
      });
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (token !== playToken) return;
        if (!data.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && data.response && data.response.code >= 400) {
          // 上游源彻底不可用（404/403），换源比重试更有意义
          failToNext('HTTP ' + data.response.code);
        } else if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          hls.startLoad();
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          try { hls.recoverMediaError(); } catch { failToNext('媒体错误'); }
        } else {
          failToNext('不可恢复错误');
        }
      });
      hls.loadSource(proxied(url));
      hls.attachMedia(els.video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (token !== playToken) return;
        setStatus(`已连接 · ${urlObj.hostname}`);
        els.video.play().catch(() => setStatus('已就绪，点击播放'));
      });
    } else {
      // Safari 原生 HLS 兜底
      els.video.src = proxied(url);
      els.video.play().catch(() => {});
      setStatus(`已连接 · ${urlObj.hostname}`);
    }
  }

  /* ------------------------------ 杂项 UI ------------------------------ */

  function setStatus(text, isError = false) {
    els.nowStatus.textContent = text;
    els.nowStatus.classList.toggle('error', isError);
  }

  let toastTimer = null;
  function toast(msg, type = '') {
    els.toast.textContent = msg;
    els.toast.className = 'toast' + (type ? ' ' + type : '');
    els.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { els.toast.hidden = true; }, 3000);
  }

  const esc = (s) => s.replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function syncClearBtn() {
    els.searchClear.hidden = !els.searchInput.value;
  }

  /* ------------------------------ 折叠（§7.6） ------------------------------ */

  const COLLAPSE_KEY = 'watch-tv.sidebar-collapsed';

  function setCollapsed(v) {
    els.sidebar.classList.toggle('collapsed', v);
    els.collapseBtn.setAttribute('aria-label', v ? '展开侧边栏' : '折叠侧边栏');
    els.collapseBtn.title = v ? '展开侧边栏' : '折叠侧边栏';
    localStorage.setItem(COLLAPSE_KEY, v ? '1' : '0');
  }

  function initCollapse() {
    setCollapsed(localStorage.getItem(COLLAPSE_KEY) === '1');
    els.collapseBtn.addEventListener('click', () =>
      setCollapsed(!els.sidebar.classList.contains('collapsed')));
  }

  /* ------------------------------ 启动 ------------------------------ */

  async function init() {
    initCollapse();

    els.searchInput.addEventListener('input', () => {
      syncClearBtn();
      renderSidebar();
      renderGrid();
    });
    els.searchClear.addEventListener('click', () => {
      els.searchInput.value = '';
      syncClearBtn();
      renderSidebar();
      renderGrid();
      els.searchInput.focus();
    });

    try {
      await loadChannels();
      renderSidebar();
      renderGrid();
    } catch (e) {
      els.gridTitle.textContent = '加载失败';
      els.emptyState.hidden = false;
      els.emptyTitle.textContent = String(e.message || e);
      els.emptyState.querySelector('.empty-sub').textContent = '请检查网络后重开应用';
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
