#!/bin/jsh
# Pi Agent 启动脚本：进入数据目录，经 npx 启动 pi（WebContainer 全局目录只读，不能用 npm -g）
# 供应商与模型在 pi 内部配置（/model），API key 按 pi 提示配置
cd $DATA_DIR
npx -y @earendil-works/pi-coding-agent
